;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {},
    destroy_fns : [],
    logPageId : 'carownerYHView',
    data : null,
    cityList : null,
    params : {},
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    quickInit : function() {
        var self = this;
        self.util.delegate( $('#js_page') );
        $('#js_page').html( self.mod.title_bar() );
        self.register(function(){
            $('#js_page').html('');
            self.cityList = null;
        });
        self.send({action: 'getExtraUrl'}, function( ext ){
            ext.token && (self.params.token = ext.token);
            self.params.diu = ext.diu;
            self.params.div = ext.div;
            self.params.tid = ext.tid;
            self.rander();
        });
        self.log('pv');
    },
    rander : function(){
        var self = this;
        self.data = JSON.parse( self.util.storage( 'viewcache' )||null ) || self.data;
        self.util.storage( 'viewcache' , null );
        self.cityList = JSON.parse( self.util.storage( 'cityList' )||null ) || self.cityList;
        //self.util.storage( 'cityList' , null );
        if( self.cityList ){
            return $('#js_page').html( self.mod.title_bar() + self.mod.content(self.data,self.cityList) );
        }
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1}
            ];
        self.params.token && params.push({token:self.params.token});
        self.api.aosrequest({
            params : params,
            urlPrefix : 'yaohaocityList',
            method : 'post',
            progress : 1,
            showNetErr : 1
        },function( dt ){
            if( dt.code == 1 && dt.data && dt.data.list && dt.data.list.length ) {
                self.cityList = dt.data.list;
                self.util.storage( 'cityList' , JSON.stringify( self.cityList ));
            }
            $('#js_page').html( self.mod.title_bar() + self.mod.content(self.data,self.cityList) );
        });
    },
    page_show : function(){
        var self = this;
        $( window ).bind( 'pageshow', function(){
            if( self.util.storage( 'refresh' ) == 1 ){
                self.rander();
            } else if( self.util.storage( 'refresh' ) == 2 ){
                self.destroy();
                self.api.webviewGoBack();
            }
            $( window ).unbind( 'pageshow' );
        } );
    },
    js_goback : function() {
        this.destroy();
        this.api.webviewGoBack();
        this.log('viewGoback');
    },
    js_edit : function() {
        this.page_show();
        this.util.storage( 'viewcache', JSON.stringify( this.data ) );
        this.log( 'editBtn', {id:this.data.id} );
        this.util.locationRedirect( 'yhedit.html' );
    },
    js_select : function( obj ) {
        this.log( 'selectYaoHao' );
        this.api.getAppPara('', '', obj.attr( 'data-url' ) ,'','','查询摇号编号');
    },
    js_goselect : function( obj ) {
        this.log( 'selectYaoHaoTips' );
        this.api.getAppPara('', '', obj.attr( 'data-url' ) ,'','','查询摇号编号');
        $( '#js_netdialog' ).remove();
    },
    js_showdialog : function( obj ) {
        this.log( 'showNetDialog' );
        $( '#js_page' ).append( this.mod.netdialog( obj.attr( 'data-url' ) ) );
    },
    js_closenet : function() {
        this.log( 'closeNetDialog' );
        $( '#js_netdialog' ).remove();
    }
});

})(POI,$);