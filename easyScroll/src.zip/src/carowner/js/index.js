/*
    车主服务首页
*/
;(function(POI,$){

'use strict';

$.extend(POI,{
    mod : {},
    page_params : {},//记录当前页  相关参数
    cache_dt : {},//缓存请求数据
    destroy_fns : [],
    logPageId : 'carowner',
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
        self.cache_dt={};
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    quickInit : function() {
        var self = this;
        self.api.getMapLocation(function( arg ){
            self.send({action: 'getExtraUrl'}, function(ext){
                self.init_page(arg, ext);
            });
        });
        self.util.delegate( $('#js_page') );
        window.addEventListener("carowner", function(e) {
            var _id = '';
            var data = e.data;
            if("string" === typeof(data)) {
                data = JSON.stringify(data);
            }
            switch(data.reson) {
                case 'offence':
                    _id = 'js_show_settingLogo1';
                    break;
                case 'carlicense':
                    _id = 'js_show_settingLogo2';
                    break;
                case 'ownerlicense':
                    _id = 'js_show_settingLogo3';
                    break;
                default:
                    break;
            }
            if(_id) {
                if(!data.status || "0" == data.status) {
                    $("#" + _id).removeClass("selected");
                } else {
                    $("#" + _id).addClass("selected");
                }
            }
        }, false);
        self.log('indexPv');
    },
    init_page : function( arg, ext) {
        var self = this;
        self.page_params.adcode = arg.adcode || 110000;
        self.page_params.cityName = arg.cityName || '北京市';
        self.page_params.lon = arg.lon;
        self.page_params.lat = arg.lat;
        if( ext ){//设备信息后面都不会变，所以只需要首次获取一次
            ext.token && (self.page_params.token = ext.token);
            self.page_params.diu = ext.diu;
            self.page_params.div = ext.div;
            self.page_params.tid = ext.tid;
        }
        self.login( function( res ) {
            if( res.userid ){//登陆了
                self.page_params.userid = res.userid;
            }
            self.rander_nodata();
            self.get_headData(function( dt ){
                self.rander( dt );
            });
        }, 1);
    },
    rander_nodata : function(){
        var self = this, str = self.util.get_arr();
        str.p( self.mod.index_titlebar( self.page_params ) )
        .p( self.mod.index_head( {} ) )
        .p( self.mod.index_nav())
        .p( '<div id="js_banner_dom" class="tmpDom"></div>' )
        .p( '<div id="js_cat_dom" class="tmpDom"></div>' );
        $('#js_page').html( str.str );
    },
    rander : function( dt ) {
        var self = this, str = self.util.get_arr();
        self.destroy();
        str.p( self.mod.index_titlebar( self.page_params ) )
        .p( self.mod.index_head( dt ) )
        .p( self.mod.index_nav())
        .p( '<div id="js_banner_dom" class="tmpDom"></div>' )
        .p( '<div id="js_cat_dom" class="tmpDom"></div>' );
        $('#js_page').html( str.str );
        self.rander_banner();
        self.rander_cat();
        self.rander_weather( dt );
    },
    headData_key : '',//因为头部信息的key一直不会变，所以这里记录一下，便于需要清除缓存的时候使用
    get_headData : function( fn ) {//获取头部数据
        var self = this, cache_dt = self.cache_dt,
            key,
            params = [
                {diu:self.page_params.diu, sign:1},
                {div:self.page_params.div, sign:1},
                {uid:self.page_params.userid}
            ];
        self.page_params.token && params.push({tokenId : self.page_params.token});
        key = JSON.stringify( params );
        if( cache_dt[ key ] && self.page_params.userid ){
            fn( cache_dt[ key ] );
        }else{
            self.page_params.userid ? self.api.aosrequest({
                params:params,
                progress : 1,
                showNetErr : 1,
                urlPrefix:'getMemorandum',
                method:'get'
            }, function( dt ){
                fn( dt );
                dt.status == 0 && (cache_dt[key] = dt, self.headData_key = key);
            }) :  fn({});
        }
    },
    /*
        onlyGetId:0 未登录进入登陆面板,1 未登录情况下返回userid为空字符串
    */
    login : function(fn, onlyGetId) {//获取用户登陆信息
        this.send({
            action : 'getAmapUserId',
            onlyGetId : onlyGetId
        }, fn);
    },
    js_goback : function() {//返回
        this.destroy();
        this.api.webviewGoBack();
        this.log('indexGoback');
    },
    rander_banner : function() {
        var self = this, cache_dt = self.cache_dt, key,
            params=[
                {x:self.page_params.lon, sign:1},
                {y:self.page_params.lat, sign:1},
                {page_id:23}
            ];
        key = JSON.stringify( params );
        if( cache_dt[key] ){
            cb( cache_dt[key] );
        }else{
            self.api.aosrequest({
                params : params,
                urlPrefix : 'bannerUrl',
                method : 'get'
            }, cb);
        }
        function cb( dt ) {
            if( dt.code == 1 ) {
                $( '#js_banner_dom' ).replaceWith( self.mod.index_banner(dt) );
                cache_dt[key] = dt;
            }
        }
    },
    init_banner : function( num ){//banner轮播
        var box = $("#js_banner_imglist"), slide;
        num > 1 && (slide =  new PicSlide(box[0], {
            startIndex : 0,
            isLoop : true,
            isAuto : true,
            afterFun : function(i){
                box.find('i.selected').removeClass( 'selected' );
                box.find('i').eq(i).addClass( 'selected' );
            }
        }));
        box.find( 'li' ).each( function() {
            var o = $( this ), src = o.attr('url');
            POI.util.loadImg( src, function(){
                o.removeClass( 'img-loading' ).html( '<img src="'+src+'" />' );
            }, function(){
                o.removeClass( 'img-loading' ).addClass( 'img-err' );
            });
        } );
        this.register(function(){
            slide && slide.destroy();
            slide=null;
        });
    },
    init_tipslist : function( num ) {//tips轮播
        var list = $( '#js_tipslist' ),
            height = 36, i = 0, timer;
        list.append( list.find('li').eq(0).clone() );
        function run() {
            timer = setTimeout( function() {
                i+=1;
                list[0].style.transitionDuration = '600ms';
                list[0].style.webkitTransform = 'translateY(-'+(i*height)+'px)';
                if( i == num ) {
                    i = 0;
                    setTimeout(function(){
                        list[0].style.transitionDuration = '0ms';
                        list[0].style.webkitTransform = 'translateY(0px)';
                    },600);
                }
                run();
            },3000+600 );
        }
        run();
        this.register(function(){
            clearTimeout( timer );
        });
    },
    /*
        冬季推荐
        上门保养模块
    */
    rander_cat : function() {
        var self = this, cache_dt = self.cache_dt,
            params = [
                {tid:self.page_params.tid, sign:1},
                {x:self.page_params.lon},
                {y:self.page_params.lat}
            ],
            key = JSON.stringify( params );
        if( cache_dt[key] ){
            cb( cache_dt[key] );
        } else {
            self.api.aosrequest({
                params : params,
                urlPrefix : 'carServiceRecommend',
                method : 'get'
            }, cb);
        }
        function cb( dt ){
            $('#js_cat_dom').replaceWith( self.mod.index_cat( dt ) || '<div class="noData">亲，服务正在建设中，敬请期待...</div>' );
            dt.code == 1 && ( cache_dt[key] = dt );
        }
    },
    /*
        天气数据
    */
    rander_weather : function( head_data) {
        var self = this,
            params = [
                {lon:self.page_params.lon, sign:1},
                {lat:self.page_params.lat, sign:1},
                {image_standard:1, sign:1},
                {traffic_restrict:1},
                {car_washing:1}
            ], cache_dt = self.cache_dt, key = JSON.stringify( params );
        if( cache_dt[key] ){
            cb( cache_dt[key] );
        }else{
            self.api.aosrequest({
                params : params,
                urlPrefix : 'mojiweather',
                method : 'get'
            }, cb);
        }
        function cb( dt ){
            if( dt.code == 1 ){
                $('#js_header_tqfixed').replaceWith( self.mod.index_weather(dt, self.page_params.cityName) );
                cache_dt[key] = dt;
            }
            $( '#js_tipslist' ).replaceWith( self.mod.index_tips( head_data, (dt.traffic_restrict||{}).plate_no||'') );
        }
    },
    fix_weather : function() {//固定天气模块
        var starTop = $('.header_tqbox').offset().top - ($('body').hasClass( 'ver7' ) ? 65 : 45),
            obj = $('#js_header_tqfixed');
        $(window).bind('scroll',scroll).bind('touchmove', scroll).bind('touchend',lazyScroll);
        function scroll(){
            if( document.body.scrollTop > starTop ){
                obj.addClass( 'header_tqfixed' );
            }else{
                obj.removeClass( 'header_tqfixed' );
            }
        }
        function lazyScroll(){
            setTimeout(scroll,350);
        }
        this.register(function(){
            $(window).unbind('scroll',scroll).unbind('touchmove', scroll).unbind('touchend',lazyScroll);
            scroll = null,lazyScroll=null;
        });
    },
    setting_key : '',
    js_go_setting : function() {
        var self = this,
            dialog = $('#js_dialog');
        dialog.length && dialog.hide();
        self.login(function( res ){
            if( res.userid ){
                self.page_params.userid = res.userid;
                self.send({
                    action:'setUserCar' // 必填
                }, function( arg ){//设置头部信息
                    arg.carLogo = '';
                    var key = JSON.stringify( arg );
                    self.cache_dt[self.headData_key] = null;//这里需要清除头部请求缓存
                    self.setting_key != key && self.init_page(self.page_params);
                    self.setting_key = key;
                });
            } else {
                self.login(function( res ){
                    if( res.userid ){
                        self.page_params.userid = res.userid;
                        self.cache_dt[self.headData_key] = null;
                        self.init_page(self.page_params);
                        self.send({
                            action:'setUserCar' // 必填
                        }, function( arg ){//设置头部信息
                            var key = JSON.stringify( arg );
                            self.cache_dt[self.headData_key] = null;//这里需要清除头部请求缓存
                            self.setting_key != key && self.init_page(self.page_params);
                            self.setting_key = key;
                        });
                    }
                }, 0);
            }
        },1);
        self.log('carSetting');
    },
    show_settingLogo : function( type ){
        var self = this,obj = $( '#js_show_settingLogo' ),
            msg={
                1 :'填写您的车牌号码，有新违章信息时，<br/>为您推送提醒消息。',
                2 :'填写您的行驶证检验有效期，<br/>年检到期时为您推送提醒消息。',
                3 :'填写您的驾驶证有效期，<br/>换证到期时为您推送提醒消息。'
            }[type];
        if( obj.length ){
            obj.show().find('.dialog_p').html( msg );
            obj.find( '.dialog_em' ).attr( 'typ', type );
        } else {
            $( '#js_page' ).append( self.mod.index_logodialog(type, msg));
        }
    },
    /*
        点亮或取消点亮小图标
    */
    js_show_settingLogo : function( obj ){
        var self = this, type = obj.attr( 'typ' );
        self.login(function( res ){
            if( res.userid ){
                self.page_params.userid = res.userid;
                if( obj.hasClass( 'selected' ) ) {
                    self.js_go_settingLogo( obj );
                }else {
                    self.show_settingLogo(type);
                }
            }else{
                self.login(function( res ){
                    res.userid && self.init_page(self.page_params);
                }, 0);
            }
        },1);
        self.log('settingLogo',{type:type});
    },
    /*
        type：2  点击车辆年检提醒，3点击驾驶证年检提醒，
    */
    js_openTips : function( obj ) {
        this.send({
            action:'setCarowerPush',
            _action:'setCarowerPush',
            type:obj.attr( 'typ' )
        });
        this.log( 'tipsList'+obj.attr( 'typ' ) );
    },
    setCarowerPush : function( arg ){
        if( arg.flag == 0 || arg.flag == 1){
            $('#js_show_settingLogo'+arg.type)[arg.flag==1?'addClass':'removeClass']('selected');
        }
    },
    /*
        弹窗设置按钮点击
    */
    js_go_settingLogo : function( obj ){
        var self = this, type = obj.attr( 'typ' ), dialog = $( '#js_show_settingLogo' );
        dialog.length && dialog.hide();
        self.send({
            action:'setCarowerPush',
            _action:'setCarowerPush',
            type:type
        });
    },
    js_close_dialog : function( obj ) {
        obj.parents('section').hide();
    },
    //切换城市
    js_changecity : function() {
        var self = this;
        this.send({
            action:'showCityList',
            adcode : this.page_params.adcode,
            cityName : this.page_params.cityName
        }, function( dt ) {
            dt.adcode != self.page_params.adcode && dt.adcode && self.init_page( dt );
        });
        self.log('changeCity');
    },
    //违章查询
    js_go_wzcx : function() {
        this.api.loadSchema((this.browser.ios ? 'iosamap' :'androidamap') +'://openFeature?featureName=OpenURL&sourceApplication=tools&urlType=0&contentType=autonavi&url=http%3A%2F%2Fwap.amap.com%2Factivity%2Fwzcx%2Findex.html');
        this.log('wzcxNav');
    },
    //用车提醒
    js_go_yctx : function() {
        this.api.loadSchema((this.browser.ios ? 'iosamap' : 'androidamap')+'://openFeature?featureName=carservice&page=0');
        this.log('carservice');
    },
    //我的订单
    js_go_myorder : function() {
        this.log('goMyorder');
        this.api.getAppPara('', '', 'http://h5.m.taobao.com/mlapp/olist.html?ttid=@aligaode');
    },
    //banner图片点击
    js_go_banner : function( obj ) {
        var act = obj.attr("act");
        this.api.loadSchema(act);
        this.log('indexBanner', {id:obj.attr( 'adid' )});
    },
    js_go_prolist : function( obj ) {//去商品列表
        var self = this, kwd = obj.attr( 'kwd' ),
            params = [
                {diu:self.page_params.diu, sign:1},
                {div:self.page_params.div, sign:1},
                {pageSize:20},
                {keyword:kwd}
            ], key = JSON.stringify( params ), cache_dt = self.cache_dt;
        if( cache_dt[ key ] ){
            cb( cache_dt[ key ] );
        }else{
            self.api.aosrequest({
                params : params,
                urlPrefix:'getTmallItem',
                method : 'post',
                progress : 1
            }, cb);
        }
        function cb( dt ) {
            if( dt.status ==0 && dt.data && dt.data.results.length ){
                cache_dt[ key ] = dt;
                try{
                    self.util.storage('_prolist', JSON.stringify( dt.data ));//本地存储给列表页使用
                }catch(e){}
                self.util.locationRedirect( 'prolist.html?kwd='+encodeURIComponent(kwd)+'&diu='+self.page_params.diu+'&div='+self.page_params.div );
            } else if(dt.status==0){
                self.api.promptMessage( '数据完善中，敬请期待!' );
            }
        }
        self.log('loadprolist',{kwd:kwd});
    },
    //查看公交
    js_search_bus : function() {
        this.api.searchRoute(null, null, 'bus');
        this.log( 'tipsList0' );
    },
    // 查看违章 tips
    js_go_weizhanglist : function( obj ) {
        var url = obj.attr( 'url' ),
            params;
        if( url ) {//这里服务不编码，H5弱势只能自己编码了
            url = url.split('?');
            params = this.util.getUrlParam( false, url[1]);
            url = url[0]+'?';
            for(var k in params ){
                if( params.hasOwnProperty( k ) ){
                    url+='&'+k+'='+encodeURIComponent(params[k]);
                }
            }
            this.api.getAppPara('', '', url);
        }
        this.log( 'tipsList1' );
    }
});

})(POI,$);