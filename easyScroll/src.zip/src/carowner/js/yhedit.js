;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {},
    destroy_fns : [],
    logPageId : 'carownerYHEdit',
    page_params : {},
    data : null,
    cityList : null,
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    params : {},
    userPhone : '',
    net : false,
    quickInit : function() {
        var self = this;
        self.util.delegate( $('#js_page') );
        self.load_data();
        $('#js_page').html( self.mod.title_bar( !self.data.id ) );
        self.api.getMapLocation(function( local ){
            self.send({action: 'getExtraUrl'}, function( ext ){
                ext.token && (self.params.token = ext.token);
                self.params.diu = ext.diu;
                self.params.div = ext.div;
                self.params.tid = ext.tid;
                self.get_citylist(function(){
                    if( !self.data.id ){//新增
                        var userCity = self.get_usercity(local , self.cityList);
                        self.data.cityId = userCity.cityId;
                        self.data.cityName = userCity.cityName;
                        self.rander();
                    } else {
                        self.rander();
                    }
                    self.get_userPhone();
                })
            });
        });
        self.log('pv');
    },
    get_userPhone : function(){
        var self = this;
        if( self.userPhone ) return;
        self.send({
            action : 'getAmapUserId',
            onlyGetId : 1
        }, function( arg ){
            if( arg.userid ) {
                self.api.aosrequest({
                    params : [{mode:2,sign:1}],
                    urlPrefix : 'getUserProfile',
                    method : 'get'
                },function( dt ){
                    if( dt.code == 1 && dt.profile ) {
                        self.userPhone = dt.profile.mobile||'';
                    }
                });
            } else {
                self.userPhone = '';
            }
        });
    },
    load_data : function(){
        var self = this;
        self.data = JSON.parse( self.util.storage( 'viewcache' ) ) || self.data || {};
        self.cityList = JSON.parse( self.util.storage( 'cityList' ) ) || self.cityList;
        self.util.storage( 'viewcache' , null );
        //self.util.storage( 'cityList' , null );
    },
    rander : function(){
        var self = this;
        $( 'input' ).unbind();
        $( '#js_page' ).html( self.mod.title_bar( !self.data.id ) + self.mod.content(self.data,self.cityList));
        self.browser.and && setTimeout( function() {
            var obj = $( '#js_code' );
            var val = obj.val();
            obj.val( '' );
            obj[0].focus();
            obj.val( val );
        },200);
        self.bind_event();
    },
    bind_event : function(){
        var self = this;
        var titlebar = $( '.titlebar' );
        $( 'input' ).unbind().bind( 'focus' , function() {
            var obj = this;
            if( $.trim( obj.value ).length ){
                $( obj ).parent().addClass( 'selected' );
            }
            setTimeout(function(){
                self.browser.ios && titlebar.css('top',-titlebar[0].getBoundingClientRect().top+'px');
                //self.browser.and && $(window).scrollTop($( obj ).parent().offset().top+44);
            },250);
        } ).bind( 'blur' , function() {
            var o = $( this ).parent();
            setTimeout(function(){
                o.removeClass( 'selected' );
                self.browser.ios && titlebar.css('top','0');
            },50);
        }).bind( 'input' , function( e ){
            if(this.id == 'js_userName' && self.browser.ios) return;
            var val = this.value;
            var len = $( this ).attr( 'maxlength' );
            val = val.replace(/\<|\>/g,'');
            if( this.id == 'js_telephone' ){
                val = val.replace(/[^0-9]/g,'');
            } else if( this.id == 'js_code' ){
                val = val.replace(/\W|_/g,'');
            }
            if( $.trim( val ).length ){
                $( this ).parent().addClass( 'selected' );
            } else {
                $( this ).parent().removeClass( 'selected' );
            }
            this.value = len ? val.substr(0,len) : val;
            self.check_btn();
        } );
        $( '#js_userName' ).bind('blur', function( e ) {
            var val = this.value;
            var len = $( this ).attr( 'maxlength' );
            this.value = len ? val.substr(0,len) : val;
            self.check_btn();
        });
        self.browser.ios && $( window ).bind( 'touchmove', function(){
            $( 'input' ).blur();
            titlebar.css('top','0');
        } );
        self.register(function(){
            $( 'input' ).unbind();
            $( '#js_page' ).unbind();
        });
    },
    check_btn : function(){
        var fig = 0;
        var tmp = $.trim( $( '#js_code' ).val() );
        if( $.trim( $( '#js_code' ).val() ).length 
            && $.trim( $( '#js_userName' ).val() ).length
            && ( !$( '#js_subscribed' ).hasClass( 'selected' ) 
                || $.trim( $( '#js_telephone' ).val() ).length )
           ) {
            fig = 1;
        }
        $( '#js_save' )[fig?'removeClass':'addClass']( 'dis' );
    },
    page_show : function(){
        var self = this;
        $( window ).bind( 'pageshow', function(){
            self.load_data();
            self.rander();
            $( window ).unbind( 'pageshow' );
        } );
    },
    get_usercity : function(local , cityList) {
        var city = {cityId:0,cityName:'请选择'};
        cityList.forEach(function( o ){
            if( o.cityName.replace( '市' , '' ) == local.cityName.replace( '市' , '' )){
                city = o;
            }
        });
        return city;
    },
    get_citylist : function( cb ) {
        var self = this;
        if( self.cityList ) return cb();
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1}
            ];
        self.params.token && params.push({token:self.params.token});
        self.api.aosrequest({
            params : params,
            urlPrefix : 'yaohaocityList',
            method : 'post',
            progress : 1,
            showNetErr : 1,
            headers : 1
        },function( dt ){
            if( dt.code == 1 && dt.data && dt.data.list && dt.data.list.length ) {
                self.net = true;//代表有网络
                self.cityList = dt.data.list;
                cb();
            }
        });
    },
    get_data : function() {
        var self = this;
        var params = [];
        var dt = {};
        var msg = '';
        self.data.id && (dt.id = self.data.id);
        dt.cityId = self.data.cityId;
        dt.cityName = self.data.cityName;
        
        dt.code = $.trim( $( '#js_code' ).val() );
        dt.userName = $.trim( $( '#js_userName' ).val() );
        dt.subscribed = $( '#js_subscribed' ).hasClass( 'selected' ) ? 1 : 0;
        if( dt.subscribed == 1 ){
            dt.telephone = $.trim( $( '#js_telephone' ).val() );
        }
        if( dt.cityId == 0 ) {
            msg = '请选择摇号城市';
        } else if( dt.code.length < 13 ){
            msg = '摇号编号有误，请检查后重试';
        } else if( dt.userName.length == 0 ) {
            msg = '姓名有误，请检查后重试';
        } else if( dt.subscribed == 1 && !/^[1][34578][0-9]{9}$/.test(dt.telephone) ) {
            msg = '手机号有误，请检查后重试';
        }
        if( msg ){
            self.msg( msg );
            return 0;
        }
        $.extend(self.data, dt);
        return dt;
    },
    js_goback : function() {
        $( 'input' ).blur();
        if( this.net ) {
            $( '#js_page' ).append( this.mod.tips_dialog( '确定要放弃此次编辑？' , 2) );
        } else {
            this.api.webviewGoBack();
        }
    },
    checkback : function() {
        $( 'input' ).blur();
        this.destroy();
        this.api.webviewGoBack();
        this.log('editGoback');
    },
    js_del : function(){
        $( '#js_page' ).append( this.mod.tips_dialog() );
        this.log( 'deleteBtn',{id:this.data.id} );
    },
    js_ok : function( obj ) {
        var type = obj.attr( 'data-type' );
        if( type == 1 ) {
            this.delYH();
        } else if ( type == 2 ){
            this.checkback();
        }
    },
    delYH : function() {
        var self = this;
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1}
            ];
        self.params.token && params.push({token:self.params.token});
        params.push( {tparam:JSON.stringify({id:self.data.id})} );
        self.api.aosrequest({
            params : params,
            urlPrefix : 'yaohaoDel',
            method : 'post',
            progress : 1,
            showNetErr : 1,
            headers : 1
        },function( dt ) {
            if( dt.code == 1 ) {
                self.msg( '删除成功！' );
                self.util.storage( 'refresh' , 2);//告诉列表页需要刷新
                self.util.storage( 'viewcache' , null );
                //self.util.storage( 'cityList' , null );
                setTimeout(function(){
                    self.api.webviewGoBack();
                },150);
            } else {
                self.msg( '删除失败！' );
            }
        });
        self.log( 'delete',{id:self.data.id} );
    },
    js_save : function( obj ) {
        var self = this;
        self.check_btn();
        if( obj.hasClass( 'dis' ) ) return;
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1}
            ];
        self.params.token && params.push({token:self.params.token});
        var data = self.get_data();
        if( data ) {
            params.push( {tparam : JSON.stringify(data)} );
            self.send({
                action : 'getAmapUserId',
                onlyGetId : 0
            }, function( arg ){
                if( arg.userid ) {
                    params.push({uid:arg.userid});
                    self.api.aosrequest({
                        params : params,
                        urlPrefix : 'yaohaoEdit',
                        method : 'post',
                        progress : 1,
                        showNetErr : 1,
                        headers : 1
                    },function( dt ) {
                        self.util.storage( 'refresh' , 2);//告诉列表页需要刷新
                        if( dt.code == 1 && dt.data && dt.data.id){
                            self.destroy();
                            self.msg( '保存成功！' );
                            setTimeout(function(){
                                self.api.webviewGoBack();
                            },150);
                        } else if( dt.code == 14 ) {
                            self.msg( '必须登录才能保存！' );
                        } else if( dt.code == 0 ) {
                            self.msg( '填写错误' );
                        } else {
                            self.msg( '保存失败，请检查网络稍后重试' );
                        }
                        
                    });
                } else {
                    self.msg( '必须登录才能保存！' );
                }
            });
        }
        self.log( 'save' , {id:data.id||'add'});
    },
    msg : function( msg ){
        this.api.promptMessage( msg );
    },
    js_clearinput : function( obj ) {
        obj.parent().find( 'input' ).val( '' );
        this.log( 'clearinput', {id:obj.attr( 'id' )} );
        this.check_btn();
    },
    js_update : function( obj ) {
        var p = $('#js_subscribed');
        var fig = p.hasClass( 'selected' );
        var tel = p.find( 'input' );
        $.trim(tel.val()).length==0 && !fig && tel.val(this.userPhone);
        p[fig?'removeClass':'addClass']( 'selected' );
        $('#js_teltips').html(fig ? '开启后，我们将及时为您发送中签结果短信通知。': '摇号结果公布时，我们将及时为您发送中签结果短信通知。' );
        this.browser.ios && tel[0][fig?'blur':'focus']();
        this.browser.and && setTimeout(function(){
            tel[0][fig?'blur':'focus']();
        },250);
        this.check_btn();
        this.log( 'pushStatus',{'status_id': (fig ? 0 : 1)+'_'+(this.data.id||'add')} );
    },
    js_citylist : function() {
        var self = this;
        var data = self.data;
        $( 'input' ).blur();
        self.page_show();
        data.code = $.trim($( '#js_code' ).val());
        data.userName = $.trim($( '#js_userName' ).val());
        data.subscribed = $( '#js_subscribed' ).hasClass( 'selected' ) ? 1 : 0;
        data.telephone = $.trim($( '#js_telephone' ).val());
        self.util.storage( 'viewcache' , JSON.stringify( data ) );
        self.log( 'gocitylist' );
        self.util.locationRedirect( 'yhcitylist.html' );
    },
    js_goselect : function( obj ) {
        $( 'input' ).blur();
        this.log( 'selectYaoHaoTips' );
        this.api.getAppPara('', '', obj.attr( 'data-url' ) ,'','','查询摇号编号');
        $( '#js_dialog' ).remove();
    },
    js_showdialog : function( obj ) {
        this.log( 'showNetDialog' );
        $('input').blur();
        $( '#js_page' ).append( this.mod.netdialog( obj.attr( 'data-url' ) ) );
    },
    js_close : function() {
        this.log( 'closeNetDialog' );
        $( '#js_dialog' ).remove();
    }
});

})(POI,$);