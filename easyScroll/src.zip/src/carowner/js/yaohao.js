;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {},
    destroy_fns : [],
    logPageId : 'carownerYaohao',
    page_params : {},
    cache : {},
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    loginUserId : null,
    params : {},
    quickInit : function() {
        var self = this;
        self.util.delegate( $('#js_page') );
        localStorage.clear();
        self.register(function(){
            $('#js_page').html('');
            self.cache = {};
        });
        self.send({action: 'getExtraUrl'}, function( ext ){
            ext.token && (self.params.token = ext.token);
            self.params.diu = ext.diu;
            self.params.div = ext.div;
            self.params.tid = ext.tid;
            self.send({
                action : 'getAmapUserId',
                onlyGetId : 1
            }, function( arg ){
                if( arg.userid ) {
                    self.loginUserId = arg.userid;
                    $('#js_page').html( self.mod.title_bar( 0 ) );
                    self.rander();
                } else {
                    $('#js_page').html( self.mod.title_bar( 0 ) + '<section class="index_content">'+ self.mod.empty() + self.mod.listmsg( 0 ) +'</section>' );
                } 
            });
        });
        self.log('pv');
    },
    rander : function(){
        var self = this;
        self.get_data(function( dt ){
            if( dt.code == 1 && dt.data && dt.data.list && dt.data.list.length > 0 ){
                $('#js_page').html( self.mod.title_bar( 1 ) + '<section class="index_content">'+ self.mod.list( dt.data.list ) + '</section>' );
                dt.data.list.forEach(function( item ){
                    self.cache[item.id] = item;
                });
            } else {
                $('#js_page').html(  self.mod.title_bar( 0 ) + '<section class="index_content">'+ self.mod.empty() + self.mod.listmsg( 1 ) +'</section>' );
            }
        });
    },
    page_show : function(){
        var self = this;
        $( window ).unbind( 'pageshow' ).bind( 'pageshow', function(){
            self.send({
                action : 'getAmapUserId',
                onlyGetId : 1
            }, function( arg ){
                self.loginUserId = arg.userid;
                if( self.util.storage( 'refresh' ) == 1 || self.util.storage( 'refresh' ) == 2 ){
                    self.rander();
                    self.util.storage( 'refresh' , null);            
                }
                //$( window ).unbind( 'pageshow' );
            });
        } );
    },
    get_data : function( cb ) {
        var self = this;
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1},
                {uid:self.loginUserId}
            ];
        self.params.token && params.push({token:self.params.token});
        self.api.aosrequest({
            params : params,
            urlPrefix : 'yaohaoList',
            method : 'post',
            progress : 1,
            showNetErr : 1,
            headers : 1
        }, function( dt ){
            cb( dt );
        });
    },
    js_goback : function() {
        this.destroy();
        this.api.webviewGoBack();
        this.log('listGoback');
    },
    js_gologin : function() {
        var self = this;
        self.send({
            action : 'getAmapUserId',
            onlyGetId : 0
        }, function( arg ){
            if( arg.userid ){
                self.loginUserId = arg.userid;
                self.rander();
            }
        });
        self.log('gologin');
    },
    js_add : function() {
        var self = this;
        if( $( '.index_content article' ).length >= 10 ){
            return $( '#js_page' ).append( self.mod.dialog() );
        }
        self.page_show();
        self.log('addBtn');
        self.util.locationRedirect( 'yhedit.html' );
    },
    js_yhview : function( obj ) {
        var self = this;
        var id = obj.attr( 'data-id' );
        self.page_show();
        self.util.storage( 'viewcache', JSON.stringify( self.cache[id] ) );
        self.log( 'view' , {type_id:(obj.hasClass('success')?1:0)+'_'+id});
        self.util.locationRedirect( 'yhview.html' );
    },
    js_closedialog : function(){
        $( '#js_adddialog' ).remove();
        this.log( 'closedialog' );
    }
});

})(POI,$);