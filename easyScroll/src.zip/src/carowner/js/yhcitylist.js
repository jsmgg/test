;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {
        title_bar : function() {
            return '<div class="titlebar half-line-bottom"><em class="titlebar_back" js_handle="js_goback"><i></i></em><p>选择城市</p></div><p class="titlebar_tmp"></p>';
        },
        list : function(item, cityList) {
            var p = POI.util.get_arr();
            p.p( '<section class="yhcitylist half-line-bottom">' );
            cityList.forEach(function( o ){
               p.p( '<div class="canTouch'+ (item.cityId == o.cityId ? ' selected' : '') +'" js_handle="js_changecity" data-cityid="'+o.cityId+'" data-name="'+ o.cityName +'"><h2 class="half-line-bottom">'+ o.cityName +'<i class="icon"></i></h2></div>' ) 
            });
            p.p( '</section>' );
            return p.str;
        }
        
    },
    destroy_fns : [],
    logPageId : 'carownerYHCitylist',
    cache : {},
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    data : null,
    cityList : null,
    params : {},
    quickInit : function() {
        var self = this;
        self.util.delegate( $('#js_page') );
        $('#js_page').html( self.mod.title_bar() );
        self.register(function(){
            $('#js_page').html('');
            self.cache = {};
        });
        self.data = JSON.parse( self.util.storage( 'viewcache' ) ) || {};
        self.cityList = JSON.parse( self.util.storage( 'cityList' ) );
        self.util.storage( 'viewcache' , null );
        self.log('pv');
        self.send({action: 'getExtraUrl'}, function( ext ){
            ext.token && (self.params.token = ext.token);
            self.params.diu = ext.diu;
            self.params.div = ext.div;
            self.params.tid = ext.tid;
            self.rander();
        });
    },
    rander : function(){
        var self = this;
        self.get_citylist(function(){
            $('#js_page').html( self.mod.title_bar() + self.mod.list( self.data,self.cityList) );
        });
    },
    get_citylist : function( cb ) {
        var self = this;
        if( self.cityList ) return cb();
        var params = [
                {diu:self.params.diu, sign:1},
                {div:self.params.div, sign:1}
            ];
        self.params.token && params.push({token:self.params.token});
        self.api.aosrequest({
            params : params,
            urlPrefix : 'yaohaocityList',
            method : 'post',
            progress : 1,
            showNetErr : 1,
            headers : 1
        },function( dt ){
            if( dt.code == 1 && dt.data && dt.data.list && dt.data.list.length ) {
                self.cityList = dt.data.list;
                cb();
            }
        });
    },
    js_goback : function() {
        var self = this;
        self.util.storage( 'viewcache' , JSON.stringify( self.data ) );
        self.destroy();
        self.log('citylistGoback');
        self.api.webviewGoBack();
    },
    js_changecity : function( obj ) {
        var self = this;
        self.destroy();
        self.data.cityId = obj.attr( 'data-cityId' );
        self.data.cityName = obj.attr( 'data-name' );
        self.util.storage( 'viewcache' , JSON.stringify( self.data ) );
        self.util.storage( 'cityList' , JSON.stringify( self.cityList ) );
        self.log('changecity',{keyword:self.data.cityName});
        self.api.webviewGoBack();
    }
});

})(POI,$);