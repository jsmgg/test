;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {},
    destroy_fns : [],
    logPageId : 'carowner',
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    page_params : {pageSize:20,pageNo:1},
    quickInit : function() {
        var self = this, dt = JSON.parse(self.util.storage('_prolist'));
        self.util.storage('_prolist', '');
        self.page_params.div = self.util.getUrlParam( 'div' );
        self.page_params.diu = self.util.getUrlParam( 'diu' );
        self.page_params.kwd = decodeURIComponent( self.util.getUrlParam( 'kwd' ) );
        if( dt ){
            self.init_page( dt );
        } else {//本地存储失败从服务取数据
            self.page_params.pageNo =0;
            self.load_end = false;
            self.load_data(function(dt){
                self.request_busy = false;
                dt.status ==0 && dt.data && dt.data.results.length && self.init_page( dt.data );
            });
        }
        self.util.delegate( $('#js_page') );
        self.register(function(){
            $('js_page').html('');
        });
        self.send({
            action: 'registRightButton',
            type: 'share',
            buttonText: ''
        });
        self.log('prolistpv');
    },
    init_page : function( dt ) {
        var self = this,str = self.util.get_arr();
        str.p(self.mod.prolist_titlebar( self.page_params.kwd ))
        .p( self.mod.prolist_list( dt , self.page_params) );
        $('#js_page').html( str.str );
    },
    lazyloadlist : null,//记录当前未加载图片的容器
    init_pagescroll : function() {
        var self = this, height = $(window).height(), timer;
        $(window).bind('scroll',scroll).bind('touchmove', scroll).bind('touchend',scroll);
        scroll();
        function scroll() {
            clearTimeout( timer );
            timer = setTimeout( function() {
                var scrollTop = document.body.scrollTop, lazyloadlist = self.lazyloadlist,
                    tmp;
                if(lazyloadlist && lazyloadlist.length){
                    lazyloadlist.each(function( i, item ){
                       tmp = item._top; 
                       if( item._loaded ) return;
                        if(!tmp){
                            item._top = tmp = item.parentNode.offsetTop;
                        }
                        if( scrollTop + height >=tmp && scrollTop < tmp+120 ){
                            item._loaded = 1;
                            self.load_item( $(item) );
                        }
                    });
                }
                if( (!self.load_end && scrollTop + height) >= ($('p.loadingBox').offset().top+10) ) {
                    self.load_data();
                }
            },100 );
        }
        self.register(function(){
             $(window).unbind('scroll',scroll).unbind('touchmove', scroll).unbind('touchend',scroll);
             scroll = null;
        });
    },
    request_busy : false,
    load_end : true,
    load_data : function( cb ){
        var self = this,
            params = [
                {diu:self.page_params.diu, sign:1},
                {div:self.page_params.div, sign:1},
                {keyword:self.page_params.kwd},
                {pageSize:self.page_params.pageSize}
            ],
            loadingobj = $('p.loadingBox');
        if( self.request_busy || self.load_end ) {
            return;
        }
        self.request_busy = true;
        loadingobj.length && loadingobj.addClass( 'loading' ).text( '' );
        params.push( {pageNo:self.page_params.pageNo+=1} );
        self.api.aosrequest({
            params : params,
            urlPrefix:'getTmallItem',
            method : 'post'
        }, cb || function( dt ){
            self.request_busy = false;
            if( dt.status ==0 && dt.data && dt.data.results.length ){
                $( '#js_prolist' ).append( self.mod.prolist_list( dt.data , self.page_params) );
                if( self.page_params.pageNo * self.page_params.pageSize >= dt.data.totalResults ){
                    loadingobj.removeClass( 'loading' ).text( '' );
                    self.load_end = true;
                }
            }else if( dt.status != 0 ){
                loadingobj.removeClass( 'loading' ).text( '加载失败...' );
            }else{
                loadingobj.removeClass( 'loading' );
            }
        });
    },
    load_item : function( obj ){
        var src = obj.attr( 'url' ),
            img = new Image();
        obj.removeClass( 'js_noload' );
        img.onload = function(){
            obj.html( '<img src="' + src + '" />' );
            obj.removeClass( 'img-loading' );
            obj = img = img.onerror = img.onload = null;
        }
        img.onerror = function(){
            obj.removeClass( 'img-loading' ).addClass( 'img-err' );
            obj = img = img.onerror = img.onload = null;
        }
        img.src = src;
    },
    js_goback : function() {//返回
        this.destroy();
        this.api.webviewGoBack();
        this.log('prolistGoback');
    },
    //打开商品详情页
    js_go_prodetail : function( obj ) {
        var url = obj.attr( 'url' );
        url && this.api.openThirdUrl(url,'淘宝',1500);
        this.log('prodetail',{itemId:obj.attr('itemId')});
    }
});

})(POI,$);