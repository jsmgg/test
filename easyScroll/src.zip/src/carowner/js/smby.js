;(function(POI,$){

'use strict';
$.extend(POI, {
    mod : {},
    destroy_fns : [],
    logPageId : 'carowner',
    page_params : {},
    destroy : function(){
        var self = this, item;
        while( item = self.destroy_fns.shift()){
            item.call(self);
        }
    },
    register : function( fn ){
        this.destroy_fns.push(fn);
    },
    log : function(click,params){
        this.api.userAction(click,params);
    },
    quickInit : function() {
        var self = this;
        self.util.delegate( $('#js_page') );
        $('#js_page').html( self.mod.title_bar() );
        self.register(function(){
            $('js_page').html('');
        });
        self.api.getMapLocation(function( arg ){
            self.send({action: 'getExtraUrl'}, function(ext){
                self.rander(arg, ext);
            });
        });
        self.register_myorder();
        self.log('smbypv');
    },
    rander : function(arg, ext){
        var self = this, cache_dt = self.cache_dt,
            params = [
                {tid:ext.tid, sign:1},
                {x:arg.lon},
                {y:arg.lat}
            ];
        self.page_params.lon = arg.lon;
        self.page_params.lat = arg.lat;
        self.page_params.tid = ext.tid;
        self.page_params.diu = ext.diu;
        self.page_params.div = ext.div;
        self.api.aosrequest({
            params : params,
            urlPrefix : 'carServiceRecommendV2',
            method : 'get'
        }, function( dt ){
            $('#js_page').html( self.mod.title_bar() + ( ( self.mod.door_service( dt.door_service||{} ) + self.mod.recommend( dt.season_recommend || {} ) ) || '<div class="noData">亲，服务正在建设中，敬请期待...</div>') );
        });
    },
    register_myorder : function() {
        var self = this;
        self.send({
            "action": "registRightButton",
            "type": "jsCallBack",
            "buttonText": '订单',
            "function": {
                "action": "jsCallBack"
            }
        }, function() {
            self.log('smbyGoMyorder');
            self.api.openThirdUrl('http://h5.m.taobao.com/mlapp/olist.html?ttid=@aligaode','淘宝',1500);
        });
    },
    js_goback : function() {//返回
        this.destroy();
        this.api.webviewGoBack();
        this.log('smbyGoback');
    },
    page_show : function(){
        var self = this;
        $(window).bind( 'pageshow' , function() {
            self.register_myorder();
            $(window).unbind( 'pageshow' );
        });
    },
    smby_cache_dt : {},
    js_go_prolist: function( obj ) {
        var self = this, kwd = obj.attr( 'kwd' ),
            params = [
                {diu:self.page_params.diu, sign:1},
                {div:self.page_params.div, sign:1},
                {pageSize:20},
                {keyword:kwd}
            ], key = JSON.stringify( params ), smby_cache_dt = self.smby_cache_dt;
        if( smby_cache_dt[ key ] ){
            cb( smby_cache_dt[ key ] );
        }else{
            self.api.aosrequest({
                params : params,
                urlPrefix:'getTmallItem',
                method : 'post',
                showNetErr : 1,
                progress : 1
            }, cb);
        }
        function cb( dt ) {
            if( dt.status ==0 && dt.data && dt.data.results.length ){
                smby_cache_dt[ key ] = dt;
                try{
                    self.util.storage('_prolist', JSON.stringify( dt.data ));//本地存储给列表页使用
                }catch(e){}
                self.page_show();
                self.util.locationRedirect( 'prolist.html?kwd='+encodeURIComponent(kwd)+'&diu='+self.page_params.diu+'&div='+self.page_params.div );
            } else if(dt.status==0){
                self.api.promptMessage( '数据完善中，敬请期待!' );
            }
        }
        self.log('loadprolist',{kwd:kwd,type:'smby'});
    }
});

})(POI,$);