/*
    首页titlebar
*/
POI.mod.title_bar = function( add ){
    return '<div class="titlebar half-line-bottom"><em class="titlebar_back" js_handle="js_goback"><i></i></em><p>'+ (add ? '添加摇号信息' : '编辑摇号信息') +'</p>' + (add ? '' : '<em class="titlebar_right c666" js_handle="js_del">删除</em>') + '</div><p class="titlebar_tmp"></p>';
};

POI.mod.content = function( item, citylist ) {
    var p = POI.util.get_arr();
    var city = citylist[0];
    var websiteUrl = city.websiteUrl;
    item.cityId && citylist.forEach( function( o ) {
        if( o.cityId == item.cityId ) {
            websiteUrl = o.websiteUrl;
        }
    } );
    p.p( '<section class="yhedit_content">' )
     .p( '<article class="half-line-bottom">' )
     .p( '<div class="canTouch item city half-line-bottom" js_handle="js_citylist">' )
     .p( '<p>摇号城市</p>' )
     .p( '<em>'+(item.cityName||city.cityName)+'</em>' )
     .p( '<i class="icon"></i></div>' )// end .city
     .p( '<div class="item half-line-bottom">' )
     .p( '<p>摇号编号<i class="tips icon" js_handle="js_showdialog" data-url="'+ (websiteUrl||'') +'"></i></p>' )
     .p( '<em class="input"><input id="js_code" type="tel" maxlength="13" value="'+ (item.code || '') +'" /><b js_handle="js_clearinput"></b></em>' )
     .p( '</div>' )
     .p( '<div class="item">' )
     .p( '<p>备注姓名</p>' )
     .p( '<em class="input"><input id="js_userName" type="text" value="'+ (item.userName||'') +'" maxlength="12" /><b js_handle="js_clearinput"></b></em>' )
     .p( '</div></article>' )
     .p( '<p class="nametips">姓名仅为您备注摇号的编号。</p>' )
     .p( '<div id="js_subscribed" class="setphone half-line-bottom half-line-top'+ (item.subscribed==1 ? ' selected':'') +'">' )
     .p( ' <h2>摇号结果短信提醒<em class="hack_blur half-border" js_handle="js_update"></em></h2>' )
     .p( '<p class="telbox half-border">' )
     .p( '<span>手机号</span><em><input id="js_telephone" type="tel" value="'+ (item.telephone||'') +'" maxlength="11"></input><b js_handle="js_clearinput"></b></em>' )
     .p( '</p>' )
     .p( '</div>' )
     .p( '<p class="nametips" id="js_teltips">'+ (item.subscribed==1 ? '摇号结果公布时，我们将及时为您发送中签结果短信通知。': '开启后，我们将及时为您发送中签结果短信通知。' ) +'</p>' )
     .p( '<p class="save"><span id="js_save" class="canTouch'+ (item.code && item.userName && (item.subscribed!=1 || item.telephone) ? '' : ' dis') +'" js_handle="js_save">保存</span></p>' )
     .p( '</section>' );
    return p.str;
}

POI.mod.netdialog = function(url){
    return '<div class="dialog" ontouchmove="javascript:event.preventDefault();event.stopPropagation();" id="js_dialog"><p class="bg" js_handle="js_close"></p><article class="box"><div class="net"><div class="content half-line-bottom">可以登录以下网站查询您的摇号编码<br/>'+ url +'</div><div class="btn"><p class="canTouch" js_handle="js_close">取消</p><p class="canTouch" js_handle="js_goselect" data-url="'+ url +'">去查询</p></div></div></article></div>'
}

/*
    msg:弹框提示内容
    type：0 删除提示确认，1 回退提示确认
*/
POI.mod.tips_dialog = function( msg , type ) {
    return '<div class="dialog" ontouchmove="javascript:event.preventDefault();event.stopPropagation();" id="js_dialog"><p class="bg" js_handle="js_close"></p><article class="box"><div class="del"><div class="content half-line-bottom">'+ (msg || '确定要删除该条摇号提醒？') +'</div><div class="btn"><p class="canTouch" js_handle="js_close">取消</p><p class="canTouch" js_handle="js_ok" data-type="'+(type||1)+'">确定</p></div></div></article></div>'
}