POI.mod.title_bar = function(){
    return '<div class="titlebar half-line-bottom"><em class="titlebar_back" js_handle="js_goback"><i></i></em><p>摇号信息</p><em class="titlebar_right" js_handle="js_edit">编辑</em></div><p class="titlebar_tmp"></p>';
};

POI.mod.content = function( item, citylist ) {
    var p = POI.util.get_arr();
    var city = {};
    citylist.forEach(function( o ){
        if( item.cityId == o.cityId ) {
            city = o;
        }
    });
    p.p( '<section class="yhview_content">' )
     .p( '<article class="half-line-bottom">' )
     .p( '<div class="item city half-line-bottom">' )
     .p( '<p>摇号城市</p>' )
     .p( '<em>'+(item.cityName||'')+'</em>' )
     .p( '</div>' )
     .p( '<div class="item half-line-bottom">' )
     .p( '<p>摇号编号<i class="tips icon" js_handle="js_showdialog" data-url="'+ (city.websiteUrl||'') +'"></i></p>' )
     .p( '<em>'+ (item.code) +'</em>' )
     .p( '</div>' )
     .p( '<div class="item">' )
     .p( '<p>备注姓名</p>' )
     .p( '<em>'+ (item.userName||'') +'</em>' )
     .p( '</div>' )
     .p( '</article>' )
     .p( '<p class="nametips">姓名仅为您备注摇号的编号。</p>' )
     .p( city.websiteUrl ? '<h2 class="canTouch half-line-bottom half-line-top" data-url="'+ city.websiteUrl +'" js_handle="js_select">查询摇号是否过期<i class="icon"></i></h2><p class="selecttips">进入相关网站查询摇号资格是否过期，若已过期请及时续签。</p>' : '' )
     .p( city.tipsList && city.tipsList.length ? '<div class="citytips">Tips:<br/>'+ city.tipsList.join( '<br/>' ) +'</div>' : '' )
     .p( '</section>' );
    return p.str;
}
POI.mod.netdialog = function(url){
    return '<div class="dialog" ontouchmove="javascript:event.preventDefault();event.stopPropagation();" id="js_netdialog"><p class="bg" js_handle="js_closenet"></p><article class="box"><div class="net"><div class="content half-line-bottom">可以登录以下网站查询您的摇号编码<br/>'+ url +'</div><div class="btn"><p class="canTouch" js_handle="js_closenet">取消</p><p class="canTouch" js_handle="js_goselect" data-url="'+ url +'">去查询</p></div></div></article></div>'
}