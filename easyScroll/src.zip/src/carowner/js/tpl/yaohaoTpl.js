/*
    首页titlebar
*/
POI.mod.title_bar = function( fig ){
    return '<div class="titlebar half-line-bottom"><em class="titlebar_back" js_handle="js_goback"><i></i></em><p>摇号提醒</p>'+(fig ? '<em class="titlebar_right" js_handle="js_add">添加</em>' : '' )+'</div><p class="titlebar_tmp"></p>';
};
POI.mod.empty = function() {
    return '<article class="canTouch" js_handle="js_add"><p class="empty"><i class="icon"></i>添加摇号信息</p></article>'
}
POI.mod.listmsg = function( fig ) {
    return fig ? '<div class="listmsg">无任何摇号查询信息</div>' : '<div class="listmsg" js_handle="js_gologin">已设置过摇号查询信息？ <i class="half-border canTouch">直接登录</i></div>';
}

POI.mod.list = function( data ){
    var self = this;
    return data.map(function( item ){
        return self[item.balloted == 1 ? 'list_success':'list_wait']( item )
    }).join('')||'';
}
POI.mod.list_success = function( item ) {
    var p = POI.util.get_arr();
        p.p( '<article class="success canTouch" js_handle="js_yhview" data-id="'+item.id+'">' )
         .p( '<div class="item_top">' )
         .p( '<p class="fistp"><span>'+(item.userName||'')+'</span><i>'+ (item.code||'') +'</i></p>' )
         .p( '<p><span>已成功中签</span></p>' )
         .p( '</div>' )
         .p( '<h2 class="item_tips">幸福来得如此突然，快去官网确认吧~</h2>' )
         .p( '</article>' );
    return p.str;
}
POI.mod.list_wait = function( item ) {
    var p = POI.util.get_arr();
    var arr = item.nextPublishDate.split('-');
    var next = new Date(arr[0],parseInt(arr[1],10)-1,parseInt(arr[2],10),0,0,0);
    var day = (next.getTime() - Date.now())/(1000*60*60*24);
    if( day <= 0 && day > -1 ) {
        day = 0;
    } else if( day > 0 ) {
        day = Math.ceil(day);
    }
    arr = item.ballotedDate.split( '-' );
    p.p( '<article class="canTouch" js_handle="js_yhview" data-id="'+ item.id +'">' )
     .p( '<div class="item_top">' )
     .p( '<p class="fistp"><span>'+(item.userName||'')+'</span><i>'+ (item.code||'') +'</i></p>' )
     .p( '<p><span>未中签</span></p>' )
     .p( '<p class="lastp"><em>'+ ( arr[0] && arr[1] && arr[2] ? parseInt(arr[0])+'年'+parseInt( arr[1] )+'月'+parseInt( arr[2] )+'日摇号结果':'') +'</em></p>' )
     .p( '</div>' )
     .p( day > 0 ? '<h2 class="item_tips">距下期摇号还有<i>'+ day +'</i>天<em class="icon"></em></h2>' : day== 0 ? '<h2 class="item_tips">今天将公布本期摇号结果<em class="icon"></em></h2>' : '' )
     .p( '</article>' );
    return p.str;
}

POI.mod.dialog = function() {
    return '<div class="dialog" ontouchmove="javascript:event.preventDefault();event.stopPropagation();" id="js_adddialog"><p class="bg" js_handle="js_closedialog"></p><article class="box"><div class="add"><div class="content half-line-bottom"><span class="s1">提示</span><br/>摇号查询数据已达上限，<br/>请删减部分再尝试添加。</div><div class="btn"><p class="canTouch" js_handle="js_closedialog">确定</p></div></div></article></div>'
}