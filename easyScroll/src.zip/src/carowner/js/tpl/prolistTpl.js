/*
    列表页titlebar
*/
POI.mod.prolist_titlebar = function( kwd ) {
    POI.api.setWebViewTitle(kwd);
    return '';
    //return '<div class="titlebar half-line-bottom"><em class="titlebar_back icon" js_handle="js_goback"></em>'+kwd+'</div>';
}
/*
    列表 
*/
POI.mod.prolist_list = function( dt , page_params ) {
    var str = POI.util.get_arr(),
        pageNo = page_params.pageNo,
        pageSize = page_params.pageSize;
    pageNo==1 && str.p( '<section class="list" id="js_prolist">' );
    dt.results.forEach(function( item ){
        str.p( '<article class="list_item half-line-top half-line-bottom canTouch" js_handle="js_go_prodetail" url="'+ item.url +'" itemId="'+item.itemId+'">' )
        .p( '<p class="list_item_imgbox img-loading js_noload" url="'+ (item.picPath||'') +'">' )
        .p( '</p>' )// end .list_item_imgbox
        .p( '<div class="list_item_right">' )
        .p( '<h2 class="list_item_title">'+ (item.title||'') +'</h2>' )
        .p( '<span class="list_item_tag">&nbsp;</span>' )
        .p( '<p class="list_item_msg">' )
        .p( item.sold? '<i>销量'+item.sold+'件</i>' : '')
        .p( '<em>' )
        .p( item.pomotion ? '促销价' : '')
        .p( item.whiteRate ? '<span>'+parseFloat(item.whiteRate).toFixed(2)+'</span>' : '')
        .p( '</em>' )
        .p( '</p>' )
        .p( '</div>' )
        .p( '</article>' );
    });
    pageNo==1 && str.p( '</section>'+ ('<p class="loadingBox'+ (dt.totalResults>pageSize ? ' loading' : '') +'"></p>') );
    pageNo==1 && (POI.load_end = dt.totalResults<=pageSize);
    setTimeout(function(){
        POI.lazyloadlist = $( 'P.js_noload' );
        POI.init_pagescroll();
    },1);
    return str.str;
}