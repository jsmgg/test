/*
    titlebar
*/
POI.mod.title_bar = function(){
    POI.api.setWebViewTitle('上门保养');
    return '';
    //return '<div class="titlebar half-line-bottom"><em class="titlebar_back" js_handle="js_goback"><i></i></em><p>上门保养</p><em class="titlebar_city" js_handle="js_go_myorder">订单</em></div><p class="tmp_titlebar"></p>';
}
/*
    头部分类模块
*/
POI.mod.door_service = function( door_service ) {
    var html = POI.util.get_arr();
    if( door_service.short_item && door_service.short_item.length ) {
        html.p( '<section class="door_service half-line-bottom">' );
        door_service.short_item.forEach(function(item , i ){
            if( i % 4 == 0){
                html.p( i==0 ? '<ul>' : '</ul><ul>' );
            }
            html.p( '<li class="canTouch" js_handle="js_go_prolist" kwd="'+ item.keyword +'">' )
                .p( '<p '+ ( item.icon ? 'style="background-image:url('+ item.icon +')"' : '' ) +'></p>' )
                .p( '<em>'+ ( item.title || '' ) +'</em>' )
                .p( '</li>' );
        });
        var ind = 4 - door_service.short_item.length % 4;
        while( ind<4 && ind-- ){
            html.p( '<li></li>' );
        }
        html.p( '</ul></section>' );
    }
    return html.str;
}
/*
    人气商品模块
*/
POI.mod.recommend = function( recommend ) {
    var data = recommend.data||[],
        html = POI.util.get_arr();
    //data = data.concat(data);
    if( data.length && data.length >= 3) {
        html.p( '<section class="recommend half-line-bottom half-line-top">' );
        recommend.name && html.p( '<h2 class="modules_title half-line-bottom">' + recommend.name + '</h2>' )
        .p( '<article class="recommend_item half-line-bottom">' )
        .p( '<div class="top_item half-line-right">' );
        var item = data[0];
        html.p( '<div class="item canTouch first" js_handle="js_go_prolist" kwd="'+ item.keyword +'">' )
            .p( '<p><em class="color1">'+(item.title || '')+'</em><i>'+(item['sub-title'] || '')+'</i></p>')
            .p( '<aside '+ (item.icon ? 'style="background-image:url('+item.icon+')"' : '') +'></aside>' )
            .p( '</div>' )
        .p( '</div>' );// end.top_item
        item = data[1];
        html.p( '<div class="top_item flex_v">' )
            .p( '<div class="item canTouch half-line-bottom" js_handle="js_go_prolist" kwd="'+ item.keyword +'">' )
            .p( '<p><em class="color2">'+(item.title || '')+'</em><i>'+(item['sub-title'] || '')+'</i></p>')
            .p( '<aside '+ (item.icon ? 'style="background-image:url('+item.icon+')"' : '') +'></aside>' )
            .p( '</div>' );// end .item
        item = data[ 2 ];
        html.p( '<div class="item canTouch half-line-right" js_handle="js_go_prolist" kwd="'+ item.keyword +'">' )
            .p( '<p><em class="color3">'+(item.title || '')+'</em><i>'+(item['sub-title'] || '')+'</i></p>')
            .p( '<aside '+ (item.icon ? 'style="background-image:url('+item.icon+')"' : '') +'></aside>' )
            .p( '</div>' )// end .item
        .p( '</div>' )//end .top_item
        .p( '</article>' );

        data = data.splice(3);
        data.forEach(function( item , i ){
            if( i%2 == 0 ){
                if( i > 0 ){
                    html.p( '</div></article>' );
                }
                html.p( '<article class="recommend_item half-line-bottom"><div class="top_item flex">' )
            }
            html.p( '<div class="item canTouch'+(i%2 == 0?' half-line-right':'')+'" js_handle="js_go_prolist" kwd="'+ item.keyword +'">' )
                .p( '<p><em class="color'+((i+3)%5+1)+'">'+(item.title || '')+'</em><i>'+(item['sub-title'] || '')+'</i></p>')
                .p( '<aside '+ (item.icon ? 'style="background-image:url('+item.icon+')"' : '') +'></aside>' )
                .p( '</div>' );// end.item
        });
        if( data.length % 2 ){
            html.p( '<div class="item" style="width:1px;"></div>' );
        }
        html.p( '</div></article>' )
            .p( '</section>' );
    }
    return html.str;
}