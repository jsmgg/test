/*
    首页titlebar
*/
POI.mod.index_titlebar = function( data ){
    return '<div class="titlebar"><em class="titlebar_back" js_handle="js_goback"><i class="icon"></i></em><p>车主服务</p><em class="titlebar_city" js_handle="js_changecity">'+ data.cityName +'<i class="icon"></i></em></div>';
};

/*
    设置小图标弹窗提示
*/
POI.mod.index_logodialog = function(type, msg){
    return '<section class="dialog" id="js_show_settingLogo"><article class="dialog_article"><p class="dialog_p">'+msg+'</p><div class="dialog_div"><span class="dialog_span canTouch" js_handle="js_close_dialog">取消</span><em class="dialog_em canTouch" js_handle="js_go_settingLogo" typ="'+type+'">设置</em></div></article></section>'
}
/*
    首页头部
*/
POI.mod.index_head = function( data ) {
    var str = POI.util.get_arr(),
        result = data.data || {},
        pushAlert = result.pushAlert||[],
        starTop = $('body').hasClass( 'ver7' ) ? 64 : 44,
        fig1 = false,//违章提醒
        fig2 = false,//车辆年检提醒
        fig3 = false;//驾照过期提醒
    pushAlert.forEach( function( item ) {
        if( item.flag == 1) {
            if( item.type == 1){
                fig1 = true;
            } else if( item.type == 2){
                fig3 = true;
            } else if( item.type == 3) {
                fig2 =true;
            }
        }
    });
    str.p( '<header>' )
    .p( '<article class="header_top">' )
    .p( '<div class="header_logo icon" js_handle="js_go_setting"'+(result.vehicleLogo?' style="background:url('+result.vehicleLogo+') center center no-repeat #fff;background-size:100%;"':'')+'>' )
    .p( '</div><div class="header_right">' )
    .p( '<p class="header_carNo" js_handle="js_go_setting">' + (result.plateNum || '设置车辆，定制保养') + '</p>' )
    .p( '<p class="header_carType" js_handle="js_go_setting">' + (result.vehicleMsg || '&nbsp;') + '</p>' )
    .p( '<p class="header_carIcon">' )
    .p( '<em id="js_show_settingLogo1" typ="1" class="'+ ( fig1 ? ' selected' : '') +'" js_handle="js_show_settingLogo"><i class="header_carIcon_no half-border icon"></i></em>' )
    .p( '<em id="js_show_settingLogo2" typ="2" class="'+ ( fig2 ? ' selected' : '') +'" js_handle="js_show_settingLogo"><i class="header_carIcon_carExp half-border icon"></i></em>' )
    .p( '<em id="js_show_settingLogo3" typ="3" class="'+ ( fig3 ? ' selected' : '') +'" js_handle="js_show_settingLogo"><i class="header_carIcon_lis half-border icon"></i></em>' )
    .p( '</p></div>' )
    .p( '<p class="header_right_btn" js_handle="js_go_setting"><em class="header_top_icon icon"></em></p>' )
    .p( '</article>' ) // end .header_top
    .p( '</header>' )
    .p( '<article class="header_tqbox"'+ (POI.browser.ios ? ' style="position:-webkit-sticky;position:sticky;top:'+starTop+'px;z-index:3;"' : '')+'><div id="js_header_tqfixed"></div>' )//这里填充天气信息
    .p( '</article>' )// end .header_tqbox
    .p( '<div class="tipslist half-line-bottom"><div id="js_tipslist"></div>' ) // start .tipslist
    .p( '</div>' ); // end .tipslist
    return str.str;
}
/*
    天气模块
*/
POI.mod.index_weather = function( dt , cityName) {
    var str = POI.util.get_arr(),
        xianxing = (dt.traffic_restrict||{}).plate_no||'',
        shiyi = (dt.car_washing||{}).desc||'';
    str.p( '<div id="js_header_tqfixed">' ).p( '<div class="header_tq">' )
    .p( '<em>'+ ( xianxing ? '今日限行'+xianxing.replace(/,/g, '/') : '不限行') +'</em>' )
    .p( '<em class="header_tq_right">'+ (cityName||'') +'<i class="header_tq_icon"'+ ( dt.image_url?' style="background-image:url('+dt.image_url+')"' : '') +'></i>'+(dt.temperature?dt.temperature+'°':'')+shiyi+'</em>' )
    .p( '</div></div>' );
    setTimeout( function(){
        $('#js_header_tqfixed').parent().addClass( 'show' );
        POI.browser.and && POI.fix_weather();
    }, 1);
    return str.str;
}
/*
    滚动tips模块
*/
POI.mod.index_tips = function( dt, xianxing) {
    var str = POI.util.get_arr(),
        result = dt.data || {},
        plateNum = result.plateNum||'',
        map = {},
        plateNum_fig,
        num = 0,
        pushAlert = result.pushAlert||[];
    xianxing = xianxing.split( ',' );
    xianxing.forEach(function( item ){
        map[item] = 1;
    });
    plateNum_fig = plateNum && map[plateNum.charAt(plateNum.length-1)];//标志是否有限行信息
    if( plateNum_fig || pushAlert.length) {
        str.p( '<div id="js_tipslist">' )
        .p( '<ul class="tipslist_ul">' );
        if( plateNum_fig ) {//限行尾号和车牌尾号对应就显示限行提示
            str.p( '<li class="tipslist_li"><i class="tipslist_xx half-border">限行</i><p class="lineDot">您的'+ plateNum +'车辆，今日限行</p><em class="icon canTouch" js_handle="js_search_bus" typ="0">查看公交</em></li>' );// 这里的typ只为埋点
            num = 1;
        }
        pushAlert.forEach( function( item ) {
            //1：违章 2：驾照 3：年检
            if( item.content ){
                if( item.type == 1 ){
                    str.p( '<li class="tipslist_li"><i class="tipslist_wz half-border">违章</i><p class="lineDot">'+ item.content +'</p>'+ (result.url ? '<em class="icon canTouch" js_handle="js_go_weizhanglist" url="'+ result.url +'" typ='+item.type+'"">点击查看</em>' : '') +'</li>' );
                } else {
                    var type = item.type == 2 ? 3 : item.type == 3 ? 2 : item.type;
                    str.p( '<li class="tipslist_li"><i class="tipslist_tx half-border">提醒</i><p class="lineDot">'+ item.content +'</p><em class="icon canTouch" js_handle="js_openTips" typ="'+type+'">点击查看</em></li>' );
                }
                num +=1;
            }
        } );
        str.p( '</ul></div>' );
    }
    num && setTimeout(function(){
       $( '#js_tipslist' ).parent().addClass( 'show' );
       num>1 && POI.init_tipslist( num ); 
    },1);
    return num ? str.str : '';
}
/*
    头部下面的大按钮
*/
POI.mod.index_nav = function(){
    return '<section class="btnlist half-line-bottom half-line-top"><div class="btnlist_wz canTouch" js_handle="js_go_wzcx">违章查询<p class="icon"><i class="icon"></i></p></div><div class="btnlist_yc canTouch" js_handle="js_go_yctx">用车提醒<p class="icon"><i class="icon"></i></p></div><div class="btnlist_order canTouch" js_handle="js_go_myorder">我的订单<p class="icon"><i class="icon"></i></p></div></section>';
}

/*
    广告模块
*/
POI.mod.index_banner = function( data ) {
    var str = POI.util.get_arr(),
        w = $(window).width(),
        num =0,
        result = data.data || [];
    if( result.length ) {
        str.p( '<section class="adslist" id="js_banner_imglist"><ul style="width:{width}px;">' );
        result.forEach( function( item, i ) {
            item.resource = item.resource || [{}];
            if( (item.resource[0]||{}).content && item.action.url){
                str.p( '<li class="img-loading" url="'+ (item.resource[0]||{}).content +'" style="width:'+ w +'px" act="'+ (item.action.url || '') +'" js_handle="js_go_banner" adid="'+item.id+'"></li>' );
                num++;
            }
        } );
        str.p( '</ul>' );
        num>1 && str.p( '<p><i class="selected">' + ( new Array(num) ).join('</i><i>') + '</i></p>' );
        str.p( '</section>' );
        setTimeout(function(){
            POI.init_banner(num);
        },1);
    }
    return num ? str.str.replace('{width}', num * w) : '';
}
/*
    冬季推荐
    上门保养模块
*/
/*
            <article>
                <h2 class="modules_title line-btm-f0">上门保养</h2>
                <div class="module_catlist">
                    <p class="lineDot canTouch">空调保养</p>
                    <p class="lineDot canTouch line-left-f0">机油三滤</p>
                    <p class="lineDot canTouch line-left-f0">刹车片</p>
                </div>
                <div class="module_catlist">
                    <p class="lineDot canTouch module_catlist_tj">玻璃安全防护镀膜</p>
                    <p class="lineDot canTouch line-left-f0 module_catlist_hot">发动机舱清洗</p>
                </div>
            </article>
*/
POI.mod.index_cat = function( data ) {
    var str = POI.util.get_arr(),
        season_recommend = data.season_recommend || {},
        rec = season_recommend.data && season_recommend.data.length,
        door_service = data.door_service || {},
        door = (door_service.short_item && door_service.short_item.length) || (door_service.long_item && door_service.long_item.length),
        tag_class = {1:' module_catlist_tj', 2:' module_catlist_dj', 3: ' module_catlist_hot'},
        index;
    if( data.code == 1 && ( rec || door )) {
        str.p( '<section class="modules half-line-top">' )
        if( rec ) {
            str.p( '<article class="modules_tj">' )
            .p( season_recommend.name ? '<h2 class="modules_title line-btm-f0">'+ season_recommend.name +'</h2>' : '' )
            .p( '<div class="modules_items line-btm-f0">' )
            season_recommend.data.forEach( function( item , i ) {
                str.p( '<p class="modules_item canTouch'+ ( i > 0 ? '  line-left-f0' : '') +'" kwd="'+ item.keyword +'" js_handle="js_go_prolist">' )
                .p( '<em>'+ (item.title||'') +'<br/><i>'+ ( item['sub-title'] || '') +'</i></em>' )
                .p( '<img src="'+ item.icon +'" />' );
                index = i;
            } );
            if( index < 2 ){
                str.p( ( new Array(2-index+1) ).join( '<p class="modules_item"></p>' ) );
            }
            str.p( '</div>' ).p( '</article>' );
        }
        if( door ) {//上门保养模块
            str.p( '<article class="modules_by">' );
            str.p( door_service.name ? '<h2 class="modules_title line-btm-f0">'+ door_service.name +'</h2>' : '');
            if( door_service.short_item && door_service.short_item.length ) {
                door_service.short_item.forEach( function( item, i) {
                    i%3 ==0 && str.p( '<div class="module_catlist line-btm-f0">' );
                    str.p( '<p class="lineDot canTouch'+ (tag_class[item.tag]||'')+ ( i%3 !=0 ? ' line-left-f0' : '') +'" kwd="'+ item.keyword +'" js_handle="js_go_prolist">'+ (item.title || '') +'</p>' );
                    i%3==2 && str.p( '</div>' );
                    index = i;
                } );
                index = 2-index%3;
                if( index ){
                    str.p( (new Array(index+1)).join( '<p class="lineDot"></p>' ))
                    .p( '</div>' );
                }
                index = 0;
            }
            if( door_service.long_item && door_service.long_item.length ) {
                door_service.long_item.forEach( function( item, i) {
                    i%2 ==0 && str.p( '<div class="module_catlist line-btm-f0">' );
                    str.p( '<p class="lineDot canTouch'+ (tag_class[item.tag]||'')+ ( i%2 ==1 ? ' line-left-f0' : '') +'" kwd="'+ item.keyword +'" js_handle="js_go_prolist">'+ (item.title || '') +'</p>' );
                    i%2==1 && str.p( '</div>' );
                    index = i;
                } );
                if( index % 2 == 0 ) {
                    str.p( '<p class="lineDot"></p>' )
                    .p( '</div>' );
                }
            }
            str.p( '</article>' );
        }
        str.p( '<section>' );
    }
    return str.str;
}