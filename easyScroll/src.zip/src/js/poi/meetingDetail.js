/*会议详情*/
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'meetingDetail',
    handleAttr : 'js_handle',
    
    toggleDetail : function() {
        var toggleDetail = $("#toggleDetail");
        var meetingIntroDetail = $("#meetingIntroDetail");
        if(meetingIntroDetail.hasClass("linesDot")) {
            meetingIntroDetail.removeClass("linesDot");
            toggleDetail.text("收起");
        } else {
            meetingIntroDetail.addClass("linesDot");
            toggleDetail.text("查看全文");
        }
    },
    
    showMeetingHeader : function(activity) {
        var toggleStr = '<a id="toggleDetail" class="meeting_intro_detail_toggle" href="javascript:void(0);">查看全文</a>';
        var str = '<h1 class="meeting_title">' + activity.name + '</h1>' +
                  (POI.util.bool(activity.intro) ? 
                  '<div class="meeting_intro line-half">' +
                      '<p class="meeting_intro_title">简介</p>' +
                      '<div id="meetingIntroDetail" class="meeting_intro_detail linesDot">' +
                          '<p>' + activity.intro + '</p>' +
                      '</div>' +
                  '</div>' : '') +
                  '<div class="meeting_info">' +
                      ((activity.date || activity.price) ? '<p class="meeting_info_title">会议信息</p>' : '') +
                      (activity.admi_time ? '<p class="meeting_info_date">入场时间：' + activity.admi_time + '</p>' : '') +
                      (activity.date ? '<p class="meeting_info_date">会议时间：' + activity.date + '</p>' : '') +
                      (activity.price ? '<p class="meeting_info_price">票价：<span>' + activity.price + '</span></p>' : '') +
                  '</div>';
        $("#meetingBase").html(str);
        
        var _detailMain = $("#meetingIntroDetail p");
        var _lineHeight = parseInt(_detailMain.css("line-height"));
        var _height = parseInt(_detailMain.height());
        if(0 !== _height % _lineHeight) {
            $(".meeting_intro").append(toggleStr);
            $("#toggleDetail").on("click", this.toggleDetail);
        }
        
    },
    
    meetingSchedule : function(activity) {
        if(activity.meeting_info && activity.meeting_info.length) {
            var meetingSchedule = $("#meetingSchedule");
            var str = '';
            for(var i = 0, len = activity.meeting_info.length, item = null; i < len; i++) {
                item = activity.meeting_info[i];
                str += '<li class="meeting_schedule_li line-half">' +
                           '<p class="meeting_schedule_subtitle">' + item.topic + '</p>' +
                           '<div class="meeting_schedule_detail clearfix">' +
                               (item.date ? '<p class="meeting_schedule_time"><i class="mstime"></i>' + item.date + '</p>' : '') +
                               (item.place ? '<p class="meeting_schedule_place"><i class="msplace"></i>' + item.place + '</p>' : '') +
                               (item.speaker ? '<p class="meeting_schedule_author"><i class="msauthor"></i>' + item.speaker + '</p>' : '') +
                           '</div>' +
                       '</li>';
            }
            if(str) {
                str = '<p class="meeting_schedule_title">会议日程</p>' +
                      '<ul>' + str + '</ul>';
                meetingSchedule.html(str);
            }
        }
    },
    
    showMeetingDetalilPage : function(activity) {
        this.showMeetingHeader(activity);
        this.meetingSchedule(activity);
    },
    
    quickInit : function(){
        var aosData = POI.aosData || POI.util.getStorageData() || {};
        var idx = POI.util.getUrlParam("idx") | 0;
        var activity = aosData.rti.activity[idx];
        this.showMeetingDetalilPage(activity);
    }
});

})(POI, Zepto);