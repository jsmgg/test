(function(POI, $) {
'use strict';
/** 酒店相关逻辑 */
$.extend(POI, {
    logPageId: 'hotelOrderComplete',
    /**
     * 将日期格式化为 'MM-dd'.
     * @param {Date} 格式化的日期
     * @return {String} 格式化后的字符串
     */
    _formatHotelDate: function(date) {
        return date.replace(/\d+-0?(\d{1,2})-0?(\d{1,2})/, '$1月$2日');
    },
    /**
     * 获取酒店付款类型.
     * @param {String} type 酒店信息的 paytype 值
     * @return {String} 付款类型名称
     */
    _payTypeText: function(type) {
        var arr = ['现付', '担保', '预付'];
        return arr[type] || '';
    },

    _showCashBack: function() {
        POI.api.userAction('hotel-cashback');
        if ( $('#lockBg').length ) {
            $('#lockBg').show();
            $('#bottomMsg').show();
            return;
        }
        $('<div/>').attr('id', 'lockBg').appendTo('body');
        $('<div/>').attr('id', 'bottomMsg').addClass('topMsg')
            .text(POI.rule_content).appendTo('body');
        $('#lockBg').height( $(document).height() ).show().click(function() {
            $(this).hide();
            $('#bottomMsg').hide();
        });
        $('#lockBg,#bottomMsg').on('touchmove', function(event) {
            event.preventDefault();
        });
    },
    quickInit: function() {
        var oid = this.util.getUrlParam('oid');
        // 订单中新详情页面无oid
        if (!oid) {
            if (this.browser.ios) {
                this.send({action: 'openHotelOrderDetail'}, this.orderCenterDetail);
            } else {
                this.send({action: 'openHotelDetail'}, this.orderCenterDetail);
            }
            this.logPageId = 'exHotelOrderDetail';
            return;
        }
        var info = JSON.parse( this.util.storage('hotel.roomInfo') );
        var params = [
            {type: 'hotel', sign: 1},
            {src_type: info.src_type, sign: 1},
            {oid: oid, sign: 1}
        ];

        // 点击订单中心按钮，呼起订单中心
        $('#orderEntry').click(function() {
            POI.send({
                action: 'orderFeature',
                feature: 'hotel'
            });
            POI.api.userAction('hotel-myorder');
        });
        POI.api.aosrequest('hotelOrderInfo', params, function(res) {
            POI.orderDetail(res);
        }, 1, true);

        // 未登录时不显示“我的订单”按钮
        POI.send({action: 'getAmapUserId', onlyGetId: '1'}, function(res) {
            if (res.userid) {
                $('body').removeClass('no-order-btn');
            }
        });
    },
    getOrderStatus: function(status) {
        var info = {
            1001: '新订处理中',
            1002: '已取消',
            1003: '已拒单',
            1004: '新订已确认',
            1005: '预订未到',
            1006: '已入住',
            1007: '已离店'
        };
        return info[status];
    },
    orderDetail: function(res) {
        if (res.code != 1 || !res.order) {
            return;
        }

        var detail = res.order.detail;
        // 无订单号时隐藏相应的行
        if (!detail.serialId) {
            $('#serialId').parent().hide();
        }
        if (parseInt(detail.prizeAmount)) {
            $('#prizeAmount').parent().show();
            this.rule_content = detail.prizeTips;
            // 查看返现说明
            $('#prizeAmount').next().on('click', this._showCashBack);
        }
        var currency = detail.currency || '￥';
        var obj = {
            orderStatus: this.getOrderStatus(res.order.status),
            serialId: detail.serialId,
            src_name: res.order.src_name,
            arriveTime: detail.arriveTime,
            order_time: res.order.order_time,
            orderAmount: '<code>' + currency + '</code>' + detail.orderAmount,
            prizeAmount: '<code>' + currency + '</code>' + detail.prizeAmount,
            payType: this._payTypeText(detail.payType),
            hotelName: detail.hotelName,
            bedName: (detail.roomName ? detail.roomName + ' &nbsp; ' : '') +
                (detail.bedName || ''),
            comeDate: this._formatHotelDate(detail.comeDate),
            leaveDate: this._formatHotelDate(detail.leaveDate),
            rooms: detail.rooms,
            contactName: detail.contactName,
            contactMobile: detail.contactMobile,
            src_tel: res.order.src_tel,
            src_name2: res.order.src_name
        };
        for (var key in obj) {
            $('#' + key).html(obj[key]);
        }
        // 路线规划
        $('#goHotel').click(function() {
            var self = POI;
            var poiInfo = self.util.getStorageData().base;
            self.api.searchRoute(null, poiInfo);
            self.api.userAction('hotel-go');
        });

        if (!detail.hotelTel) {
            $('#planChangeInfo').hide();
        } else {
            var phoneList = detail.hotelTel.split(';');
            var phoneStr = phoneList[0];
            if (phoneList.length > 1) {
                phoneStr += '...';
            }
            $('#hotelTel').click(function() {
                POI.api.showPanellist(phoneList);
                POI.api.userAction('hotel-tel');
            }).text(phoneStr);
        }
        // 拨打电话
        $('#src_tel').click(function() {
            var phones = $(this).text();
            var arr = phones.trim().split(';');
            POI.api.showPanellist(arr);
            POI.api.userAction('ota-tel');
        });
    },
    orderCenterDetail: function(obj) {
        var params = [
            {type: obj.type, sign: 1},
            {src_type: obj.src_type, sign: 1},
            {oid: obj.oid, sign: 1}
        ];
        POI.api.aosrequest('hotelOrderInfo', params, function(res) {
            POI.orderDetail(res);
        }, 1, true);
    }
});

})(POI, $);
