(function(POI, $) {

'use strict';

$.extend(POI, {
    living_arr: [],
    showEasyHtml: function( deep ) {
        var that = this;
        var ul_arr = [];
        var trans_str = '';
        var dining_str = '';
        var rest_str = '';
        var busi_str = '';
        
        if (POI.util.bool(deep.index_trans) === true) {
            ul_arr.push('index_trans');
            that.living_arr.push({
                'score': deep.index_trans.score || '',
                'name': '出行'
            });

            trans_str = that.makeTransArticle(deep);//生成article
        }
        
        if (POI.util.bool(deep.index_dining) === true) {
            ul_arr.push('index_dining');
            that.living_arr.push({
                'score': deep.index_dining.score,
                'name': '美食'
            });
            dining_str = that.makeDiningArticle(deep);//生成article
        }

        if (POI.util.bool(deep.index_rest) === true) {
            ul_arr.push('index_rest');
            that.living_arr.push({
                'score': deep.index_rest.score,
                'name': '休闲'
            });
            rest_str = that.makeRestArticle(deep);//生成article
        }

        if (POI.util.bool(deep.index_busi) === true) {
            ul_arr.push('index_busi');
            that.living_arr.push({
                'score': deep.index_busi.score,
                'name': '购物'
            });
            busi_str = that.makeBusiArticle(deep);//生成article
        }
        
        if (ul_arr.length < 1) {
            POI.headerToolBar.hotelaround_flag = true;
            return '';
        }

        var first_section = ul_arr.length > 1?'<section class="easy" id="hotel_easy"><h2 class="module_title_p divide-line">便利指数</h2>':'<section class="easy" id="hotel_easy"><h2 class="module_title_p divide-line">便利指数<span>&nbsp;—&nbsp;</span><span class="easy-info">'+that.living_arr[0].name+'&nbsp;'+that.living_arr[0].score+'</span></h2>';
            
        var last_section = '</section>';
        var ul_str = ul_arr.length > 1?that.makeEasyUl(ul_arr):'';
        POI.api.userAction('show_easy');
        //设置导航栏
        POI.headerToolBar.hotelaround_flag = true;
        POI.headerToolBar.poiHotelToolBar({class_name:'header_around', title: '周边'});
        return first_section+ul_str+trans_str+dining_str+rest_str+busi_str+last_section;
    },
    makeEasyUl: function(arr) {
        var that = this;
        var ul_arr = [];
        var pre_ul = '<ul class="easy_list divide-line">';
        var last_ul = '</ul>';
        var ratio = window.devicePixelRatio | 2;
        var canvasWidth = 66;
        var canvasHeight = 66;
        for (var i=0; i<arr.length; i++) {
            var class_str = i==0?' class="on"':'';
            var li_str = '<li class="easy_item" rel="#'+arr[i]+'">'+
                         '<p'+class_str+'><canvas width="' + canvasWidth + '" height="' + canvasHeight + '"></canvas></p>'+
                         '</li>';
            ul_arr.push(li_str);
        }
        
        return pre_ul+ul_arr.join('')+last_ul;
    },
    makeTransArticle: function( deep ) {
        var that = this;
        var obj = deep.index_trans;
        var subway_arr = [];
        var station_str = '';
        var airport_str = '';

        if (POI.util.bool(obj.subway) === true) {
            var subway_num = obj.subway.length > 3?3:obj.subway.length;

            for (var i=0; i<subway_num; i++) {
                var str = '<button>'+obj.subway[i].name+'</button>';
                subway_arr.push(str);
            }

        }
        
        if (POI.util.bool(obj.station) === true) {
            station_str = '<button>'+obj.station.name+'&nbsp;'+obj.station.distance+'公里</button>';            
        }
        
        if (POI.util.bool(obj.airport) === true) {
            airport_str = '<button>'+obj.airport.name+'&nbsp;'+obj.airport.distance+'公里</button>';
        }
        
        var pre_p = '<article id="index_trans" class="living_cont">';
        var last_p = '</article>';

        var p1 = subway_arr.length > 0 ?'<p class="subway divide-line more" data-name="地铁站">'+'<button class="num_subway">'+obj.num_subway+'个地铁站</button>'+subway_arr.join('')+'</p>':'';
        
        var p2 = station_str.length > 0?'<p class="bus divide-line more" data-name="火车站">'+'<button class="num_bus">火车站</button>'+station_str+'</p>':'';

        var p3 = airport_str.length > 0?'<p class="bus divide-line more" data-name="飞机场">'+'<button class="num_bus">飞机场</button>'+airport_str+'</p>':'';
        
        return pre_p+p1+p2+p3+last_p;

    },
    makeDiningArticle: function( deep ) {
        var that = this;
        var obj = deep.index_dining.dining_detail;
        if(!obj) {
            return '';
        }
        
        var chinese_arr = [];
        var western_arr = [];
        var fast_arr = [];
        var chinese_num = '';
        var western_num = '';
        var fast_num = '';
        
        for (var i=0; i<obj.length; i++) {
            if (obj[i].dining_type === '中餐') {
                if (chinese_arr.length === 3) {
                    return;
                }
                chinese_arr.push('<button>'+obj[i].name+'</button>');
                chinese_num = obj[i].num;
            } else if (obj[i].dining_type === '异国美食') {
                if (western_arr.length === 3) {
                    return;
                }
                western_arr.push('<button>'+obj[i].name+'</button>');
                western_num = obj[i].num;
            } else if (obj[i].dining_type === '快餐') {
                if (fast_arr.length === 3) {
                    return;
                }
                fast_arr.push('<button>'+obj[i].name+'</button>');
                fast_num = obj[i].num;
            }
        }

        var pre_p = '<article id="index_dining" class="living_cont hide">';
        var last_p = '</article>';

        var p1 = chinese_arr.length > 0?'<p class="bus divide-line more" data-name="中餐">'+
                 '<button class="num_bus">'+chinese_num+'家中餐厅</button>'+
                 chinese_arr.join('')+
                 '</p>':'';
        
        var p2 = western_arr.length > 0?'<p class="bus divide-line more" data-name="外国餐厅">'+
                 '<button class="num_bus">'+western_num+'家外国餐厅</button>'+
                 western_arr.join('')+
                 '</p>':'';

        var p3 = fast_arr.length > 0?'<p class="bus divide-line more" data-name="快餐">'+
                 '<button class="num_bus">'+fast_num+'家快餐厅</button>'+
                 fast_arr.join('')+
                 '</p>':'';

        return pre_p+p1+p2+p3+last_p;
    },
    makeRestArticle: function( deep ) {
        var that = this;
        var obj = deep.index_rest.rest_detail;
        if(!obj) {
            return '';
        }

        var viewpoint_arr = [];
        var recreation_arr = [];
        var theater_arr = [];
        var viewpoint_num = '';
        var recreation_num = '';
        var theater_num = '';

        for (var i=0; i<obj.length; i++) {
            if (obj[i].rest_type === '景点') {
                if (viewpoint_arr.length === 3) {
                    return;
                }
                viewpoint_arr.push('<button>'+obj[i].name+'</button>');
                viewpoint_num = obj[i].num;
            } else if (obj[i].rest_type === '娱乐') {
                if (recreation_arr.length === 3) {
                    return;
                }
                recreation_arr.push('<button>'+obj[i].name+'</button>');
                recreation_num = obj[i].num;
            } else if (obj[i].rest_type === '影剧院') {
                if (theater_arr.length === 3) {
                    return;
                }
                theater_arr.push('<button>'+obj[i].name+'</button>');
                theater_num = obj[i].num;
            }
        }

        var pre_p = '<article id="index_rest" class="living_cont hide">';
        var last_p = '</article>';

        var p1 = viewpoint_arr.length > 0?'<p class="bus divide-line more" data-name="景点">'+
                 '<button class="num_bus">'+viewpoint_num+'个公园景点</button>'+
                 viewpoint_arr.join('')+
                 '</p>':'';

        var p2 = recreation_arr.length > 0?'<p class="bus divide-line more" data-name="娱乐">'+
                 '<button class="num_bus">'+recreation_num+'个娱乐场所</button>'+
                 recreation_arr.join('')+
                 '</p>':'';

        var p3 = theater_arr.length > 0?'<p class="bus divide-line more" data-name="影剧院">'+
                 '<button class="num_bus">'+theater_num+'个影剧院</button>'+
                 theater_arr.join('')+
                 '</p>':'';

        return pre_p+p1+p2+p3+last_p;
    },
    makeBusiArticle: function( deep ) {
        var that = this;
        var obj = deep.index_busi.busi_detail;
        if(!obj) {
            return '';
        }
        var mall_arr = [];
        var supermarket_arr = [];
        var street_arr = [];
        var mall_num = '';
        var supermarket_num = '';
        var street_num = '';

        for (var i=0; i<obj.length; i++) {
            if (obj[i].busi_type === '购物中心') {
                if (mall_arr.length === 3) {
                    return;
                }
                mall_arr.push('<button>'+obj[i].name+'</button>');
                mall_num = obj[i].num;
            } else if (obj[i].busi_type === '超市') {
                if (supermarket_arr.length === 3) {
                    return;
                }
                supermarket_arr.push('<button>'+obj[i].name+'</button>');
                supermarket_num = obj[i].num;
            } else if (obj[i].busi_type === '特色商业街') {
                if (street_arr.length === 3) {
                    return;
                }
                street_arr.push('<button>'+obj[i].name+'</button>');
                street_num = obj[i].num;
            }
        }
        
        var pre_p = '<article id="index_busi" class="living_cont hide">';
        var last_p = '</article>';

        var p1 = mall_arr.length > 0?'<p class="bus divide-line more" data-name="购物中心">'+
                 '<button class="num_bus">'+mall_num+'个购物中心</button>'+
                 mall_arr.join('')+
                 '</p>':'';

        var p2 = supermarket_arr.length > 0?'<p class="bus divide-line more" data-name="超市">'+
                 '<button class="num_bus">'+supermarket_num+'个超市</button>'+
                 supermarket_arr.join('')+
                 '</p>':'';

        var p3 = street_arr.length > 0?'<p class="bus divide-line more" data-name="特色商业街">'+
                 '<button class="num_bus">'+street_num+'条特色商业街</button>'+
                 street_arr.join('')+
                 '</p>':'';
        
        return pre_p+p1+p2+p3+last_p;
    },
    //周边搜索
    searchCategory: function(name) {
        var obj = {
            'action': 'searchCategory',
            'category': name,
            'poiInfo': POI.clientData.poiInfo
        };

        POI.send(obj);
    },
    addEventToClick: function() {
        var that = this;
        //点击便利指数中的P
        $('.living_cont p').on('click', function() {
            var name = $(this).data('name');
            
            if (!name) {
                return;
            }
            POI.api.userAction('easyTypeList', {name:name});
            that.searchCategory(name);
        });

        $('.easy_list').on('click', 'li', function() {
            var li = $(this);

            if (li.length) {
                li.find('p').addClass('on');
                li.siblings().find('p').removeClass('on');
                var rel = li.attr('rel');

                $(rel).removeClass('hide')
                        .siblings('article').addClass('hide');
                var poiid = POI.aosData.base.poiid;
                POI.api.userAction('easyType', {type_poiid: rel.substr(1)+'_'+poiid});
            }
        });

    },
    showHotelAroundHtml: function() {
        var that = this;

        var params = [
            {'pagenum':1},
            {'pagesize':5},
            {'longitude':POI.clientData.poiInfo.lon,sign:1},
            {'latitude':POI.clientData.poiInfo.lat,sign:1},
            {'category':'10',sign:1},
            {'cmspoi':'1'},
            {'query_type':'RQBXY'},
            {'range':'5000'},
            {'sort_rule':'5'},//按好评排序
            {'sort_fields':'rating:D'}//按好评排序
        ];

        POI.util.executeAfterDomInsert(function() {
            POI.api.aosrequest('nearbyRoomType', params, function(data) {
                var html;
                if (data.code != 1 || !data.poi_list || !data.poi_list.length) {
                    
                } else {
                    html = that.makeHotelAroundHtml(data);
                    $('#hotelAround').replaceWith(html);
                    
                    //重新设置图片
                    
                    var li_arr = $('.around-list li');
                    
                    for (var i=0; i<li_arr.length; i++) {
                        var item = $(li_arr[i]);

                        if (item.find('.hotel_img').data('img') !== undefined) {
                            var url = item.find('.hotel_img').data('img');

                            new POI.util.loadImage(url, item.find('.hotel_img')[0], function(elem, _img) {
                                var img_obj = $(elem);
                                img_obj.html('<img src="'+_img.getAttribute("src")+'" alt=""/>');
                            }, function(elem){});
                        }
                    }
                }
            });
        });

        return '<div id="hotelAround"></div>';
    },
    //对象数组排序方法
    bySort: function( name ) {
        return function(o, p) {
            var a, b;
            if (typeof o === "object" && typeof p === "object" && o && p) {
                a = o[name];
                b = p[name];
                if (a === b) {return 0;}
                if (typeof a === typeof b) { return a < b ? -1 : 1;}
                return typeof a < typeof b ? -1 : 1;
            }          
            else {}
        }
       
    },
    makeHotelAroundHtml: function(res) {
        var that = this;
        var handleAttr = POI.handleAttr;
        var arr = res.poi_list;
        var new_arr = [];
        var li_arr = [];
        
        var pre_section = '<section class="hotelAround">'+
                          '<h2 class="module_title_p divide-line">附近推荐酒店</h2>'+
                          '<ul class="around-list">';

        var last_section = '</ul><div class="search_hotel" '+handleAttr+'="js_goToMoreHotel">更多附近酒店</div></section>';

        for (var i=0; i<arr.length; i++) {
            var obj = arr[i];
            if (obj.cmspoi && obj.cmspoi.hotel) {
                if (obj.id === POI.aosData.base.poiid) {

                } else {
                    obj.distance = parseFloat(obj.distance);
                    new_arr.push(obj);
                }
            }

        }
        
        new_arr.sort(that.bySort('distance'));
        var arr_length = new_arr.length > 3? 3 : new_arr.length;
        
        for (var i=0; i<arr_length; i++) {
            var obj = new_arr[i];
            
            var hotel = obj.cmspoi.hotel;
            var imgurl = obj.cmspoi.pic_list && obj.cmspoi.pic_list[0];
            var star_w = Math.floor((obj.rating/5)*100)+'%';
            var star_html = '<span class="highlight" style="width:'+star_w+';"></span>';
            imgurl = POI.util.imageUrlTransform(imgurl, 80, 80);
            if (imgurl) {
                var img_html = '<div class="hotel_img" data-img="'+imgurl+'"></div>';
            } else {
                var img_html = '<div class="hotel_img"></div>';
            }
            
            var price_html = String(hotel.lowestprice).length > 0?'<span class="price">¥'+hotel.lowestprice+'<i>起</i></span>':'<span class="no-price">暂无报价</span>';

            var wifi_html = String(hotel.wifi) === '1'?'<span class="wifi"></span>':'';
            var parking_html = String(hotel.park_type) === '1'?'<span class="parkingstyle"></span>':'';
            var group_html = String(obj.group_flag) === '1'?'<img src="img/groupbuy.png"/>':'';
            var distance = that.formatKilometer(obj.distance);
            
            var li_str = '<li class="clearfix divide-line" data-poi=\''+JSON.stringify(obj)+'\'  '+handleAttr+'="js_goToPoiInfo">'+
                         img_html+
                         '<aside class="right">'+
                         '<h3 class="hotel-name">'+(i+1)+'. '+obj.name+group_html+'</h3>'+
                         '<div class="hotel-level">'+
                         '<span class="hotel-num">'+star_html+'</span>'+
                         '<span class="level_name">'+hotel.star+'</span>'+
                         wifi_html+
                         parking_html+
                         '</div>'+
                         '<div class="hotel-info">'+
                         price_html+
                         '<span class="distance">'+distance+
                         '</span>'+
                         '</div>'+
                         '</aside>'+
                         '</li>';
            li_arr.push(li_str);

        }
        
        return pre_section+li_arr.join('')+last_section;
    },
    js_goToPoiInfo: function(obj) {
        var poi_obj = obj.data('poi');
        var poiid = poi_obj.id;
        var name = poi_obj.name;
        var address = poi_obj.address;
        var citycode = poi_obj.citycode;
        var newType = poi_obj.newtype;
        var tel = poi_obj.tel;
        var lon = poi_obj.longitude;
        var lat = poi_obj.latitude;
        var status = '1';
        if (!poiid) {
            return;
        }

        POI.api.openPoiInfo(poiid, name, address, citycode, newType, tel, lon, lat, status);
        POI.api.userAction('hotelList', {poiid_name:poiid+'_'+name});
    },
    js_goToMoreHotel: function() {
        var that = this;
        that.searchCategory('酒店');
        POI.api.userAction('moreHotel');
    },
    formatKilometer: function(meter) {
        meter = parseFloat(meter);
        if (meter < 0 || !meter) {
            return '';
        }
        if (meter < 1000) {
            return meter.toFixed(0) + ' 米';
        }
        return (meter / 1000).toFixed(1) + ' 公里';
    },
    
    HotelPageList: function(hotelPicStr, easyStr, hotelStr, infoHtml) {
        var that = this;
        var allAry = that.index.moduleAll(['alipayDiscount', 'sendComment', hotelPicStr, 'rti', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', infoHtml, 'impression', 'commentInfo', easyStr, 'indoorMap', hotelStr, 'placeContribution']);
        that.pagebody.html(allAry.join(''));
        POI.util.executeAfterDomInsert();

        [].slice.call(document.querySelectorAll('.easy_list canvas'),0).forEach(function( item , i){
                new POI.util.DrawPie(item , that.living_arr[ i ]);
                that.browser.and && that.circleCanvas_hack(item);
            });

        that.addEventToClick();
    },
    circleCanvas_hack : function(item){
        window.addEventListener('pageshow',function(){
            if($(item).length==0)return;
            var k = 'js_test'+parseInt(Math.random()*100);
            $('body').append('<div id="'+k+'" style="display:none;"></div>');
            $('#'+k).remove();
            $(item)[0].toDataURL("image/png");
        },false);
        
    },
    init: function() {
        var self = this;
        var deep = self.aosData.deep[0];
        var price = deep.price;
        if (price) {
            price = '￥' + price + '起';
        }
        // 酒店星级
        if (deep.star) {
            var hotelStar = parseInt(deep.star);
        }
        var tags = '';
        if (POI.aosData.base.std_t_tag_0_v) {
            var arr = POI.aosData.base.std_t_tag_0_v.split(';');
            for (var i=0; i<arr.length; i++) {
                tags += self.index.moduleHeadItem(arr[i]);
            }
        }
        var hotelPicStr = '';
        var infoHtml = '';
        var installation = '';

        if (self.business == 'hotel') {
            // 酒店设施
            installation = self.index.introInstallation(deep.detail_facilities + '|' + deep.service,1);
            if(hotelStar && hotelStar > 3){
                hotelPicStr = '<section>' +
                              '<h2 id="baseIntro" class="module_title_p hotel_title_p more">设施详情' + installation + '</h2>' +
                              '</section>';
            } else {
                var titleStr = '';
                if(deep.detail_facilities || deep.service) {
                    titleStr = '<h2 id="baseIntro" class="module_title_p hotel_title_p more">设施详情' + installation + '</h2>';
                } else {
                    if(deep.keys) {
                        if(deep.keys.intro || deep.keys.service_dinning || deep.keys.service_meeting || deep.keys.service_room || deep.keys.surrounding) {
                            titleStr = '<h2 id="baseIntro" class="module_title_p hotel_title_p more">设施详情' + installation + '</h2>';
                        }
                    }
                }
                hotelPicStr += '<section class="hotel-pic">' + titleStr;
                hotelPicStr += '</section>';
            }
        } else {
            // 酒店设施
            installation = self.index.introInstallation(deep.detail_facilities + '|' + deep.service);
            infoHtml = self.index.moduleIntro(['酒店图片', '酒店介绍', '酒店服务'], ['service', 'service_dinning', 'service_meeting', 'service_room', 'surrounding'], installation);
        }
        this.index.moduleDeepHead(tags, price);
        
        this.HotelPageList(
            hotelPicStr,
            this.showEasyHtml(deep),
            this.showHotelAroundHtml(),
            infoHtml
        );
    }
});

})(POI, $);
