(function(POI, $) {
'use strict';
/** 酒店相关逻辑 */
$.extend(POI, {
    logPageId: 'hotelOrderFill',
    /**
     * 将日期格式化为 'MM-dd'.
     * @param {Date} 格式化的日期
     * @return {String} 格式化后的字符串
     */
    _formatHotelDate: function(date) {
        return date.replace(/\d+-0?(\d{1,2})-0?(\d{1,2})/, '$1月$2日');
    },


    /** 订单填写页面初始化. */
    quickInit: function() {
        var self = this;
        var info = JSON.parse( self.util.storage('hotel.roomInfo') );
        self.roomDetail = info;
        var moneyFlag = POI.util.moneyFlag(info.Currency);
        $('#orderSubmit code').text( moneyFlag );
        // 显示返现规则、金额
        if (info.Upperlimit > 0) {
            $('#reminderInfo > span').text(info.rule_content);
            $('#reminderInfo').show();
            $('#orderSubmit span').text(moneyFlag).parent().show();
        }
        $('#orderForm > h4').text( self.util.getStorageData().base.name );
        $('#roomInfo .lineDot').text(info.RoomTypeName);
        $('#comeDate').text('入住:' + self._formatHotelDate(info.comeDate));
        $('#leaveDate').text('离店:' + self._formatHotelDate(info.leaveDate));
        $('#agentInfo').text('代理商：' + info.src_name);
        var num = info.room_num;
        // 按数据显示可选的房间数量
        var roomHtml = [], selectArr = ['<select>'];
        for (var i = 1; i <= num; i++) {
            selectArr.push('<option value="' + i + '">' + i + '间</option>');
            roomHtml.push('<article><h3>入住人' + i + '</h3><div><input placeholder="请输入姓名"/></div></article>');
        }
        selectArr.push('</select>');
        $('#roomInfo').append( roomHtml.join('') );
        // 根据选择的房间数量显示相应数量的入住人姓名输入框
        $('#roomQuantity').append(selectArr.join(''));
        $('#roomQuantity > select').change(function() {
            var $this = $(this);
            var quantity = $this.val(),
                text = $this[0].options[$this[0].selectedIndex].text;
            $this.prev().text( text );
            var $list = $('#roomInfo > article');
            for (i = 1; i < $list.length; i++) {
                if (i > quantity) {
                    $list.eq(i).hide();
                } else {
                    $list.eq(i).show();
                }
            }
            var that = POI;
            $('#orderSubmit cite').text( that.roomDetail.total_price * quantity );
            var cashBack = Number( that.roomDetail.total_upperlimit * quantity );
            if (cashBack) {
                $('#orderSubmit em').text(cashBack);
            }
        }).change();

        // 到店时间选择框初始化数据
        i = 0;
        for (var n = info.arrival_time.length; i < n; i++) {
            $('#arriveTime').append('<option value="' + info.arrival_time[i].time +
                '">' + info.arrival_time[i].time_desc + '</option>');
        }
        // 选择到店时间后更新到店时间显示
        $('#arriveTime').on('change', function() {
            var $this = $(this);
            $this.prev().text( $this[0].options[$this[0].selectedIndex].text );
        }).change();

        // 显示上次的入住人信息
        var userInfo = self.util.storage('hotel.userInfo');
        if (userInfo) {
            userInfo = JSON.parse(userInfo);
            $('#contactName').val(userInfo.contactName);
            $('#contactMobile').val(userInfo.contactMobile);
            $('#roomInfo input').first().val(userInfo.guestName1);
        }

        // 提交订单
        $('#orderSubmit > button').on('click', self.orderSubmit);

        // 检测是否登陆 TODO 接口写入native
        self.send({action: 'getAmapUserId', onlyGetId: '1'}, function(res) {
            self.orderLoginInfo(res);
        });
    },
    /**
     * 用户登陆情况检测回调.
     * @param {Object} res 返回的参数
     */
    orderLoginInfo: function(res) {
        // 未登陆时显示登录好处及入口
        if (res && res.userid) {
            return;
        }
        var $line = $('#loginInfo > h1');
        if (this.roomDetail.Upperlimit > 0) {
            $line.text('验证手机号可领取返现');
        } else {
            $line.text('验证手机号可轻松查看管理订单');
        }
        $('#loginInfo').on('click', function() {
            // 点击后弹出登陆界面 TODO 接口写入native
            POI.send({
                action: 'showLoginPannel',
                type: 'phone'
            }, function(res) {
                // 登陆成功后，隐藏登陆提示
                if (res && res.userid) {
                    $('#loginInfo').hide();
                }
            });
        }).show();
    },
    orderSubmit: function() {
        var pageHotel = POI;
        var info = pageHotel.roomDetail;
        var num = $('#roomQuantity > select').val();
        var $names = $('#roomInfo input');
        var guestName = $names.eq(0).val();
        var guestName1 = guestName;

        if (!testName(guestName)) {
            return;
        }
        for (var i = 1; i < num; i++) {
            var name = $names.eq(i).val().replace(/\s+/g,''); // 产品定义过滤所有空格
            if (!testName(name)) {
                return;
            }
            guestName += ',' + name;
        }
        var contactName = $('#contactName').val().replace(/\s+/g,''),
            contactMobile = $('#contactMobile').val();
        if (!testName(contactName, '联系人')) {
            return;
        }
        if (!contactMobile) {
            pageHotel.api.promptMessage('联系方式不能为空');
            return;
        }
        if (!contactMobile || !pageHotel.util.isMobile(contactMobile)) {
            pageHotel.api.promptMessage('手机号码输入不正确');
            return;
        }

        function testName(name, user) {
            if (!user) {
                user = '入住人';
            }
            var nameReg1 = /小姐|先生|太太|夫人/;
            var nameReg2 = /^\w+\/\w+$/;
            var nameReg3 = /[^a-zA-Z\u4e00-\u9fa5]/;
            var nameReg4 = /^\w+$/;
            if (!name) {
                pageHotel.api.promptMessage(user + '不能为空');
                return false;
            }
            if (nameReg2.test(name)) {
                return true;
            }
            if (nameReg3.test(name)) {
                pageHotel.api.promptMessage('名字不能包含特殊字符或数字');
                return false;
            }
            if (nameReg1.test(name)) {
                pageHotel.api.promptMessage(user + '不能包含小姐、先生、太太、夫人等称谓');
                return false;
            }
            if (nameReg4.test(name)) {
                pageHotel.api.promptMessage(user + '姓名是英文名称的中间需要加/，如liu/ming');
                return false;
            }
            return true;
        }

        // 存储入住人信息
        var userInfo = {
            contactName: contactName,
            contactMobile: contactMobile,
            guestName1: guestName1
        };
        pageHotel.util.storage('hotel.userInfo', JSON.stringify(userInfo));

        var poiInfo = pageHotel.util.getStorageData().base;
        var data = {
            policyId: info.RatePlanId,
            hotelId: info.hotelid,
            roomTypeId: info.RoomTypeId,
            rooms: num,
            comeDate: pageHotel.util.formatDate(new Date(info.comeDate), 'yyyy-MM-dd'),
            leaveDate: pageHotel.util.formatDate(new Date(info.leaveDate), 'yyyy-MM-dd'),
            arriveTime: $('#arriveTime').val(),
            contactName: contactName,
            contactMobile: contactMobile,
            guestName: guestName,
            guestMobile: contactMobile,
            prizeTips: info.rule_content,
            // 以上参数必填，以下参数根据不同cp选填
            orderAmount: $('#orderSubmit cite').text(), // 订单总价，艺龙、携程必填
            hotelTel: poiInfo.telephone, // 酒店电话，艺龙必填
            hotelName: poiInfo.name, // 酒店名，携程必填
            hotelAddress: poiInfo.address || '', // 酒店地址，选填（艺龙缺），用于补充订单详情输出
            roomName: info.RoomTypeName || '',
            bedName: info.bed || '',
            // 以下参数返现相关，选填
            hour_room: info.hour_room || 0,
            currency: info.Currency, // 币种
            paytype: info.paytype || 0,
            prizeAmount: $('#orderSubmit em').text() || 0, // 返现金额，选填，无返现填0或空或不填
            poiid: poiInfo.poiid,
            gd_roomid: info.roomgroup_id // 高德房型ID，选填，返现校验需要
        };
        var params = [
            {type: 'hotel', sign: 1},
            {src_type: info.src_type, sign: 1},
            {mobile: contactMobile, sign: 1},
            {order_data: JSON.stringify(data)}
        ];
        pageHotel.api.aosrequest('hotelOrderAdd', params, pageHotel.orderResult, 1, true);
        pageHotel.api.userAction('hotel-submit');
    },
    orderResult: function(res) {
        if (res.code != 1 || !res.order) {
            this.api.promptMessage('该房型满房，请尝试其他房型或者酒店');
            return;
        }
        this.util.locationRedirect('exHotelOrderComp.html?oid=' + res.order.oid);
    }
});

})(POI, $);
