(function(POI, $) {

'use strict';

$.extend(POI, {
    logPageId: 'hotelRoomTypeDetail',
    TYPE_NUM: 5,
    roomList: null, // 酒店信息列表

    // 房型详情页面初始化
    quickInit: function() {
        this.pagebody = $('.hotelTypeDetail');
        this.util.delegate(this.pagebody);

        this.isHourlyRoom = this.util.getUrlParam('isHourly') === 'true';
        this.api.setWebViewTitle( this.util.getUrlParam('typeName') );
        this.hotelDate = JSON.parse( this.util.getUrlParam('hotelDate') );

        if (this.browser.ios && !/OS [1-6]/.test(navigator.userAgent)) {
            $('.back-btn').css('top', '37px');
        }

        var rooms = POI.util.storage('hotelRoomList');
        localStorage.removeItem('hotelRoomList');
        this.moreRooms( JSON.parse(rooms) );

        // 钟点房时增加日志参数
        if (this.isHourlyRoom) {
            this.api.addLogParam({hourlyRoom: 1});
        }

        // 更多报价点击事件
        $('.hotelBook .toggleAll').click(function() {
            var self = POI;
            var $list = $('#roomList > li');
            for (var i = self.TYPE_NUM, n = $list.length; i < n; i++) {
                $list.eq(i).toggle();
            }
            if ($(this).hasClass('up')) {
                $(this).removeClass('up').text('查看全部');
            } else {
                $(this).addClass('up').text('收起');
                self.api.userAction('hotel-dl-more');
            }
        });

        this.bookEvent();
    },
    // 房型详情页面 显示房型房价信息
    moreRooms: function(res) {
        if (!res || res.code != 1 || !res.roomlist || !res.roomlist[0]) {
            return;
        }

        var list = res.roomlist[0].multilist,
            isShowSrc = '1' == res.show_src_name,
            activity = res.promotion_content,
            frag = document.createDocumentFragment();
        var i = 0;
        this.roomList = res.roomlist;

        // 展示房型信息
        var info = res.roomlist[0].room_info || {};
        var infoList = $('#hotelDetailInfo').children();
        if (info.network) {
            infoList.eq(0).text(info.network);
        }
        if (info.floor) {
            infoList.eq(1).text(info.floor + '层');
        }
        if (info.area) {
            infoList.eq(2).text(info.area);
        }
        if (info.bed) {
            infoList.eq(3).text(info.bed);
        }

        var j = 0, numj = list.length;
        for (; j < numj; j++) {
            this._formatRoomInfo(list[j], i, j, isShowSrc, activity).appendTo(frag);
        }
        $('#roomList').append(frag);

        var $list = $('#roomList > li');
        for (j = this.TYPE_NUM; j < numj; j++) {
            $list.eq(j).hide();
        }

        if (list.length > this.TYPE_NUM) {
            $('.toggleAll').show();
        } else {
            $('.toggleAll').hide();
        }

        // 房型图片
        if (info.pic_info && info.pic_info.length) {
            $('#headPic').show();
            var imgs = [], points = [];
            var imgWidth = Math.min($(document).width(), $(document).height());
            for (var k = 0, numk = Math.min(info.pic_info.length, 5); k < numk; k++) {
                var imgUrl = this.util.imageUrlTransform(info.pic_info[k].url, imgWidth, 198);
                imgs.push('<li><img class="img-loading" data-presrc="' +
                    imgUrl + '" src="' + imgUrl + '?type=8" /></li>');
                points.push('<em></em>');
            }
            $('#headPic > ul').css('width', numk + '00%').html(imgs.join(''));
            // 只有一张图片时不显示圆点
            if (numk > 1) {
                $('#headPic > .points').html(points.join('')).show();
                $('#headPic > .points em').first().addClass('current');
            } else {
                $('#headPic > ul').css('-webkit-transform', 'none');
                $('#headPic > ul li').css('width', '100%');
            }
            POI.util.imgloading($('#headPic ul img'), '1x1');
            /*global PicSlide: true*/
            new PicSlide($('#headPic')[0], {
                afterFun: function(index) {
                    $('#headPic em.current').removeClass('current');
                    $('#headPic em').eq(index).addClass('current');
                }
            });
        }
    },
    // 点击左上角后退按钮
    js_goback: function() {
        this.api.webviewGoBack();
    }
});

})(POI, $);
