/* 酒店/订单详情 */
;(function(POI, $) {
'use strict';

    var handlerAttr = 'js_handler';
    var orderData = null;   // 缓存服务接口返回的数据

    $.extend(POI, {
        logPageId: 'hotelOrderDetail',

        /**
         * 打开POI页面
         * @param  {Boolean} status true/false ~ POI详情页/搜索结果页
         * @return nth
         */
        _openPoi: function(status) {
            var self = this;

            var poiInfo = {
                poiid        : orderData.poi_id,
                name         : orderData.hotel_name,
                address      : '',
                cityCode     : '',
                poiType      : '',
                new_type     : '',
                phoneNumbers : '',
                lon          : orderData.longitude,
                lat          : orderData.latitude
            };
            
            self.api.openPoi(poiInfo, status, 'hotel');
        },

        /*-------------------------------------事件处理器*/
        //打电话
        js_phoneCall: function(ele, e) {
            var self = this;

            var $phone = $(ele).find('.phone');
            // 打电话，酒店，第三方客服
            if ($phone.size() > 0) {
                var phoneNumber = $phone.text();
                self.api.showPanellist([phoneNumber]);

                var $source = $(ele).parents('.roomInfo');
                if ($source.size() > 0) {
                    // 埋点3 酒店电话的点击
                    self.api.userAction('phoneCallHotel');
                }
                else {
                    // 埋点4 客服电话的点击
                    self.api.userAction('phoneCallSupplier');
                }
            }
        },

        // 修改订单，跳转至‘去啊’订单修改页面
        js_editOrder: function(ele, e) {
            var self = this;
            
            self.util.locationRedirect(orderData.order_edit_url);
        },

        js_openHotelPoi: function(ele, e) {
            // 跳转到酒店POI详情页
            this._openPoi(1);

            // 埋点1 酒店名称的点击
            this.api.userAction('openHotelPoi');
        },

        js_openSearchResult: function(ele, e) {
            // 跳转到搜索结果页
            this._openPoi(0);

            // 埋点2 酒店地址的点击
            this.api.userAction('openSearchResult');
        },
        /*------------------------------------- end 事件处理器*/

        // 获取订单详情数据
        getOrderDetail: function(arg) {
            var self = POI;

            // var params = [
            //     {type: arg.type, sign: 1},
            //     {src_type: arg.src_type, sign: 1},
            //     {oid: arg.oid, sign: 1}
            // ];

            self.api.aosrequest({
                urlPrefix: 'hotelOrderDetail',
                method: 'GET',
                progress: 1,
                params: [
                    {order_id: arg.oid, sign: 1}
                ],    // channel参数由客户端添上
                showNetErr: '1'
            }, function(res) {
                if ('1' == res.code && Object.prototype.toString.call(res.order) === '[object Object]') {
                    // 缓存一份
                    orderData = res.order;

                    // 显示数据
                    self._displayOrderDetail(res.order);
                }
                else if (res.code == '14') {
                    // 去登录页
                    self.send({
                        action: 'getAmapUserId',
                        onlyGetId: '0', /* 未登录则去登录页面 */
                        needRelogin: '1'
                    }, function(userInfo) {
                        if (userInfo.userid) {
                            // 已登录
                            // 重新获取数据并显示
                            self.initPage();
                        }
                    });
                }
            });
        },

        /**
         * 添加前导0
         * @param {String} strNum 数字串
         * @param {Integer} len    期望输出长度
         */
        _addPrefix0: function(strNum, len) {
            var tmp = '0' + strNum;

            // x.x xx:xx
            return tmp.substring(tmp.length - len);
        },

        /**
         * 格式化日期，返回需要显示的格式
         *     5.25 11:00-5.26 01:00 2小时/1间
         *     5.25 10:00-12:00 2小时/1间
         *     5.24-5.25 1晚/1间
         * @param  {String} enter   入住时间,格式是"%Y-%m-%d %H:%M:%S" 比如2015-06-19 13:33:10
         * @param  {String} leave   离开时间,格式是"%Y-%m-%d %H:%M:%S" 比如2015-06-19 13:33:10
         * @param  {Integer/String} roomNum 房间数
         * @return {String}         期望格式
         */
        _formatDate: function(enter, leave, roomNum) {
            var self = this;

            var res = '';
            // 
            // "date_enter": 入住时间,格式是"%Y-%m-%d %H:%M:%S" 比如2015-06-19 13:33:10，
            // "date_leave": 离开时间,格式是"%Y-%m-%d %H:%M:%S" 比如2015-06-19 13:33:10,
            // 转换成yyyy/mm/dd更安全
            var startDate = new Date(enter.replace(/-/g, '/'));
            var endDate = new Date(leave.replace(/-/g, '/'));
            var start = {
                /* NOTICE: 月份从0开始 */
                m: startDate.getMonth() + 1,
                d: startDate.getDate(),
                h: startDate.getHours(),
                M: startDate.getMinutes()
            };
            var end = {
                /* NOTICE: 月份从0开始 */
                m: endDate.getMonth() + 1,
                d: endDate.getDate(),
                h: endDate.getHours(),
                M: endDate.getMinutes()
            };


            var gap = endDate.getTime() - startDate.getTime();
            // TODO: 根据cp来源分不开全日房和钟点房，需要再确认接口
            // REVIEW: 默认是全日房
            if (true) {
                // 全日房
                // x.x-x.x
                res += start.m + '.' + start.d + '-' + end.m + '.' + end.d;
                
                gap = Math.ceil(gap / (24 * 3600 * 1000));  // 不足一天也算一天
                // x.x-x.x x晚/x间
                res += ' ' + gap + '晚/' + roomNum + '间';
            }
            else {
                // 钟点房
                gap = Math.ceil(gap / (3600 * 1000));   // 不足1小时也算1小时
                if (start.m === end.m && start.d === end.d) {
                    // 同一天
                    // x.x
                    res += start.m + '.' + start.d;
                    // x.x xx
                    res += ' ' + self._addPrefix0(start.h, 2);
                    // x.x xx:xx
                    res += ':' + self._addPrefix0(start.M, 2);
                    // x.x xx:xx-xx
                    res += '-' + self._addPrefix0(end.h, 2);
                    // x.x xx:xx-xx:xx
                    res += ':' + self._addPrefix0(end.M, 2);
                    // x.x xx:xx-xx:xx x小时/x间
                    if (gap < 0) {  // 处理23:00 - 00:30
                        gap += 24;
                    }
                    res += ' ' + gap + '小时/' + roomNum + '间';
                }
                else {
                    // 跨天
                    // x.x
                    res += start.m + '.' + start.d;
                    // x.x xx
                    res += ' ' + self._addPrefix0(start.h, 2);
                    // x.x xx:xx
                    res += ':' + self._addPrefix0(start.M, 2);
                    // x.x xx:xx-x.x
                    res += '-' + end.m + '.' + end.d;
                    // x.x xx:xx-x.x xx
                    res += ' ' + self._addPrefix0(end.h, 2);
                    // x.x xx:xx-x.x xx:xx
                    res += ':' + self._addPrefix0(end.M, 2);
                    // x.x xx:xx-xx:xx x小时/x间
                    res += ' ' + gap + '小时/' + roomNum + '间';
                }
            }

            return res;
        },

        /**
         * 格式化入住人姓名
         * @param  {String} strName 入住人姓名，多个用逗号分开
         * @return {String}         期望输出
         */
        _formatGuestName: function(strName) {
            var names = strName.split(',');

            if (names.length === 1) {
                // 1人直接返回
                return strName;
            }
            else if (names.length === 2) {
                // 2人用顿号分割
                return names[0] + '、' + names[1];
            }
            else {
                // 2人以上添上...
                return names[0] + '、' + names[1] + '...';
            }
        },

        _displayOrderDetail: function(order) {
            // 展示页面（直接填写并显示隐藏内容，不拼接）
            //     来自去啊/来自其他
            //     去啊要求：1.显示修改订单按钮
            //               2.隐藏footer
            
            var self = this;

            var isQuA = (typeof order.order_edit_url === 'string' && order.order_edit_url.length > 0);

            var $pageBody = $('#js_pagebody');
            var $roomInfo = $pageBody.find('.roomInfo');
            var $orderInfo = $pageBody.find('.orderInfo');
            var $supplierInfo = $pageBody.find('.supplierInfo');
            var $footer = $('.footer');


            $roomInfo.find('.name').text(order.hotel_name); // 酒店名称
            $roomInfo.find('.address').text(order.hotel_address);   // 酒店地址
            // 格式化日期
            var dateInfo = self._formatDate(order.date_enter, order.date_leave, order.room_number);
            $roomInfo.find('.date').text(dateInfo);    // 入住时间
            $roomInfo.find('.type').text(order.room_type);  // 房型（高级大床房）
            $roomInfo.find('.price').text(order.amount);    // 房价
            // 约定分隔符为英文逗号
            var phoneNumbers = order.hotel_phone.split(',');
            // 直接填第一条
            $roomInfo.find('.phone').text(phoneNumbers[0]);   // 酒店电话
            if (phoneNumbers.length > 1) {
                // 新建更多条
                for(var i = 1, len = phoneNumbers.length;i < len; i++) {
                    var strHtml = '<div class=\'wrapper canTouch\' js_handler=\'js_phoneCall\'>' +
                            '<div class=\'infoLine icon ic_phone\'><span class=\'phone\'>'+
                            phoneNumbers[i] + '</span><span class=\'ic_func\'></span></div></div>';
                    $roomInfo.append(strHtml);
                }
            }
            

            $orderInfo.find('.order_id').text(order.amap_order_id || order.order_id);
            if (isQuA) {    // 来自去啊，显示修改订单按钮
                $orderInfo.find('.editOrder').show();
            }
            
            if(order.cp_name && order.cp_id) {
                $orderInfo.find('.cp_name').text(order.cp_name + "订单号：");
                $orderInfo.find('.cp_order_id').text(order.cp_id).parents('.infoLine').show();;
            }
            // 无入住人则不显示该栏
            if (typeof order.guest_name === 'string' && order.guest_name.length > 0) {
                $orderInfo.find('.guest_name').text(self._formatGuestName(order.guest_name))
                    .parents('.infoLine').show();
            }
            $orderInfo.find('.pay_type').text( self._payTypeText(order.pay_type) );


            $supplierInfo.find('.serviceSupplier').text(order.cp_name);
            $supplierInfo.find('.phone').text(order.cp_phone);

            if (isQuA) {
                $footer.hide(); // 来自去啊，隐藏footer
            }
            else {
                $footer.find('.serviceSupplier').text(order.cp_name);
            }

            $('#js_poi_page').show();
        },
        _payTypeText: function(type) {
            var arr = ['现付', '担保', '预付', '担保'];
            return arr[type] || '';
        },

        initPage: function() {
            var self = this;

            // 获取参数order_id，回调显示订单详情
            if (self.browser.ios) {
                self.send({action: 'openHotelOrderDetail'}, self.getOrderDetail);
            } else {
                self.send({action: 'openHotelDetail'}, self.getOrderDetail);
            }
        },


        quickInit: function() {
            var self = this;
            var $root = $('#js_poi_page');

            // 绑定事件处理器
            self.util.delegate($root, handlerAttr);

            // 获取数据并展示
            self.initPage();
// TEST
// self.getOrderDetail({oid: '123'});
        }
    });
})(POI, Zepto);