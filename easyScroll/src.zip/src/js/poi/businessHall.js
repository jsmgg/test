/*
 * 辽宁联通
 */
;(function(POI, $){

$.extend(POI, {
    
    showLnunicom : function(deep, srcInfo) {
        if(!deep)
            return '';

        var hallStr = '';
        if(deep.scope) {
            hallStr = '<section id="businessHall" class="businessHall">' +
                          '<h2 class="module_title_p line-half">经营范围</h2>' +
                          '<article>' + deep.scope.split('\n').join('</article><article>') + '</article>' +
                      '</section>';
        }

        if(srcInfo && srcInfo.business_hall_lnunicom) {
            var name_cn = srcInfo.business_hall_lnunicom.name_cn;
            if(name_cn) {
                // hallStr += '<h2 ' + this.handleAttr + '="js_hallShowWapPage">数据来源：' + name_cn + '</h2>';
            }
        }
        
        return hallStr;
    },

    /* ---------------------------事件函数----------------------------- */
    js_hallShowWapPage : function(ele, e) {
        var wapUrl = POI.aosData.deep[0].info_wapurl;
        if(wapUrl) {
            POI.api.getAppPara('', '', wapUrl );
            POI.api.userAction('lnunicomFrom');
        }
    },

    /* ---------------------------事件函数 end----------------------------- */

    hallPageList : function(hallStr) {
        var htmlStr = hallStr;
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2"]);
        var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        this.pagebody.html(htmlStr + allAry.join(""));
        POI.util.executeAfterDomInsert();
    },

    init : function() {
        this.index.moduleDeepHead();
        var deep = this.aosData.deep[0],
            srcInfo = this.aosData.src_info;
        
        this.hallPageList(this.showLnunicom(deep, srcInfo));
    }
    
    
    
});

})(POI, Zepto);