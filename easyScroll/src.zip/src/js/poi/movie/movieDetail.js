/**
 * 电影详情页
 */
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'movieDetail',
    quickInit:function(){
        var self = this;
        if( self.util.getUrlParam('from') == 'poi' ) {// 从详情页面进入的
            self.api.aosrequest('qqMovieContent', [{'movieid':self.util.storage('movieID'),'sign':1}], self.exMovieDetail, 1, true, 'POST');
        }else{
            self.send({action: 'openMovieDetail'}, function(arg){
                self.api.aosrequest('qqMovieContent', [{'movieid':arg.movieID,'sign':1}], self.exMovieDetail, 1, true, 'POST');
            });
        }
    },
    exMovieDetail:function( movieInfo ){
        var self = this, fromIndex = self.util.getUrlParam('from')=='poi',sale_sta,actor=[],post_img=[],movie = movieInfo.movieinfo,cover,imgW,snippet = [],postArr = movie.poster,synopsis=[],review = movie.review,review_list;
        if (!movieInfo || !movieInfo.movieinfo) {
            return;
        }
        // debugInfo('movie.name',movie.name)
        if( movie.name ){
            document.title = movie.name;
            self.util.setPageTitle && self.util.setPageTitle(movie.name);
        }
        self.util.storage('movieID', movie.id||'' );
        // 海报
        cover = movie.coverpic;
        // console.log('cover.url'+cover.url);
        if( cover && cover.url ){
			var tmpcover = self.util.imageUrlTransform(cover.url,99,137,'resize');
			$('#movie_intro>a>span>img').attr('src', tmpcover ).attr('data-presrc',tmpcover);
        }
        // 评分
        if( movie.score_movie ){
            $('hgroup>h3').html( self.util.stars(movie.score_movie, 10) + '<b>'+movie.score_movie+'</b>' );
        }else{
            $('hgroup>h3').html( '<em style="margin-left:10px;">暂无评分</em>');
        }
        //信息碎片
        $.each([
            {
                'title':'类型', 'data':movie.type
            },
            {
                'title':'国家', 'data':'中国'
            },
            {
                'title':'时长', 'data':movie.length ? movie.length+'分钟' : ''
            },
            {
                'title':'上映时间',
                'data':(function(){
                    if( movie.releasedate ){//时间截取
                        var t = movie.releasedate.split(/\s/);
                        if( t.length ){
                            return t[0];
                        }
                    }
                    return '';
                })()
            }
        ],function( index, item ){
            if( item.data ){
                snippet.push(
                    '<h4>',
                    '<b>'+item.title+'：</b>'+item.data,
                    '</h4>'
                );
            }
        });
        switch(movie.sale_status){
            case '0':
                sale_sta='未知';
                break;
            case '1':
                sale_sta='在售';
                break;
            case '2':
                sale_sta='预售';
                break;
            case '3':
                sale_sta='新片';
                break;
            default:
        }
        snippet.push('<h4><span>'+sale_sta+'</span>');
        if(movie.screen_type){
            snippet.push('<span>'+movie.screen_type+'</span>');
        }
        snippet.push('</h4>');
        $('hgroup>h3').siblings().remove();
        $('hgroup>h3').after( snippet.join('') );
        $('#movie_intro').show();
        //演员表
        if(movie.director){
            actor.push('<p><em>导演：</em>'+movie.director+'</p>');
        }
        if(movie.actor){
            actor.push('<p class="linesDot"><em>主演：</em>'+movie.actor+'</p>');
        }
        $('#movie_actor article').html(actor.join('')).parent().show();

        //剧情介绍
        if(movie.synopsis){
            synopsis.push('<article class="noline"><p id="movie_sy" class="limits">'+(movie.synopsis||'')+'</p></article>');
        }
        if(movie.synopsis || postArr.length){
            $('#movie_pic').after(synopsis.join(''));
            $('#movie_plot').show();

            if (movie.synopsis) {
                new self.util.toggleContent($('#introA'),$('#movie_sy'),{matchDomNodes:$('#movie_sy')});
            }
        }
        if( postArr && postArr.length ){
            self.util.picThumb({
                type:'movie',
                itemid:movie.id,
                cont:$('#movie_pic'),
                pics:postArr,
                count:movie.poster_count
            });
            if(!movie.synopsis) $('#movie_pic').css('padding-bottom','13px')
        }    else{
            $('#movie_pic').remove();
        }
        // 热门影评
        if( review && review.review_list && review.review_list.length ){
            var cmtHtml = [];
            $.each( review.review_list , function( index, item ){
                if( item.author && item.review ){
                    cmtHtml.push('<article><aside><b>'+ item.author +'</b>'+ self.util.stars(item.score, 10)+'<span>'+ self.monthDate(item.time) +'</span></aside><p>'+ item.review +'</p></article>');
                }
            });
            if( cmtHtml.length ){
                cmtHtml.unshift('<h2>热门影评</h2>');
                $('#movie_eval').html( cmtHtml.join('') ).show();
            }
        }
        self.util.imgloading($('#movie_intro>a>span>img'));
        self.api.userAction('movieDetail',{movieID : self.util.storage('movieID')});
    },
    monthDate: function( timeStr ){
        if( timeStr ){
            var d = timeStr.split(/[ \-]/);
            if( d.length>2 ){
                return (+d[1]) + '月'+ (+d[2]) + '日';
            }
        }
        return '';
    }
});
})(POI, Zepto);
