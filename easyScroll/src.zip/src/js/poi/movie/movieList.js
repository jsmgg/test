/**
 * 电影列表页
 */
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'movieMorePrice',
    handleAttr : 'js_handle',
    search : null,
    quickInit:function(){
        var self = this , search = JSON.parse( self.util.storage( 'movie_more_price' ) ),
            params = [
                {'poiid': search.poiid,'sign':1},
                {'movieid':search.movieid,'sign':1},
                {'ticketid':search.ticketid,'sign':1}
            ];
        self.search = search;
        self.api.aosrequest('qqMovieMore', params, self.movieInfoMore, 1, true, 'POST');
        self.util.delegate($('#js_movielist'), self.handleAttr);
    },
    // 电影 更多报价
    movieInfoMore: function(res) {
        if (!res || res.code != 1 || !res.ticket_info || !res.ticket_info.cp
            || !res.ticket_info.cp.length) {
            return;
        }
        var html = [], handleAttr = this.handleAttr,
            info = res.ticket_info,
            screenLang;
        // 电影类型和语言显示
        if (info.screen && info.lang) {
            screenLang = info.screen + ' ' + info.lang;
        } else if (info.screen || info.lang) {
            screenLang = info.screen || info.lang;
        } else {
            screenLang = '&nbsp;';
        }
        for (var i = 0, len = info.cp.length; i < len; i++) {
            var obj = info.cp[i],
                canBuy = obj.xz == 1 && obj.cp_url, // 是否可购买
                style = ' class="canTouch"';
            html.push('<article');
            if (canBuy) {
                html.push(' class="canTouch" ' + handleAttr + '="js_checkticket" cp_url="' + obj.cp_url + '"');
            }
            html.push('><div>');
            html.push('<h2>' + ((obj.privilege && obj.privilege !=0 ? obj.src_name+'<i>[惠]</i>' : obj.src_name) || '') + '</h2>');
            html.push('<p><i>' + screenLang + '</i>');
            html.push('<em>' + (info.hall.substring(0,5) || '') + '</em>');
            html.push('<span>' + (Number(obj.price) || ' ') + '</span>');
            html.push('</p></div>');
            if (canBuy) {
                html.push('<dfn class="canTouch">选座购票</dfn>');
            }
            html.push('</article>');
        }
        $('#MovieList>section').html(html.join('')).show();
    },
    js_checkticket : function(obj) {//选座按钮处理函数
        var self = this, search = self.search;
        self.api.userAction('infoMore');
        self.util.storage( 'movie_more_price' , JSON.stringify( search ) );//更多报价页面参数列表,这里客户端不支持 地址栏传参数
        self.api.getAppPara('','',obj.attr('cp_url'),{buttonText: '更多报价', localFile:'exMovieList.html',otherUrl:''});
    }
});
})(POI, Zepto);