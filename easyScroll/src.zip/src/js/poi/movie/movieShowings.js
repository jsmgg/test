/**
 * 电影列表页
 */
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'movieShowings',
    handleAttr : 'js_handle',
    quickInit:function(){
        var self = this;
        if(this.browser.and){
            self.send({action: 'openMovieShowings'}, self.openMovieShowings);
        }
        self.util.delegate($('#js_movieshowings'), self.handleAttr);
    },
    openMovieShowings : function(arg) {//客户端主动吐数据
        this.movie.poiid = arg.poiID;
        this.movie.clientID=arg.movieID;
        this.movie.getMovieDate(arg.poiID,arg.movieID,1,'progress');
    }
});
})(POI, Zepto);