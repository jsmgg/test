/**
 * 电影团购详情页
 */
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'movieTuan',
    handleAttr : 'js_handle',
    notuan : 0,
    poiid : '',
    pagebody : $('#js_movietuan'),
    quickInit:function(){
        var self = this, params;
        self.poiid = self.util.getUrlParam('poiid');//self.util.storage('pageId');
        document.title = self.util.storage('movieTitle');
        POI.util.setPageTitle && POI.util.setPageTitle(document.title);
        self.api.aosrequest('nearbyTuanType', [
            {poiid: self.poiid, sign: 1},
            {pagenum: 1},
            {pagesize: 2},
            {custom: 'sort_rule=2'},
            {classify: '0'}
        ], self.movieTuanList, false, false, 'POST');
        self.util.delegate(self.pagebody, self.handleAttr);
    },
    movieTuanList: function(res) {
        this.api.aosrequest('qqMovieTuan', [{'poiid': this.poiid,'sign':1}], this.movieInfoTuan, 1, true, 'POST');
        if (!res || res.code != 1 || !res.tuan_list || !res.tuan_list.length) {
            this.notuan=1;
            return;
        }
        var list = res.tuan_list,handleAttr = this.handleAttr,
            formatMoney = this.util.formatMoney,
            htmlArr = [];
        for (var i = 0, len = Math.min(list.length, 2); i < len; i++) {
            var obj = list[i],
                canBuy = obj.id && obj.mergeid && obj.src,
                price_current = formatMoney(obj.price_current),
                price_previous = formatMoney(obj.price_previous);
            if (!canBuy && !obj.description && !price_current && !price_previous) {
                continue;
            }
            htmlArr.push('<article');
            if (canBuy) {
                htmlArr.push(' class="canTouch" ' + handleAttr + '="js_gotuan" oid="' + obj.id + '" ind="' + i + '" mergeid="' + obj.mergeid + '" _src="' + obj.src + '"');
            }
            htmlArr.push('><div>');
            htmlArr.push('<h4>' + (obj.description || '') + '</h4>');
            if (price_current) {
                htmlArr.push('<span>' + price_current + '</span>');
            }
            if (price_previous) {
                htmlArr.push('<del>' + price_previous + '</del>');
            }
            htmlArr.push('</div>');
            if (canBuy) {
                htmlArr.push('<dfn class="canTouch">抢购</dfn>');
            }
            htmlArr.push('</article>');
        }
        //$('#movie_group > h2').siblings('article').remove();
        $('#movie_group > h2').after(htmlArr.join(''));
        // 记录 poiid，更多团购使用
        this.poiInfo = {poiid: this.poiid};
        // 团购信息多余两条时显示 查看更多按钮
        // console.log('res.total'+res.total)
        if (res.total > 2) {
            $('#movie_group > a').show();
        }
        $('#movie_group').show();
        res.total > 2 && htmlArr.push('<a class="canTouch viewMore" ' + handleAttr + '="js_moretuan"><b class="rightDir">查看本影院更多团购</b></a>');
        this.pagebody.html( '<section id="movie_group"><h2>团购</h2>' + htmlArr.join('') + '</section>' );
    },
    // 电影兑换券列表
    movieInfoTuan: function(res) {
        if (!res || res.code != 1 || !res.cinema_info || !res.cinema_info.coupon
            || !res.cinema_info.coupon.length) {
            return;
        }
        // 优惠券模块
        var list = res.cinema_info.coupon,
            htmlArr = [];
        for (var i = 0, len = list.length; i < len; i++) {
            htmlArr.push( this._movieQuanItem(list[i],i) );
        }
        if(this.notuan){
            $('#movie_ticket').css('margin-top','0');
            this.pagebody.append('<section id="movie_ticket" style="margin-top:0;"><h2>兑换券</h2>' + htmlArr.join('') + '</section>');
        }else{
            this.pagebody.append('<section id="movie_ticket"><h2>兑换券</h2>' + htmlArr.join('') + '</section>');
        }    },
    /**
     * 获取一条电影兑换券的html代码.
     * @param {Object} obj 一条兑换券对象
     * @return {String} 兑换券的html代码
     */
    _movieQuanItem: function(obj,index) {
        if (!obj) {
            return '';
        }
        var htmlArr = [], canBuy = !!obj.coupon_url, handleAttr = this.handleAttr;
        htmlArr.push('<article');
        if (canBuy) {
            htmlArr.push(' class="canTouch" ' + handleAttr + '="js_checkticket" coupon_url="' + obj.coupon_url + '" index="'+index+'"');
        }
        htmlArr.push('><div><h4>');
        htmlArr.push(obj.coupon_name || '');
        htmlArr.push('</h4>');
        var coupon_price = this.util.formatMoney(obj.coupon_price);
        if ( coupon_price ) {
            htmlArr.push('<span>' + coupon_price + '</span>');
        }
        if (canBuy) {
            htmlArr.push('<dfn class="canTouch">购买</dfn>');
        }
        htmlArr.push('</article>');
        return htmlArr.join('');
    },
    js_gotuan : function(obj) {
        this.api.userAction('rbMovie',{goTuanID : obj.attr('ind')});
        location.href='exTuangou.html?type=tuan&tuangouID='+obj.attr('oid')+'&mergeID='+obj.attr('mergeid')+'&src_type=' + obj.attr('_src') + '&source=shopOthers' + (window.hasWebPageTitleBar ? '&showTitleBar=1' : '');
    },
    js_moretuan : function() {
        var self = this;
        self.api.triggerFeature('tuangouList', self.poiInfo);
        self.api.userAction('tuangouList-movie')
    },
    js_checkticket : function(obj) {
        this.api.getAppPara('', '', obj.attr('coupon_url'))
        this.api.userAction('appMovie',{goCouponID : obj.attr('index')});
    }
});
})(POI, Zepto);