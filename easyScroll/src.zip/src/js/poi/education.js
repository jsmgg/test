/*
    大学行业
*/
;(function(POI, $) {

'use strict';

$.extend(POI,{
    get_arr : function( str ){
        var html = [ str || ''];
        return {
            p : function( s ){
                s+='';
                html.push( s );
                return this;
            },
            str : function() {
                var str = html.join('');
                html = null;
                this.str = this.p = null;
                return str;
            }
        }
    },
    init : function() {
        var self = this,
            deep = (self.aosData.deep || [{}])[0] || {},
            tag_class = deep.tag_class||'',intro,
            top_tags ='', html = [], edu_mods = self.get_arr();
        //造假数据
        /*tag_class = '958;456';
        deep.sch_rank = deep.teach_rank = deep.keydiscipline_num =5;
        deep.fe_ratio = 0.39;
        deep.distrib = [{
            location : '河北',
            stu_ratip : 30.5
        },{
            location : '华北',
            stu_ratip : 41.5
        },{
            location : '西北',
            stu_ratip : 20.5
        },{
            location : '华南',
            stu_ratip : 13.5
        },{
            location : '东北',
            stu_ratip : 20
        }];
        deep.is_scores = 1;*/
        //end 造假数据
        if( tag_class ) {
            tag_class.split( ';' ).forEach( function( item ){
                top_tags += self.index.moduleHeadItem( item );
            } );
        }
        edu_mods.p(self.get_rank( deep ));//排名模块
        if( deep.is_scores == 1 ) {//有录取分数线模块
            edu_mods.p('<div id="js_education_scores" style="display:none;"></div>');
            self.get_scores([{select_item:1}], true);
        }
        edu_mods.p( self.get_ratio( deep ) );//生源模块
        self.index.moduleDeepHead( top_tags );
        intro = self.index.moduleIntro(["学校照片", "学校概况", ''], []);
        html = self.index.moduleAll(['alipayDiscount', 'sendComment', 'stopStrategy', 'activityInfo', intro, 'commentInfo',  'indoorMap', 'placeContribution']);
        self.pagebody.html( edu_mods.str() + html.join('') );
        self.util.executeAfterDomInsert();
    },
    /*
        "sch_rank":1,<!-- 综合排名 -->
        "teach_rank":1,<!-- 师资排名 -->
        "keydiscipline_num":0.35,<!-- 国家重点学科数量（单位：个） -->
    */
    get_rank : function( deep ) {
        var html = this.get_arr();
        if( deep.sch_rank && deep.teach_rank && deep.keydiscipline_num) {
            html.p('<section class="paiming" id="js_paiming">')
            .p('<p><span>综合排名</span><i count="'+ deep.sch_rank +'">')
            .p('<em class="paiming_scrollnum"><b></b><b></b><b></b><b></b><b></b></em>')
            .p('</i></p>')
            .p('<p class="center"><span>师资排名</span><i count="'+ deep.teach_rank +'">')
            .p('<em class="paiming_scrollnum"><b></b><b></b><b></b><b></b><b></b></em>')
            .p('</i></p>')
            .p('<p><span>重点学科</span><i count="'+ deep.keydiscipline_num +'">')
            .p('<em class="paiming_scrollnum"><b></b><b></b><b></b><b></b><b></b></em>')
            .p('</i></p>')
            .p('</section>');
            this.util.executeAfterDomInsert(function() {
                setTimeout(function(){
                    $('#js_paiming i').each( function() {
                        var obj = $(this), count = parseInt(obj.attr( 'count' ))||1,
                            bs =obj.find('b'),index=0,
                            start = count -4;
                        for( ; start <= count ; start++){
                            if( start > 0){
                                bs.eq(index++).text(start);
                            }
                        }
                        index>1 && (obj.find( 'em' )[0].style.webkitTransform = 'translateY(-'+ (index-1)*45+'px)');
                    });
                },500);
            });
        }
        return html.str();
    },
    /*
        生源情况
        区域分布
    */
    get_ratio : function( deep ) {
        var self = this, html = self.get_arr(), count, num, i=0;
        if( deep.fe_ratio || ( deep.distrib && deep.distrib.length )) {
            if( deep.fe_ratio ) {//生源情况模块
                count = parseFloat(deep.fe_ratio * 100).toFixed(1);//女生比例
                html.p( '<section class="studentmod">' )
                .p( '<h2 class="module_title_p">生源情况</h2>' )
                .p( '<article class="studentmod_icon">' )
                .p( '<em>男生<br/>' + (100 - count ).toFixed(1) + '%</em>' )
                .p( '<p>' );
                num = 10 - Math.round( count/10 );
                while( i < 10 ){
                    html.p( '<i class="' + ( i < num ? 'studentmod_boy' : 'studentmod_girl' ) + '"></i>' );
                    i++;
                }
                
                html.p( '</p>' )
                .p('<em class="studentmod_right">女生<br/>' + count + '%</em>')
                .p( '</article>' )
                .p( '<article class="studentmod_msg">')
                //.p( '<p>男女比例九比一，五对情侣一对基，男生女生搭配学习不累</p>' )
                .p( '</article>' )
                .p( '</section>' );
            }
            
            if( deep.distrib && deep.distrib.length ) {
                html.p( '<section>' )
                .p( '<h2 class="module_title_p">地域分布</h2>' )
                .p( '<article class="studentmod_address">' )
                .p( '<ul class="studentmod_address_list" style="width:' + ( 73 * deep.distrib.length) + 'px;">' );
                deep.distrib.sort( function(a , b) {
                    return a.stu_ratio < b.stu_ratio;
                } );
                deep.distrib.forEach( function( item ) {
                    count = parseFloat( item.stu_ratio||0 ).toFixed(3);
                    html.p( '<li class="studentmod_address_item"><p><canvas width="132" height="132" count="'+count+'"></canvas></p>' + ( item.location || '') + '</li>' );
                });
                
                html.p( '</ul></article></section>' );// end studentmod_address
                self.util.executeAfterDomInsert(function(){//画图
                    self.education_address();
                });
            }
            
        }
        return html.str();
    },
    education_address : function(){//区域分布模块画图
        $( 'li.studentmod_address_item canvas' ).each( function() {
            new DrawPie( this, $( this ).attr( 'count' ));
        });
        if( $('article.studentmod_address').width() <  $('ul.studentmod_address_list').width()) {
            this.easyScroll('article.studentmod_address',{
                preventDefault : false,
                align:'x'
            });
        }
    },
    get_scores : function( params , first ){
        var self = this,
            p = [{
                poiid : self.aosData.base.poiid,
                sign : 1
            }];
        p = p.concat( params );
        //http://group.testing.amap.com/zhiming.hu/datalist.js
        //http://100.69.198.235:8088/ws/valueadded/education/scores/
        // educationScores
        self.api.aosrequest({'params': p,'urlPrefix':'educationScores' ,'method':'get'},function( dt ){
            if( dt.code == 1 || dt.code == 7) {
                self.rander_scores( dt , first );
            }
        });
    },
    selected_scores : null,
    rander_scores : function( dt, first ) {
        var self = this, html = self.get_arr(),
            scores = dt.scores || [], year, fig= false;
        if( first ){
            html.p( '<section class="gaokaomod" id="js_gaokaomod">' );
        }
        first && (self.selected_scores = [ dt.select_province || '', dt.select_genre||'', dt.select_batch || '']);
        if( !self.selected_scores.join('') ){
            return;
        }
        html.p('<h2 class="module_title_p">高考录取分数线<em class="gaokaomod_address canTouch" '+ self.handleAttr +'="js_change_gaokaoaddress">' + self.selected_scores.join('<i></i>') +'</em></h2>')
        .p( '<div class="gaokaomod_item gaokaomod_item_head"><em>年份</em><i></i><b class="w85">平均录取分数</b><i></i><b class="w60">招生人数</b><i></i><b class="w70">批次分数</b></div>' );
        for( year in scores){
            scores[year].forEach( function( item ) {
                html.p( '<div class="gaokaomod_item"> ')
                .p( '<em>' + year + '</em><i></i>' )
                .p( '<b class="w85">' + ( item.aver_score || '') + '</b><i></i>' )
                .p( '<b class="w60">' + ( item.enrollment || '') + '</b><i></i>' )
                .p( '<b class="w70">' + ( item.batch_score || '') + '</b>' )
                .p( '</div>' );
                fig = true;
            } );
        }
        if( !fig ) {//没有分数信息
            html.p( '<div class="gaokaomod_item" style="color:#999;">哎呀，数据没找到...</div>' );
        }
        if( first ) {
            html.p( '</section>' );
            self.province_list = dt.province_list || [];
            self.genre_list = dt.genre_list || [];
            self.batch_list = dt.batch_list || [];
            $( '#js_education_scores' ).replaceWith( html.str() );
        } else {
            $( '#js_gaokaomod' ).html( html.str() );
        }
    },
    js_change_gaokaoaddress : function() {
        var self = this, box = $( '#js_gaokao_citys' ),
            selected_scores = self.selected_scores;
        if( box.length ) {
            box.show();
        } else {
            self.pagebody.append( self.get_arr( '<div class="gaokao_citys" id="js_gaokao_citys" ' + self.handleAttr + '="js_gaokao_citys">' )
            .p( '<section class="gaokao_citys_box" ' + self.handleAttr + '="js_preventDefault">')
            .p( '<h2 class="gaokao_citys_title">高考录取分数线筛选</h2>' )
            .p( '<article class="gaokao_citys_scroller">' )
            .p( '<div class="gaokao_citys_list">' )
            .p( self.get_dialog_item(self.province_list, '地区', selected_scores[0]) )
            .p( self.get_dialog_item(self.genre_list, '类型', selected_scores[1]) )
            .p( self.get_dialog_item(self.batch_list, '批次', selected_scores[2]) )
            .p( '</div></article><em class="canTouch gaokao_citys_btn" '+self.handleAttr+'="js_gaokao_citys_btn">确定</em></section></div>' ).str() );
            self.init_dialog();
        }
        self.api.userAction('changeGaokaoaddress');
    },
    init_dialog : function() {
        if( $('div.gaokao_citys_list').height() >  $( 'article.gaokao_citys_scroller' ).height() ) {
            this.easyScroll('article.gaokao_citys_scroller',{
                preventDefault : false
            });
        }
        $( '#js_gaokao_citys' ).bind( 'touchmove', function(e) {
            e.preventDefault();
        })
    },
    get_dialog_item : function(list,name,selected) {
        var self = this,
            fig = {'地区':1,'类型':2,'批次':3}[name],
            html = self.get_arr( '<h3 class="gaokao_citys_name">'+name+'</h3><article class="js_education_box js_education_fig'+ fig +'">' ),
            count;
        list.forEach( function( item, i) {
            if( (i+1) % 4 == 1 ) {
                html.p( '<div class="gaokao_citys_item">' );
            }
            html.p( '<em class="half-border canTouch'+ (selected == item ? ' selected':'') +'" '+ self.handleAttr +'="js_selected_item">' + item + '</em>' );
            if( (i+1) % 4 == 0 ) {
                html.p( '</div>' );
            }
        } );
        count = 4-list.length % 4;
        while( count > 0 && count<4 ){
            html.p( '<em>&nbsp;</em>' );
            count==1 && html.p( '</div>' );
            count--;
        }
        html.p( '</article>' );
        return html.str();
    },
    js_selected_item : function( obj ) {
        if( !obj.hasClass( 'selected' ) ) {
            obj.parents( 'article.js_education_box' ).find( '.selected' ).removeClass( 'selected' );
            obj.addClass( 'selected' );
            this.api.userAction('gaokaoaddressItem', {name: obj.text()});
        }
    },
    js_gaokao_citys : function( obj ){
        obj.hide();
    },
    js_preventDefault : function(){
        return false;
    },
    js_gaokao_citys_btn : function() {
        var self = this,
            selected_scores = self.selected_scores,
            now_selected = [];
        if( $( '.js_education_fig1 em.selected' ).length ) {
            now_selected.push( $( '.js_education_fig1 em.selected' ).text() );
        } else {
            return;
        }
        if( $( '.js_education_fig2 em.selected' ).length ) {
            now_selected.push( $( '.js_education_fig2 em.selected' ).text() );
        } else {
            return;
        }
        if( $( '.js_education_fig3 em.selected' ).length ) {
            now_selected.push( $( '.js_education_fig3 em.selected' ).text() );
        } else {
            return;
        }
        if(now_selected.join('_') != selected_scores.join('_')) {
            self.selected_scores = now_selected;
            self.get_scores([
                {province : now_selected[0], sign:1},
                {genre : now_selected[1], sign:1},
                {batch : now_selected[2], sign:1}
            ]);
        }
        $( '#js_gaokao_citys' ).hide();
        self.api.userAction('gaokaoaddressBtn');
    }
});

function DrawPie( canvas,count ){
    this.canvas = canvas;
    this.ctx = this.canvas.getContext( '2d' );
    this.width = this.canvas.width;
    this.height = this.canvas.height;
    this.radius = this.canvas.height/2;//最完成圆的半径
    this.rander_radius = 6;//着色环的宽度
    this.count = count;//百分比
    this.init( );
}
DrawPie.prototype = {
    constructor:DrawPie,
    init : function(){
        var self = this;
        self.canvas.width = this.width;
        self.canvas.height = this.height;
        self.ctx.translate(this.width/2,this.height/2);
        self.draw();
    },
    draw : function() {
        var self = this, ctx = self.ctx,text = self.count<0.01? (0+'%') : (parseFloat(self.count*100).toFixed(1) + '%');
        ctx.beginPath();
        ctx.fillStyle = '#ebecec';
        ctx.arc(0,0,self.radius,0,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        self.draw_pie();
        //画中间的空心白园
        ctx.beginPath();
        ctx.fillStyle = '#fff';
        ctx.arc(0,0,self.radius-self.rander_radius,0,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        //写字
        ctx.font="28px Arial";
        ctx.fillStyle = '#333';
        ctx.fillText(text,-(14*(text.length-1)+20)/2,7);
    },
    draw_pie : function(){
        var self = this,ctx = self.ctx,
            deg = Math.PI*2 * self.count;
        if( self.count < 0.01 ){
            return;
        }
        ctx.save();
        ctx.rotate(-Math.PI/2);
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,this.radius,0,deg);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        self.draw_radius( deg );
    },
    draw_radius : function( deg ) {//画圆角
        var self = this, rander_radius = self.rander_radius,
            ctx = self.ctx,
            radius = self.radius;
        //上半圆角
        ctx.save();
        ctx.rotate(-Math.PI/2);
        ctx.translate(radius-rander_radius/2,0);
        ctx.beginPath();
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,rander_radius/2,Math.PI,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        
        //下半圆角
        ctx.save();
        ctx.rotate(deg-Math.PI/2);
        ctx.translate(radius-rander_radius/2,0);
        ctx.beginPath();
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,rander_radius/2,0,Math.PI);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
};
})(POI, $)