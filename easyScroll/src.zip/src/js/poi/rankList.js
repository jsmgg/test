/* 榜单列表（2级页） */
;(function(POI, $) {

var pageSize = 10;

$.extend(POI, {
    /**
     * 格式化距离.
     * @param {Number} dis 距离
     * @return {String} 12m 3km 5.1km
     */
    logPageId: "dinningRank",
    
    formatDistance: function(dis) {
        if (typeof dis != 'number') {
            dis = parseFloat(dis, 10);
        }
        if (isNaN(dis) || dis < 0) {
            return '';
        }
        if (dis < 1000) {
            return dis.toFixed(0) + '米';
        }
        dis /= 1000;
        return dis.toFixed(1) + '公里';
    },

    //请求榜单列表数据
    quickInit:function() {
        var paramObj = POI.util.getUrlParam(),
            indexParms = [
                {"rank_id": paramObj.listid, "sign": 1},
                {"user_loc": paramObj.loc,"sign": 0},
                {"user_city": paramObj.adcode,"sign": 0},
                {"poiid": paramObj.poiid,"sign":0},
                {"pagenum": 1,"sign": 0},
                {"pagesize": 30,"sign": 0}
            ];
        POI.api.aosrequest("dinningRank", indexParms, this.analyzeList, 1, true, "POST");
    },

    isSony:function(){
        if(navigator.userAgent.match(/L36h/g)){
            //索尼
            $('.rankList').addClass('sony');
        }
    },

    //解析榜单列表数据
    analyzeList:function(arg) {
        if(arg.code == 1 && arg.poi_list.length>0) {
            var poiList = arg.poi_list || [],
                listLen = poiList.length,
                totalNum = Math.ceil(listLen / pageSize),
                lastNum = listLen % pageSize || pageSize,
                divStack = [],
                articleEach = [],
                lastIndex = -1;
            for(var i=totalNum;i>0;i--){
                var j=0;
                if(i>1){
                    j = pageSize;
                }else{
                    j = lastNum;
                }
                divStack.push('<div>');
                var articleStack=[];
                while(j--){
                    analyzeArticle(articleStack,j,lastIndex);
                }
                divStack.push(articleStack.join('')+'</div>');
            }

            var rankList=$('.rankList');
            rankList.html(divStack.join('')).show();
            rankList.children('div:first-child').attr('class','show');
            POI.pullup();
            POI.isSony();
            //解析数据的相关逻辑
            function analyzeArticle(stack, ditj, index) {
                var _index = index + 1;
                lastIndex = _index++;  //lastIndex是解析数据的索引
                var _poilist = poiList[lastIndex];

                stack.push('<article class="splitLine '+(_poilist.flag==1?'on':'')+'" onclick="POI.api.openPoiInfo(\''+_poilist.poiid+'\',\''+_poilist.poi_name+'\',\'\',\'\',\'\',\'\',\''+_poilist.x+'\',\''+_poilist.y+'\',\'1\');POI.api.userAction(\'ranklist\',{poiid:\'' + _poilist.poiid+'\'});"><h2>'+(_poilist.index?('<i class="index">'+_poilist.index+'</i>'):'')+(_poilist.poi_name?('<span class="title">'+_poilist.poi_name+'</span>'):''));
                if(_poilist.groupbuy_flag == 1){
                    stack.push('<i class="ico ico_tuan"></i>');
                }
                if(_poilist.book_flag== 1){
                    stack.push('<i class="ico ico_ding"></i>');
                }
                if(_poilist.discount_flag == 1){
                    stack.push('<i class="ico ico_discount"></i>');
                }
                if(_poilist.distance>0){
                    stack.push('<em>' + POI.formatDistance(_poilist.distance)+'</em>');
                }
                stack.push('</h2>');
                if(_poilist.src_star>0 || _poilist.price && _poilist.price>0) {
                    stack.push('<h5>');
                    if(_poilist.src_star>0){
                        stack.push(POI.util.stars(_poilist.src_star,5));
                    }
                    if(_poilist.classify && "null" !== _poilist.classify && "undefined" !== _poilist.classify) {
                        stack.push('<span>' + _poilist.classify + '</span>');
                    }
                    stack.push((_poilist.price && _poilist.price>0?('<span class="price">'+_poilist.price+'</span>'):''));
                    stack.push('</h5>');
                }
                stack.push('</article>');
            }
        }
    },

    //榜单列表加载更多
    getmore:function(){
        var rankListdiv = document.querySelectorAll('.show'),
            originaldiv = document.querySelectorAll('.rankList > div'),
            divlen = rankListdiv.length,
            oridivlen = originaldiv.length,
            nextdiv = rankListdiv[divlen-1].nextElementSibling;

        if(nextdiv && !nextdiv.className){
            nextdiv.setAttribute('class','show');
        }
        var newdivlen = document.querySelectorAll('.show').length;
        if(newdivlen === oridivlen && this.pullupgetmore){
            //移除事件
            this.pullupgetmore.destory();
            return;
        }
        this.pullupgetmore.refresh();
    },

    pullup:function(){
        var rankList = document.querySelector('.rankList'),
            articlelist = document.querySelectorAll('.rankList > div > article'),
            articlelen = articlelist.length;

        if(articlelen > pageSize){
            POI.pullupgetmore = new POI.util.PullUpGetMore(function() {
                POI.getmore();
            });
        }
    }

});

})(POI, Zepto);