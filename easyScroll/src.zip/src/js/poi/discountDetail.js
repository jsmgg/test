/*
 * 优惠信息详情页
 */
;(function(POI, $) {

$.extend(POI, {

    // 买点page标识
    logPageId : "exCouponDetail",

    poiData : null,
    
    quickInit: function() {
        var self = this;
        self.get_data(function(dis, from, poiData) {
            $('#body').html(self.get_detail_html(dis, from));
            if(from == 'list') {
                self.check_save(dis.discount_gd_id, 0, function(arg) {//设置保存按钮状态
                    if(arg.result == 1) {
                        self.subscribeSucess();
                        self.flag = true;
                    }else {
                        self.flag = false;
                    }
                });
                self.registerShare(dis, poiData);//这里需要注册分享功能
            }
            self.bind_detail(dis, from);
        });
    },
    
    get_data : function(callback) {//获取优惠券详情数据
        var self = this,
            dis_id = POI.util.getUrlParam("did"),
            from = dis_id ? 'list' : 'life',//来源标志
            discount, strArray = [], dis;
        if(from == 'list') {
            self.poiData = POI.util.getStorageData();
            if (!self.poiData || !self.poiData.rti.discount) return;
            discount = JSON.parse(POI.util.storage('discount')||'[]');
            for (var i = 0, j = discount.length; i < j; i++) {
                if (discount[i].discount_gd_id == dis_id) {
                    dis = discount[i];
                    break;
                }
            }
            dis.poi_name = self.poiData.base.name;
            if (dis) typeof callback === 'function' && callback(dis, from, self.poiData);
        }else{
            POI.api.lifeServiceCallBack("openCouponDetail", function(data) {
                if (data) typeof callback === 'function' && callback(POI.browser.and ? $.parseJSON(data.json) : data, from, null);
            });
        }
    },
    
    /*
        获取优惠价详情html
        dis 优惠券详情
        from ：'life' ro 'list' 标志来源，life代表个人中心我的优惠券列表过来的，list代表优惠券列表过来的
    */
    get_detail_html : function(dis, from) {
        var html = ['<section id="sectionDetail" class="notop" style="display:block;">'],
            tmp = '';
        if( dis.pic_info && dis.pic_info[0]){
            dis.usetype == 1 && (tmp = 'valid');
            if(dis.src_type.indexOf('cpr') > -1){
                if(dis.pic_info[0].url.indexOf('?') > -1){
                    dis.pic_info[0].url = dis.pic_info[0].url +'&type=pic';
                }else {
                    dis.pic_info[0].url = dis.pic_info[0].url +'?type=pic';
                }
            }
        }else if(dis.usetype == 1){
            tmp = 'noimgvalid';
        }
        html.push('<div class="' + tmp + '" style="position:relative;font-size:0;">');
        dis.pic_info && dis.pic_info[0] && tmp != 'noimgvalid' && html.push('<img class="logo" src="' + dis.pic_info[0].url + '" />');
        html.push('</div>');
        tmp = '';
        if (dis.discount_bank) {
            tmp = '【' + dis.discount_bank + '】';
        }
        tmp += dis.discount_title || '';
        html.push('<article><h2 id="desc">'+tmp+'</h2></article>');

        if(dis.discount_desc || (dis.price_dis && dis.price_ori)){
            html.push('<article>');
            if (dis.price_dis && dis.price_ori) {
                html.push('<h5><span>' + dis.price_dis + '</span><del>' + dis.price_ori + '</del></h5>');
            }
            if (dis.discount_desc) {
                html.push('<p>' + dis.discount_desc + '</p>');
            }
            html.push('</article>');
        }
        html.push('<article class="viewMoreInfo">');
        html.push('<p>有效期：' + (!dis.endtime ? dis.starttime.substring(0, 10) : dis.starttime.substring(0, 10) + " 至 " + dis.endtime.substring(0, 10)) + '</p>');
        if (dis.carddetails) {
            html.push('<p>支持卡种：' + dis.carddetails + '</p>');
        }
        if (dis.discount_used) {
            tmp = dis.discount_used.split('|');
            if (tmp.length < 7) {
                html.push('<p>适用时间：' + tmp.join('、') + '</p>');
            }
        }
        html.push('</article>');// end .viewMoreInfo
        html.push('</section>');// end #sectionDetail
        if (dis.discount_details) {
            html.push(['<section style="display:block;">',
                '<h2>消费提示</h2>',
                '<article class="viewMoreInfo">',
                '<p>'+dis.discount_details+'</p>',
                '</article>',//end .viewMoreInfo
                '</section>'
            ].join(''));
        }
        //提供来源
        
        tmp = dis.src_name || this.getCnName(dis.src_type);
        dis.src_name = tmp;
        dis.info_appurl = dis.info_appurl || {};
        if(tmp && tmp.indexOf('布丁') >= 0 && (dis.info_appurl.android_appurl || dis.info_appurl.ios_appurl || dis.info_wapurl)) {
            html.push('<section id="viewGraph" and="' + (dis.info_appurl.android_appurl || '') + '" ios="' + (dis.info_appurl.ios_appurl || '') + '" wap="' + (dis.info_wapurl || '') + '" style="display:block;">');
            html.push('<h1 class="more canTouch" >去' + tmp + '查看优惠详情</h1>');
            html.push('</section>');// end #viewGraph
        }
        html.push('<div class="origin" style="display:block;' + (from == 'list' ? '' : 'margin-bottom:0;') + '">');
        if (dis.src_type == 'discount_kahui') {
            html.push('【来源：卡惠】');
        }
        html.push('</div>');// end .origin
        //if(from == 'list'){
        //    html.push('<div id="fixContainer">');
        //    html.push('<div class="picSave">');
        //    html.push('<span class="save" id="test">保存</span>');
        //    html.push('</div>');// end .picSave
        //    html.push('</div>');// end #fixContainer
        //}
        return html.join('');
    },
    
    //来源中文名称
    getCnName : function(src_type) {
        if (src_type && this.poiData && this.poiData.src_info && this.poiData.src_info[src_type]) {
            return this.poiData.src_info[src_type].name_cn;
        } else {
            return "";
        }
    },
    
    check_save : function(dis_id, state, callback, data) {//发送保存或取消保存请求
        POI.api.discountSubscribe(dis_id, state, callback, data);
    },
    
    bind_detail : function(dis, from) {//事件绑定
        var self = this, body = $('#body'), img = new Image();
        $('#viewGraph').click(function(ev) {
            var o = $(this);
            POI.api.getAppPara(o.attr('ios'), o.attr('and'), o.attr('wap'));
            POI.api.userAction('thirdDiscountPoi', {
                discountId : dis.discount_gd_id
            });
        });
        from == 'list' && $('#fixContainer .picSave').click(function(){//保存按钮事件绑定
            POI.api.userAction((self.flag ? 'cancelSave' : 'save'), {
                discountId : dis.discount_gd_id
            });
            self.check_save(dis.discount_gd_id, self.flag ? 2 : 1, function(arg) {
                if(arg.result == 1){
                    self.flag ? self.subscribeCancel() : self.subscribeSucess();
                    self.flag = !self.flag;
                }
            }, self.flag ? '' : dis);
        });
        img.onload = function() {
            body.show();
            img = img.onload = img.onerror = null;
        };
        img.onerror = function() {
            var obj = body.find('img.logo');
            if (dis.usetype == 1) {
                obj.parent().removeClass('valid').addClass('noimgvalid');
            }
            obj.remove();
            body.show();
            img = img.onload = img.onerror = null;
        };
        dis.pic_info && dis.pic_info[0] ? (img.src = dis.pic_info[0].url) : img.onload();
    },
    
    registerShare : function(dis, poiData) {//注册分享按钮
        var arrArg = [],arrStr = '',
            nativeurl, iosurl, androidurl, url, cont;
        arrArg.push('?poiid=' + poiData.base.poiid);
        arrArg.push('discount_gd_id=' + dis.discount_gd_id);
        arrArg.push('source=' + dis.source);
        arrArg.push('page_src=' + 'discountPoi');
        arrStr = arrArg.join('&');
        POI.activityUrl.discountShareMoUrl += arrStr;
        nativeurl = encodeURIComponent(POI.activityUrl.discountShareClientUrl + "?poi_id=" + poiData.base.poiid + "&discount_id=" + dis.discount_gd_id + "&activity_title=" + poiData.base.name + "&page_src=mo&source=" + dis.source);
        iosurl = "openFeature?featureName=OpenURL&sa=1&sourceApplication=amap&url=" + nativeurl + "&urlType=0&contentType=autonavi";
        androidurl = "androidamap?&action=openFeature&featureName=OpenURL&sourceApplication=amap&url=" + nativeurl + "&urlType=0&contentType=autonavi";
        url = "http://mo.amap.com/callAPP?ios=" + encodeURIComponent(iosurl) + "&android=" + encodeURIComponent(androidurl) + "&mo=" + encodeURIComponent(POI.activityUrl.discountShareMoUrl);
        cont = [{
            type: "weibo",
            message: "[" + poiData.base.name + "]" + dis.discount_title + "，快来查看~",
            title: "[" + poiData.base.name + "]" + dis.discount_title + "，快来查看~",
            url: url
        }, {
            type: "weixin",
            message: "超值优惠：[" + poiData.base.name + "]" + dis.discount_title + "，快来查看~",
            title: "来高德地图找优惠，让你更“惠”生活！",
            url: url
        }, {
            type: "pengyou",
            message: "超值优惠：[" + poiData.base.name + "]" + dis.discount_title + "，快来查看~",
            title: "来高德地图找优惠，让你更“惠”生活！",
            url: url
        }];
        POI.api.registShareBtn(cont);
    },
    
    subscribeSucess : function(){
        $('#test')[0].innerHTML = '已保存';
        var $fixContainer = $('#fixContainer');
        $fixContainer.find('.picSave').removeClass('picSave').addClass('saveBacSuccess');
        $fixContainer.find('.save').addClass('saveSuccess');
    },
     
    subscribeCancel : function(){
        $('#test')[0].innerHTML = '保存';
        var $fixContainer = $('#fixContainer');
        $fixContainer.find('.saveBacSuccess').removeClass('saveBacSuccess').addClass('picSave');
        $fixContainer.find('.save').removeClass('saveSuccess');
    }
    
});

})(POI, Zepto);