;(function(POI) {
//电影动态模块公用代码
$.extend(POI, {
    movie :{
        sale_s : [],
        scroll : null,
/*

*/
        showMovie : function(){
            var self = this,
                rti = POI.aosData.rti||{}, moviesS = rti.movies || [];
            self.sale_s = [];
            if (moviesS.length == 0) return '';
            self.poiSign = 1; //POI详情页的标志
            POI.util.executeAfterDomInsert(function() {
                POI.send({action: 'openMovieDetail'}, function(arg){
                    var index = self.movieid_map[arg.movieID]||0;
                    self.show_movie($('.movieticket_imgbox_ul li').eq(index));
                    index>0 && self.scroll.moveto($('.movieticket_imgbox_ul li')[index],0);
                });
            });
            return self.get_movie_html( moviesS );
        },
        movieid_map : {},//movie_id:index
        get_movie_html : function( moviesS ){
            var self = this,
                html = ['<section class="movieticket">'],
                winw = document.documentElement.clientWidth,
                ml = [],imgs = ['<div class="movieticket_imgbox"><ul class="movieticket_imgbox_ul" style="width:' + moviesS.length * 75 + 'px;padding-left:'+ (winw/2-38) +'px;padding-right:'+ (winw/2-37) +'px;">'],
                handleAttr = POI.handleAttr;
            moviesS.forEach(function( item , i) {
                self.sale_s.push(item.sale_status);
                ml.push('<div class="movieticket_list" id="js_movie_'+i+'">');
                ml.push('<h2 class="movieticket_list_h2 module_title_p more line-half" '+ handleAttr +'="js_gomovie_detail">' + (item.name || ''));
                ml.push('<em>');
                if ( item.score_movie ) {
                    ml.push(item.score_movie + '分');
                } else {
                    ml.push('暂无评分');
                }
                if (item.length) {
                    ml.push('<span>时长:' + item.length + '分钟</span>');
                }
                ml.push('</em></h2>');// end h2
                ml.push('<article class="movieticket_art1" style="display:none;"></article>');
                ml.push('<div class="movieticket_list_wrap">');
                ml.push('<ul class="movieticket_list_ul" id="js_movieticket_loading" style="display:block;">');
                ml.push('<li class="movieticket_list_loading"><img src="img/loading_getmore.gif" /><label>正在加载影片排期…</label></li>');
                ml.push('</ul>');// end .movieticket_list_ul
                ml.push('</div>');// end .movieticket_list_wrap
                ml.push('</div>');// end .movieticket_list
                
                imgs.push('<li '+ handleAttr +'="js_movie_imglist" index="'+i+'"><p>'+ (item.coverpic &&  item.coverpic != 'null' ? '<img src="'+ POI.util.imageUrlTransform(item.coverpic,72,98,'resize') +'"/>' : '') +'</p></li>');
                self.movieid_map[item.id] = i;//缓存movieid  和  index的对应关系
            });
            imgs.push( '</ul><i></i></div>' );// end .movieticket_imgbox
            
            html = html.concat( imgs );
            html = html.concat( ml );
            html.push( '</section>' );// end .movieticket
            POI.util.executeAfterDomInsert(function() {
                self.movieEvent();
            });
            return html.join( '' );
        },
        movieEvent : function(){
            var self = this, timer;
            self.scroll = POI.easyScroll('.movieticket_imgbox',{
                snap:true,
                preventDefault : false,
                align : 'x',
                snap_callback : function( obj ) {
                    self.show_movie( $(obj) );
            }});
            $(window).resize(resize).bind('orientationchange', resize);
            function resize(){
                clearTimeout( timer );
                timer = setTimeout( function() {
                    var winw = document.documentElement.clientWidth;
                    $('.movieticket_imgbox_ul').css({
                        'padding-left' : (winw/2-37) +'px',
                        'padding-right' : (winw/2-38) +'px'
                    });
                    self.scroll.refresh();
                }, 300);
            }
        },
        movie_click_cache : {},
        show_movie : function( obj ){
            var key = obj.attr('index'),
                rti = (POI.aosData||{}).rti || {};
                moviesS_i = (rti&&rti.movies) || (this.includeMovies&&this.includeMovies.movies) || [];
            if(!this.movie_click_cache[ key ]){//发过请求的不在发了，直接显示隐藏dom就行啦
                this.movie_click_cache[ key ] = true;
                this.getMovieDate(this.poiid || POI.clientData.poiInfo.poiid, moviesS_i[key].id,0,0, key);
            }
            !obj.hasClass( 'selected' ) && obj.addClass( 'selected' );
            POI.util.storage('movieID', moviesS_i[key].id);
            POI.util.storage('movieTitle', moviesS_i[key].name);
            $('.movieticket_list').not('#js_movie_'+key).hide();
            $('#js_movie_'+key).show();
        },
        /*
            返回页面排期、图片列表 html数组
        */
        showMovieDate : function(movietickets){
            var self = this,
                handleAttr = POI.handleAttr,
                key = $('.movieticket_imgbox_ul li.selected').attr('index'),
                ticket_info = movietickets.ticket_info || [],
                len = ticket_info.length,
                dayhtml = [],
                moviesS = movietickets.movies || [],
                hgroupStack = [], groupDis = [], titleStack = [], imgStack = '',
                html = [], day,
                status, ticketlist, text, t_date;
                
            if( len ){
                
                ticket_info.forEach(function( item , i ) {
                    day = ['今天','明天','后天'][i];
                    status = item.status;
                    
                    if(status) {
                        ticketlist = item.tickets;
                        html.push('<ul class="movieticket_list_ul" id="js_list_' + key + '_' + i + '" '+ (i==0?'style="display:block;"' : '') +'>');
                        
                        if( status == '1' && ticketlist.length ) {
                            
                            ticketlist.forEach(function( ticket ) {
                                
                                if(ticket.xz && ticket.xz == 1 && ticket.ticket_status==1 ) {
                                    html.push('<li ' + handleAttr + '="js_movie_checkticket" url="' + ticket.url + '" cp_count="' + ticket.cp_count + '" ticketid="' + ticket.ticketid + '" class="canTouch">');
                                } else {
                                    html.push('<li>');
                                }
                                
                                html.push('<p class="movieticket_list_stime"><i>' + (ticket.time.substring(11, 16) || '&nbsp') + '</i>' + (ticket.finish_time.substring(11, 16) || '&nbsp') + '散场</p>');
                                
                                html.push('<p class="movieticket_list_section"><i>' + (ticket.lang.substring(0, 2) || '&nbsp') + (ticket.screen.substring(0, 8) || '&nbsp') + '</i>' +( ticket.hall ? ticket.hall.match(/^.{0,4}[^\(\)（）]/)[0] : '&nbsp')+ '</p>');
                                
                                html.push( '<p class="movieticket_list_price">' +(ticket.price && ticket.price > 0 ? Number(ticket.price)+'<i>元</i>' : '')+ '</p>' );
                                
                                if(ticket.xz && ticket.xz == 1 && ticket.ticket_status) {
                                    if(ticket.ticket_status == '1') {
                                        html.push( '<p class="movieticket_list_buy"><em>购买</em></p>' );
                                    } else {
                                        html.push( '<p class="movieticket_list_buy"><em class="dis">购买</em></p>' );
                                    }
                                } else {
                                    html.push( '<p class="movieticket_list_buy"><em class="dis">购买</em></p>' );
                                }
                                html.push('</li>');
                            });
                            dayhtml.push('<li '+ ( i == 0 ? 'class="selected"' : '') +' '+handleAttr+'="js_moveTicket_day" index="'+i+'" key="'+key+'"><p class="half-border canTouch"><span class="lineDot">' + self.cutStr(item.date, day) + '</span><i></i></p></li>');
                        } else {
                            
                            if( self.poiSign ){
                                if(self.sale_s && self.sale_s[key] == 2){
                                    //預售
                                    text = '此片暂未上映';
                                }else{
                                    if(status == '2'){
                                        //其它
                                        text = '暂无当日排期';
                                    }else if(status == '3'){
                                        //其它
                                        text = '当日已映完';
                                    }
                                }
                            } else {
                                if(self.client_s && self.client_s[key] == 2){
                                    //預售
                                    text = '此片暂未上映';
                                }else{
                                    if(status == '2'){
                                        //其它
                                        text = '暂无当日排期';
                                    }else if(status == '3'){
                                        //其它
                                        text = '当日已映完';
                                    }
                                }
                            }
                            html.push( '<li class="movieticket_list_nodata"><label>'+ text +'</label>' );
                            
                            if (i + 1 != len) { //说明不是最后一个
                                t_date = ticket_info[i + 1] && ticket_info[i + 1].date;
                                
                                if (i == 0) { //只对今日
                                    var key_date = 0;
                                    
                                    for (var z = 1; z < Math.min(3, len); z++) {
                                        var j_status = ticket_info[z] && ticket_info[z].status;
                                        
                                        if (Number(j_status) == 1 && ticket_info[z].tickets.length) {
                                            key_date = z;
                                            html.push('<br/><i index="'+(i+1)+'" '+handleAttr+'="js_movieTickets_nextday" class="canTouch">点击查看' + self.cutStr(ticket_info[z].date) + '排期</i>');
                                            break;
                                        }
                                    }
                                    
                                    if (len > 3 && key_date == 0) {
                                        html.push('<br/><i index="'+(i+1)+'" '+handleAttr+'="js_movieTickets_nextday" class="canTouch">点击查看' + self.cutStr(ticket_info[3].date) + '排期</i>');
                                    }
                                    
                                } else {
                                    html.push('<br/><i index="'+(i+1)+'" '+handleAttr+'="js_movieTickets_nextday" class="canTouch">点击查看' + self.cutStr(t_date) + '排期</i>');
                                }
                            }
                            
                            html.push('</li>');// end li
                            i==0 && dayhtml.push('<li class="selected" '+handleAttr+'="js_moveTicket_day" index="'+i+'" key="'+key+'"><p class="half-border"><span class="lineDot">' + self.cutStr(item.date, day) + '</span><i></i></p></li>');
                        }
                        html.push('</ul>');//end movieticket_list_ul
                    }
                });
            }
            dayhtml = dayhtml.length ? '<ul class="movieticket_art1_ul" style="width:' + dayhtml.length*100 + 'px;">' + dayhtml.join('') + '</ul>' : '';
            
            if(!self.poiSign) {
                //表示从客户端电影列表进入的
                //头部信息数据解析
                var poiinfo = movietickets.poi_info || {};
                if(poiinfo.name || poiinfo.address){
                    hgroupStack.push('<hgroup><strong class="canTouch">去这里</strong>');
                    if(poiinfo.name){
                        hgroupStack.push('<h3>'+poiinfo.name+'</h3>');
                    }
                    if (poiinfo.address) {
                        hgroupStack.push('<em>地址：'+poiinfo.address+'</em>');
                    }
                    hgroupStack.push('</hgroup>');
                }
                var hasWebTitleBarStr = window.hasWebPageTitleBar ? "&showTitleBar=1" : "";
                if (movietickets.isgroupbuy && movietickets.isgroupbuy == '1') {
                    //有团购
                    if (movietickets.iscoupon && movietickets.iscoupon == '1') {
                        //团购 兑换券都存在
                        groupDis.push('<article class="module_title_p more"><a href="exMovieTuan.html?poiid=' + self.poiid + hasWebTitleBarStr + '">本店还支持团购和兑换券');
                    } else {
                        //只有团购
                        groupDis.push('<article class="module_title_p more"><a href="exMovieTuan.html?poiid=' + self.poiid + hasWebTitleBarStr + '">本店还支持团购');
                    }
                } else if (movietickets.iscoupon && movietickets.iscoupon == '1') {
                    //只有兑换券
                    groupDis.push('<article class="module_title_p more"><a href="exMovieTuan.html?poiid=' + self.poiid + hasWebTitleBarStr + '">本店还支持兑换券');
                }

                if ((movietickets.isgroupbuy && movietickets.isgroupbuy == '1') || (movietickets.iscoupon && movietickets.iscoupon == '1')) {
                    if (movietickets.coupon_price_lowest && movietickets.coupon_price_lowest > 0) {
                        groupDis.push('<span>' + Number(movietickets.coupon_price_lowest) + '</span></a></article>');
                    }
                }

                //图片轮播图
                if (moviesS && moviesS.length) {
                    imgStack = self.get_movie_html(moviesS);
                }
            }
            return [dayhtml,html.join(''), hgroupStack.join(''), groupDis.join(''), imgStack];
        },
        //电影日期切换格式转换
        cutStr:function(dateStr,preStr){
            if(!dateStr) return;
            var dates = dateStr.split('-'),datestack=[],conStr,preStr=preStr||'';
            for(var i=1;i<dates.length;i++){
                switch(dates[i].indexOf('0')){
                    case 0:
                    //以0开头
                        datestack.push(dates[i].substr(1));
                        break;
                    default:
                        datestack.push(dates[i]);
                        break;
                }
            }
            conStr = preStr+datestack[0]+'月'+datestack[1]+'日';
            return conStr;
        },
        //从客户端电影列表进入的排期页
        pushMovieShowing: function(para, movietickets) {
            var self = this, poiinfo = movietickets.poi_info || {}, movieIdStack = [], movies = self.includeMovies && self.includeMovies.movies || [], key_Id = 0, cinema_name = movietickets.poi_info.name || '';
            //存储所有的movieid
            for (var i = 0, len = movies.length; i < len; i++) {
                if (self.clientID == movies[i].id) {
                    key_Id = i;
                    break;
                }
            }
            if (cinema_name) {
                document.title = cinema_name;
            }
            if (movietickets.movie_privilege && movietickets.movie_privilege.privilege && movietickets.movie_privilege.privilege != 0 && movietickets.movie_privilege.privilege_content) {
                //表示有优惠信息
                $('#moviePromotion').html('<h2 class="module_title_p' + (movietickets.movie_privilege.privilege_link ? ' more': '') + '">'+movietickets.movie_privilege.privilege_content+'</h2>');
                if(movietickets.movie_privilege.privilege_link){
                    $('#moviePromotion').click(function(){
                        POI.util.locationRedirect(movietickets.movie_privilege.privilege_link);
                    })
                }
            }
            $('#MovieInfoSpec').html(para[2]+para[3]);
            $('#MovieInfoSpec').show();
            $('#MovieInfoSpec hgroup strong').click(function() {
                //Matrix.poiinfo = {
                var p  = {
                    poiid: '',
                    name: poiinfo.name,
                    address: poiinfo.address,
                    poiType: 1,
                    phoneNumbers: poiinfo.tel,
                    x: '',
                    y: '',
                    lon: poiinfo.x || '',
                    lat: poiinfo.y || ''
                }
                POI.api.searchRoute(null, p);
                POI.api.userAction('gotohere'); //去这里
            });

            if (!movies.length) {
                if(!self.poiSign){
                    $('#movieNodata').show();
                }
                $('.movieticket').hide();
                return;
            }

            $('.movieticket').show();
            if (para[4]) {
                $('.autoTip').show();
            }
            $('.movieticket').replaceWith(para[4]);
            self.movieEvent();

            POI.util.executeAfterDomInsert();
            //选中指定影片
            POI.js_movie_imglist($('.movieticket_imgbox_ul li').eq( key_Id ), 0);
            POI.js_moveTicket_day( $('.movieticket_art1_ul li.selected').eq(0) );
        },
        //poi详情页排期
        pushMovieDate: function(para, movietickets, key) {
            var self = this,
                box = $('#js_movie_'+key), timebox = box.find('.movieticket_art1');
            $('.movieticket_list').not('#js_movie_'+key).hide();
            timebox.html(para[0]).show();
            box.find('.movieticket_list_wrap').html(para[1]);
            box.show();
            if( timebox.width() < timebox.find('ul').width() ){
                POI.easyScroll(timebox[0],{
                    preventDefault : false,
                    align : 'x'
                });
            }
            POI.js_moveTicket_day( timebox.find('li.selected').eq(0) );
            
        },
        client_s : [],
        clientID : '',//记录客户端传过来的电影id
        first_getdata : true,
        //电影排期
        getMovieDate:function(poiID,movieID,mode,sign, index){
            var self = this, params = [
                {'poiid':poiID,'sign':1},
                {'movieid':movieID,'sign':1},
                {'mode':mode}
            ], key = [poiID,movieID,mode].join('_');
            sign = sign || 0;
            POI.api.aosrequest('qqMovieDate', params, fun , sign ? 1 : 0, true, 'get');
            function fun( movieDate ) {
                var pushPara;
                if(movieDate && movieDate.code && movieDate.code == 1){
                    pushPara = self.showMovieDate(movieDate);
                    if (self.poiSign){
                       self.pushMovieDate(pushPara,movieDate, index); 
                    } else {
                        //从客户端进入会把所有的电影图片都返回（mode为1）,以后点击图片获取到的是没有movie的
                        if(movieDate.movies && movieDate.movies.length){
                            self.includeMovies=movieDate;
                        }
                        //第一次请求为页面请求，需要拼接页面头部信息及其他信息，其他时候为图片列表切换请求，只需要拼接对应电影的排期信息
                        self.first_getdata ? self.pushMovieShowing(pushPara,movieDate) : self.pushMovieDate(pushPara,movieDate, index);
                        self.first_getdata = false;
                    }
                    
                }else{
                    if(!self.poiSign){
                        $('#movieNodata').show();
                    }
                }
            }
        }
    },
    get_movie_navbg : function() {
        return new POI.util.DialogBox({
            width: 90,
            height: 30,
            borderWidth: 1,
            borderColor: "#0091ff",
            borderRadius: 2,
            arrowDirection: 0,
            arrowDistance:  40,
            arrowWidth: 10,
            arrowHeight: 5
        });
    },
    js_movie_checkticket : function(obj) {//选座按钮处理函数
        var self = this;
        //self.util.storage('ticketID',obj.attr('ticketid'));
        self.api.userAction('selSeat');
        if(parseInt(obj.attr('cp_count')||0)>1){
            self.util.storage('movie_more_price',JSON.stringify( {ticketid : obj.attr('ticketid'), poiid : self.movie.poiid || self.clientData.poiInfo.poiid, movieid : self.util.storage('movieID') } ));//更多报价页面参数列表,这里客户端不支持 地址栏传参数
            self.api.getAppPara('','',obj.attr('url'),{buttonText: '更多报价', localFile:'exMovieList.html'});
        }else{
            self.api.getAppPara('','',obj.attr('url'));//tickets.url;_tickets.cp_count>1;_tickets.ticketid
        }
    },
    js_movie_imglist : function( obj , time ){
        if(obj.hasClass( 'selected' )) return;
        this.movie.scroll.moveto( obj[0] , time);
        $('.movieticket_imgbox_ul li.selected').removeClass('selected');
        this.movie.show_movie( obj );
        this.api.userAction('movie_img_click');
    },
    js_moveTicket_day : function( obj ){
        var key = obj.attr('key'), index = obj.attr('index'),
            box = $('#js_movie_'+key), p = obj.find('p');
        !p.find('canvas').length && p.append(this.get_movie_navbg());
        if( obj.hasClass('selected') ) return;
        box.find('.movieticket_list_ul').not('#js_list_'+key+'_'+index).hide();
        $('#js_list_'+key+'_'+index).show();
        obj.parent().find('.selected').removeClass('selected');
        obj.addClass('selected');
        this.api.userAction('movPost');
    },
    js_movieTickets_nextday : function( obj ){//点击查看下一天排期
        var box = obj.parents('.movieticket_list').eq(0);
        this.js_moveTicket_day(box.find('.movieticket_art1 li').eq( obj.attr('index') ));
    },
    js_gomovie_detail : function(){
        this.api.userAction('gomovie_detail');
        this.util.locationRedirect('exMovieDetail.html?from=poi' + (window.hasWebPageTitleBar ? '&showTitleBar=1' : ''));
    }
});
})(POI, Zepto)