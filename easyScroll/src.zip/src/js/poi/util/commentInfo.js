/*
    评论模块公共部分
*/
;(function(POI, $) {
'use strict';

var pageShowCallback = null;
function pageShow(evt) {
    var pageAry = ['/index.html', '/exComment.html'];
    var reg = new RegExp('('+pageAry.join('|')+')', 'g');
    if(reg.exec( location.href )) {
        window.removeEventListener("pageshow", pageShow, false);
        if(pageShowCallback) {
            pageShowCallback();
        }
    }
    
}

$.extend(POI, {
    commentUtil : {
        openNativeCommentEditor : function(score, business, from, callback, poi) {
            var poiInfo = null;
            if(poi) {
                poiInfo = poi;
            } else {
                var clientDataStr = POI.util.storage("clientData");
                var clientData = null;
                if(clientDataStr) {
                    clientData = JSON.parse(clientDataStr);
                    poiInfo = clientData ? clientData.poiInfo : null;
                }
            }
            if(3 <= this.getStorageInfoCount(poiInfo.poiid)) {
                POI.api.promptMessage("今天你已经点评过这里3次了哦");
                return;
            }
            var param = {
                action: "commentsWrite",
                business: business || POI.business,
                score: score | 0,
                from: from,
                poiInfo: poiInfo
            };
            POI.send(param, function(data) {
                if(data && -1 == data.status) {
                    POI.star_animate( 0 , $('.sendComment_gray p') );
                    return;
                }
                if(data && data.comment && data.comment.id) {
                    POI.commentUtil.updateStorageInfo(data.poiId);
                    if(/\/comment_success\.html/.test(location.href)) {
                        callback && callback(data);
                    } else {
                        pageShowCallback = callback;
                        window.addEventListener("pageshow", pageShow, false);
                        setTimeout(function() {
                            POI.util.storage("COMMENT_POIINFO", JSON.stringify(poiInfo));
                            POI.util.locationRedirect("comment_success.html?star=" + data.comment.score + "&business=" + POI.business + "&c=" + data.comment.id + "&n=" + POI.mostTingCount);
                        }, 17);
                    }
                }
            });
        },
        
        updateStorageInfo : function(poiid, isRefresh) {
            var argLength = arguments.length;
            var storageStr = POI.util.storage("COMMENT_USER_STORAGE_INFO");
            var storageInfo = {};
            if(storageStr) {
                storageInfo = JSON.parse(storageStr);
            }
            var key = "p_" + poiid;
            if(1 == argLength) {
                if(storageInfo[key]) {
                    var lTime = new Date(storageInfo[key].lastTime);
                    var now = new Date();
                    if(now.getFullYear() === lTime.getFullYear() && now.getMonth() === lTime.getMonth() && now.getDate() === lTime.getDate()) {
                        storageInfo[key].lastTime = new Date().getTime();
                        storageInfo[key].count += 1;
                        storageInfo[key].isRefresh = true;
                    } else {
                        storageInfo[key] = {
                            poiid: "" + poiid,
                            lastTime: new Date().getTime(),
                            count: 1,
                            isRefresh: true
                        };
                    }
                } else {
                    storageInfo[key] = {
                        poiid: "" + poiid,
                        lastTime: new Date().getTime(),
                        count: 1,
                        isRefresh: true
                    };
                }
            } else if(2 == argLength) {
                storageInfo[key] = storageInfo[key] || {
                        poiid: "" + poiid,
                        count: 0
                    };
                if(isRefresh) {
                    storageInfo[key].lastTime = new Date().getTime();
                }
                storageInfo[key].isRefresh = isRefresh;
            }
            POI.util.storage("COMMENT_USER_STORAGE_INFO", JSON.stringify(storageInfo));
        },
        
        getStorageInfoCount : function(poiid) {
            var storageStr = POI.util.storage("COMMENT_USER_STORAGE_INFO");
            var storageInfo = {};
            if(storageStr) {
                storageInfo = JSON.parse(storageStr);
            }
            var key = "p_" + poiid;
            var thisPoiInfo = storageInfo[key];
            if(thisPoiInfo) {
                var lTime = new Date(storageInfo[key].lastTime);
                var now = new Date();
                if(now.getFullYear() === lTime.getFullYear() && now.getMonth() === lTime.getMonth() && now.getDate() === lTime.getDate()) {
                    return storageInfo[key].count | 0;
                } else {
                    delete storageInfo["p_" + poiid];
                    POI.util.storage("COMMENT_USER_STORAGE_INFO", JSON.stringify(storageInfo));
                    return 0;
                }
            } else {
                return  0;
            }
            
        },
        
        getRefreshStatus : function(poiid) {
            var storageStr = POI.util.storage("COMMENT_USER_STORAGE_INFO");
            var storageInfo = {};
            if(storageStr) {
                storageInfo = JSON.parse(storageStr);
            }
            var key = "p_" + poiid;
            var thisPoiInfo = storageInfo[key];
            if(thisPoiInfo) {
                var lTime = new Date(thisPoiInfo.lastTime);
                var now = new Date();
                if((5 * 3600 * 1000) > (now - lTime)) {
                    return true;
                }
            }
            return false;
        }
    },
    js_open_commentlist : function() {
        //var self = this;
        //self.api.userAction('exComment');
        //self.util.locationRedirect('exComment.html?business='+self.business+'&pageId='+ self.clientData.poiInfo.poiid);
    }
})

})(POI, Zepto);