﻿/**
 * 显示title bar
 */
(function(POI, $) {

    'use strict';
    
    window.hasWebPageTitleBar = false;
    
    if (POI.util.getUrlParam('hideTitleBar')) {
        return;
    }
    
    // TODO 附近 -> 看电影 -> 选择电影院
    var noTitleBarAry = {
            "exHotelCalendar"     : 1,
            "exHotelOrderDetail"  : 1,
            "hotelOrderDetail"    : 1,
            "queueOrderList"      : 1,
            "exMovieDetail"       : 1,
            "exMovieShowings"     : 1,
            "exMovieTuan"         : 1,
            "exMovieList"         : 1,
            "exTuangou"           : 1,
            "exScenicOrderDetail" : 1,
            "shareToCar/index"    : 1,
            "exCouponDetail"      : 1
        };

    var isShowTitleBar = POI.util.getUrlParam('showTitleBar');
    for (var key in noTitleBarAry) {
        if ( -1 !== location.href.indexOf("/" + key + '.html') && !isShowTitleBar ) {
            return;
        }
    }

    window.hasWebPageTitleBar = true;
    
    var agent = navigator.userAgent,
        os = agent.match(/iphone|ipad|ipod/i) ? "ios" : "android",
        //isIndex = /\/index.html/.test(location.href),
        // todo: 测试用例
        isIndex = /\/poiHead.html/.test(location.href),
        body = document.body,
        headerDom = document.createElement("nav"),
        titleBarHeight = 0;

    headerDom.id = "poiTitleBar";
    if("android" === os) {
        if(isIndex) {
            headerDom.className = "topBar indexBar transparent";
        } else {
            headerDom.className = "topBar";
            body.style.paddingTop = "44px";
        }
        titleBarHeight = 44;
    } else {
        if(isIndex) {
            headerDom.className = "topBar ver7 indexBar transparent";
        } else {
            headerDom.className = "topBar ver7";
            body.style.paddingTop = "64px";
        }
        titleBarHeight = 64;
    }
    headerDom.innerHTML = '<a id="webviewGoBack" href="javascript:void(0);" class="topBar_back canTouch"><i class="topBar_arrow"></i></a>' +
                          '<div class="topBar_wrapper">' +
                              '<p id="topBarName" class="topBar_name linesDot' + (isIndex ? ' topBar_opacity0' : '') + '">' + document.title + '</p>' +
                          '</div>' +
                          '<div id="titleBarBtns" class="topBar_btns">' +
                              (isIndex ? 
                              '<div class="topBar_ibox">' +
                                  '<i id="favorite" class="topBar_i1"></i><i id="poiShare" class="topBar_i2"></i>' +
                              '</div>' +
                              '<i id="gohereBar" class="topBar_i3 hid">去这里</i>' : '')+
                          '</div>';

    body.insertBefore(headerDom, body.firstChild);

    POI.util.setPageTitle = function(title) {
        if(title) {
            $("#topBarName").text(title);
        }
    };
    POI.util.getTitleBarHeight = function() {
        return titleBarHeight;
    };
    POI.util.registerRightBtn = function( html, fun) {
        $( '#titleBarBtns' ).html( html );
        rightBtnClick = fun;
    };
    var rightBtnClick = function(){};
    var click = function(ele, handler, once) {
        var startTime = 0,
            startPos = {
                x: 0,
                y: 0
            };
        var start = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            startTime = new Date();
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            ele.addEventListener("touchmove", move, false);
            ele.addEventListener("touchend", end, false);
            if(e.touches) {
                startPos.x = e.touches[0].pageX;
                startPos.y = e.touches[0].pageY;
                var tar = e.target;
                tar.className = tar.className + " hover";
                setTimeout(function() {
                    tar.className = tar.className.replace(" hover", "");
                }, 300);
            }
            e.stopPropagation();
        },
        move = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            if(5 < Math.abs(e.touches[0].pageX - startPos.x) || 5 < Math.abs(e.touches[0].pageY - startPos.y)) {
                ele.removeEventListener("touchmove", move, false);
                ele.removeEventListener("touchend", end, false);
                e.stopPropagation();
            } else {
                var tar = e.touches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
        },
        end = function(e) {
            var endTime = new Date();
            if(200 > (endTime - startTime)) {
                handler.call(null, e);
                if(once) {
                    ele.removeEventListener("touchstart", start, false);
                }
            }
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            if(e.changedTouches) {
                var tar = e.changedTouches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
            e.preventDefault();
            e.stopPropagation();
        };
        ele.addEventListener("touchstart", start, false);
    };
    //var $titleBar = $('#poiTitleBar');
    //$titleBar.on('click', '#webviewGoBack', function(e) {
    //    POI.api.webviewGoBack();
    //});
    click($("#webviewGoBack")[0], function() {
        try {
            var inputs = $("input, textarea");
            for(var i = 0, len = inputs.length; i < len; i++) {
                inputs[i].blur();
            }
        } catch(e) {}
        POI.api.webviewGoBack();
    });
    click( $( '#titleBarBtns' )[0], function( e ){
        rightBtnClick.call(POI, e, $( '#titleBarBtns' ));
    });
    if(isIndex) {
        //$titleBar.on('click', '#favorite', function() {
        //    var self = POI, o = $( this );
        //    self.api.toggleFavoritePoint(self.clientData.poiInfo, function(res) {
        //        if (res.result != 1) {
        //            return;
        //        }
        //        o.hasClass('favorited') && $('#MyFavInfo').remove();
        //        o.toggleClass('favorited');
        //    });
        //    self.api.userAction('favorite');
        //});
        var favorite = $("#favorite")[0];
        click(favorite, function() {
            var self = POI, o = $( favorite );
            var name = self.util.bool(self.clientData.poiInfo.name) ? self.clientData.poiInfo.name : '';
            if(!name && self.aosData && self.aosData.base.name) {
                name = self.aosData.base.name;
            }
            if (self.clientData.CURRENT_BUS_ALIAS) {
                self.clientData.poiInfo.name = name.replace('(公交站)','(公交站' + self.clientData.CURRENT_BUS_ALIAS + '站台)');
            }
            self.api.toggleFavoritePoint(self.clientData.poiInfo, function(res) {
                self.clientData.poiInfo.name = name;
                if (res.result != 1) {
                    return;
                }
                o.hasClass('favorited') && $('#MyFavInfo').remove();
                o.toggleClass('favorited');
            });
            self.api.userAction('favorite');
        });
        
        //$titleBar.on('click', '#poiShare', function() {
        //    var self = POI;
        //    self.api.shareToFriends(self.clientData.poiInfo);
        //    self.api.userAction('barpoishare');
        //});
        click($("#poiShare")[0], function() {
            var self = POI;
            self.api.shareToFriends(self.clientData.poiInfo);
            self.api.userAction('barpoishare');
        });
        //$titleBar.on('click', '#gohereBar', function() {
        //    var self = POI;
        //    self.api.searchRoute(null, self.clientData.poiInfo);
        //    self.api.userAction('bargohere');
        //});
        click($("#gohereBar")[0], function() {
            var self = POI;
            self.api.searchRoute(null, self.clientData.poiInfo);
            self.api.userAction('bargohere');
        });
        
        var poiTitleBar = $("#poiTitleBar");
        var $titleBarBtns = $("#titleBarBtns");
        var nameShow = false;
        var nameShowFinish = false;
        var gohereShow = false;
        var gohereShowFinish = false;
        var backgroundShowing = false;
        var backgroundShown = false;
        var $name = $("#topBarName");
        var $gohere = $("#gohereBar");
        var mainDom = null;
        var titleDom = null;
        var gohereDom = null;
        var mainPos = 0;
        var titlePos = 0;
        var goherePos = 0;
        var iosBackgroundRange = 28;
        var iosCommonRange = 50;
        var backgroundRangeFlag = false; // ios触发scroll事件时正好位于中间地带的标识
        var timer;
        var titleIconFlag = 0;
        var changeIcon = function(flag) {
            if(1 == flag) {
                poiTitleBar.removeClass("transparent");
            } else {
                poiTitleBar.addClass("transparent");
            }

        };
        var touchStart = function() {
            if(0 === titlePos) {
                if(!mainDom) {
                    mainDom = document.querySelector(".poihead_cont");
                    titleDom = mainDom.querySelector(".name");
                    gohereDom = mainDom.querySelector(".line");
                }
                if(mainDom) {
                    var mainDomRect = mainDom.getBoundingClientRect();
                    mainPos = mainDomRect.top - titleBarHeight;
                }
                if (gohereDom) {
                    var gohereDomRect = gohereDom.getBoundingClientRect();
                    goherePos = gohereDomRect.top + gohereDomRect.height - titleBarHeight;
                }
                if(titleDom) {
                    var titleDomRect = titleDom.getBoundingClientRect();
                    titlePos = titleDomRect.top + titleDomRect.height - titleBarHeight - 10;
                    window.removeEventListener("touchstart", touchStart, false);
                }
            }
        };
        var androidScroll = function() {
            if(!titlePos) return;
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop + iosBackgroundRange) {
                if(!backgroundShown) {
                    changeIcon(1);
                    backgroundShown = true;
                    poiTitleBar.removeClass("topBar_bg_transition").addClass("topBar_bg_transition");
                    setTimeout(function() {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)");
                    }, 0);
                }
            } else {
                if(backgroundShown) {
                    changeIcon(0);
                    backgroundShown = false;
                    poiTitleBar.removeClass("topBar_bg_transition").addClass("topBar_bg_transition");
                    setTimeout(function() {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)");
                    }, 0);
                }
            }

            if(titlePos < scrollTop) {
                if(!nameShow) {
                    $name.css("opacity", "1");
                    nameShow = true;
                }
            } else {
                if(nameShow) {
                    $name.css("opacity", "0");
                    nameShow = false;
                }
            }
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    $titleBarBtns.addClass("topBar_gohere_show");
                    setTimeout(function() {
                        $gohere.css("opacity", "1");
                    }, 0);
                    gohereShow = true;
                }
            } else {
                if(gohereShow) {
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    gohereShow = false;
                }
            }
        };
        var iosMove = function() {
            if(!mainPos) {
                return;
            }
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop) {
                backgroundRangeFlag = false;
                if(!titleIconFlag) {
                    titleIconFlag = 1;
                    changeIcon(1);
                }
                if(!backgroundShown) {
                    poiTitleBar.css("background-color", "#fff").removeClass("indexBar");
                    backgroundShown = true;
                    backgroundShowing = false;
                }
            } else {
                if(mainPos < scrollTop + iosBackgroundRange) {
                    if(!titleIconFlag) {
                        titleIconFlag = 1;
                        changeIcon(1);
                    }
                    if(!backgroundRangeFlag) {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, " + ((scrollTop + iosBackgroundRange - mainPos) / iosBackgroundRange) + ")");
                        if(backgroundShown && !backgroundShowing) {
                            poiTitleBar.addClass("indexBar");
                        }
                    }
                    backgroundShown = false;
                    backgroundShowing = true;
                } else {
                    if(titleIconFlag) {
                        titleIconFlag = 0;
                        changeIcon(0);
                    }
                    backgroundRangeFlag = false;
                    if(!backgroundShown && backgroundShowing) {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)").removeClass("indexBar").addClass("indexBar");
                        backgroundShown = false;
                        backgroundShowing = false;
                    }

                }
            }

            if(!titlePos) {
                return;
            }
            if(titlePos < scrollTop) {
                if(!nameShowFinish) {
                    if((titlePos + iosCommonRange) > scrollTop) {
                        $name.css("opacity", 1 - ((titlePos + iosCommonRange) - scrollTop) / iosCommonRange);
                        nameShow = true;
                    } else {
                        $name.css("opacity", "1");
                        nameShowFinish = true;
                        nameShow = true;
                    }
                }
            } else {
                if(nameShowFinish || nameShow) {
                    $name.css("opacity", "0");
                    nameShowFinish = false;
                    nameShow = false;
                }
            }
            
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    $titleBarBtns.addClass("topBar_gohere_show");
                    gohereShow = true;
                }
                if(!gohereShowFinish) {
                    if((goherePos + iosCommonRange) > scrollTop) {
                        $gohere.css("opacity", 1 - ((goherePos + iosCommonRange) - scrollTop) / iosCommonRange);
                    } else {
                        gohereShowFinish = true;
                        $gohere.css("opacity", "1");
                    }
                }
            } else {
                if(gohereShowFinish) {
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    gohereShow = false;
                    gohereShowFinish = false;
                }
            }

        };
        var iosScroll = function() {
            if(!mainPos) {
                return;
            }
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop) {
                if(!titleIconFlag) {
                    titleIconFlag = 1;
                    changeIcon(1);
                }
                backgroundRangeFlag = false;
                if(!backgroundShown) {
                    backgroundShown = true;
                    backgroundShowing = false;
                    poiTitleBar.addClass("topBar_bg_transition");
                    poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)").removeClass("indexBar");
                    setTimeout(function() {
                        poiTitleBar.removeClass("topBar_bg_transition");
                    }, 217);
                }
            } else {
                if(mainPos < scrollTop + iosBackgroundRange) {
                    if(!titleIconFlag) {
                        titleIconFlag = 1;
                        changeIcon(1);
                    }
                    backgroundRangeFlag = true;
                    if(!backgroundShown) {
                        backgroundShown = false;
                        backgroundShowing = true;
                        poiTitleBar.addClass("topBar_bg_transition");
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)").removeClass("indexBar");
                        setTimeout(function() {
                            poiTitleBar.removeClass("topBar_bg_transition");
                        }, 217);
                    }
                } else {
                    if(titleIconFlag) {
                        titleIconFlag = 0;
                        changeIcon(0);
                    }
                    if(backgroundShowing || backgroundShown) {
                        backgroundRangeFlag = false;
                        backgroundShowing = false;
                        backgroundShown = false;
                        poiTitleBar.addClass("topBar_bg_transition");
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)").addClass("indexBar");
                        setTimeout(function() {
                            poiTitleBar.removeClass("topBar_transition");
                        }, 217);
                    }
                }
            }

            if(!titlePos) {
                return;
            }
            if(titlePos < scrollTop) {
                if(!nameShowFinish) {
                    nameShowFinish = true;
                    $name.addClass("topBar_transition");
                    $name.css("opacity", "1");
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            } else {
                if(nameShowFinish) {
                    nameShowFinish = false;
                    $name.addClass("topBar_transition");
                    $name.css("opacity", "0");
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            }
            
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    gohereShow = true;
                    $titleBarBtns.addClass("topBar_gohere_show");
                }
                if(!gohereShowFinish) {
                    gohereShowFinish = true;
                    $gohere.addClass("topBar_transition");
                    setTimeout(function() {
                        $gohere.css("opacity", "1");
                    }, 0);
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            } else {
                if(gohereShow) {
                    gohereShow = false;
                    gohereShowFinish = false;
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    $gohere.removeClass("topBar_transition");
                }
            }
        };
        var init = function() {
            if(isIndex) {
                window.addEventListener("touchstart", touchStart, false);
            }
            if("android" === os) {
                $name.addClass("topBar_transition");
                $gohere.addClass("topBar_transition");
                window.addEventListener("scroll", androidScroll, false);
            } else {
                window.addEventListener("touchmove", iosMove, false);
                window.addEventListener("scroll", iosScroll, false);
                window.addEventListener("touchend", function(e){
                    clearTimeout(timer);
                    timer = setTimeout(function(){
                        document.body.scrollTop = document.body.scrollTop;
                    }, 350);
                }, false);
            }
        };
        document.addEventListener("DOMContentLoaded", init, false);
    }
    
    
    
})(POI, Zepto);
