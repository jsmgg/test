(function(POI, $) {

'use strict';
var egg = {
    
    eggCount : 0,
    
    eggTimeout : null,
    
    loadVersionJS : function() {
        var script = document.createElement('script');
        script.src = 'js/package.js';
        script.type = 'text/javascript';
        document.querySelector('head').appendChild(script);
    },
    
    showInfo : function() {
        var htmlStr = document.createElement('div');
        htmlStr = '<section><a href="http://tpl.testing.amap.com/api/index.html">离线模板包版本：</a>' + window.packageInfo + '</section>';
        $("#js_pagebody").append(htmlStr);
    },
    
    setEgg : function() {
        var _this = this;
        $("#js_header").on("touchstart", function(e) {
            if(2 !== e.touches.length) {
                return;
            }
            clearTimeout(_this.eggTimeout);
            _this.eggCount++;
            _this.eggTimeout = setTimeout(function() {
                _this.eggCount = 0;
            }, 1000);
            if(3 === _this.eggCount) {
                _this.eggTimeout = setTimeout(function() {
                    _this.loadVersionJS();
                    setTimeout(function() {
                        _this.showInfo();
                    }, 1000);
                }, 2000);
            }
        });
    },
    
    easterEgg : function(poiInfo) {
        if("string" === typeof(poiInfo)) {
            poiInfo = JSON.parse(poiInfo);
        }
        if("塞班" === poiInfo.name) {
            this.setEgg();
        }
    }
};

$.extend(POI.util, egg);

})(POI, Zepto);
