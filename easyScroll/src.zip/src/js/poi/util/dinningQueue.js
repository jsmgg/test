(function(POI, $) {

'use strict';

var STORAGE_KEY = 'dinningQueueInfo';

var queueKey;

$.extend(POI.util, {
    /**
     * 设置用户相对于店的唯一id.
     * @param {String} userid 用户id
     * @param {String} poiid
     */
    setQueueKey: function(userid, poiid) {
        queueKey = userid + '_' + poiid;
    },
    /**
     * 存储我的排号订单信息.
     * @param {Boolean} isWaiting 是否正在下单
     * @param {Object} queueInfo 如果下单成功则为订单信息，否则为undefined
     */
    storeQueueInfo: function(isWaiting, queueInfo) {
        var oldData = this.storage(STORAGE_KEY) || '{}';
        oldData = JSON.parse(oldData);

        var time = new Date();
        if (!oldData.time || (new Date(oldData.time)).toDateString() != time.toDateString()) {
            oldData = {time: time.getTime()};
        }

        oldData[queueKey] = oldData[queueKey] || {};
        oldData[queueKey].isWaiting = isWaiting;
        oldData[queueKey].queueInfo = queueInfo;
        if (queueInfo) {
            oldData[queueKey].hasGot = true;
        }
        this.storage(STORAGE_KEY, JSON.stringify(oldData));
    },
    /**
     * 获取用户在当前店的排号信息.
     * @return {Object} 无信息时返回undefined
     *    hasGot {Boolean} 为true时表示在当前poi已成功取过号
     *    queueInfo {Object} 用户已拍的号，当前无排号时此属性为undefined
     *    isWaiting {Boolean} 为true时表示正在取号
     */
    getStoredQueueInfo: function() {
        var info = this.storage(STORAGE_KEY);
        if (!info) {
            return;
        }
        info = JSON.parse(info);
        var time = new Date();
        if ((new Date(info.time)).toDateString() != time.toDateString()) {
            return;
        }
        return info[queueKey];
    }
});

})(POI, $);
