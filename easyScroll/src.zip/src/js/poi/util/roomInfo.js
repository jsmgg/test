(function(POI, $) {

'use strict';

var roomInfo = {
    bookEvent: function() {
        // 房间详情点击事件
        POI.pagebody.on('click', '[data-roomIdx]', function(event) {
            var self = thatObj;
            var $elem = $(event.currentTarget);
            var index = $elem.attr('data-roomIdx');
            var indexArr = index.split('-');
            //var obj = self.roomList[ indexArr[0] ].multilist[ indexArr[1] ];
            var obj = JSON.parse($elem.attr('data-obj'));
            var hd = self.hotelDate;
            var params = [
                {srctype: obj.src_type, sign: 1},
                {hotelid: obj.hotelid, sign: 1},
                {roomtypeid: obj.RoomTypeId},
                {rateplanid: obj.RatePlanId},
                {paytype: obj.paytype},
                {poiid: POI.clientData ? POI.clientData.poiInfo.poiid : POI.util.getUrlParam('poiid')},
                {start: hd.inDate},
                {end: hd.outDate},
                {hour_room: obj.hour_room || 0}
            ];
            if (obj.RatePlanCategory) {
                params.push({rateplancategory: obj.RatePlanCategory});
            }
            if (obj.HotelCode) {
                params.push({hotelcode: obj.HotelCode});
            }
            POI.api.aosrequest('hotelCanBook', params, function(res) {
                self.canBookRes(res, $elem);
            }, 1, true);
            POI.api.userAction('hotelBook', {src_type: obj.src_type});
        });
        // 点击行，预订按钮变色处理
        POI.pagebody.on('touchstart', '[data-roomIdx]', function(event) {
            $(event.currentTarget).find('.book-btn').addClass('hover');
        });
        POI.pagebody.on('touchend', '[data-roomIdx]', function(event) {
            $(event.currentTarget).find('.book-btn').removeClass('hover');
        });
    },
    /**
     * 格式化房间信息.
     * @param {Object} obj 房间对象
     * @param {Integer} i 房型下标
     * @param {Integer} j 房间下标
     * @param {String} [activity=''] 活动标志
     * @return {jQuery} 房间DOM对象
     */
    _formatRoomInfo: function(obj, i, j, isShowSrc, activity) {
        var $cont = $('<li/>').addClass('room-item line-half');
        if ( this._isAvailable(obj) ) {
            $cont.addClass('canTouch').attr('data-roomIdx', i + '-' + j).attr("data-obj", JSON.stringify(obj));
        } else {
            $cont.addClass('full');
        }
        //// 支付类型
        //$('<h4/>').addClass('room-name').append( obj.RoomTypeName +
        //    this._otherInfo(obj) ).appendTo($cont);
        //var averagePrice = POI.util.formatMoney(obj.AveragePrice),
        //    upperlimit = POI.util.formatMoney(obj.Upperlimit);
        //// 房间价格不合法时不显示报价和返现
        //if (averagePrice) {
        //    // 币种标识符
        //    var moneyFlag = POI.util.moneyFlag(obj.Currency);
        //    // 价格
        //    $('<cite/>').addClass('price').text(moneyFlag + averagePrice).appendTo($cont);
        //    // 钟点房显示小时数
        //    if (obj.hour_room == 1 && obj.hours) {
        //        $('<i/>').addClass('hours').text('/' + obj.hours + '小时').appendTo($cont);
        //    }
        //    if (upperlimit) {
        //        // 显示返现
        //        $('<span/>').addClass('active half-border')
        //            .text('返现' + upperlimit).appendTo($cont);
        //    }
        //}
        //// 运营活动标识
        //if (obj.active) {
        //    $('<span/>').addClass('active half-border').text(obj.active).appendTo($cont);
        //}
        //// 支付类型
        //this._payType(obj.paytype).appendTo($cont);
        //// 活动标志
        //if (activity && obj.can_resell == '1') {
        //    $('<span/>').addClass('active half-border').text(activity).appendTo($cont);
        //}
        //// 来源
        //if (isShowSrc && obj.src_name) {
        //    $cont.append('<p class="source">' + obj.src_name + '提供</p>');
        //}
        //// 预定按钮
        //$cont.append( this._bookBtn(obj) );
        
        var averagePrice = POI.util.formatMoney(obj.AveragePrice);
        var upperlimit = POI.util.formatMoney(obj.Upperlimit);
        var moneyFlag = POI.util.moneyFlag(obj.Currency);
        var iconStr = obj.src_logo ? '<i style="background-image:url(' + obj.src_logo + ')"></i>' : '';
        var btnStr = '';
        if(this._isAvailable(obj)) {
            btnStr = '<div class="book-btn half-border">' +
                         '<p class="book-btn-book">预订</p>' +
                         '<p class="book-btn-type">' + (this._payTypeText(obj.paytype) || ' ') + '</p>' +
                     '</div>'
        } else {
            btnStr = '<button class="book-btn-full">满房</button>';
        }
        var upperlimitStr = upperlimit ? '<button class="half-border">返现' + upperlimit + '</button>' : '';
        var tpl = '<p class="room-name">' + obj.RoomTypeName + this._otherInfo(obj) + '</p>' +
                  (averagePrice ? '<p class="room-price">' + moneyFlag + averagePrice + upperlimitStr + '</p>' : '') +
                  '<p class="room-desc">' + iconStr + obj.src_name + '提供</p>' +
                  btnStr;
        $cont.append(tpl);
        return $cont;
    },
    /**
     * 房间是否可预订.
     * @param {Object} obj 房间对象
     * @return {Boolean} 房间可订返回 true，否则返回false
     */
    _isAvailable: function(obj) {
        return obj.IsAvailable && obj.IsAvailable === 'true';
    },
    /**
     * 生成酒店的附加信息，格式为 (早餐 床型).
     * @param {Object} obj 酒店信息对象
     * @return {String} 酒店的早餐和床型信息
     */
    _otherInfo: function(obj) {
        var info = '';
        var bed = obj.bed;
        if (bed) {
            // 去除床型后的大小信息
            bed = bed.replace(/[(（].+[)）]/, '');
        }
        if (obj.breakfast && bed) {
            info = obj.breakfast + ' ' + bed;
        } else if (obj.breakfast || bed) {
            info = obj.breakfast || bed;
        }
        if (info) {
            info = '(' + info + ')';
        }
        return info;
    },
    /**
     * 获取酒店付款类型.
     * @param {String} type 酒店信息的 paytype 值
     * @return {jQuery} 付款类型html jquery对象
     */
    _payType: function(type) {
        if (!type || type == '0') {
            return $();
        }
        type = this._payTypeText(type);
        if (!type) {
            return $();
        }
        return $('<span/>').addClass('active half-border').text( type );
    },
    /**
     * 获取酒店付款类型.
     * @param {String} type 酒店信息的 paytype 值
     * @return {String} 付款类型名称
     */
    _payTypeText: function(type) {
        var arr = ['现付', '担保', '预付', '现付'];
        return arr[type] || '';
    },
    /**
     * 生成订房按钮.
     * @param {Integer} i 酒店信息对象
     * @param {Integer} j 第几个按钮，作为按钮在页面的唯一标识
     * @return {jQuery} 按钮对象
     */
    _bookBtn: function(obj) {
        var $btn = $('<span/>').addClass('book-btn');
        if ( this._isAvailable(obj) ) {
            $btn.addClass('canTouch').text('预订');
        }
        else {
            $btn.text('满房');
        }
        return $btn;
    },
    /**
     * 酒店是否可预订查询结果处理.
     * 如果不可预订，则把预订按钮改为满房，如果可预订则跳转至第三方页面
     * @param {Object} res aos返回的结果
     * @param {jQuery} $elem 当前事件元素
     */
    canBookRes: function(res, $elem) {
        if (res.code != 1 || !res.status) {
            return;
        }
        var index = $elem.attr('data-roomIdx');
        var status = res.status.split(',')[0],
            indexArr = index.split('-'),
            obj = JSON.parse($elem.attr('data-obj')),
            hd = this.hotelDate;
        if (status == '0') {
            this._btnFull($elem);
            return;
        }
        if (obj.can_resell == '1') {
            if (!res.arrival_time || !res.arrival_time.length || res.room_num < 0) {
                this._btnFull($elem);
                return;
            }
            // 本地下单
            if (res.room_num == '0') {
                res.room_num = 8;
            }
            obj.room_num = parseInt(res.room_num);
            obj.arrival_time = res.arrival_time;
            obj.comeDate = hd.inDate;
            if (obj.hour_room == 1) {
                // 钟点房离店时间使用入住时间
                obj.leaveDate = hd.inDate;
            } else {
                obj.leaveDate = hd.outDate;
            }
            // obj.roomgroup_id = this.roomList[ indexArr[0] ].roomgroup_id;
            obj.roomgroup_id = $elem.parents('li').attr('data-roomtypeid');
            obj.rule_content = res.rule_content;
            POI.util.storage('hotel.roomInfo', JSON.stringify(obj));
            POI.util.locationRedirect('exHotelOrder.html');
        }
        // 酒店跳转下单（aos下单，并且同步第三方订单）
        else if (obj.can_resell == '2') {
            thatObj.addCpOrder(obj);
        }
        else {
            // 第三方订单页面
            POI.api.getAppPara('', '', obj.url);
        }
    },
    addCpOrder: function(obj) {
        var poiInfo = POI.aosData;
        if (!poiInfo) {
            poiInfo = POI.aosData = POI.util.getStorageData();
        }
        poiInfo = poiInfo.base;
        var tel = "";
        try {
            tel = (poiInfo.telephone || POI.clientData.poiInfo.phoneNumbers || "").replace(/\/|;/g, ',');
        } catch(e) {
        }
        var param = [
            {cp_source    : obj.src_type, sign: 1},
            {poi_id       : poiInfo.poiid, sign: 1},
            {longitude    : poiInfo.x},
            {latitude     : poiInfo.y},
            {hotel_name   : poiInfo.name},
            {hotel_address: poiInfo.address},
            {hotel_phone  : tel},
            {pay_type     : obj.paytype},
            {room_type    : obj.RoomTypeName},
            {url          : obj.url}
        ];
        POI.api.aosrequest('hotelCpOrderAdd', param, function(response) {
            if (response.code == '27' ||
                    (response.code == '14' && response.need_bind == '2')) {
                POI.api.loginBind('phone', function(userInfo) {
                    if (!userInfo.phone) {
                        POI.api.promptMessage('为了方便预订和订单查询，请先登录并绑定手机号');
                        return;
                    }
                    thatObj.addCpOrder(obj);
                });
            }
            // 绑定淘宝账号错误码
            else if (response.code == '59' ||
                    (response.code == '14' && response.need_bind == '1')) {
                POI.api.loginBind('taobao', function(userInfo) {
                    if (!userInfo.taobao) {
                        POI.api.promptMessage('为了方便预订和订单查询，请先登录并绑定淘宝帐号');
                        return;
                    }
                    thatObj.addCpOrder(obj);
                });
            }
            else if (response.code == '14') {
                POI.send({
                    action: 'getAmapUserId',
                    onlyGetId: '0',
                    needRelogin: '1'
                }, function(userInfo) {
                    if (!userInfo.userid) {
                        POI.api.promptMessage('为了方便预订和订单查询，请先登录');
                        return;
                    }
                    thatObj.addCpOrder(obj);
                });
            }
            if (response.code != '1') {
                return;
            }
            POI.api.userAction('hotelCpOrder', {url: response.url});
            POI.api.getAppPara('', '', response.url);
        }, 0, true);
    },
    /**
     * 将预定按钮改为满房按钮.
     * @param {jQuery} $elem 预定按钮
     */
    _btnFull: function($elem) {
        $elem.removeClass('canTouch').addClass('full').removeAttr('data-roomIdx')
            .find('.book-btn').replaceWith('<button class="book-btn-full">满房</button>');
    }
};

var thatObj;
if (location.href.indexOf('index.html') != -1) {
    POI.bookRoom = POI.bookRoom || {};
    thatObj = POI.bookRoom;
} else {
    thatObj = POI;
}
$.extend(thatObj, roomInfo);

})(POI, $);
