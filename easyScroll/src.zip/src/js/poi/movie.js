/*电影*/
;(function(POI, $) {
$.extend(POI, {
    init : function() {
        var self = this,
            introHtml = self.index.moduleIntro(["影院图片", "影院介绍", "影院特色"], ["child_benefit", "service_3D", "surrounding", "service_dinning", "service_game", "service_parking", "opentime2"]),
            deep = self.aosData.deep[0]||{},
            base = self.aosData.base||{},
            classify = base.classify ? self.index.moduleHeadItem(base.classify) : '',
            price = Math.max((deep.price || "") | 0, 0);
        price = price ? '人均:￥' + price : '';
        self.index.moduleDeepHead(classify, price);
        self.index.moduleAll(null, introHtml);
        self.util.executeAfterDomInsert();
    }
})
})(POI, Zepto);