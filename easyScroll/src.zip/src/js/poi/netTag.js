/**
 * 网吧模块
 */
;
(function(POI, $) {

    $.extend(POI, {
        showNetBar: function(deep) {
            var that = this;
            var obj = deep.pri_info;
            if (!obj) {
                return '';
            } else if (obj && obj.length < 1) {
                return '';
            }
            
            var is_pri_bar = deep.is_pri_bar == 1?'特权网吧':'';
            var pre_section = '<section class="netBar_section">';
            var last_section = '</section>';
            
            var title_html = that.makeTitleHtml(obj, is_pri_bar);
            var article_html = that.makeArticleHtml(obj);
            POI.api.userAction('showNetBar');
            return pre_section+title_html+article_html+last_section;
        },
        makeTitleHtml: function(arr, is_pri_bar) {
            var that = this;
            var res_html = '';

            if (arr.length > 1) {
                var li_arr = [];
                for (var i=0; i<arr.length; i++) {
                    if (arr[i].pri_type == 'dota2') {
                        var type = 'Dota2';
                    } else if (arr[i].pri_type == 'lol') {
                        var type = 'LOL';
                    }
                    var str = '<li rel="#'+arr[i].pri_type+'" class="on">'+type+is_pri_bar+'</li>';
                    li_arr.push(str);
                }
                res_html = '<ul class="bar_title">'+li_arr.join('')+'</ul>';
            } else {
                if (arr[0].pri_type == 'dota2') {
                    var img_html = '<img src="img/dota_tab.png" class="dota"/>';
                    var type = 'Dota2';
                } else if (arr[0].pri_type == 'lol') {
                    var img_html = '<img src="img/hero_tab.png" class="hero"/>';
                    var type = 'LOL';
                }
                
                res_html = '<div class="title_one divide-line all-line">'+
                           img_html+'<p><span>'+
                           type+'</span>'+
                           is_pri_bar+'</p>'+
                           '</div>';
            }
            return res_html;
        },
        makeArticleHtml: function(arr) {
            var that = this;
            var article_arr = [];
            
            for (var i=0; i<arr.length; i++) {
                var hide = i == 0?'':' class="hide"';
                var pre_article = '<article id="'+arr[i].pri_type+'"'+hide+'><ul>';
                var more = arr[i].pri_type == 'dota2'?'':'<div class="check_detail">查看详细信息</div>';
                var last_article = '</ul>'+more+'</article>';
                var li_arr = [];
                var arr1 = arr[i].pri_info_detail;
                for (var j=0; j<arr1.length; j++) {
                    var class_name = j == 0?' class="divide-line all-line"':'';
                    var url_str = arr1[j].pic_info && arr1[j].pic_info[0] && arr1[j].pic_info[0].url.length > 0?'<span class="img" style="background:url('+that.imgTransform(arr1[j].pic_info[0].url, 90, 90)+') no-repeat center center;background-size:cover;"></span>':'<span class="img"></span>';
                    
                    var li_str = '<li'+class_name+'>'+
                                 url_str+
                                 '<div class="cont">'+
                                 '<p class="title">'+arr1[j].title+'</p>'+
                                 '<p class="describe">'+arr1[j].content+'</p>'+
                                 '</div>'+
                                 '</li>';
                    li_arr.push(li_str);
                }
                article_arr.push(pre_article+li_arr.join('')+last_article);
            }
            
            return article_arr.join('');
        },
        imgTransform: function(url, width, height) {
            return POI.util.imageUrlTransform(url, width, height) || '';
        },
        showNetTag: function(data) {
            var aosData = data || POI.util.getStorageData() || {};
            var spec = aosData.spec;
            
            if (!spec || !spec.webbar_deep_grab) {
                return '';
            }
            var level = ["金牌网吧", "银牌网吧", "铜牌网吧", "新进网吧"],
                grab = spec.webbar_deep_grab,
                tagHtml = ['<h2 class="netTag_title module_title">网吧特色</h2><article class="netTag_detail">'],
                levelTxt = level[grab.wb_level - 1],
                scaleTxt = '机器' + grab.wb_scale + '台';
            tagHtml.push('<span >' + levelTxt + '、</span><span>' + scaleTxt + '</span>');
            tagHtml.push('</article>');

            return '<section id="netBar">' + tagHtml.join("") + '</section>';
        },
        bindEvent: function() {
            var that = this;

            $('.bar_title').on('click', 'li', function() {
                var li = $(this);

                if (li.length) {
                    li.addClass('on');
                    li.siblings().removeClass('on');
                    var rel = li.attr('rel');

                    $(rel).removeClass('hide')
                            .siblings('article').addClass('hide');
                    POI.api.userAction('netBarType', {type: rel.substr(1)});
                }
            });

            //点击英雄联盟的详细信息
            $('.check_detail').click(function() {
                //此处可能需要修改，目前是写死的
                var url = 'http://wb.qq.com/netbar_reward/lol/search-wb-content.html';
                POI.api.openThirdUrl(url);
                POI.api.userAction('heroUnionDetail');
            });
        },
        buildingPageList: function(netTag, netBar) {
            var that = this;
            
            var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', netTag, netBar, 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
            that.pagebody.html(allAry.join(""));
            POI.util.executeAfterDomInsert();
            that.bindEvent();
        },
        init: function() {
            var deep = this.aosData.deep[0];
            var rti = this.aosData.rti;
            this.index.moduleDeepHead();

            this.buildingPageList(
                this.showNetTag(this.aosData),
                this.showNetBar(deep)
            );
        }
    });

})(POI, Zepto);