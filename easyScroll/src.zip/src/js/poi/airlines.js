
/*
    机场线路列表页面
    进入页面地址location.search为?poiid_cityid  [及poiid下划线城市id]
*/
;(function(POI, $){

$.extend(POI, {

    // 买点page标识
    logPageId : "airLinesList",

    cityid : location.search.replace('?','').split('_')[1] || '',
    
    poiid : location.search.replace('?','').split('_')[0] || '',
    
    price : function(num1, num2) {
        num1 = parseFloat(num1 || 0);
        num2 = parseFloat(num2 || 0);
        var priceStr = '免费';
        if(0 !== num1 || 0 !== num2) {
            priceStr = (num1 === num2 ? num1 : (Math.min(num1, num2) + "-" + Math.max(num1, num2)));
            return '<span class="airport_subtitle_price">' + priceStr + '</span>元';
        } else {
            return '<span class="airport_subtitle_price">' + priceStr + '</span>';
        }
    },
    
    time : function(srart, end) {
        if(void(0) === srart || void(0) === end) {
            return '';
        }
        srart = ("0000" + srart).slice(-4).replace(/(\d\d)$/, ":$1");
        end = ("0000" + end).slice(-4).replace(/(\d\d)$/, ":$1");
        if(("00:00" === srart && "24:00" === end) || ("00:00" === end && "24:00" === srart)) {
            //return "24小时";
            return '<span class="airport_time_start">00:00</span><span class="airport_time_end">24:00</span>';
        } else {
            //return srart + "-" + end;
            return '<span class="airport_time_start">' + srart + '</span><span class="airport_time_end">' + end + '</span>';
        }
    },
    
    showFerry : function(ferryList) {
        try {
            var len = ferryList.length;
            if(1 > len) {
                return '';
            }
            var returnStr = '<p class="airport_subtitle">' + (ferryList[0].interval ? ('发车间隔：不超过' + ferryList[0].interval + '分钟&nbsp;&nbsp;') : '') + '票价：' + this.price(ferryList[0].basic_price, ferryList[0].total_price) + '</p>';
         
            /*
            <a class="lineBtn canTouch moreAfter half-border">
                <p class="lineDir">方庄&nbsp;→&nbsp;机场</p>
                <p class="lineTime">05：00－21：00</p>
            </a>   
            */
            
            for(var i = 0, item = null, hgroupStr = ''; i < len; i++) {
                item = ferryList[i];
                hgroupStr += '<div class="airport_link_item half-border canTouch" line_id="' + $.trim(item.line_id) + '">' +
                                 '<div class="airport_line">' + item.front_name + '<span class="airport_line_arrow"></span>' + item.terminal_name + '</div>' +
                                 '<div class="airport_time">' + this.time(item.start_time, item.end_time) + '</div>' +
                             '</div>';
            }
            
            return '<section id="linesFerry" class="airport_sec">' + 
                            '<h2 class="airport_type">摆渡车</h2>' + 
                            '<article>' + 
                                returnStr + 
                                '<hgroup class="airport_link">' + 
                                    hgroupStr + 
                                '</hgroup>' + 
                            '</article>' + 
                        '</section>';
        } catch(e) {
            //alert(e.message)
            return '';
        }
    },
    
    showBus : function(busList) {
        try {
            var len = busList.length;
            if(1 > len) {
                return '';
            }
            
            busList.sort(function(a, b){
                return (a.key_name.trim()||'').localeCompare(b.key_name.trim()||'');
            });
            
            var returnStr = '';
            
            for(var i = 0, item = null, hgroupStr = ''; i < len; i++) {
                item = busList[i];
                hgroupStr += '<div class="airport_link_item half-border canTouch" line_id="' + $.trim(item.line_id) + '">' +
                                 '<div class="airport_line">' + item.front_name + '<span class="airport_line_arrow"></span>' + item.terminal_name + '</div>' +
                                 '<div class="airport_time">' + this.time(item.start_time, item.end_time) + '</div>' +
                             '</div>';
                
                if(!busList[i+1] || item.key_name !== busList[i+1].key_name) {
                    returnStr += '<article>' + 
                                     //'<p class="lineDesc line"><span class="lineNum">' + item.key_name + '</span>' + (item.interval ? ('发车间隔：不超过' + item.interval + '分钟') : '') + '&nbsp;&nbsp;票价：' + this.price(item.basic_price, item.total_price) + '</p>' + 
                                     '<p class="airport_title">' + item.key_name + '</p>' +
                                     '<p class="airport_subtitle">' + (item.interval ? ('发车间隔：不超过' + item.interval + '分钟&nbsp;&nbsp;') : '') + '票价：' + this.price(item.basic_price, item.total_price) + '</p>' +
                                     '<hgroup class="airport_link">' + 
                                         hgroupStr +
                                     '</hgroup>' +
                                 '</article>';
                    hgroupStr = '';
                }
            }
            
            return '<section id="linesBus" class="airport_sec">' +
                       '<h2 class="airport_type">机场大巴</h2>' +
                       returnStr +
                   '</section>';
        } catch(e) {
            //alert(e.message);
            return '';
        }
    },
    
    showSubway : function(subwayList) {
        try {
            var len = subwayList.length;
            if(1 > len) {
                return '';
            }
            var returnStr = '';
            
            for(var i = 0, item = null, hgroupStr = ''; i < len; i++) {
                item = subwayList[i];
                hgroupStr += '<div class="airport_link_item half-border canTouch" line_id="' + $.trim(item.line_id) + '">' +
                                 '<div class="airport_line">' + item.front_name + '<span class="airport_line_arrow"></span>' + item.terminal_name + '</div>' +
                                 '<div class="airport_time">' + this.time(item.start_time, item.end_time) + '</div>' +
                             '</div>';
                //if(1 === i % 2) {
                    returnStr += '<article>' + 
                                     //'<p class="lineDesc line"><span class="lineNum">' + item.key_name + '</span>' + (item.interval ? ('发车间隔：不超过' + item.interval + '分钟') : '') + '&nbsp;&nbsp;票价：' + this.price(item.basic_price, item.total_price) + '</p>' + 
                                     '<p class="airport_title">' + item.key_name + '</p>' +
                                     '<p class="airport_subtitle">' + item.key_name + '</span>' + (item.interval ? ('发车间隔：不超过' + item.interval + '分钟') : '') + '&nbsp;&nbsp;票价：' + this.price(item.basic_price, item.total_price) + '</p>' +
                                     '<hgroup class="airport_link">' + 
                                         hgroupStr +
                                     '</hgroup>' +
                                 '</article>';
                    hgroupStr = '';
                //}
            }
            
            return '<section id="linesSubway" class="airport_sec">' +
                       '<h2 class="airport_type">机场快轨</h2>' +
                       returnStr +
                   '</section>';
        } catch(e) {
            //alert(e.message);
            return '';
        }
    },
    
    // 展示机场、航站楼摆渡车、公交、机场快轨
    showLinesInfo : function(linesInfo) {
        try {
            var htmlStr = '';
            if("1" in linesInfo) {
                htmlStr += this.showFerry(linesInfo["1"]);
            }
            if("0" in linesInfo) {
                htmlStr += this.showBus(linesInfo["0"]);
            }
            if("2" in linesInfo) {
                htmlStr += this.showSubway(linesInfo["2"]);
            }
            
            $("#linesInfo").html(htmlStr).on("click", ".airport_link_item", function(evt) {
                var lineid = this.getAttribute("line_id");
                POI.api.userAction('airLinesList', {poiid_lineid: POI.poiid + '_' +lineid});
                POI.api.openBusLine(this.getAttribute("line_id"), this.cityid);
            });
        } catch(e) {
            //alert(e.message);
        }
    },
    
    quickInit : function() {
        POI.api.aosrequest('airlineListUrl', [{poiid: this.poiid, sign: 1}], function(dt){
            POI.showLinesInfo(dt.busline_list || {});
        }, 1, true, 'GET');
    }

});

})(POI, Zepto);