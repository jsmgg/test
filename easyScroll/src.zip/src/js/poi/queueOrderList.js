/* 美食/我的排号 */
;(function(POI, $) {

// TODO: 服务接口返回数据检查，只信任version、result、code、message、timestamp

var PAGE_SIZE = 10;

var pageNum = 1;    // 接口参数要求初始值为1

$.extend(POI, {
    logPageId: 'queueOrderList',

    _tid: null,
    _isLogIn: false,

    /**
     * 获取排号列表数据
     * @return nth
     */
    getQueueData: function() {
// 模拟数据
        // var res1 = [];
        // var res2 = [
        //     {
        //         'poi_name': "餐厅名称餐厅名称餐厅名称餐厅名称x",
        //         "queue_size": "12",
        //         "serial_number": "AA",
        //         "type": "3人桌",
        //         "create_time": "2015-3-4",

        //         // 2: 有效排号 4：叫号 5：已经过号 6： 已经取消 7：已就餐
        //         // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        //         "order_status": 2
        //     },
        //     {
        //         'poi_name': "餐厅名称",
        //         "queue_size": "还需等待桌数",
        //         "serial_number": "序列号",
        //         "type": "桌型",
        //         "create_time": "开始排队时间",

        //         // 2: 有效排号 4：叫号 5：已经过号 6： 已经取消 7：已就餐
        //         // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        //         "order_status": 4
        //     },
        //     {
        //         'poi_name': "餐厅名称",
        //         "queue_size": "还需等待桌数",
        //         "serial_number": "序列号",
        //         "type": "桌型",
        //         "create_time": "开始排队时间",

        //         // 2: 有效排号 4：叫号 5：已经过号 6： 已经取消 7：已就餐
        //         // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        //         "order_status": 5
        //     },
        //     {
        //         'poi_name': "餐厅名称",
        //         "queue_size": "还需等待桌数",
        //         "serial_number": "序列号",
        //         "type": "桌型",
        //         "create_time": "开始排队时间",

        //         // 2: 有效排号 4：叫号 5：已经过号 6： 已经取消 7：已就餐
        //         // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        //         "order_status": 6
        //     },
        //     {
        //         'poi_name': "餐厅名称",
        //         "queue_size": "还需等待桌数",
        //         "serial_number": "序列号",
        //         "type": "桌型",
        //         "create_time": "开始排队时间",

        //         // 2: 有效排号 4：叫号 5：已经过号 6： 已经取消 7：已就餐
        //         // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        //         "order_status": 7
        //     }
        // ];
        // this.displayQueueData(res2);
        
        var self = this;

        /**
         * 请求排号数据并显示
         * @return nth
         */
        function requestQueueData() {
            self.api.aosrequest({
                urlPrefix: 'queueOrderList',
                method: 'GET',
                params: [
                    {tid: self._tid, sign: 1},
                    {page_size: PAGE_SIZE},
                    {page_num: pageNum}
                ],    // channel参数由客户端添上
                showNetErr: '1'
            }, function(res) {
                if (res.code == 1 && Object.prototype.toString.call(res.data) === '[object Array]') {

                    /* FIX: 修复加载重复页bug */
                    // if (res.total_page > pageNum) {
                        // 启动上拉事件
                        self.onPullUp(res.data.length, res.total_page);
                    // }

                    // 显示列表
                    self.displayQueueData(res.data);
                }
                else if (res.code == 14) { // 未登录
                    $('#noLoginTip').show();
                }
                else {
                    // REVIEW: 暂时用于调试，发布时显示空列表
                    // self.api.promptMessage(res.code + ": " + res.message);
                    
                    // 显示空列表
                    $('#emptyQueueTip').show();
                }
            });
        }

        if (self._isLogIn === false) {
            // 获取登录及手机绑定状态
            self.send({
                action: 'getAmapUserId',
                onlyGetId: '1'
            }, function(loginInfo) {
                // 未登陆或未绑定手机
                if (!loginInfo.userid) {
                    $('#noLoginTip').show();

                    /* 出口1 */
                    return;
                }

                // 记录登录状态
                self._isLogIn = true;
                self.userid = loginInfo.userid;

                if (self._tid === null) {
                    // 获取tid
                    self.send({action: 'getExtraUrl'}, function(arg) {

                        // 记录tid
                        self._tid = arg.tid;

                        // 请求排号数据
                        requestQueueData();
                    });
                }
            });
        }
        else if (self._tid !== null){
            // 直接请求排号数据，不用获取tid
            requestQueueData();
        }
    },

    /**
     * 拼接生成html
     * @param  {Array} arrHtml 存放html串的数组
     * @param  {Object} data    持有排号项所需各项数据的对象
     *   data.name = data.poi_name;            // 餐厅名称
     *   data.tableNum = data.queue_size;      // 还需等待桌数
     *   data.queueNum = data.serial_number;   // 序列号
     *   data.type = data.type;                // 桌型
     *   data.datetime = data.create_time;     // 开始排队时间
     *   data.status = data.order_status;      // 状态
     *   data.orderid = data.amap_order_id;    // 排号订单id（用于取消排号）
     *   data.poiid = data.poiid;              // poiid（用于log）
     * @return nth
     */
    genHtml: function(arrHtml, data) {
        var tmp;

        arrHtml.push('<section class="queueInfo ');
        arrHtml.push((data.order_status == 2 || data.order_status == 4) ? 'active' : 'nonactive');
        // arrHtml.push('"><h2>');
        arrHtml.push('"><h2><abbr class="lineDot">');
        // 餐厅名字
        arrHtml.push(data.poi_name);
        arrHtml.push('</abbr>');
        // 2=4 ~ 取消排号，5 ~ 已失效，6 ~ 已取消，7 ~ 已就餐
        if (data.order_status == 2 || data.order_status == 4) {
            tmp = '<span class="js_cancel half-border" js_cancel="js_cancel" data-orderid="' +
                    // order id
                    data.amap_order_id + '" data-poiid="' +
                    // poi id
                    data.poiid + '">取消排号</span>';
        } else if (data.order_status == 5) {
            tmp = '<span>已失效</span>';
        } else if (data.order_status == 6) {
            tmp = '<span>已取消</span>';
        } else if (data.order_status == 7) {
            tmp = '<span>已就餐</span>';
        }
        // 状态（按钮）
        arrHtml.push(tmp);
        arrHtml.push('</h2><div class="infoBody flex splitLine">');
        arrHtml.push('<div class="infoLeft flex1"><span class="tableNum num">');
        // 桌数
        // 2=4 ~ 显示x桌，5=6=7 ~ 显示---（没有桌）
        if (data.order_status == 2 || data.order_status == 4) {
            arrHtml.push(data.queue_size);
            arrHtml.push('</span><span> 桌</span>');
        }
        else {
            arrHtml.push('---</span>');
        }
        arrHtml.push('<span class="desc subactive">还需等待</span></div>');
        arrHtml.push('<div  class="infoRight flex1"><span class="queueNum num">');
        // 号
        arrHtml.push(data.serial_number);
        arrHtml.push('</span><span class="desc subactive">我的排号</span></div></div>');
        arrHtml.push('<div class="infoFooter flex subactive"><span class="type flex1 desc">');
        // 桌型
        arrHtml.push(data.type);
        arrHtml.push('</span><span class="datetime flex1 desc">');
        // 时间
        arrHtml.push(data.create_time);
        arrHtml.push('</span></div></section>');
    },

    /**
     * 解析并显示排号列表数据
     * @param  {Array} data 请求返回的排号数组
     * @return nth
     */
    displayQueueData: function(data) {
        var arrHtml = [];
        var $footer = $('.queueListFooter');
        var self = this;

        if (data.length === 0) {
            if ($('#js_pagebody section').size() === 0) {
                $('#emptyQueueTip').show();
            }

            /* 出口1 */
            return;
        }

        for (var i = 0; i < data.length; i++) {
            // 生成html
            self.genHtml(arrHtml, data[i]);
        }
        // 内容插入页面
        $footer.before(arrHtml.join(''));
        // 显示页脚
        $('.queueListFooter').show();

        // 更新pageNum
        pageNum++;
    },

    /**
     * 取消排号
     * @param  {String} orderid 订单id
     * @param  {Zepto Object} $btnCancel 取消按钮
     * @return nth
     */
    cancelQueueOrder: function(orderid, $btnCancel) {
        var self = this;

        var okMsg = '排号取消成功';
        var errMsg = '取消失败，请稍候再试~';

        self.api.aosrequest({
            urlPrefix: 'cancelQueueOrder',
            method: 'GET',
            progress: 1,
            params: [{orderid: orderid, sign: 1}],
            showNetErr: '1'
        }, function(res) {
            if(res.code == 1){
                // 取消成功
                self.api.promptMessage(okMsg);
                $btnCancel.removeClass('js_cancel').text('已取消')
                    .parents('section').addClass('nonactive')
                    .find('.tableNum').text('---').next().hide();
                self.util.setQueueKey(self.userid, $btnCancel.data('poiid'));
                self.util.storeQueueInfo();
            }
            else {
                // -1, -2表示网络错误，此时不显示失败提示，因为native.js会提示检查网络
                if (res.code != -1 && res.code != -2) {
                    self.api.promptMessage(errMsg);
                }
            }
        });
    },

    /*-------------- 事件处理器*/
    /**
     * 处理取消订单事件
     * @param  {DOM Object} ele 事件源
     * @param  {Event Object} e   事件对象
     * @return nth
     */
    js_cancel: function(ele, e) {
        var self = this;

        var $btnCancel = $(ele);
        var data = {
            poiid: $btnCancel.data('poiid'),
            orderid: $btnCancel.data('orderid')
        };

        // 埋点1 点击取消按钮
        self.api.userAction('cancelQueueOrder');

        // 弹窗确认
        self.send({
            action: 'nativeAlert',
            title: '',
            message: '亲，真的要取消排号吗？',
            cancelbutton: '否',
            otherbuttons: ['是']
        }, function(res) {
            if (res.result == 0) {
                // 埋点3 取消取消
                self.api.userAction('cancelQueueOrderNo', {
                    poiid_orderid: data.poiid + '_' + data.orderid
                });
            }
            else if (res.result == 1) {
                // 确定取消排号
                self.cancelQueueOrder(data.orderid, $btnCancel);

                // 埋点2 确定取消
                self.api.userAction('cancelQueueOrderYes', {
                    poiid_orderid: data.poiid + '_' + data.orderid
                });
            }
        });
    },
    /*-------------- 结束*/

    /**
     * 启动pullup事件，加载更多
     * @param  {Integer} num 本次获取到的列表项数目
     * @return nth
     */
    onPullUp: function(num, totalPages) {
        var self = this;

        // 没有了
        if (num < PAGE_SIZE || totalPages <= pageNum) {
            // 移除pullup事件
            self.offPullUp();
            /* 出口1 */
            return;
        }
        else {  // 本次可能没取完，需要分页
            if (typeof self.pullup !== 'object') {
                self.pullup = new self.util.PullUpGetMore(function() {
                    // 获取下一页数据
                    self.getQueueData();
                });
            }
            else {
                self.pullup.refresh();
            }
        }
    },

    /**
     * 移除pullup事件
     * @return nth
     */
    offPullUp: function() {
        if (typeof this.pullup === 'object') {
            // 移除事件
            this.pullup.destory();
        }
    },

    quickInit: function() {
        // 绑定事件处理器
        this.util.delegate($('#js_poi_page'), 'js_cancel');

        var self = this;
        self.send({
            action: 'getAmapUserId',
            onlyGetId: '1'
        }, function(res) {
            self.userid = res.userid;
        });

        this.getQueueData();

        var urlParam = this.util.getUrlParam();
        if (urlParam) {
            this.urlParam = urlParam;
            this.util.setQueueKey(urlParam.userid, urlParam.poiid);
            if (urlParam.jump) {
                this.send({
                    action: 'setGobackStep',
                    step: 2
                });
            }
        }
    }

});

})(POI, Zepto);