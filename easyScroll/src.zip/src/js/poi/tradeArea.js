/*
 * 商圈详情页，没有指定的business，依靠spec.mining_shape.type == 2判定为商圈
 */
;(function(POI, $){

$.extend(POI, {
    // 商圈详情页中展示UGC相关模块功能delay，所以先注释掉入口代码
    init : function() {
        this.tradeAreaPageList();
        //var base = this.aosData.base;
        //this.getTradeThread(base.poiid);
        //this.getTradeResidential(base.poiid, base.city_adcode, 3);
    },
    
    tradeAreaPageList : function() {
        this.index.moduleDeepHead();
        var htmlStr = '<section id="trade" class="building"></section>';
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2", "b_sphere"]);
        this.index.moduleAll(null, introHtml);
        this.pagebody.append(htmlStr);
        POI.util.executeAfterDomInsert();
    },
    
    // 获取商圈下的一条热帖
    getTradeThread: function(poiid) {
        if(!poiid) {
            return;
        }
        var params = [
            {poiid: "" + poiid, sign: 1},
            {count: 2}
        ];
        POI.api.aosrequest("ugcTradeThread", params, POI.showTradeThread, false, false, "GET");
    },
    showTradeThread: function(data) {
        if(!data || "0" != data.code) {
            return;
        }
        var threadList = data.data.thread;
        if(threadList && threadList.length) {
            var htmlStr = '';
            for(var i = 0, thread = null; i < threadList.length; i++) {
                thread = threadList[i];
                if(thread && thread.title) {
                    htmlStr += '<p ' + this.handleAttr + '="js_showTradeThread" tid="' + thread.tid + '" class="building_model more lineDot">' +
                                  '<button class="building_icon building_topic">热点</button>' +
                                  '<span>' + thread.title + '</span>' +
                               '</p>';
                }
            }
            if(htmlStr) {
                $("#trade").prepend(htmlStr);
            }
        }
    },
    
    // 获取商圈内的小区
    getTradeResidential: function(poiid, city_code, count) {
        var params = [
            {poiid: "" + poiid, sign: 1},
            {city_code: "" + city_code},
            {count: count | 0 || 3}
        ];
        POI.api.aosrequest("ugcTradeResidential", params, POI.showTradeResidential, false, false, "GET");
    },
    showTradeResidential: function(data) {
        if(!data || "0" != data.code) {
            return;
        }
        var rList = data.data;
        var htmlStr = '';
        if(rList.length) {
            for(var i = 0; i < rList.length; i++) {
                htmlStr += '<button class="residential r' + (i + 1) + '">' + rList[i].fname + '</button>';
            }
            if(htmlStr) {
                htmlStr = '<p ' + this.handleAttr + '="js_tradeResidential" class="building_model residential_list more">' +
                              '<button class="building_icon building_residential">小区</button>' +
                              htmlStr +
                          '</p>';
                $("#trade").append(htmlStr);
            }
        }
    },
    
    /*---------------------------事件函数------------------------------*/
    
    js_showTradeThread: function(ele, e) {
        var tid = ele.attr("tid");
        POI.api.userAction("tradeThread", {
            pageId_tid: POI.clientData.poiInfo.poiid + "_" + tid
        });
        var url = POI.activityUrl.ugcUrl + "#detailtz/" + tid;
        POI.util.locationRedirect(url);
    },
    
    js_tradeResidential: function(ele, e) {
        POI.api.userAction("tradeResidential", {
            pageId: POI.clientData.poiInfo.poiid
        });
        var url = POI.activityUrl.ugcUrl + "#allxq/buss_poiid=" + POI.clientData.poiInfo.poiid;
        POI.util.locationRedirect(url);
    }
    
    /*---------------------------事件函数------------------------------*/
    
    
});

})(POI, Zepto);