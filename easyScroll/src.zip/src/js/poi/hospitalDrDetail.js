/**
 * 医生详情页面.
 */
;(function(POI, $) {
'use strict';

$.extend(POI, {
	logPageId: 'hospitalDrDetail',
	handleAttr: 'js_handle',

	quickInit: function() {
		this.util.delegate( $('#js_pagebody') );
		this.api.userAction('pv');

		var data = this.util.storage('hospital.doctorInfo');
		localStorage.removeItem('hospital.doctorInfo');
		data = JSON.parse(data);
		data = data.doctors[0];

		showDrInfo(data);

		// 主治病情
		if (data.doc_speciality) {
			var $spCont = $('#speciality .content');
			$spCont.text(data.doc_speciality);
			$('#speciality').removeClass('none');
			new this.util.toggleContent( $('#speciality .toggle-btn'), $spCont );
		}

		// 出诊信息
		if (data.visit_info && data.visit_info.length) {
			showVisitInfo(data.visit_info);
		}

		// 医师简介
		if (data.doc_intro) {
			var $cont = $('#hospitalIntro .content');
			$cont.text(data.doc_intro);
			$('#hospitalIntro').removeClass('none');
			new this.util.toggleContent( $('#hospitalIntro .toggle-btn'), $cont );
		}

		// 显示评论
		if (data.patient_review && data.patient_review.length) {
			var review = data.patient_review[0];
			$('#comment').append( tplReviewItem(review) ).removeClass('none');
		}
	},
	js_open3rdAdd: function(elem) {
		this.api.userAction('open3rdAdd');
		this.api.openThirdUrl( elem.attr('data-url') );
	}
});
/**
 * 拼接头部html.
 * @param {Object} obj 医生对象
 */
function showDrInfo(obj) {
	var doc_attitude = parseInt(obj.doc_attitude, 10);
	var doc_effect = parseInt(obj.doc_effect, 10);
	var total_patient = parseInt(obj.total_patient, 10);
	var html = '<img src="img/empty.png" class="img-def">' +
		'<div class="info">' +
			'<h3 class="name-info">' +
				obj.doc_name +
				(obj.doc_title ? '<small class="office">' + obj.doc_title + '</small>' : '') +
				(obj.child_name ? '<cite class="department">' + obj.child_name + '</cite>' : '') +
			'</h3>' +
			'<div class="score">' +
				(doc_attitude ? '<span>态度:<i class="red">' + doc_attitude + '</i>分</span>' : '') +
				(doc_effect ? '<span>疗效:<i class="red">' + doc_effect + '</i>分</span>' : '') +
				(total_patient ? '<span>患者:<i class="red">' + total_patient + '</i>人</span>' : '') +
			'</div>' +
			(obj.bookurl ? '<div class="book" data-url="' + obj.bookurl + '" ' +
				POI.handleAttr + '="js_open3rdAdd">预约加号</div>' : '') +
		'</div>';
	$('#doctorInfo').html(html);

	// 头像加载处理
	var img = obj.pic_info && obj.pic_info[0] && obj.pic_info[0].url;
	new POI.util.loadImage(img, $('#doctorInfo .img-def'), imgLoadSuccess);
	function imgLoadSuccess(elem, img) {
		$(elem).css({
			backgroundImage: 'url(' + img.src + ')',
			backgroundPosition: 'center 0',
			backgroundSize: 'cover'
		});
	}
}
/**
 * 显示出诊信息.
 * @param {Array} list 出诊列表
 */
function showVisitInfo(list) {
	// 专家 特需 普通
	// TODO 埋点
	var priceInfo = {
		'普通': 0,
		'专家': 0,
		'特需': 0
	};
	var typeInfo = {
		'普通': 1,
		'专家': 2,
		'特需': 3,
		'其他': 4
	};
	var dayIndex = {
		'上午': 2,
		'下午': 3,
		'夜间': 4,
		'全天': 1
	};
	var weekDayIndex = {
		'周一': 1,
		'周二': 2,
		'周三': 3,
		'周四': 4,
		'周五': 5,
		'周六': 6,
		'周日': 7
	};
	var $visitInfo = $('#visitInfo');
	for (var i = 0, len = list.length; i < len; i++) {
		var obj = list[i];
		var price = Number(obj.regis_fee);
		if (price) {
			priceInfo[obj.regis_type] = price;
		}
		var type = typeInfo[obj.regis_type];
		var posx = weekDayIndex[obj.visit_date] + 1;
		var posy = dayIndex[obj.visit_time];
		if (type && posx && posy) {
			// 全天时选择三行
			if (posy === 1) {
				posy = 'n+2';
			}
			$visitInfo.find('tr:nth-child(' + posy + ') td:nth-child(' + posx
				+ ')').addClass('type' + type);
		}
	}

	// 显示价格信息
	var priceHtml = '';
	for (var key in priceInfo) {
		if (priceInfo[key]) {
			priceHtml += '<span class="type' + typeInfo[key] + '">' +
				key + '号' + priceInfo[key] + '元</span>'
		}
	}
	if (priceHtml) {
		$visitInfo.find('.intro').html(priceHtml).removeClass('none');
	}

	$visitInfo.removeClass('none');
}
/**
 * 格式化评论信息.
 * @param {Object} review 评论对象
 * @return {String} html
 */
function tplReviewItem(review) {
	return '<p class="content">' + review.patient_name + '</p>' +
		'<div class="illness">' +
			(review.patient_disease ? '<i>患者病情：' + review.patient_disease + '</i>' : '') +
			(review.effect ? '<i>疗效：' + review.effect + '</i>' : '') +
		'</div>' +
		'<p class="comment">' + review.review + '</p>' +
		'<p class="source">' +
			(review.time || '') +
			(review.from ? ' 来自于' + review.from : '') +
		'</p>';
}

})(POI, $);
