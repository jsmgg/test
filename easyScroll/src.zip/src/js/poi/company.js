/*
** 网站诚信通
*/
;
(function(POI, $) {

	$.extend(POI, {
		showBusinessScope: function(deep) {
			var that = this;

			if (!deep.scope || (deep.scope && deep.scope.length < 1)) {
				return '';
			}

			POI.util.executeAfterDomInsert(function() {
				var html = '';

				html = that.makeCompanyHtml(deep, 'business_scope', '经营范围');
				$('#businessScopeDom').replaceWith(html);
				POI.api.userAction('showCompanyPage');
				
				if ($('.business_scope .cont').height() > 44) {
					$('.business_scope .toggle').show();
				} else if ($('.business_scope .cont').height() < 25) {
					$('.business_scope .cont').css('margin-top', '1.7rem');
				}
			});

			return '<div id="businessScopeDom"></div>';
		},
		makeCompanyHtml: function(deep, classname, title) {
			var that = this;
			var handleAttr = POI.handleAttr;

			var cont = classname == 'business_scope'?deep.scope:deep.main_industry;
			var html = '<section class="'+classname+'">'+
					   '<h2 class="module_title_p divide-line">'+title+'</h2>'+
					   '<div class="parent_contanier divide-line">'+
					   '<div class="cont">'+cont+'</div>'+
					   '</div>'+
					   '<div class="toggle" '+handleAttr+'="js_toggleCompanyCont"><span class="check_more">全部</span><span class="toggle_icon"></span></div>'
					   '</section>';
			return html;
		},
		showMajorBusiness: function(deep) {
			var that = this;

			if (!deep.main_industry || (deep.main_industry && deep.main_industry.length < 1)) {
				return '';
			}

			POI.util.executeAfterDomInsert(function() {
				var html = '';

				html = that.makeCompanyHtml(deep, 'major_business', '主营行业');
				$('#majorBusinessDom').replaceWith(html);

				if ($('.major_business .cont').height() > 44) {
					$('.major_business .toggle').show();
				} else if ($('.major_business .cont').height() < 25) {
					$('.major_business .cont').css('margin-top', '1.7rem');
				}
			});

			return '<div id="majorBusinessDom"></div>';		
		},
		js_goToUserPicList: function(ele, e) {
			var param = ele.attr('data-param');
			
			param = JSON.parse(param);
			param.showType = 'list';

			POI.api.userAction('businessImagesList');
			POI.util.getPicData(param);
		},
		js_toggleCompanyCont: function(ele) {
			ele.find('.toggle_icon').toggleClass('unfold');

			if (ele.find('.toggle_icon').hasClass('unfold')) {
				ele.find('.check_more').html('收起');
				ele.siblings('.parent_contanier').css('height', '100%');
			} else {
				ele.find('.check_more').html('全部');
				ele.siblings('.parent_contanier').css('height', '5.6rem');
			}
		},
		companyPageList: function(scopeStr, businessStr) {
			var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', scopeStr, businessStr, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
	        this.pagebody.html(allAry.join(""));
	        this.util.executeAfterDomInsert();
		},
		init: function() {
			this.index.moduleDeepHead();
        
	        var deep = this.aosData.deep[0];
	        var rti = this.aosData.rti;
	        var poiInfo  = this.clientData.poiInfo;

	        this.companyPageList(
	        	this.showBusinessScope(deep),
	        	this.showMajorBusiness(deep)
	        );
		}
	});
	

})(POI, Zepto);