;(function(POI, $) {
$.extend(POI, {

    // 买点page标识
    logPageId : "golfDetail",

    /**
     * 球场详情View
     */
    quickInit:function(){
        var self = this, index = self.util.getUrlParam('index') || 0,
            golfInfo = self.util.getStorageData();
        if( !golfInfo ){return;}//no data
        var courses = golfInfo.deep[0].course;
        if( courses && courses[index] ){
            if( courses[index].course_name ){
                document.title = courses[index].course_name || '高尔夫球场详情';
            }
            self.buildDetail( courses[index] );
        }
        self.util.executeAfterDomInsert();
        self.util.delegate($('#js_page'), 'js_handle');
    },
    /**
     * 创建详情页
     * @param  {JSON} data
     */
    buildDetail:function( data ){
        var self = this, box = $('#golfdetail section'),
            courseId = data.course_id;
        //缩略图
        /*self.util.picThumb({
            type:'golf',
            cont:thumb,
            pics:data.pic_info,
            count:data.pic_count,
            itemid:courseId,
            poiid : self.util.getUrlParam('poiid')
        });*/
        
        //信息项
        var dataItem = {
                'course_kind': '球场类型',
                'designer':    '设计师',
                'course_data': '球场数据',
                'fw_length':   '球场长度',
                'course_area': '球场面积',
                'built_time':  '建造时间',
                'ggseed_name': '果岭草种',
                'fwseed_name': '球道草种'
            },html = [self.util.modulePicList( data.pic_info, data.pic_count , JSON.stringify({
                    poiid : self.util.getUrlParam('poiid'),
                    itemId : courseId,
                    type:'golf'
                }) )];
        for( var i in dataItem ){
            var item = dataItem[i],
                d = data[i];
            if( d ){
                html.push( '<article>'+ item + '：'+ d +'</article>');
            }
        }
        //thumb.siblings().remove();
        box.html( html.join('') );
        var setBottomMargin = this.setBookButton( $('button') , data.order_url , data.order_price );
        if( setBottomMargin ){
            $('body').addClass('fixedBody');
        }
    },
    setBookButton:function( b , url, price ){
        var self = this;
        if( url &&  typeof price !== 'undefined' ){
            if( price < 0 ){//显示已封场
                b.text('已封场');
                b.css({opacity:0.4}).removeClass('canTouch');//重置封场样式
            }else{
                var txt = '球场预订' + ( price > 0 ? '（￥'+ price +'起）': '' );
                b.text( txt );
                b.attr('url',url);
            }
            b.parent().show();//详情页的默认隐藏，需要再次show
            return true;//显示时则返回true,用于为详情页的按钮fixed样式撑个高度
        }
        b.parent().hide();
        return false;
    },
    js_order_buy : function(obj){
        var self = this, url = obj.attr('url');
        if( url ){
            self.api.getAppPara( '','', url );
            self.api.userAction( 'golfBook',{orderUrll : url} );
        }
    }
});

})(POI, Zepto)