/* 办事指南列表 */
;(function(POI, $) {

$.extend(POI,{
    
    logPageId : "serviceGuide",
    
    adcode : '',
    
    bindEvent: function() {
        $("#body").on("click", ".sg_type2 button", function(evt) {
            var $ele = $(this);
            var type1 = $ele.attr("type1");
            var type2 = $ele.attr("type2");
            var title = $ele.attr("title");
            POI.api.userAction("serviceGuideItem", {name: title});
            if(type1 && type2 && title) {
                var url = "serviceDetail.html?adcode=" + POI.adcode + "&type1=" + type1 + "&type2=" + type2 + "&title=" + title;
                POI.util.locationRedirect(url);
            }
        });
    },

    // 判断字体宽度，中文算一个宽度，其它算半个
    processTitle: function(title) {
      var fontSize = 15 // 新闻内容字体大小
      var totalWidth = 0
      var l = title.length
      var contentWidth = (window.innerWidth - 14 * 2) / fontSize // 14是内容外的padding

      while(l--) {
        if (/[\u4E00-\u9FA5\uF900-\uFA2D]/.test(title[l])) {
          totalWidth += 1
        } else {
          totalWidth += .5
        }
      }

      if (totalWidth / contentWidth > 2) {
        title = title.slice(0, contentWidth * 2 - 3) + '...'
      }

      return title
    },
    
    showServiceGuide: function(list) {
        if(!POI.util.bool(list)) {
            return;
        }
/*
<div class="sg_item line-half">
    <h2 class="sg_type1">结婚生育</h2>
    <ul class="sg_type2">
        <li><button>北京结婚证</button></li>
        <li><button>北京准生证</button></li>
        <li><button>北京单独二胎</button></li>
        <li><button>北京离婚证</button></li>
        <li><button>北京婚检</button></li>
        <li><button>北京涉外婚姻</button></li>
    </ul>
</div>
*/
        var _this = this;
        var htmlStr = '';
        var buttonStr = '';
        for(var i = 0, len = list.length, item = null; i < len; i++) {
            item = list[i];
            buttonStr = '';
            if(!(item.type1 || POI.util.bool(item.type2_info))) {
                continue;
            } else {
                for(var j = 0, _len = item.type2_info.length, _item = null; j < _len; j++) {
                    _item = item.type2_info[j];
                    _item.title = _this.processTitle(_item.title)

                    buttonStr += '<li><button class="canTouch" type1="' + item.type1 + '" type2="' + _item.type2 + '" title="' + _item.title + '">' + _item.title + '</button></li>';
                }
            }
            if(buttonStr) {
                htmlStr += '<div class="sg_item line-half">' +
                               '<h2 class="sg_type1">' + item.type1 + '</h2>' +
                               '<ul class="sg_type2">' +
                                   buttonStr +
                               '</ul>' +
                           '</div>';
            }
        }
        if(htmlStr) {
            $("#body").html(htmlStr);
            setTimeout(_this.bindEvent, 0);
        }
    },
    
    getServiceGuideData: function(adcode) {
        if(!POI.util.bool(adcode)) {
            return;
        }
        var _this = this;
        var params = [
            {adcode: adcode, sign: 1}
        ];
        POI.api.aosrequest('serviceGuide', params, function(data) {
            if("1" == data.code) {
                var list = data.data;
                if(!POI.util.bool(list)) {
                    return;
                }
                _this.showServiceGuide(list);
            }
        }, 1, true, "GET");
    },
    
    quickInit : function(){
        this.adcode = POI.util.getUrlParam("adcode");
        this.getServiceGuideData(this.adcode);
    }
});

})(POI, Zepto)
