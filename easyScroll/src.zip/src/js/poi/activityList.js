/**
 * 活动、会议、聚会等信息
 */
;(function(POI, $) {

'use strict';

$.extend(POI, {
    
    handleAttr: "js_handle",
    
    logPageId : "activityList",
    
    activityConfig : [
        {title: "活动信息", iconClass: "ych", iconName: "演唱会", date: "演出时间"},
        {title: "活动信息", iconClass: "jh",  iconName: "聚会",   date: "聚会时间"},
        {title: "活动信息", iconClass: "hd",  iconName: "活动",   date: "活动时间"},
        {title: "会议信息", iconClass: "hy",  iconName: "会议",   date: "会议时间"}
    ],
    activityStr : function(activity, idx, len) {
        var type = ("" + activity.type).split(";")[0] | 0;
        var config = this.activityConfig[ (type - 1) ];
        var pic = '';
        try { pic = activity.pic_info[0].url; } catch(e) {}
        // 数据在入测试库时字段名拼写错误，在正式库中修改正确，先兼容下
        activity.activity_wapurl = activity.activity_wapurl || activity.acitvity_waprul || activity.activity_waprul || '';
        var cpwap = (activity.meeting_info && activity.meeting_info.length) ? 'meetingDetail.html' : activity.activity_wapurl;
        var str = '<section class="line-half">' +
                      '<article ' + POI.handleAttr + '="js_gotoActivityCPWap" class="act_con canTouch' + (pic ? '' : ' no_cover') + '" idx="' + idx + '" cpwap="' + cpwap + '">' +
                          (pic ? '<div class="act_cover" style="background-image: url(\'' + pic + '\'); background-size: cover;"></div>' : '') +
                          '<div>' +
                              '<p class="act_title"><button class="act_type ' + config.iconClass + '">' + config.iconName + '</button>' + activity.name + '</p>' +
                              (activity.admi_time ? '<p class="act_enter_time">入场时间：' + activity.admi_time + '</p>' : '') +
                              (activity.date ? '<p class="act_start_time">' + config.date + '：' + activity.date + '</p>' : '') +
                              (activity.price ? '<p class="act_price">票价：<span>' + activity.price + '</span></p>' : '') +
                              (activity.intro ? '<p class="act_intro">简介：' + activity.intro + '</p>' : '') +
                          '</div>' +
                      '</article>' +
                  '</section>';
        return str;
    },
    
    activityHtml : function() {
        POI.aosData = POI.aosData || POI.util.getStorageData() || {};
        var rti = POI.aosData.rti;
        if(rti && rti.activity && rti.activity.length) {
            var activityLength = rti.activity.length;
            var htmlStr = '';
            for(var i = 0, activity = null; i < activityLength; i++) {
                var activity = rti.activity[i];
                var type = ("" + activity.type).split(";")[0] | 0;
                // 1:演出 2:聚会 3:活动 4:会议
                if(/^(1|2|3|4)$/.test(type)) {
                    htmlStr += this.activityStr(activity, 0, activityLength);
                }
            }
            return htmlStr;
        } else {
            return '';
        }
    },

    js_gotoActivityCPWap : function(ele, e) {
        var cpWap = ele.attr("cpwap");
        var idx = ele.attr("idx");
        if(cpWap) {
            if(0 === cpWap.indexOf("http")) {
                POI.api.userAction('activityCpWap', {name_url : POI.aosData.rti.activity[idx].name + "_" + cpWap });
                POI.api.openThirdUrl(cpWap);
            } else {
                POI.api.userAction('activityDetail', {name : POI.aosData.rti.activity[idx].name});
                POI.util.locationRedirect(cpWap + "?idx=" + idx);
            }
        }
    },
    
    quickInit : function() {
        var htmlStr = this.activityHtml();
        var activityListDom = $("#activityList");
        activityListDom.html(htmlStr);
        POI.util.delegate(activityListDom, POI.handleAttr);
    }
});

})(POI, $);
