/*场馆活动列表*/
;(function(POI, $) {
$.extend(POI,{
    logPageId : 'activity',
    handleAttr : 'js_handle',
    //近期活动二级页面
    quickInit : function(){
        var self = this, poiData=self.util.getStorageData(), Swidth, Sheight, handleAttr= self.handleAttr,
            theater=poiData&&poiData.rti&&poiData.rti.theater, actList=[],len=theater&&theater.length;
        if(len){
            for (var i=0; i<len; i++){
                var item=theater[i];
                actList.push('<article class="canTouch"><a ' + handleAttr + '="js_goActivityPage" url="' + item.activity_wapurl + '"><span><img class="img-loading" data-presrc="'+item.coverimg+'" src='+item.coverimg+'></span><cite><b class="linesDot">'+item.name+'</b>'+(item.date ? '<em>'+item.date+'</em>' : '')+'<span class="price linesDot">'+(item.price || '暂无')+'</span></cite></a></article>');
            }    
        }
        $("#exActivity").html(actList.join(''));
        self.util.imgloading($("#exActivity img"));
        Swidth = $("#exActivity article").find("span").width(), Sheight = Math.floor(Swidth * 1.1);
        $("#exActivity article").find("img").css("min-height",Sheight);
        self.util.delegate($('#exActivity'), handleAttr);
    },
    js_goActivityPage : function( obj ) {
        this.api.getAppPara('', '', obj.attr('url'));
        this.api.userAction('getAppPara-avt3');
    }
});

})(POI, Zepto);