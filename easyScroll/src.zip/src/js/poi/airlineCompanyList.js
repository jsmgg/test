/*
    航站楼航空公司列表页
    进入页面地址location.search为?poiid
*/
;(function(POI, $){

var cache = {},
    page = 1, //当前页码
    pagesize = 20, //一页显示数量
    busy = false,
    index = 0,
    loadMore = null; //更多控件

$.extend(POI, {

    // 买点page标识
    logPageId : "airlineCompanyList",

    stationName : decodeURIComponent(location.search.replace('?','').split('_')[1] || ''),
    
    poiid : location.search.replace('?','').split('_')[0] || '',
    
    bindEvent : function() {//事件绑定
        $('section').click(function(e) {
            var target = $(e.target).closest('article'),
                key,
                item,
                list = [];
            if(target.length && (key = target.attr('key'))) {
                item = cache[key];
                if(!item || !item.air_tel) return;
                POI.api.userAction('airlineCompanyList', {poiid_airways: POI.poiid + '_' + item.airways});
                (item.air_tel || '').split(';').forEach(function(tel) {
                    tel && list.push({
                        'title': tel + '',
                        'content': tel + ''
                    });
                });
                list.length && POI.api.showPanellist(list);
            }
        });
    },
    
    rander : function(airline_list) {
        var box = $('section'),
            html = [],
            key;
        airline_list.forEach(function(item, i) {
            key = 'item' + index++;
            item.air_tel = $.trim(item.air_tel) || '';
            html.push('<article'+(item.air_tel ? ' class="airCompany_con canTouch"' : ' class="airCompany_con"')+' key="' + key + '"><p class="airCompany_name">' + (item.airways || '') + '<i class="airCompany_bar">' + (item.cuss || '') + '</i></p>' + (item.air_tel ? '<a href="javascript:void(0)" class="airCompany_call half-border">打电话</a>' : '') + '</article>');
            cache[key] = item;
        });
        box[ page == 1 ? 'html' : 'append' ](html.length ? html.join('') : '');
        //<p style="width:100%;padding:40px 0;text-align:center;">亲，暂时还没有航空公司列表数据！</p>
        page == 1 && box.removeClass('hide');
    },
    
    get_companys : function() {//获取航空公司列表
        if(busy) return;
        busy = true;
        var params = [
            {poiid: POI.poiid, sign: 1},
            {pagenum: page},
            {pagesize: pagesize}
        ];
        POI.api.aosrequest('airlineCompanyList', params, function(dt) {
            dt.airline_list = dt.airline_list || [];
            POI.rander(dt.airline_list);
            if(page == 1 && dt.page_total > page) {
                loadMore = new POI.util.PullUpGetMore(function() {
                    POI.get_companys();
                });
            }
            if(dt.airline_list.length == 0 || dt.page_total <= page){
                loadMore && loadMore.destory();
            }else{
                loadMore && loadMore.refresh();
            }
            page++,busy = false;
        }, page == 1 ? 1 : 0, true, "GET");
    },
    
    quickInit : function() {
        POI.util.setPageTitle(this.stationName + '航空公司');
        this.get_companys();
        this.bindEvent();
    }
    
    
    
});

})(POI, Zepto);