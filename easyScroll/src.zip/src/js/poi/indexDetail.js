;(function(POI, $) {
'use strict';

$.extend(POI, {
    
    logPageId: 'poiIntroDetail',

    pagebody: $("#js_poi_page"),
    
    business: "",
    
    aosData: null,
    
    jsMap: {
        "hotel"         : "js/poi/detail/det_hotel.js",                   // 酒店
        "dining"        : "js/poi/detail/det_dinning.js",                 // 餐饮美食
        "cinema"        : "js/poi/detail/det_movie.js",
        "scenic"        : 'js/poi/detail/det_scenic.js',
        "residential"   : "js/poi/detail/det_building.js",
        "education"     : "js/poi/detail/det_education.js"                  //大学
    },
    
    showIntro: function(business, deep, otherStr) {
        var str = '';
        if(business) {
            var bmap = {
                "dining" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "服务设施", data: deep.tag_category ? '<span class="intro_category">' + deep.tag_category.replace(/\|/g, '</span><span class="intro_category">') + '</span>' : ''},
                    {name: "餐厅特色", data: deep.service ? deep.service.replace(/\|/g, " ") : ""},
                    {name: "餐厅氛围", key: "tag_atmosphere"},
                    {name: "商户简介", key: "intro", more: true}
                ],
                "hotel" : [],
                "airport" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ],
                "residential" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ],
                "car" : [
                    {name: "简介", key: "intro", more: true},
                    {name: "主营品牌", data: deep.tag_special && 'string' === typeof deep.tag_special ? deep.tag_special.replace(/\|/g, " ") : ""},
                    {name: "主营车型", key: "tag_car"}
                ],
                "event" : [{name: "简介", key: "intro", more: true}],
                "golf" : [
                    {name: "商户简介", key: "intro", more: true},
                    {name: "球会设施", key: "club_facility"}
                ],
                "cinema" : [
                    {name: "影院简介", key: "intro", more: true},
                    {name: "营业时间", key: "opentime2"},
                    {name: "3D厅设施", key: "service_3D"},
                    {name: "周边休闲场所", data: deep.surrounding ? deep.surrounding.replace(/\|/g, " ") : ""},
                    {name: "周边餐饮设施", data: deep.service_dinning ? deep.service_dinning.replace(/\|/g, " ") : ""},
                    {name: "周边游戏厅", key: "service_game"},{name: "停车场", key: "service_parking"}
                ],
                "bus" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ],
                "subway" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ],
                "traffic" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ],
                "bank" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "业务范围", data: deep.b_sphere ? deep.b_sphere.replace(/(对[公私][:：]?)/g, "<span>$1</span>").replace(/\|/g, "、").replace("\r\n", "<br/>") : "", more: true}
                ],
                "atm" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "业务范围", data: deep.b_sphere ? deep.b_sphere.replace(/(对[公私][:：]?)/g, "<span>$1</span>").replace(/\|/g, "、").replace("\r\n", "<br/>") : "", more: true}
                ],
                "theater" : [{name: "场馆简介", key: "intro", more: true}],
                "hospital" : [{name: "商户简介", key: "intro", more: true}],
                "business_hall" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "营业厅性质", key: "nature"}
                ],
                "other" : [
                    {name: "营业时间", key: "opentime2"},
                    {name: "简介", key: "intro", more: true}
                ]
            }
            if(otherStr) {
                bmap["cinema"].unshift(otherStr);
            }
            if(bmap[business]) {
                str = POI.util.intro(bmap[business]);
            } else {
                str = POI.util.intro([{name: "营业时间", key: "opentime2"},{name: "简介", key: "intro", more: true}]);
            }
        } else {
            str = POI.util.intro([{name: "营业时间", key: "opentime2"},{name: "简介", key: "intro", more: true}]);
        }
        POI.util.executeAfterDomInsert(function() {
            var $introSpec = $('#intro #introSpec'),
                $introFold = $('#intro .introFold');
            new POI.util.toggleContent($introFold, $introSpec);
        });
        return str;
    },
    
    setTitle : function() {
        var title = this.aosData.base.name;
        this.util.setPageTitle(title || "详情");
    },
    
    quickInit: function() {
        var self = this;
        self.util.delegate($('#js_poi_page'), 'js_handle');
        var business = self.util.getUrlParam('business');
        self.business = business;
        self.aosData = self.util.getStorageData();
        self.setTitle();
        if( self.jsMap[business] ) {
            self.util.loadResources(self.jsMap[business], function() {
                self.indexDetail && self.indexDetail();
            });
        } else {
            //var pic = self.aosData.pic;
            //var param = {
            //    type: 'poiface',
            //    poiid: self.aosData.base.poiid
            //};
            //param = JSON.stringify(param);
            //var introStr = self.util.modulePicList(pic.gallery, pic.pic_count, param);
            //if (introStr) {
            //    introStr = '<section class="notop">' + introStr + '</section>';
            //}
            var introStr = self.showIntro(business, self.aosData.deep[0]);
            self.pagebody.html(introStr);
            POI.util.executeAfterDomInsert();
        }
    }
});

})(POI, $);
