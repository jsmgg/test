/**
 * 日期控件.
 * @required Zepto
 * @required AMAP6.3.0+
 *
 * 创建全局对象 calendar, 使用 setPageInfo 进行初始化
 * 使用 localStorage： calendar {JSON string}
 *    calendar.type 控件应用类型，hotel、 scenic
 *    calendar.title 页面标题
 *    calendar.selected 选中的日期，格式yyyy-MM-dd
 *    calendar.today 今天的时间戳，为空时取客户端时间
 *    calendar.visitList 景点门票时必存，门票列表 [{date: 'yyyy-MM-dd', price: '$x'}]
 */
;(function(win, $, POI) {

'use strict';

var
    doc = win.document,

    storage = POI.util.storage,

    WEEK_DAY = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],

    // 一天的毫秒数
    DAY_MILLISEC = 1000 * 60 * 60 * 24,

    fromNativeHotel = false, // 是否从客户端进入的此页面

    // 控件类型，酒店或景点
    calendarType,

    CALENDAR_MONTH_NUM = 3,

    lastCalendarDay,

    inDateSelected,

    waitingReturn = false,

    todayDate = new Date();

/**
 * 将 yyyy-MM-dd 格式的字符串转换为时间戳.
 * @param {String} ymd 年月日时间字符串
 * @return {Integer} 时间戳
 */
function ymd2Timestamp(ymd) {
    if (!ymd) {
        return 0;
    }
    var arr = ymd.split('-');
    return ( new Date(arr[0], arr[1] - 1, arr[2]) ).getTime();
}

/**
 * 获取日期月份的天数.
 * @param {Date|Integer} month 日期对象或日期月份，为日期对象时忽略第二个参数，
 *    返回该对象月份的天数，为数值类型时返回月份的天数，year缺省时认为是平年
 * @param {Integer} year 日期年份
 * @return {Integer} 日期月份所含天数
 */
function getDaysOfMonth(month, year) {
    if ( $.type(month) == 'date' ) {
        year = month.getFullYear();
        month = month.getMonth() + 1;
    }
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
        case 2:
            return year && ( year % 400 === 0 ||
                ( year % 4 === 0 && year % 100 !== 0 ) ) ? 29 : 28;
    }
}

/**
 * 点击日期返回上一页面.
 */
function selectCalendarDate(event) {
    var $this = $(event.currentTarget);
    if ($this.hasClass('disabled') || $this.hasClass('blank') || waitingReturn) {
        return;
    }

    var selected = +$this.attr('data-date');
    var sdate = new Date(parseInt(selected));
    selected = POI.util.formatDate(sdate, 'yyyy-MM-dd');

    // 离店日期不能和入住一起一样
    if (selected == inDateSelected) {
        return;
    }

    var params = {
        action: 'freshRoomData'
    };
    var delay = 0;
    if (calendarType == 'hotel') {
        POI.api.promptMessage('', '-1');
        // 第一次选择为入住日期，等待第二次选择
        if (!inDateSelected) {
            $('.selected,.middle').removeClass();
            $this.removeClass('festival').addClass('selected in');
            inDateSelected = selected;
            $('td[data-date="' + lastCalendarDay.getTime() + '"]').removeClass('disabled');
            // 离店日期不能超过入住日期15天
            var startDay = sdate.getTime();
            var endDay = startDay + 15 * DAY_MILLISEC;
            var $days = $('td[data-date]');
            for (var i = 0, len = $days.length; i < len; i++) {
                var $day = $days.eq(i);
                var date = $day.attr('data-date');
                if (date > endDay || date < startDay) {
                    $day.addClass('disabled');
                }
            }
            POI.api.promptMessage('请选择离店日期', '3');
            return;
        }
        // 中间的日期增加中间样式
        var dayTime = ymd2Timestamp(inDateSelected) + DAY_MILLISEC;
        while (dayTime < sdate) {
            $('td[data-date="' + dayTime + '"]').addClass('middle');
            dayTime += DAY_MILLISEC;
        }
        $this.addClass('selected out');
        params.inDate = inDateSelected;
        params.outDate = selected;
        delay = 600;

        // 存储用户选择的日期
        POI.api.nativeStorage('hotelDate', inDateSelected + '|' + selected +
            '|' + POI.util.formatDate(new Date(), 'yyyy-MM-dd'));
    }
    else if (calendarType == 'scenic') {
        params.date = selected;
    }
    params.type = calendarType;

    if (!fromNativeHotel) {
        // ios下此值已写死
        params._action = 'freshRoomData';
    }

    var info = {date: selected};
    // 存储门票价格
    if ( $this.children('div').length ) {
        info.price = $this.children('div').text().substr(1);
    }
    storage('calendar', JSON.stringify(info));

    waitingReturn = true;
    setTimeout(function() {
        POI.send(params);
    }, delay);
}

/**
 * 将页面滚动到所选择的日期部分.
 * @param  {String} calendarSelected 显示到屏幕中央的日期，yyyy-MM-dd
 * @return {[type]} [description]
 */
function scrollToSelected(calendarSelected) {
    if (!calendarSelected) {
        return;
    }
    // 将滚动条滚动到选中日期位置
    var selected = new Date( ymd2Timestamp(calendarSelected) );
    var months = selected.getMonth() - todayDate.getMonth();
    if (months == 2 || months == -10) {
        // 差两个月滚动到页面底部
        $('body').scrollTop( $(doc).height() );
    } else if (months == 1 || months == -11) {
        // 差一个月则滚动到页面中央
        $('body').scrollTop( ($(doc).height() - $(win).height()) / 2 );
    }
}

/**
 * 创建日历的一个月份.
 * @param {Date} date 创建的月份
 */
function createMonth(date) {
    var i, n;
    var $month = $('<section/>').addClass('calendar');

    // 添加头部信息
    $('<h1/>').text( date.getFullYear() + '年' + (date.getMonth() + 1) + '月' )
        .appendTo($month);
    var $head = $('<div/>').addClass('calendar-header');
    for (i = 0, n = WEEK_DAY.length; i < n; i++) {
        $('<span/>').text( WEEK_DAY[i] ).appendTo($head);
    }
    $head.children().first().addClass('weekend');
    $head.children().last().addClass('weekend');

    // 添加日期信息
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1),
        dateVal = firstDay.getTime(),
        // 第一天前面应填充的空白表格数目
        startDays = firstDay.getDay(),
        // 今天
        today = todayDate,
        // 今天之前的天数
        pastDays = today.getDate() - 1,
        // 本月的天数
        monthDays = getDaysOfMonth(date),
        // 最后一天后的空白数，最外层的求余为防止值为7
        endDays = ( 7 - (startDays + monthDays) % 7 ) % 7,
        // 单元格html数组，元素为jQuery对象
        days = [];
    // 用空白填充前面上月的日期
    for (i = 0; i < startDays; i++) {
        days.push( $('<td/>').addClass('blank') );
    }
    // 添加已经过去的日期
    i = 1;
    if (today.getMonth() == date.getMonth()) {
        for (; i <= pastDays; i++) {
            days.push( $('<td/>').addClass('disabled').text(i) );
        }
        // 添加今天
        days.push( $('<td/>').attr('data-date',  dateVal + (i - 1) * DAY_MILLISEC).html('今天').addClass('festival') );
        i += 1;
    }
    for (;i <= monthDays; i++) {
        days.push( $('<td/>').attr('data-date', dateVal + (i - 1) * DAY_MILLISEC).text(i) );
    }
    // 使用空白补齐表格
    for (i = 0; i < endDays; i++) {
        days.push( $('<td/>').addClass('blank') );
    }
    // 将单元格组成行放入表格中
    var $table =  $('<table/>');
    for (i = 0, n = days.length / 7; i < n; i++) {
        var $line = $('<tr/>');
        for (var j = 0; j < 7; j++) {
            $line.append( days[i * 7 + j] );
        }
        $line.appendTo($table);
    }

    // 添加点击事件
    $table.find('td').click(selectCalendarDate);

    $('<article/>').append($head).append($table).appendTo($month);
    $('body').append( $month );
}

/**
 * 创建日历.
 * 如果想改变起始的月份，在调用此方法前设置 todayDate 的值
 * @param {String} [title="选择日期"] 标题
 * @param {Integer} [monthNum=3] 显示的月份个数
 */
function createCalendar(title, monthNum) {
    if (!monthNum) {
        monthNum = CALENDAR_MONTH_NUM;
    }

    POI.api.setWebViewTitle(title || '选择日期');

    // 将今天的时分秒设置为0
    todayDate = new Date(todayDate.getFullYear(), todayDate.getMonth(), todayDate.getDate());
    for (var i = 0; i < monthNum; i++) {
        createMonth( new Date(todayDate.getFullYear(), todayDate.getMonth() + i) );
    }
    $('body').css('margin-bottom', '10px');

    $(win).on('resize', resizeCellHeight).resize();
}

/**
 * 转屏时重新设置单元格大小.
 */
function resizeCellHeight() {
    var cellSize = Math.round($('.calendar-header').first().width() / 7) - 1;
    $('.calendar td').css({height: cellSize});
}

var calendar = {
    logPageId: 'calendar',

    quickInit: function() {
        var _this = this;
        var now = new Date();

        // 景点poi详情进入
        var info = _this.util.storage('calendar');
        if (info) {
            info = JSON.parse(info);
            var pastTime = now.getTime() - info.timestamp;
            if (pastTime < 3000 && pastTime > 0 && info.type === 'scenic') {
                win.localStorage.removeItem('calendar');
                todayDate = new Date(info.today);
                calendarType = info.type;
                createCalendar(info.title);
                scrollToSelected(info.selected);
                // 景点只有特定的日期可以点击，并显示价格
                $('[data-date]').removeClass().addClass('disabled');
                var list = info.visitList || [];
                for (var i = 0, n = list.length; i < n; i++) {
                    var $cell = $('[data-date="' + ymd2Timestamp(list[i].date) + '"]')
                        .removeClass('disabled');
                    if (list[i].price > 0) {
                        $cell.html( $cell.text() + '<div>￥' + list[i].price + '</div>' );
                    }
                }
                return;
            }
        }
        else {
            fromNativeHotel = true;
        }

        // 酒店日期
        _this.api.nativeStorage('hotelDate', function(res) {
            calendarType = 'hotel';
            var nowStr = _this.util.formatDate(now, 'yyyy-MM-dd');
            var inDateStr = '', outDateStr = '';
            var useStorageData = false;
            if (res.value) {
                var arr = res.value.split('|');
                if (nowStr === arr[2]) {
                    inDateStr = arr[0];
                    outDateStr = arr[1];
                    useStorageData = true;
                }
            }
            if (!useStorageData) {
                inDateStr = nowStr;
                now.setDate(now.getDate() + 1);
                outDateStr = _this.util.formatDate(now, 'yyyy-MM-dd');
            }
            createCalendar();
            scrollToSelected(inDateStr);

            // 酒店最后一天不能作为入住日期
            var lastDay = new Date(todayDate.getTime());
            lastDay.setMonth(lastDay.getMonth() + CALENDAR_MONTH_NUM);
            lastDay.setDate(0);
            lastCalendarDay = lastDay;
            $('td[data-date="' + lastDay.getTime() + '"]').addClass('disabled');

            // 将入住日期和离店日期中间日期增加样式
            var inDate = ymd2Timestamp(inDateStr);
            var outDate = ymd2Timestamp(outDateStr);
            $('td[data-date="' + inDate + '"]').removeClass().addClass('selected in');
            $('td[data-date="' + outDate + '"]').addClass('selected out');
            inDate += DAY_MILLISEC;
            while (inDate < outDate) {
                $('td[data-date="' + inDate + '"]').addClass('middle');
                inDate += DAY_MILLISEC;
            }
            POI.api.promptMessage('请选择入住日期', '3');
        });
    }
};

// win.calendar = calendar;
$.extend(POI, calendar);

})(window, $, POI);
