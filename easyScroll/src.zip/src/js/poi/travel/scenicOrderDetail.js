/* 景点/订单详情 */
;(function(POI, $) {
'use strict';

    var handlerAttr = 'js_handler';
    var orderData = {};   // 缓存服务接口返回的数据
    
    $.extend(POI, {
        logPageId: 'scenicOrderDetail',

        /**
         * 打开POI页面
         * @param  {Boolean} status true/false ~ POI详情页/搜索结果页
         * @return nth
         */
        _openPoi: function(status) {
            var self = this;

            var poiInfo = {
                poiid        : orderData.poi_id,
                name         : orderData.poi_name,
                address      : orderData.poi_address,
                cityCode     : '',
                poiType      : '',
                new_type     : '',
                phoneNumbers : orderData.poi_tel,
                lon          : orderData.longitude,
                lat          : orderData.latitude
            };
            
            self.api.openPoi(poiInfo, status);
        },
        
        _phoneCall: function(phoneList) {
            var self = this;
            self.api.showPanellist(phoneList);
        },
        /*-------------------------------------事件处理器*/
        //打电话
        js_phoneCallPOI: function(ele, e) {
            var self = this;
            var phone = orderData.poi_tel;
            var ary = phone.split(",");
            self._phoneCall(ary);
            self.api.userAction('phoneCallPOI');
        },
        
        js_phoneCallCP: function() {
            var self = this;
            var phone = orderData.cp_tel;
            var ary = phone.split(",");
            self._phoneCall(ary);
            self.api.userAction('phoneCallCP');
        },
        
        js_openScenicPoiDetail: function() {
            // 跳转到POI详情页面
            this._openPoi(1);
            this.api.userAction('openScenicPoiDetail');
        },

        js_openScenicPoiMap: function(ele, e) {
            // 跳转到搜索结果页
            this._openPoi(0);
            this.api.userAction('openScenicPoiMap');
        },
        // 显示重发短信弹窗
        js_showResendPrompt: function(elem) {
            if ($(elem).hasClass('disabled')) {
                return;
            }
            var $prompt = $('#prompt');
            if (!$prompt.length) {
                var html = '<div id="prompt" class="prompt none">' +
                        '<h3 class="title"></h3>' +
                        '<input type="text">' +
                        '<div class="buttons line-half">' +
                            '<span class="button" js_handler="js_cancelPrompt">取消</span>' +
                            '<span class="button" js_handler="js_reSendMessage">发送</span>' +
                        '</div>' +
                    '</div>';
                $('#js_poi_page').append(html);
                $prompt = $('#prompt');
            }
            $prompt.find('.title').text('请确认手机号');
            var phone = '';
            if (orderData.order_mobile && /^1\d{10}$/.test(orderData.order_mobile)) {
                phone = orderData.order_mobile;
            }
            $prompt.find('input').attr('type', 'tel').val(phone);
            $prompt.show();
        },
        js_cancelPrompt: function() {
            $('#prompt').hide();
        },
        // 重发短信
        js_reSendMessage: function() {
            var self = this;
            var phone = $('#prompt input').val();
            if (!phone) {
                self.api.promptMessage('请填写手机号');
                return;
            }
            if (!/^1\d{10}$/.test(orderData.order_mobile)) {
                self.api.promptMessage('请填写正确的手机号');
                return;
            }
            $('#prompt').hide();
            self.api.aosrequest('scenicResendMessage', [
                {order_mobile: phone},
                {amap_order_id: orderData.order_id}
            ], function(res) {
                if (res.code != 1) {
                    self.api.promptMessage('发送失败，请稍后重试');
                    return;
                }
            }, 1, true, 'get');
        },
        /*------------------------------------- end 事件处理器*/

        // 获取订单详情数据
        getOrderDetail: function(arg) {
            var self = POI;

            self.api.aosrequest({
                urlPrefix: 'scenicCPOrderDetail',
                method: 'GET',
                progress: 1,
                params: [
                    {order_id: arg.value, sign: 1}
                ],
                showNetErr: '1'
            }, function(res) {
                if ('1' == res.code && Object.prototype.toString.call(res.order) === '[object Object]') {
                    // 缓存一份
                    orderData = res.order;

                    // 显示数据
                    self._displayOrderDetail(res.order);
                }
                else if (res.code == '14') {
                    // 去登录页
                    self.send({
                        action: 'getAmapUserId',
                        onlyGetId: '0', /* 未登录则去登录页面 */
                        needRelogin: '0'
                    }, function(userInfo) {
                        if (userInfo.userid) {
                            // 已登录
                            // 重新获取数据并显示
                            self.initPage();
                        } else {
                            self.api.webviewGoBack(1);
                        }
                    });
                }
            });
        },

        _displayOrderDetail: function(order) {
            var self = this;
            var addressStr = order.poi_address || " ";
            var ticketDateStr = order.ticket_date || " ";
            var orderIdStr = order.order_id || " ";
            var amountStr = order.amount ? order.amount + "张" : " ";
            var totalPriceStr = order.total_price ? '<span id="money" class="sod_icon_total">￥' + order.total_price + '</span>' : '';
            var poiTelStr = order.poi_tel || " ";
            $("#poiName").text(order.poi_name);
            $("#address").html('<i class="sod_icon sod_icon_address"></i>' + addressStr);
            $("#time").html('<i class="sod_icon sod_icon_time"></i>' + ticketDateStr);
            // 判断是否显示重发短信按钮
            if (order.resend_count != undefined && order.resend_count != -1) {
                orderIdStr += '<cite js_handler="js_showResendPrompt" class="re-send' +
                    (order.resend_count == '0' ? ' disabled' : '') + '">重发短信</cite>';
            }
            $("#oid").html('<i class="sod_icon sod_icon_oid"></i>' + orderIdStr);
            $("#count").html('<i class="sod_icon sod_icon_count"></i>' + amountStr + totalPriceStr);
            $("#telphone").html('<i class="sod_icon sod_icon_telphone"></i>' + poiTelStr);
            $("#cpInfo").html(order.cp_name + '客服：<span class="sod_service_number">' + order.cp_tel + '</span><span class="sod_icon_tel"></span>');
            $("#tip").html('取消或修改订单请联系' + order.cp_name + '客服');
            $("#js_poi_page").show();
        },

        initPage: function() {
            var self = this;

            // 获取参数order_id，回调显示订单详情
            self.api.nativeStorage("scenic_order_id", self.getOrderDetail);
        },


        quickInit: function() {
            var self = this;
            var $root = $('#js_poi_page');

            // 绑定事件处理器
            self.util.delegate($root, handlerAttr);

            // 获取数据并展示
            self.initPage();
        }
    });
})(POI, Zepto);