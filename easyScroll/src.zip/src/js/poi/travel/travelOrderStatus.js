/**
 * 景点支付结果页面
 */

(function(POI, $) {
  'use strict';
	$.extend(POI, {
		logPageId : 'exTravelOrderStatus',//为埋点category用
		oAllOrderStatusArg : null,//存储从订单页面传过来的数据
		quickInit: function() {
			var self = this;
				console.log('__oAllOrderStatusArg'+self.util.getUrlParam('oAllOrderStatusArg'));
			var oAllOrderStatusArg = JSON.parse(self.util.getUrlParam('oAllOrderStatusArg'));
			self.oAllOrderStatusArg = oAllOrderStatusArg;
			self.requestTicketOrderStatusData(oAllOrderStatusArg.ticketID, oAllOrderStatusArg.srcType, oAllOrderStatusArg.amount, oAllOrderStatusArg.ticketDate, oAllOrderStatusArg.oBookArg, oAllOrderStatusArg.oPartnerArg);
			
		},
		/*请求订票须知的接口*/
		requestTicketOrderStatusData: function(g_ticketId, g_srctype, g_amount, g_ticketdate, g_booker, g_partners) {
			var that = this,
        g_poiid = that.oAllOrderStatusArg.poiInfo.poiid;
			if (!g_poiid || !g_ticketId || !g_srctype || !g_amount || !g_ticketdate || !g_booker) {
				return;
			}
			var Params = [{
				poiid: g_poiid,
				sign: 1
			}, {
				src_type: g_srctype,
				sign: 1
			}, {
				ticket_id: g_ticketId,
				sign: 1
			}, {
				amount: g_amount,
				sign: 1
			}, {
				ticket_date: g_ticketdate,
				sign: 1
			}, {
				booker: g_booker,
				sign: 1
			}];
			if (g_partners) {
				Params.push({
					partner: g_partners,
					sign: 0
				});
			}
      // alert('jiegou'+JSON.stringify(Params))
			POI.api.aosrequest("scenicSendStatus", Params, function(arg) {
				try{that.responseTicketOrderStatusData(arg);}catch(e){}
			}, 1, true, "GET");
		},
		responseTicketOrderStatusData: function(arg) {
			if (arg.code == 1) {
				//成功
				$('#travelBookStatus h4').html('预订成功！').css('background-image', "url('img/travel_ticket_success.png')");
				if ($('#getTicket').hasClass('rebook')) {
					$('#getTicket').removeClass('rebook');
				}
				$('#getTicket').addClass('order').html('查看订单');
				$('#travelBookStatus p').html('恭喜您，订单提交成功！预订人手机将收到来自同程旅游的凭证短信，可直接到指定的售票窗口取票。');
				$('#getTicket').unbind('click').bind('click', function() {
					//进入我的订单
					POI.send({
						"action": "orderFeature",
						"feature": "travel"
					});
				})
			} else {
				if (arg.code == 128) {
					//失败透传第三方
					$('#travelBookStatus p').html(arg.cp_api_msg);
				} else {
					$('#travelBookStatus p').html('订单异常出错');
				}
				$('#travelBookStatus h4').html('预订失败！').css('background-image', "url('img/travel_ticket_error.png')");
				if ($('#getTicket').hasClass('order')) {
					$('#getTicket').removeClass('order');
				}
				$('#getTicket').addClass('rebook').html('重新订票');
				$('#getTicket').unbind('click').bind('click', function() {
					//打开poi详情页
					var poiInfo = POI.oAllOrderStatusArg.poiInfo;
					// alert('poiInfo'+JSON.stringify(poiInfo))  
					// alert(poiInfo.poiid)
					POI.api.openPoiInfo(poiInfo.poiid, poiInfo.name, poiInfo.address, poiInfo.cityCode, poiInfo.new_type, '', poiInfo.lon, poiInfo.lat, 1);
				})
			};
			if (arg.cs && arg.cs.cp_tel) {
				var phones = [];
				$('#travelBookStatus>article').siblings().remove;
				$('#travelBookStatus').append('<h2 class="more">客服电话:' + arg.cs.cp_tel + '</h2>');
				phones.push([{
					title: arg.cs.cp_tel,
					content: arg.cs.cp_tel
				}]);
				$('#travelBookStatus h2').unbind('click').bind('click', function() {
					POI.api.showPanellist(phones[0]);
				});
			};
		}
	})
})(POI, Zepto);