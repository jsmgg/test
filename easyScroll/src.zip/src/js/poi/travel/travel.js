/**
 * 景点公共部分相关
 */
;
(function(POI, $) {
  'use strict';
  $.extend(POI, {
    groupData : '',
    discountData : '',
    couponData : '',
    init: function() {
      var self = this;
      self.fConcatName();
    },
    fConcatName : function(){
      var self = this,
        deep = self.aosData.deep[0];
      var season = '';
      if (deep.season && deep.season.length) {
        if("[object Array]" === Object.prototype.toString.call(deep.season)) {
          if (deep.season.length === 12) {
            season = '全年';
          }
          else {
            season = deep.season.join('月,') + '月';
          }
          season = '最佳旅游时节:' + season;
        }
      }
      var price = (POI.aosData.deep[0].price + '' || "").replace(".00", "") | 0;
      price = price ? '门票<span class="min_money">¥' + price +'</span>起': "";

      var tags = '';

      if (POI.aosData.base.std_t_tag_0_v) {
          var arr = POI.aosData.base.std_t_tag_0_v.split(';');
          for (var i=0; i<arr.length; i++) {
              tags += self.index.moduleHeadItem(arr[i]);
          }
      }

      self.index.moduleDeepHead(tags, price);

      var html = this.recSports(deep)

      html += this.travelsAndQA(deep)

      var guideInfo = this.tplIntroGuide(this.aosData.rti.tourism_line);
      
      var allAry = self.index.moduleAll(['alipayDiscount', 'sendComment', html, 'guidePicList', 'rti', 'stopStrategy', 'shoppingGuide', 'activityInfo', 'commentInfo', this.convenienceIndex(deep), guideInfo, this.shenmaSerach(), 'indoorMap', 'banner', 'placeContribution']);

      this.pagebody.html(allAry.join(''));
      self.util.executeAfterDomInsert();

      $('.scenic-convenienceindex-header-item canvas').each(function(i, canvas) {
        var $canvas = $(canvas)

        if (i == 0) {
          $canvas.parent().addClass('active')	
        }

        new POI.util.DrawPie(canvas, {
          score: $canvas.data('score'),
          name: $canvas.data('name')
        })		
      });

    },
    recSports: function(deep) {
      var tpl = ''

      if (deep.rec_sports && deep.rec_sports.length) {
        var itemMaxWidth = (window.innerWidth - 50) / 3;
        var itemMaxHeight = itemMaxWidth * 2 /3;
        var rti = POI.aosData.rti;
        var vGuideFlag = false;
        if(rti.scenic_guide && "1" == rti.scenic_guide.is_txt_tts) {
            vGuideFlag = true;
        }
        var rec_sports = 3 < deep.rec_sports.length ? deep.rec_sports.slice(0, 3) : deep.rec_sports;
        var mustVisitCoverList = rec_sports.map(function(item) {
        var itemTpl = '';

          if (item.name && item.pic) {
            itemTpl = "\
            <li style='width: " + itemMaxWidth + "px;max-width:" + itemMaxWidth + "px'>\
            <div class='img3' style='width:" + itemMaxWidth + "px;height:" + itemMaxHeight + "px;background-image:url(\"" + POI.util.imageUrlTransform(item.pic, itemMaxWidth, itemMaxHeight) + "\")'></div>" + item.name +
              "</li>";
          }

          return itemTpl;
        }).join('');

        if(mustVisitCoverList) {
            tpl = '\
            <section class="scenic-card">\
            <h2 class="module_title_p line-half">必游景点</h2>\
            <ul class="scenic-mustvisit-cover line-half">'
            + mustVisitCoverList +
              '</ul>' +
              (vGuideFlag ? '<div class="scenic-voicelink" js_handle="js_openVoiceGuide">语音导游带你玩儿</div>' : '') +
              '</section>';
        }
      }	

      return tpl;
    },
    js_clickTravelNotes: function($ele) {
      if($ele.hasClass('active')) {
        return;
      }
      POI.api.userAction("switchTravelNotes");
      $ele.addClass('active').siblings().removeClass('active')

      $('.scenic-travelnote-list').show()
      $('.scenic-travelqa-list').hide().next().html('更多游记').data('appurl', POI.aosData.deep[0].travels_info.travel_notes_url)
    },
    js_clickTravelQA: function($ele) {
      if($ele.hasClass('active')) {
        return;
      }
      POI.api.userAction("switchTravelQA");
      $ele.addClass('active').siblings().removeClass('active')

      $('.scenic-travelnote-list').hide()
      $('.scenic-travelqa-list').show().next().html('更多问答').data('appurl', POI.aosData.deep[0].travels_info.travel_qa_url)
    },
    travelsAndQA: function(deep) {
      var tpl = ''

      if (deep.travels_info && this.util.bool(deep.travels_info.travel_qa) && this.util.bool(deep.travels_info.travel_notes)) {
        var $tpl = $("\
                     <section id='notesAndQa' class='scenic-card'>\
                     <h2 class='scenic-card-title flexbox line-half'>\
                     <div class='flexbox-child scenic-travelslink active' js_handle='js_clickTravelNotes'>游记</div>\
                     <div class='flexbox-child scenic-travelslink' js_handle='js_clickTravelQA'>问答</div>\
                     </h2>\
                     <ul class='scenic-travelnote-list'>\
                     </ul>\
                     <ul class='scenic-travelqa-list' style='display: none'>\
                     </ul>\
                     <div class='scenic-card-footer' js_handle='js_openTravelLinkMore' data-appurl='" + deep.travels_info.travel_notes_url + "'>更多游记</div>\
                     </section>")
                     var travelsInfo = deep.travels_info
                     if(3 < (travelsInfo.travel_notes.length | 0)) {
                        travelsInfo.travel_notes = travelsInfo.travel_notes.slice(0, 3);
                     }

                     // 游记列表模板拼接
                     var travelNotes = travelsInfo.travel_notes.map(function(item) {
                       var itemTpl = ''

                       if (item.travels_name && item.appurl) {
                         itemTpl = "<li data-appurl='" + item.appurl + "' js_handle='js_openTravelLinkNote'>" +
                                   "<h3>" + item.travels_name + "</h3>" +
                                   "<div>" +
                                   "<span class='scenic-travelnote-publishtime'>" + (item.time ? "发表于" + item.time : "&nbsp;") + "</span>" +
                                   "<span class='scenic-travelnote-pageview'>" + (item.views_num ? "<em>" + item.views_num + "</em>浏览" : "&nbsp;") + "</span>" +
                                   "</div>" +
                                   "</li>";
                       }

                       return itemTpl;
                     }).join('');

                     $tpl.find('.scenic-travelnote-list').html(travelNotes);

                     // 问答列表内容
                     if(3 < (travelsInfo.travel_qa.length | 0)) {
                        travelsInfo.travel_qa = travelsInfo.travel_qa.slice(0, 3);
                     }
                     var travelQA = travelsInfo.travel_qa.map(function(item) {
                       var itemTpl = '';

                       if (item.question) {
                         itemTpl = "\
                         <li data-appurl='" + item.appurl + "' js_handle='js_openTravelLinkQA'>\
                         <div>"
                         + item.question + 
                           "</div>" +
                           (item.answer ? "<span>已回答</span>" : "<span>&nbsp;</span>") +
                           "</li>";
                       }

                       return itemTpl
                     }).join('')

                     $tpl.find('.scenic-travelqa-list').html(travelQA)
                     tpl = $tpl.attr('outerHTML')
      }

      return tpl
    },
    js_openTravelLinkMore: function($ele) {
      if ($ele.data('appurl')) {
        if("更多游记" == $ele.text()) {
            this.api.userAction("openTravelLinkNoteMore");
        } else {
            this.api.userAction("openTravelLinkQAMore");
        }
        this.api.getAppPara('', '', $ele.data('appurl'));
      } 
    },
    js_openTravelLinkNote: function($ele) {
      if ($ele.data('appurl')) {
        this.api.userAction("openTravelLinkNote");
        this.api.getAppPara('', '', $ele.data('appurl'));
      } 
    },
    js_openTravelLinkQA: function($ele) {
      if ($ele.data('appurl')) {
        this.api.userAction("openTravelLinkQA");
        this.api.getAppPara('', '', $ele.data('appurl'));
      } 
    },
    tplIntroGuide: function(list) {
      if (list && list.travel_list) {
        list = list.travel_list;
      }
      if (!list || !list.length) {
        return '';
      }

      var isNewCity = '';
      var html = '';
      var len = list.length;
      for (var i = 0; i < len; i++) {
        if (list[i].info_wapurl) {
          isNewCity = 1;
        }
        html += '<li class="canTouch' + (i > 0 ? ' none"' : '"') +
          ' js_handle="js_openGuide" data-id="' + list[i].id +
          '" data-url="' + (list[i].info_wapurl || '') + '">' +
          '<div class="head-info">' +
          '<img src="' + list[i].pic_url + '" alt="">' +
          '<div class="name-info">' +
          '<h3>' + list[i].travels_name + '</h3>' +
          '<p>' + list[i].days + '日游</p>' +
          '</div>' +
          '<p class="intro-text linesDot">' + (list[i].preface || '') + '</p>' +
          '</div>' +
          '</li>';
      }
      html = '<section class="intro-guide">' +
        '<h2 js_handle="js_openGuideList" data-isnew="' + isNewCity +
        '" class="module_title_p line-half more">推荐路线</h2>' +
        '<ul class="list-guide-2">' + html + '</ul>' +
        (len > 1 ? '<div js_handle="js_toggleAllGuide" class="toggleAll more-bottom-blue">查看全部</div>' : '') +
        '</section>';
      POI.api.userAction("scenicGuideShow");
      if(len > 1) {
        POI.api.userAction("scenicGuideMoreShow");
      }
      return html;
    },
    // 打开路线列表
    js_openGuideList: function($elem) {
      var url = 'travel/' + ($elem.attr('data-isnew') ? 'list_guide_2.html' : 'list_guide.html');
      this.travelSchemaRedirect(url, {
        source   : '1',
        adcode   : this.aosData.base.city_adcode,
        shortName: this.aosData.base.city_name.replace(/市$/, ''),
        batches  : '1'
      });
      this.api.userAction('openGuideList');
    },
    // 打开路线详情
    js_openGuide: function($elem) {
      var wapurl = $elem.attr('data-url');
      if (wapurl) {
        this.api.getAppPara('', '', wapurl);
      }
      else {
        localStorage.setItem('page_guide_id', $elem.attr('data-id'));
        if(POI.browser.ios) {
            this.travelSchemaRedirect('travel/guide.html', {
                source   : '1',
                adcode   : this.aosData.base.city_adcode,
                shortName: this.aosData.base.city_name.replace(/市$/, ''),
                batches  : '1'
              });
        } else {
            this.travelSchemaRedirect('travel/guide.html');
        }
      }
      this.api.userAction('openGuide', {guideId: $elem.attr('data-id')});
    },
    travelSchemaRedirect: function(page, param) {
      var url = (POI.browser.ios ? 'ios' : 'android') + 'amap://openFeature?' +
      'featureName=spotGuid' + (POI.browser.ios ? '' : 'e') +
        '&sa=1&sourceApplication=amap&url=' +
        encodeURIComponent(page) + '&urlType=1&contentType=autonavi';
      
      if(POI.browser.ios) {
        url = 'amapuri://spotGuide/main?url=' + encodeURIComponent(page) + '&urlType=1';
      }
      if (param) {
        url += '&key=getSelectedCity&webData=' + encodeURIComponent(
          JSON.stringify(param));
      }
      this.api.loadSchema(url);
    },
    parseGeometry: function(str) {
      var arr = str.split(',')	

      return {
        lon: arr[0],
        lat: arr[1]
      }
    },
    parseIndexTrans: function(data) {
      var self = this
      var obj = {}	

      // 公交站
      if (data.bus && data.bus.length) {
        obj['公交站'] = data.bus.map(function(item) {
          return item.name	
        })
      }
      obj['__公交站'] = data.num_bus

      // 地铁站
      if (data.subway && data.subway.length) {
        obj['地铁站'] = data.subway.map(function(item) {
          return item.name	
        })	
      }
      obj['__地铁站'] = data.num_subway

      if (data.station) {
        obj['火车站'] = [data.station.name]	

        if (/([\d.]+),([\d.]+)/.test(data.station.geometry)) {
          var distance = POI.util.getDistance({lat: POI.clientData.poiInfo.lat, lon: POI.clientData.poiInfo.lon}, {lon: RegExp.$1, lat: RegExp.$2})
          distance = Number(distance / 1000).toFixed(2)
          obj['火车站'].push( distance + '公里')	
        }	
      }

      if (data.airport) {
        obj['飞机场'] = [data.airport.name]	

        if (/([\d.]+),([\d.]+)/.test(data.airport.geometry)) {
          var distance = POI.util.getDistance({lat: POI.clientData.poiInfo.lat, lon: POI.clientData.poiInfo.lon}, {lon: RegExp.$1, lat: RegExp.$2})
          distance = Number(distance / 1000).toFixed(2)
          obj['飞机场'].push( distance + '公里')	
        }	
      }

      return obj
    },
    parseIndexDining: function(data) {
      var obj = {}
      var list = data.dining_detail	|| []

      list.forEach(function(item) {
        if (obj[item.dining_type] === undefined) {
          obj[item.dining_type] = [item.name]
          obj["__" + item.dining_type] = item.num
        } else {
          obj[item.dining_type].push(item.name)	
        }
      })

      return obj
    },
    // 酒店数据和CMS规格不符，规格是poiname，实际返回的是 name，暂且兼容
    parseIndexHotel: function(data) {
      var obj = {}	

      var list = data.index_hotel_detail || []

      list.forEach(function(item) {
        if (obj[item.hotel_type] === undefined) {
          obj[item.hotel_type] = [item.poiname || item.name]
          obj["__" + item.hotel_type] = item.num
        } else {
          obj[item.hotel_type].push(item.poiname || item.name)	
        }
      })

      return obj
    },
    parseIndexEmergency: function(data) {
      var obj = {}		
      var list = data.index_emer_detail || []

      list.forEach(function(item) {
        if (obj[item.emer_type] === undefined) {
          obj[item.emer_type] = [item.name]
          obj["__" + item.emer_type] = item.num
        }	else {
          obj[item.emer_type].push(item.name)	
        }
      })

      return obj
    },
    convenienceIndex: function(deep) {
      var tpl = '';
      var self = this;
      
      var indexArr = [{name: '出行', unit: '个', key: 'Trans', data: deep.index_trans}, {name: '美食', unit: '家', key: 'Dining', data: deep.index_dining}, {name: '酒店', unit: '家', key: 'Hotel', data: deep.index_hotel}, {name: '应急', unit: '个', key: 'Emergency', data: deep.index_emergency}].filter(function(item) {
        if (item.data && Object.keys(item.data).length) {
          return true;
        }
      }).map(function(item) {
        return $.extend(item, {
          // 只取小数点后两位
          score: Number(item.data.score).toFixed(1),
          data: self['parseIndex' + item.key](item.data)
        });
      });

      if (indexArr.length) {
        tpl = "<section class='scenic-convenienceindex' id='scenic_around'>"
        + 
          (self.convenienceIndexHeader(indexArr) + self.convenienceIndexBody(indexArr))	
        +
          "</section>";
        POI.api.userAction("travelEasyShow");
        //设置导航栏
        POI.headerToolBar.scenicaround_flag = true;
        POI.headerToolBar.poiScenicToolBar({class_name:'scenic_around', title: '周边'});
      }

      if (!POI.headerToolBar.scenicaround_flag) {
        POI.headerToolBar.scenicaround_flag = true;
      }

      return tpl;
    },
    convenienceIndexHeader: function(data) {
      var tpl = '';

      if (data.length === 1) {
        tpl = '<h2>便利指数 - <span>' + (data[0].name + ' ' + data[0].score) + '</span></h2>';	
      } else {
        var headerList = data.map(function(item) {
          return '<li class="scenic-convenienceindex-header-item" data-key="' + item.key + '" js_handle="js_switchConvenience">\
          <canvas data-score="' + item.score + '" data-name="' + item.name + '" width="66" height="66" data-key="' + item.key + '"></canvas>\
          ';
        }).join('');

        tpl = '<h2>便利指数</h2>\
        <ul class="scenic-convenienceindex-header">' + headerList + '</ul>';
      }		

      return tpl;
    },
    js_switchConvenience: function($ele) {
      $ele.addClass('active').siblings().removeClass('active');	
      $('.scenic-convenienceindex_' + $ele.data('key')).addClass('active').siblings().removeClass('active');

      var poiid = POI.aosData.base.poiid;
      POI.api.userAction('travelEasyType', {type_poiid: $ele.data('key')+'_'+poiid});

    },
    js_searchCategory: function($ele) {
      var base = POI.aosData.base

      this.send({
        action: 'searchCategory',
        category: $ele.data('category'),
        poiInfo: POI.clientData.poiInfo
      });
      POI.api.userAction('travelEasyTypeList', {name:$ele.data('category')});
    },
    generateIndexContent: function(index, item) {
      var self = this
      if(0 === item.indexOf("__")) {
        return '';
      }
      if (['火车站', '飞机场'].indexOf(item) != -1) {
        return	"\
        <div class='lineDot'>\
        <h3>" + item + "</h3><span class='trans-ext'>" + index.data[item].join('</span> <span class="trans-ext">') + "</span>\
        </div>\
        "	
      } else {
        return	"\
        <div>\
        <h3>" + (index.data["__" + item] + index.unit + self.adaptIndexSearchWord(self.adaptIndexDisplayWord(item))) + "</h3><span>" + index.data[item].slice(0, 3).join('</span> <span>') + "</span>\
        </div>\
        "	
      }
    },
    adaptIndexDisplayWord: function(item) {
      if (['快餐', '中餐'].indexOf(item) > -1) {
        item += '厅';
      } 

      return item;
    },
    adaptIndexSearchWord: function(item) {
      if (item === '医疗') {
        item = '医院';
      } 

      return item;
    },
    convenienceIndexBody: function(data) {
      var self = this;
      var body = data.map(function(index, i) { 
        var list = Object.keys(index.data).map(function(item) { return self.generateIndexContent(index, item).length  > 0?"\
          <li class='scenic-convenienceindex-item' data-category='" + self.adaptIndexSearchWord(item) + "' js_handle='js_searchCategory'>"
          + self.generateIndexContent(index, item) + 
          "</li>":'';
        }).join('');

        return "<ul class='scenic-convenienceindex_" + index.key + (i === 0 ? ' active' : '') + "'>" + list + '</ul>' 
      }).join('');

      return '<div class="scenic-convenienceindex-list">' + body + '</div>';
    },
    js_toggleAllGuide: function($elem) {
      var $list = $('.list-guide-2 > li');
      $elem.toggleClass('up');
      if ($elem.hasClass('up')) {
        $elem.text('收起');
      }
      else {
        $elem.text('查看全部');
      }
      $list.toggle();
      $list.eq(0).show();
      this.api.userAction('toggleScenicGuideList',
                          {act: $elem.hasClass('up') ? 'unfold' : 'fold'});
    },
    //神马搜索模块
    shenmaSerach: function() {
      var that = this;

      var params = [
        {'keywords': POI.aosData.base.name, 'sign': 1}
      ];

      POI.util.executeAfterDomInsert(function() {
        POI.api.aosrequest('travelShenmaSearch', params, function(data) {
          var html;
          data.word_list = data.word_list || [];

          if (data.code == 1 && data.word_list.length > 0) {
            html = that.makeShenmaSearchHtml(data);
            
            $('#travelShenmaSearch').replaceWith(html);
          }
        });
      });

      return '<div id="travelShenmaSearch"></div>';
    },
    makeShenmaSearchHtml: function(data) {
      var that = this;
      var handleAttr = POI.handleAttr;
      var arr = data.word_list;
      var li_arr = [];
      var pre_section = '<section class="shenma_search">'+
                        '<h2 class="module_title_p line-half">浏览此地点的人还想知道</h2>'+
                        '<ul class="shenma_list">';
      var last_section = '</ul></section>';

      for (var i=0; i<arr.length; i++) {
        var li_str = '<li data-url="'+arr[i].search_url+'" '+handleAttr+'="js_goToShenmaSearch"><span>'+arr[i].word+'</span></li>';
        li_arr.push(li_str);
      }

      return pre_section+li_arr.join('')+last_section;
    },
    js_goToShenmaSearch: function(ele, e) {
      var url = ele.data('url');

      POI.api.openThirdUrl(url);
      POI.api.userAction('travelPageShenmaSerach', {url: url});
    }
  });
})(POI, Zepto);
