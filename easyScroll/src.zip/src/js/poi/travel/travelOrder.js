/**
 * 景点本地下单页面
 */
(function(POI, $) {
	'use strict';
	$.extend(POI, {
		logPageId : 'exTravelOrder',//为埋点category用
		dTicketDate : '',//日期控件返回的日期
		oAllOrderArg : null, // 存储poi详情页传过来的数据
		quickInit: function() {
			var self = this,
				oAllOrderArg = JSON.parse(self.util.getUrlParam('oAllOrderArg'));
			self.oAllOrderArg = oAllOrderArg;
			self.requestTicketDetailData(oAllOrderArg.ticketID, oAllOrderArg.srcType);
			self.freshRoomData();
		},
		/*请求订票须知的接口*/
		requestTicketDetailData: function(ticketid, srctype) {
			var that = this;
			if (!ticketid || !srctype) {
				return;
			}
			var Params = [{
				poiid: that.oAllOrderArg.poiInfo.poiid,
				sign: 1
			}, {
				ticketid: ticketid,
				sign: 1
			}, {
				src_type: srctype,
				sign: 1
			}, {
				is_calendar: 1,
				sign: 0
			}, {
				mode: 0,
				sign: 0
			}];
			POI.api.aosrequest("scenicSendTickets", Params, function(arg) {
				try {
					that.responseTicketDetailData(arg);
				} catch (e) {
					// alert(e.stack)
				}
			}, 1, true, "GET");
		},
		responseTicketDetailData: function(arg) {
			var that = this;
			if (arg.code != 1 || !arg.ticket_info) return;
			var ticketInfo = arg.ticket_info,
				visitDate = ticketInfo.visit_calendar,
				ticketNotice = ticketInfo.notice;
			$('#travelBookTitle>aside').html((ticketInfo.name ? '<h3>' + ticketInfo.name + '</h3>' : '') + (ticketInfo.src_name ? '<span>由' + ticketInfo.src_name + '提供</span>' : ''));
			$('#travelBookTitle>div').html((ticketInfo.current_price ? '<cite>单价:&nbsp;</cite><code>￥' + ticketInfo.current_price + '</code>' : ''));

			var _visitDate = visitDate[0];
			_visitDate && $('#travelBookDate>article>cite').html(_visitDate.date + '&nbsp;&nbsp' + _visitDate.date_desc);
			POI.dTicketDate = _visitDate.date;
			//进入日历控件
			var timestamp = arg.timestamp;
			$('#travelBookDate>article').eq(0).unbind('click').bind('click', function() {
				var paraCalendar = {
					type: "scenic",
					title: "游玩日历",
					today: (arg.timestamp) * 1000,
					selected: _visitDate.date,
					visitList: visitDate
				};
				POI.api.openCalendar(paraCalendar);
			})

			function limitcount() {
				if (!ticketInfo.min || !ticketInfo.max) {
					return;
				}
				if (ticketInfo.min == 1 && ticketInfo.max == 1) {
					return '购买数量(限购1张)';
				} else {
					return '购买数量(' + ticketInfo.min + '-' + ticketInfo.max + ')';
				}
			}
			$('#travelBookDate>article:last-child>span').html(limitcount());
			$('#count').html(Number(ticketInfo.min));
			if (ticketInfo.usecard == 1) {
				//需要填写身份证信息
				$('#personid').show();
			}

			//订票须知
			var advanceDay = '';
			if (ticketInfo.advance_day == 0) {
				advanceDay = '当天';
			} else if (ticketInfo.advance_day) {
				advanceDay = '前' + ticketInfo.advance_day + '天';
			}
			$('#tipTime').html(advanceDay + (ticketInfo.latest_time ? '的' + ticketInfo.latest_time + '前' : ''));
			if (ticketInfo.remarks) {
				$('#tipMarks').html('补充说明：' + ticketInfo.remarks).show();
			}
			var notice = [];
			for (var i = 0, len = ticketNotice.length; i < len; i++) {
				notice.push('<p class="tiptit">' + ticketNotice[i].ntypename || '' + '</p>');
				var _ninfo = ticketNotice[i].ninfo;

				var new_info = that.collectDifferentSourceData(_ninfo);
				for (var j = 0, lenj = new_info.length; j < lenj; j++) {
					notice.push('<p class="tiptit">' + new_info[j].nname + '</p>' + '<p class="tip">' + new_info[j].ncontent + '</p>');
				}
			}
			$('#tip_div').html(notice.join(''));
			//支付类型及价格
			if (ticketInfo.pmode == 0) {
				$('#travelBookSubmit>h3').html('现场支付');
				$('#travelBookSubmit>span').html(ticketInfo.current_price);
				$('#travelBookSubmit>kbd').html('￥' + ticketInfo.original_price);
				$('#travelBookSubmit').show();
			}

			//点击购买数量的加、减
			$("#count_div").off('click').on("click", "i", function() {
				var $this = $(this),
					eid = $this.attr("id");
				if ("reduce" !== eid && "increase" !== eid) return;
				if ($this.hasClass("active")) {
					var $count = $("#count"),
						_c = parseInt($count.html(), 10) + ("reduce" === eid ? -1 : 1);
					$count.html(_c);
					if (Number(ticketInfo.min) === _c) {
						$("#reduce").removeClass("active canTouch");
					} else if (Number(ticketInfo.max) === _c) {
						$("#increase").removeClass("active canTouch");
					} else {
						$("#reduce").addClass("active canTouch");
						$("#increase").addClass("active canTouch");
					}
				}
				if (ticketInfo.realname == 1) {
					//支持实名制
					if ("reduce" === eid && _c >= 1) {
						//减少
						var reducelen = $('#travelBookOthers>.travleInfo').length;
						$('#travelBookOthers>.travleInfo').eq(reducelen - 1).remove();
						if (_c == 1) {
							$('#travelBookOthers').hide();
						}
					} else if ("increase" === eid && _c <= Number(ticketInfo.max)) {
						//增加
						var $input = $('.travleInfo').eq(0).find('input');
						if (!$input.attr('class')) {
							$input.eq(0).attr('class', 'travelName');
							$input.eq(1).attr('class', 'travelPhone');
						}
						$('#travelBookOthers').append($('.travleInfo').eq(0).clone());
						$input.removeAttr('class');
						$('#travelBookOthers>.travleInfo').show().parent().show();
					}
				} else {
					$('#travelBookOthers').hide();
				}
				//计算总价
				var priceSum = Number(ticketInfo.current_price) * Number($('#count').text());
				$('#travelBookSubmit>span').html(priceSum);
			});
			//调用客户端的提示信息接口
			function showMsg(msg) {
					POI.send({
						action: 'promptMessage',
						message: msg,
						type: 0
					});
				}
				//将用户信息存下来，为支付结果页面发送请求提供参数
			function getTicketStatue() {
					var oAllOrderStatusArg = {
						ticketID: ticketInfo.ticketid,
						srcType: ticketInfo.src_type,
						amount: $('#count').text(),
						ticketDate: POI.dTicketDate

					};
					var oBookArg = {
						name: $('#travelBookMan .travelName').val(),
						mobile: $('#travelBookMan .travelPhone').val(),
						id_card: $('#personid>input').val() || ''
					}
					oAllOrderStatusArg.oBookArg = JSON.stringify(oBookArg);
					var partnerStack = {};
					//实名制情况下游客的信息
					if (ticketInfo.realname == 1 && $('#count').text() > 1) {
						//说明有游客信息
						var partners = [],
							$g_name = $('#travelBookOthers .travelName'),
							$g_mobile = $('#travelBookOthers .travelPhone');
						for (var z = 0; z < len; z++) {
							var part = {};
							part.name = $g_name.eq(z).val();
							part.mobile = $g_mobile.eq(z).val();
							if (part.name && part.mobile) {
								partners.push(part);
							}
						}
						partnerStack.others = partners;
					}
					// alert('partnerStack'+JSON.stringify(partnerStack)+'oAllOrderStatusArg'+JSON.stringify(oAllOrderStatusArg));
					oAllOrderStatusArg.oPartnerArg = Object.keys(partnerStack).length > 0 ? JSON.stringify(partnerStack) : '';
					oAllOrderStatusArg.poiInfo = POI.oAllOrderArg.poiInfo;
					var exTravelStatusUrl = encodeURI('exTravelOrderStatus.html?oAllOrderStatusArg='+JSON.stringify(oAllOrderStatusArg));
					POI.util.locationRedirect(exTravelStatusUrl);
					// location.href = 'exTravelOrderStatus.html?oAllOrderStatusArg=' + JSON.stringify(oAllOrderStatusArg);

				}
				//校验信息
			var usecardSign = 0;

			function isdone(obj, index) {
				var val = obj.val();
				switch (index) {
					case 0:
						if (!$('#count').text() || $('#count').text() > ticketInfo.max) {
							showMsg('购票数量不符合要求');
							return false;
						}
						break;
					case 1:
						if (!val || val.length > 20 || !/^[a-zA-Z\u4e00-\u9fa5]+$/.test(val)) {
							showMsg('姓名填写有误');
							return false;
						}
						break;
					case 2:
						if (ticketInfo.usecard == 1 && usecardSign == 1) {
							if (!val || val.length !== 18 || !/^[a-zA-Z0-9]+$/.test(val)) {
								showMsg('身份证号填写有误');
								return false;
							}
							usecardSign = 0;
							break;
						}
					case 3:
						if (val.length !== 11 || !val || !/^\d+$/.test(val)) {
							showMsg('手机号填写有误');
							return false;
						}
						break;
				}
				return true;

			}

			$('#subcribe').unbind('click').bind('click', function() {
				POI.api.userAction("getScenicSubcribe");

				var inputStack = [];
				//修改验证顺序
				inputStack.push($('#count'), $('#travelBookMan .travelName')); //购买数量,取票人名字
				if (ticketInfo.usecard == 1) {
					//身份证号
					inputStack.push($('#personid input'));
					usecardSign = 1;
				}
				inputStack.push($('#travelBookMan .travelPhone')); //取票人电话号码

				//校验购买数量和取票人信息
				for (var i = 0; i < inputStack.length; i++) {
					if (isdone(inputStack[i], i) == false) {
						return;
					}
				}
				//校验游客信息
				if (ticketInfo.realname == 1) {
					var realInfo = $('#travelBookOthers>.travleInfo'),
						lenr = realInfo.length;
					for (var t = 0; t < lenr; t++) {
						var _input = realInfo.eq(t).find('input');
						for (var j = 0; j < _input.length; j++) {
							if (isdone(_input.eq(j), j + 1) == false) {
								return;
							}
						}
					}
				}

				//为请求接口准备参数
				getTicketStatue();
			})
			$('#exTravelOrder>section').not('.travleInfo,#travelBookOthers').show();
		},
		// 日期控件主动回调
		freshRoomData: function(obj) {
			if (POI.bookRoom) {
				POI.bookRoom.updateDateRoom(obj);
			} else {
				POI.freshDate(JSON.parse(POI.util.storage('calendar')));  //明天验证一下
			}
		},
		freshDate: function(obj) {
			function changeDay(day) {
				var c_day = '';
				switch (day) {
					case 0:
						c_day = '日';
						break;
					case 1:
						c_day = '一';
						break;
					case 2:
						c_day = '二';
						break;
					case 3:
						c_day = '三';
						break;
					case 4:
						c_day = '四';
						break;
					case 5:
						c_day = '五';
						break;
					case 6:
						c_day = '六';
						break;
					default:
						break;
				}

				return '周' + c_day;
			}

			function prevDay(obj) {
				var today = new Date(),
					tyear = today.getFullYear(),
					tmonth = today.getMonth(),
					tdate = today.getDate();
				var t_start = new Date(tyear, tmonth, tdate).getTime(),
					time = 1000 * 60 * 60 * 24,
					m_start = t_start + time,
					h_start = m_start + time;
				if (m_start == obj.getTime()) {
					//明天
					return '明天';
				} else if (t_start == obj.getTime()) {
					//今天
					return '今天';
				} else if (h_start == obj.getTime()) {
					//后天
					return '后天';
				} else {
					return '';
				}
			}
			if (obj && obj.date) {
				var dateS = obj.date.split('-'),
					dateDesc = '',
					prevD = prevDay(new Date(dateS[0], dateS[1] - 1, dateS[2]));
				var day = new Date(obj.date).getDay();
				if (prevD) {
					dateDesc = prevD;
				} else {
					dateDesc = changeDay(day);
				}
				$('#travelBookDate>article>cite').html(obj.date + '&nbsp;&nbsp' + dateDesc);
				POI.dTicketDate=obj.date;
			}
		},
		/*同程携程数据融合*/
		collectDifferentSourceData: function(ninfo) {
			var newInfo = [];
			if (ninfo.length === 1) {
				newInfo = ninfo;
			} else {
				var referNames = [],
					referCons = [];
				referNames.push(ninfo[0].nname);
				referCons.push(ninfo[0].ncontent);
				var j = 1;
				while (j < ninfo.length) {
					var name = ninfo[j].nname;
					var con = ninfo[j].ncontent;
					var dif = false;
					var z = 0;
					var r_len = referNames.length;
					while (z < r_len) {
						if (name === referNames[z]) {
							referCons[z] += con;
							break;
						} else if (z === r_len - 1) {
							dif = true;
						}
						z++;
					}
					if (dif) {
						referNames.push(name);
						referCons.push(con);
					}
					j++;
				}
				var i = 0,
					nr_len = referNames.length;
				while (i < nr_len) {
					var newobj = {};
					newobj.nname = referNames[i];
					newobj.ncontent = referCons[i];
					newInfo.push(newobj);
					i++;
				}
			}

			return newInfo;
		}
	});
})(POI, Zepto);