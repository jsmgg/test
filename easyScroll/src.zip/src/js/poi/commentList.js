/*
 * 评论列表页
 */
;(function(POI, $){

    $.extend(POI, {
        commentList_pageNum :1,
        commentList_pageSize : 20,
        commentList_busy : false,
        // 771需求，初始为全部
        select_mode : '4',//4：数据取新表(全部)，1：带图，0：最新，2：差评 （3：数据默认顺序不处理）,5:771及以后的最新
        commentList_page : null,
        review_info_cache : [],
        commentListTags_count:[],//标签点击量,不重复
        commentlist_show : function(business,poiid) {
            var self = this;
            self.poiid = poiid;
            self.business = business;
            self.commentlist_rander();
            self.api.userAction( 'commentList', {poiid:self.poiid} );
            self.commentListTags_count = [];
        },
        commentlist_rander : function() {
            var self = this;
            self.get_data(function(dt){
                //生成头部tags a
                var head = self.tpl_head(dt);
                var tags = self.tpl_tags(dt);
                var html = self.get_arr();
                if (self.select_mode == '4') {
                    html.p(self.tpl_tags(dt));
                }
                var has =  dt.page_total > self.commentList_pageNum;
                html.p( '<article>' )
                    .p( '<ul class="my_list" id="js_my_list">' );
                if( dt.review_list && dt.review_list.length ) {
                    html.p( self.tpl_list( dt.review_list ) );
                } else {
                    html.p( '<li>暂无评论</li>' );
                }
                html.p( '</ul>' )
                    .p( '<div id="js_loadingBox" class="loadingBox">'+ ( has ? '' : self.tpl_source(dt.review_info && dt.review_info.length ? dt.review_info : self.review_info_cache, dt.review_list.length)) +'</div>' )
                    .p( '</article>' );
                self.review_info_cache = dt.review_info && dt.review_info.length ? dt.review_info : self.review_info_cache;
                html = '<section class="comment_list_page" id="js_comment_list" style="padding:0;">'+html.str+'</section>';
                if( self.commentList_page ){
                    $( '#js_comment_list' ).replaceWith( html );
                    $( '.default_header .comment_tabs').replaceWith( head );
                    $( '.default_header .comments_tags').replaceWith( tags );
                    self.api.userAction("displayTags");
                    self.commentList_page.refresh( 1 );
                    //!has && self.commentList_page.load_end();
                } else {
                    var hasRightBtn = '';
                    if(POI.jsMap[POI.business] && !/^(bus|subway|event)$/.test(POI.business)) {
                        hasRightBtn = '<em js_handle="js_right_btn">写评论</em>';
                    }
                    var headerStr = '<div class="default_header"><div class="top"><i js_handle="js_close_scrollPage"></i><h2>评论</h2>'+hasRightBtn+'</div>'+head+'</div>';
                    //headerStr += this.tpl_tags( dt );
                    self.commentList_page = self.scrollPage({
                        header : headerStr,
                        content : html
                    });
                    self.commentList_page.destroy( function(){
                        self.commentList_pageNum = 1;
                        self.select_mode = '4';//4：数据取新表(全部)，1：带图，0：最新，2：差评 （3：数据默认顺序不处理）
                        self.nameTag = null;
                        self.commentList_page = null;
                        self.commentList_dt_cache = {};
                        self.js_comment_page_show();
                        self.api.userAction("commentListTags_count" ,{count:self.commentListTags_count.length});
                    } );
                    //self.pagebody.append( '<div id="js_comment_delete_mask" class="commentList_delete_mask" ontouchmove="javascript:event.preventDefault();event.stopPropagation();"><div class="cont"><p>确认删除自己的评论吗</p><div class="btn_box"><div id="js_delete_comment" js_handle="js_delete_comment">删除</div><div js_handle="js_commentList_cnacel">取消</div></div></div></div>' );
                };
                if( has ){
                        self.commentList_page.load_more(function (box) {
                            self.commentList_load_more(box);
                        });
                } else {
                    self.commentList_page.load_end();
                }
                POI.util.lazyLoad(".displayImg");
            });
        },
        commentList_load_more : function() {
            var self = this;
            self.get_data(function( dt ){
                $( '#js_my_list' ).append( self.tpl_list( dt.review_list || []) );
                if( dt.page_total <= self.commentList_pageNum ) {
                    $( '#js_loadingBox' ).removeClass( 'loading' ).html( self.tpl_source(dt.review_info||[], dt.review_list.length) );
                    self.commentList_page.load_end();
                }
                self.commentList_page.refresh();
            });
        },
        commentList_dt_cache : {},
        get_data : function( handler ) {
            var self = this;
            if (self.commentList_busy)return;
            var params  = [
                {poiid: self.poiid, sign: 1},
                {pagenum: self.commentList_pageNum},
                {is_sellpoint: 1},
                {pagesize: self.commentList_pageSize},
                {select_mode: self.select_mode},
                {like_flag: 1}
            ];
            if (self.select_mode == 4) {
                if (self.nameTag != null) {
                    var tag = { tag : self.nameTag}
                    params.push(tag);
                }
        }
            if( self.commentUtil.getRefreshStatus( self.poiid ) ) {
                params.push({at_once_flag:1});
            }
            var key = JSON.stringify( params );
            if( self.commentList_dt_cache[ key] ) {
                handler.call(self, self.commentList_dt_cache[ key]);
                self.check_limits();
                self.commentList_pageNum += 1;
                return;
            }
            self.commentList_busy = true;
            self.busyTimeout = setTimeout(function() {
                self.commentList_busy = false;
            }, 1000);
            self.api.aosrequest('getCommentsUrl', params, function( dt ) {
                clearTimeout(self.busyTimeout);
                self.commentList_busy = false;
                if( dt.code != 1 ) return;
                self.commentList_dt_cache[ key ] = dt;
                handler.call(self, dt);
                self.check_limits();
                self.commentList_pageNum+=1;
            }, self.commentList_pageNum===1?1:0, 1,'get');
        },
        get_arr : function( str ){
            return {
                p : function( s ){
                    this.str +=s;
                    return this;
                },
                str : str === undefined ? '' : (str+'')
            }
        },
        tpl_head : function( dt ) {
            return '<ul class="comment_tabs divide-line"><li rel="4" js_handle="js_commentList_change"><span class="'+ ((this.select_mode == '4' && this.nameTag==null) ? 'on' : '') +'">全部</span></li><li class="flex"></li><li rel="1" js_handle="js_commentList_change"><span class="'+ (this.select_mode == '1' ? 'on' : '') +'">带图'+(dt.pic_count||'0')+'</span></li><li class="flex"></li><li rel="5" js_handle="js_commentList_change"><span class="'+ (this.select_mode == '5' ? 'on' : '') +'">最新'+(dt.total||'0')+'</span></li><li class="flex"></li><li rel="2" js_handle="js_commentList_change"><span class="'+ (this.select_mode == '2' ? 'on' : '') +'">差评'+(dt.bad_count||'0')+'</span></li></ul>';
        },
        tpl_tags : function ( dt ){
            var self = this;
            var num = this.nameTag;
            var htmlTags='<div class="comments_tags" style="'+ (self.select_mode == 4?'display:block;':'display:none;') +'">';
            for (var i=0;(i < dt.sellpoints.length) && (i < 9);i++)
            {
                var name = dt.sellpoints[i].name;
                var count= dt.sellpoints[i].count;
                var tagType = dt.sellpoints[i].type;
                var level = dt.sellpoints[i].level;
                var className=(num == name ? 'on' : '')+' '+(tagType== 1 ? ' activeTag': '') + (level== 3 ? ' badTag': '');
                htmlTags += '<button tag_name="' + name + '" class="'+ className + '"' + (tagType==1?' js_handle="js_chooseTags"':'') + (tagType == 1? 'rel="'+ dt.sellpoints[i].type +'"':'') + '>'+ name + '' + count +'</button>';
            }
            htmlTags+='</div>';
            return htmlTags;
        },
        cache_source : {},
        /**
         * 显示来源信息.
         * @param {Object} list 来源信息
         */
        tpl_source : function(list, reviewLength) {
            ////其他来源信息
            var html = '';
            var segment = '<p class="tpl_source"><span class="end_line"></span><span class="end_text">&nbsp;&nbsp;以上是高德为您精选评论&nbsp;&nbsp;</span><span class="end_line end_line_left"></span></p>';
            if (this.select_mode == 4 && reviewLength){
                html += segment;
                return html;
            }
            else {
                if (!list || !list.length) {
                    return '';
                }
                var isHotel = this.business === 'hotel';
                var isIOS = POI.browser.ios;
                var check = {};
                for (var i = 0, len = list.length; i < len; i++) {
                    var obj = list[i];
                    // 酒店行业不显示“大众点评”和“携程”的来源
                    if (isHotel && /ctrip_wireless|dianping/.test(obj.src_type)) {
                        continue;
                    }
                    var appurl = obj.review_all_appurl;
                    if (obj.review_all_wapurl || (isIOS && appurl.ios_appurl) ||
                        (!isIOS && appurl.android_appurl)) {
                        if( !check[obj.src_name] ) {
                            html += '<a data-index="' + i + '" js_handle="js_other_app">' + obj.src_name + '</a>';
                            check[obj.src_name] = 1;
                            this.cache_source[i] = obj;
                        }
                    }
                }
                if (html) {
                    return reviewLength ? segment + '<p><span>更多评论：</span>'+html+'</p>' : '<p><span>更多评论：</span>'+html+'</p>';
                }
                else return reviewLength ? segment : '';
            }
        },
        commentList_cache_pic : {},//图片缓存
        commentList_pic_key : 1,
        tpl_list : function( review_list ) {
            var self = this;
            return review_list.map(function( obj ) {
                var pic_info = (obj.pic_info || []).slice(0,6);
                var avatar = obj.author_profileurl || 'img/comment_default.png';
                var review_content=obj.review;
                var label_light = "";
                if (obj.labels != undefined && self.select_mode == "4") {
                    for (var i = 0; i < obj.labels.length; i++) {
                        if (obj.labels[i].label_content == self.nameTag) {
                            label_light = obj.labels[i].label_light;
                        }
                    }
                    var reg = new RegExp("(" + label_light.replace(/,/,"|") + ")","g");
                    review_content = review_content.replace(reg,'<span style="color:#f37327">'+label_light+'</span>');
                }
                //关键字高亮
                var html = self.get_arr( '<li id="js_check_'+obj.review_id+'"><div class="head">' )
                    .p( '<div class="img"><img src="'+ avatar +'"></div>' )
                    .p( '<p>' )
                    .p( '<span class="name">'+( obj.author || '高德用户') +'</span>' )
                    .p( obj.score && obj.score > 0 ? '<span class="star"><i style="width:'+((obj.score/5).toFixed(2)*100|0)+'%"></i></span>' : '' )
                    .p( obj.score && obj.score > 0 ? '<span class="score">'+(obj.score*1.0|0)+'分</span>' : '' )
                    .p( '</p>' )
                    .p( '</div>' )// end .head
                    .p( obj.review ? '<div class="comment_cont comment_cont_limits" js_handle="js_toggle_text">'+review_content+'</div>' : '')
                    .p( obj.review ? '<div class="comment_toggle" js_handle="js_toggle_text">查看全文</div>' : '')
                    .p( pic_info.length ? self[ 'tpl_pic']( pic_info, self.commentList_pic_key ) : '' );
                if(self.get_time( obj.time ) || obj.src_name || (obj.like_num && obj.like_num > 0) ) {
                    html.p( '<div class="time_resource">'+self.get_time( obj.time )+' <span>'+(obj.src_name ? '来自于' + obj.src_name : '')+'</span>' );
                    obj.like_num && obj.like_num > 0 && html.p( '<em><b>'+obj.like_num+'个</b>好友挺他</em>' );
                    html.p( '</div>' );
                }

                html.p( '</li>' );
                pic_info.length && (self.commentList_cache_pic[ self.commentList_pic_key ] = obj.pic_info);
                self.commentList_pic_key++;
                return html.str;
            }).join('')
        },
        get_time : function( time ) {
            // 时间
            if (time) {
                var timeRes = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(time);
                if (timeRes && timeRes.length === 4) {
                    return timeRes[1] + '年' + timeRes[2] + '月' + timeRes[3] + '日';
                }
            }
            return '';
        },
        imgTran : function( url, width, height ) {
            return this.util.imageUrlTransform(url, width, height) || '';
        },
        tpl_pic: function( pic_info , review_id ) {
            var array={};
            var imgWidth = document.body.clientWidth - 30;
            imgWidth = (imgWidth - 20 )/3 | 0 ;
            var imgHeight = imgWidth;
            var html='<div class="comment_imgs" id="img_two" js_handle="js_prev_img" data-id="'+review_id+'"><div>';
            if (pic_info.length<=3) {
                for (var i = 0, item = null; i < pic_info.length; i++) {
                    var ssrc = this.imgTran(pic_info[i].url, imgWidth, imgHeight).toString();
                    html += '<img style="width:' + imgWidth + 'px;height:' + imgHeight + 'px;"  ori-src="' + ssrc + '" class="displayImg"/>';
                }
                html += '</div></div>';
            }
            else if (pic_info.length == 4){
                for (var i = 0, item = null; i < 2; i++) {
                    var ssrc = this.imgTran(pic_info[i].url, imgWidth, imgHeight).toString();
                    html += '<img style="width:' + imgWidth + 'px;height:' + imgHeight + 'px;"  ori-src="' + ssrc + '" class="displayImg"/>';
                }
                html+='</div><div>';
                for (var i = 2, item = null; i < 4; i++) {
                    var ssrc = this.imgTran(pic_info[i].url, imgWidth, imgHeight).toString();
                    html += '<img style="width:' + imgWidth + 'px;height:' + imgHeight + 'px;"  ori-src="' + ssrc + '" class="displayImg" />';
                }
                html+='</div></div>';
            }
            else{
                for (var i = 0, item = null; i < 3; i++) {
                    var ssrc = this.imgTran(pic_info[i].url, imgWidth, imgHeight).toString();
                    html += '<img style="width:' + imgWidth + 'px;height:' + imgHeight + 'px;"  ori-src="' + ssrc + '" class="displayImg"/>';
                }
                html+='</div><div>';
                for (var i = 3, item = null; i < pic_info.length; i++) {
                    var ssrc = this.imgTran(pic_info[i].url, imgWidth, imgHeight).toString();
                    html += '<img style="width:' + imgWidth + 'px;height:' + imgHeight + 'px;"  ori-src="' + ssrc + '" class="displayImg" />';
                }
                html+='</div></div>';
            }
            POI.util.executeAfterDomInsert();
            return html;
        },
        check_timer : 0,
        check_limits : function() {
            clearTimeout( this.check_timer );
            this.check_timer = setTimeout( function() {
                $( 'div.comment_cont_limits' ).each(function() {
                    var obj = $( this );
                    var height = obj.height();
                    obj.removeClass( 'comment_cont_limits' );
                    if( obj.height() > height ) {
                        obj.addClass( 'comment_cont_limits' );
                        obj.parent().find( '.comment_toggle' ).show();
                    } else {
                        obj.removeAttr( 'js_handle' );
                    }
                });
            });
        },
        js_commentList_change : function( obj ) {
            var self = this;
            var commentTags = $(".scrollPage_content .comments_tags");
            var fig = obj.find( 'span.on' ).length;
            if( fig || self.commentList_busy ) return;
            //obj.parent().find( 'span.on' ).removeClass( 'on' );
            //obj.find( 'span' ).addClass( 'on' );
            self.commentList_pageNum =1;
            self.select_mode = obj.attr( 'rel' );
            self.nameTag = null;
            self.commentlist_rander();
            self.api.userAction( 'commentNav', {type:self.select_mode} );
        },
        //771需求，筛选不同的标签
        js_chooseTags : function( obj ) {
            var self = this;
            self.commentList_pageNum = 1;
            //$('.comments_tags').find('button').removeClass('on');
            //$('.comment_tabs ' ).find('span').removeClass('on');
            //$(obj).addClass('on');
            var type = $(obj).attr('rel');
            if ((type!='undefined') && type) {
                self.nameTag = $(obj).attr('tag_name');
            }
            self.commentlist_rander();
            //埋点
            self.api.userAction("chooseTags",{name:self.nameTag});
            if ( self.commentListTags_count.length < 1) {
                self.commentListTags_count.push(self.nameTag);
            }
            else {
                var has = false;
                for (var i=0;i< self.commentListTags_count.length;i++)
                {
                    if (self.commentListTags_count[i] == self.nameTag){
                        has = true;
                    }
                }
                if (!has){
                    self.commentListTags_count.push(self.nameTag);
                }
            }

        },
        js_toggle_text : function( obj ) {
            var p = obj.parent();
            var limits = p.find( '.comment_cont' ).eq(0);
            var toggle = p.find( '.comment_toggle' ).eq(0);
            if( limits.hasClass( 'comment_cont_limits' ) ) {
                limits.removeClass( 'comment_cont_limits' );
                toggle.text( '收起' );
            } else {
                limits.addClass( 'comment_cont_limits' );
                toggle.text( '查看全文' );
            }
            this.commentList_page.refresh();
            this.api.userAction( 'commentShowHide' );
        },
        js_prev_img : function( obj , e ) {
            var target = $( e.target );
            var list = this.commentList_cache_pic[ obj.attr( 'data-id' ) ];
            var module = 'list';
            var index = 0;
            if( e.target.tagName.toLocaleLowerCase() == 'img' ) {
                index = obj.find( 'img' ).index(target);
                module = 'single';
                POI.api.imagePreview(module, index, list);
                this.api.userAction( 'commentPrevImg' );
            }
        },
        js_right_btn : function() {
            var self = this;
            self.api.userAction( 'commentsListWrite' );
            POI.commentUtil.openNativeCommentEditor(0, this.business, "Detailall", function( dt ) {
                self.commentList_dt_cache = {};
                self.util.storage("COMMENT_CHANGE_ID", '1');
                self.commentList_pageNum = 1;
                self.commentlist_rander();
            }, POI.clientData.poiInfo);
        },
        js_other_app : function( obj ) {
            var self = this;
            var info = self.cache_source[ obj.attr('data-index') ];
            var wapurl = info.review_all_wapurl || '';
            self.api.getAppPara(info.review_all_appurl.ios_appurl || '',
                info.review_all_appurl.android_appurl || '', wapurl);
            self.api.userAction('cmtOrign_' + wapurl);

        }

    });

})(POI, Zepto);
