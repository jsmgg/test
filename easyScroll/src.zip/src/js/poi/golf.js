;(function(POI, $) {
$.extend(POI, {
    init : function() {
        var self = this, html = [],
            deep = self.aosData.deep[0]||{},
            course = deep.course,
            price = deep.price ? '人均:￥' + deep.price : '';
        self.index.moduleDeepHead(null, price);
        if( course ) {
            $.each( course , function( index , item ){
                html.push(self.get_buildCourse(index, item));
            });
            /*self.util.executeAfterDomInsert(function() {
                self.pagebody.find('article.js_golf_thumb').each(function() {
                    var data = self.golf_thumbcache[$(this).attr('index')];
                    data && self.util.picThumb({
                        'type':'golf',
                        'itemid': data.course_id,
                        'cont': $(this),
                        'pics':data.pic_info,
                        'count':data.pic_count,
                        'poiid':self.clientData.poiInfo.poiid
                    });
                });
            });*/
        }
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "club_facility"]),
            introAry = self.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'placeContribution']);
        self.pagebody.append(html.join('') + introAry.join(''));
        self.util.executeAfterDomInsert();
    },
    golf_thumbcache : {},
    get_buildCourse : function(index, data) {
        var self = this, html = ['<section id="golf' + (index || '') + '" class="golf_item">'],
            courseId = data.course_id, handleAttr = self.handleAttr, key = 'index'+index,
            dataItem = {
                'course_kind': '球场类型',
                'course_data': '球场数据'
            };
        self.golf_thumbcache[key] = data;
        html.push('<h2 class="more module_title_p line-half" ' + handleAttr + '="js_goGolfDetail" courseId="' + courseId + '"><a href="exGolf.html?index=' + index + '&poiid=' + self.clientData.poiInfo.poiid + '"><span>' + data.course_name + '</span><em>查看全部</em></a></h2>');
        //html.push('<article class="thumb js_golf_thumb" index="' + key + '"></article>');
        html.push( self.util.modulePicList( data.pic_info, data.pic_count , JSON.stringify({
            poiid : self.clientData.poiInfo.poiid,
            itemId : data.course_id,
            type:'golf'
        }) ) );
        $.each( dataItem , function(key, val) {
            if( data[key] ){
                html.push( '<article class="line1"><span>'+ val +'：</span>' + data[key] +'</article>');
            }
        });
        html.push(self.getBookButton(data.order_url , data.order_price));
        html.push('</section>');
        return html.join('');
    },
    js_goGolfDetail : function(obj) {
        this.api.userAction( 'golfDetail',{courseID : obj.attr('courseId')});
    },
    getBookButton:function(url, price ){
        var self = this, str = '' ,txt;//<article><button class="canTouch">球场预订</button></article>
        if( url &&  typeof price !== 'undefined' ){
            str = '<article class="golf_button_wrap">';
            if( price < 0 ){//显示已封场
                str += '<button style="opacity:0.4">已封场</button>'
            }else{
                txt = '球场预订' + ( price > 0 ? '（￥'+ price +'起）': '' );
                str += '<button class="canTouch" ' + self.handleAttr + '="js_golf_ordering" url="' + url + '">' + txt + '</button>'
            }
            str += '</article>';
        }
        return str;
    },
    js_golf_ordering : function( obj ) {
        var self = this, url = obj.attr('url');
        self.api.getAppPara( '','', url );
        self.api.userAction( 'golfBook',{'orderUrl':url});
    }
});

})(POI, Zepto)