/**
*	POI top10排行榜
**/
;(function(POI, $) {

$.extend(POI, {
    poiRank : {
        busy : false,
        rankList_page : null,
        show: function(id,x,y) {
            var that = this;
            if( that.busy ) return;
            that.busy = true;
            var params = [
                {
                    'rank_id': id,
                    'sign': 1
                },
                {
                    'user_loc': x+','+y
                }
            ];
            
            POI.api.aosrequest('poiRankList', params, function(data) {
                that.busy = false;
                if (data.code == 1 && data.rank_info.items.length > 0) {
                    that.makeRankHtml(data);
                }
            }, 1, true, "GET");
            POI.api.userAction('poiRankShow',{business:POI.business});
        },
        //价格格式化
        formatePrice: function(price) {
            var that = this;
            if (!price || price == null) {
                return '';
            } else if (Number(price) < 0) {
                return '';
            }
            var arr = price.split('.');
            var res = '';
            var title = '';
            if (arr[1]) {
                if (arr[1] == '0' || arr[1] == '00') {
                    if (arr[0] == '0' || arr[0] == '00') {
                        res = '';
                    } else {
                        res = arr[0];
                    }
                } else if (arr[1].lastIndexOf('0') == (arr[1].length-1)) {
                    var res1 = arr[1].substring(0,arr[1].length-1);
                    if (res1.lastIndexOf('0') == (res1.length-1)) {
                        res1 = res1.substring(0,res1.length-1);
                    }

                    res = arr[0]+'.'+res1;
                } else {
                    res = arr[0]+'.'+arr[1];
                }
            } else {
                if (price == '0' || price == '00') {
                    res = '';
                } else {
                    res = price;
                }               
            }
            if (POI.business == 'scenic') {
                title = '门票';
            } else if (POI.business == 'hotel' || POI.business == 'residential') {
                title = '';
            } else {
                title = '人均';
            }
            return res.length > 0?'<span class="per_capita">'+title+'<span class="consume">¥'+res+'</span></span>':'';
            
        },
        makeRankHtml: function(data) {
            var that = this;
            var title = data.rank_info.district+data.rank_info.poi_type+'排行榜';
            var list = data.rank_info.items;
            var html_arr = [];

            for (var i=0; i<list.length; i++) {
                var li_class = i == list.length - 1?'':'divide-line';
                var star_w = Math.floor((Number(list[i].star)/5)*100)+'%';
                var distance = that.poiRank_formatDistance(list[i].distance).length > 0?'<div class="base_info"><span class="distance">距您'+that.poiRank_formatDistance(list[i].distance)+'</span></div>':'';

                var price = that.formatePrice(list[i].price_u);

                var comment = list[i].review && list[i].review.length > 0?'<div class="rank_comment"><span>评论：</span>'+list[i].review+'</div>':'';
                var detail = list[i].poiid == POI.clientData.poiInfo.poiid?'':'<a href="javascript:void(0);" class="poi_info canTouch" data-poiid="'+list[i].poiid+'" data-name="'+list[i].name+'" data-x="'+list[i].x+'" data-y="'+list[i].y+'" js_handle="js_goToPoiDetail">详情</a>';

                var li_str = '<li class="'+li_class+'">'+
                             '<div class="title">'+
                             '<p>'+list[i].name+'</p>'+
                             detail+
                             '</div>'+
                             '<div>'+
                             '<span class="star">'+
                             '<span class="highlight" style="width:'+star_w+';"></span>'+
                             '</span>'+
                             price+
                             '</div>'+
                             distance+
                             that.makeImgHtml(list[i])+
                             comment+
                             '</li>';
                html_arr.push(li_str);
            }
            that.scroll_obj = POI.scrollPage({
                defaultHeader : title,
                content : '	<section class="poi_ranking"><ul id="ranking_list">'+html_arr.join('')+'</ul></section>'
            });
            that.scroll_obj.load_end();
            POI.util.lazyLoad(".rank_imgs");
        },
        scroll_obj : null,
        commentList_cache_pic : {},//图片缓存
        commentList_pic_key : 1,
        makeImgHtml: function(item) {
            if (item.pic.length < 1) {
                return '';
            }
            var that = this;
            var imgs = item.pic;
            var p_arr = [];
            var p_html = '';
            var pic_info = [];
            var img_width = (document.body.clientWidth - 50)/3 | 0;
            var img_height = img_width/(180/120) | 0;

            for (var i=0; i<imgs.length; i++) {
                if (i == 3) {
                    return;
                }
                var url = that.imgTransform(imgs[i], img_width, img_height);
                var p_str = '<p class="rank_imgs" ori-src="'+url+'" style="width:'+img_width+'px;height:'+img_height+'px;background-size:cover;"></p>';

                p_arr.push(p_str);
                pic_info.push({'url': url,'title':''});
            }

            //缓存图片列表
            that.commentList_cache_pic[that.commentList_pic_key] = pic_info;

            var pre_div = '<div class="imgs" js_handle="js_previewimg" data-id="'+that.commentList_pic_key+'">';
            var last_div = '</div>';

            if (imgs.length > 3) {
                p_html = p_arr.slice(0,3).join('');
            } else {
                p_html = p_arr.join('');
            }
            that.commentList_pic_key++;
            return pre_div+p_html+last_div;
        },
        imgTransform: function(url, width, height) {
            return POI.util.imageUrlTransform(url, width, height) || '';
        },
        poiRank_formatDistance: function(dis) {
            if (typeof dis != 'number') {
                dis = parseFloat(dis, 10);
            }
            if (isNaN(dis) || dis < 0) {
                return '';
            }
            if (dis < 1000) {
                return dis.toFixed(0) + '米';
            }
            dis /= 1000;
            return dis.toFixed(1) + '公里';
        }
    },
    js_previewimg: function(obj, e) {
        var that = this;
        var target = $( e.target );
        var p = target.find( 'p' ).eq(0);
        var list = that.poiRank.commentList_cache_pic[ obj.attr( 'data-id' ) ];
        var module = 'single';
        if( e.target.tagName.toLocaleLowerCase() == 'p' ) {
            p = target;
        }
        var index = obj.find('p').index(p);

        that.api.imagePreview(module, index, list);
        that.api.userAction( 'poiRankPrevImg' );
    },
    js_goToPoiDetail: function(ele) {
        var that = this;
        var name = ele.data('name');
        var poiid = ele.data('poiid');
        var lon = ele.data('x');
        var lat = ele.data('y');

        var status = '1';
        if (!poiid) {
            return;
        }
        that.poiRank.scroll_obj.destroy();
        POI.api.openPoiInfo(poiid, name, '', '', '', '', lon, lat, status);
        POI.api.userAction('poiRankList', {poiid_name:poiid+'_'+name});

    }
});

})(POI, Zepto);