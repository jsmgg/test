/*餐飲*/
;(function(POI, $) {

'use strict';

var user_loc = "",
    user_adcode = "";

$.extend(POI, {
    
    recommendMenu : function(deep, rti) {
        var menu_count = deep.menu_count,
            tag_special = deep.tag_special,
            cpr_info = rti.cpr_info || {};
        var imgRect = (document.body.clientWidth - 50) / 3;
        var recoStr = '';
        var menu_pic = deep.menu_pic;
        // TODO 图片少于3张时的显示逻辑
        if(menu_count > 2 && menu_pic && menu_pic.length > 2) {
            if(menu_pic && menu_pic.length) {
                var liStr = '';
                for(var i = 0, len = Math.min(menu_pic.length, 3); i < len; i++) {
                    liStr += '<li class="recodishes_item" ' + this.handleAttr + '="js_diningShowBigPicIndex" ori-src="' + (POI.util.imageUrlTransform(menu_pic[i].pic_cover, imgRect, parseInt(imgRect/1.5)) || '') + '">' +
                                 '<div class="recodishes_img" style="width:' + imgRect + 'px;height:' + parseInt(imgRect/1.5) + 'px;"></div>' +
                                 '<span class="recodishes_name">' + (menu_pic[i].name || '') + '</span>' +
                             '</li>';
                }
                
                recoStr = '<section>' +
                              '<h2 class="module_title_p line-half more" ' + this.handleAttr + '="js_diningShowBigPic">推荐菜&nbsp;<span class="small_text">(' + menu_count + ')</span></h2>' +
                              '<ul class="recodishes_wrapper">' + liStr + '</ul>' +
                          '</section>';
                POI.api.userAction("recodishesImageShow");
                POI.util.executeAfterDomInsert(function() {
                    var recodishes = $(".recodishes_wrapper li");
                    function successFun(elem, _img) {
                        var divImg = $(elem);
                        divImg.css({
                            'background' : 'url("' + _img.getAttribute("src") + '") no-repeat center',
                            'background-size' : 'cover'
                        });
                    }
                    function errorFun(elem) {}
                    for(var i = 0, len = recodishes.length, item = null; i < len; i++) {
                        item = $(recodishes[i]);
                        new POI.util.loadImage(item.attr("ori-src"), item.find(".recodishes_img")[0], successFun, errorFun);
                    }
                });
                
            } else {
                return '';
            }
        } else {
            if(tag_special) {
                recoStr = '<section id="recommendDish">' +
                              '<h2 class="module_title_p line-half">推荐菜</h2>' +
                              '<p class="recodishes_wrapper recodishes_noimg linesDot">' +
                                  '<span class="recodishes_name_only">' + tag_special.replace(/[,\|;； ]/g, '</span><span class="recodishes_name_only">') + '</span>' +
                              '</p>' +
                              '<a class="introFold"></a>' +
                          '</section>';
                POI.api.userAction("recodishesNameShow");
                POI.util.executeAfterDomInsert(function() {
                    new POI.util.toggleContent($('#recommendDish .introFold'),
                        $('#recommendDish > p'), {
                        switchClassName: 'linesDot',
                        eleContent: {
                            showAll:'查看全部',
                            hidePort:'收起'
                        }
                    });
                });
            } else {
                return '';
            }
        }
        return recoStr;
    },
    
    diningRankList : function(rti) {
        var topRank = rti.top_rank || {},
            rankName = $.trim(topRank.list_name),
            city_name = $.trim( topRank.city_name ),
            rankTop = +topRank.shop_ranking;

        if(rankName && 30 >= rankTop && 0 < rankTop) {
            return '<section id="dinningRank" class="dinningRank more" ' + this.handleAttr + '="js_diningShowRankPage" poiid="' + topRank.poiid + '" listid="' + topRank.list_id + '">' +
                       '<h2 class="dinningRank_con module_title">' + 
                           '<span class="dinningRank_title">' + city_name + rankName + '餐厅</span>' + 
                           (10 >= rankTop ? '<span class="dinningRank_ranklist">排名第</span><dfn class="dinningRank_rank">' + rankTop + '</dfn>' : '') +
                       '</h2>' +
                   '</section>';
        } else {
            return '';
        }
    },
    
    /*-------- 美食不用等 --------*/
    initPoiQueueInfo: function() {
        var self = this;
        self.send({
            action: 'getAmapUserId',
            onlyGetId: '1'
        }, function(res) {
            self.userid = res.userid;
            self.util.setQueueKey(res.userid, self.aosData.base.poiid);
        });

        var page = self.browser.ios ? window : document;
        page.addEventListener('pageshow', function() {
            self.reShowPage();
        });

        self.getPoiQueueInfo();
    },
    getPoiQueueInfo: function(getType) {
        var self = this;
        var orderInfo = 0;
        var waitingInfo;
        // 获取我的排位信息
        if (getType !== 2) {
            self.api.aosrequest('dinningQueueStatus', [{poiid: self.aosData.base.poiid, sign: 1}], function(res) {
                if (res.code != 1) {
                    orderInfo = 1;
                    if (waitingInfo) {
                        self.showWaitingInfo(waitingInfo);
                    }
                    return;
                }
                orderInfo = 2;
                // 已排号
                if (res.waiting == 0 && res.serial_number) {
                    self.createMyQueueInfo(res);
                }
                // 正在取号
                else if (res.waiting == 1) {
                    this.showSelfIsWaiting();
                }
            }, false, false, 'GET');
        }
        self.dinningStoreId = self.aosData.idDictionaries.dining_meiwei_api_id;
        // 获取当前餐厅的排位信息
        POI.api.aosrequest('dinningQueue', [
            {sid: self.dinningStoreId, sign: 1}
        ], function(res) {
            if (res.code != 1 || (!getType && orderInfo == 2)) {
                return;
            }
            if (orderInfo == 0 && !getType) {
                waitingInfo = res;
                return;
            }
            POI.showWaitingInfo(res);
        }, false, false, 'GET');
    },
    reShowPage: function() {
        if (!this.hasQueueInfo) {
            return;
        }
        var info = this.util.getStoredQueueInfo();
        if (!info) {
            return;
        }
        // 取号中
        if (info.isWaiting) {
            this.showSelfIsWaiting();
        }
        // 排号成功
        else if (info.queueInfo) {
            this.createMyQueueInfo(info.queueInfo);
        }
        // 排号失败
        else {
            if (this.queueWaitingInfo) {
                this.showWaitingInfo(this.queueWaitingInfo);
            }
            else {
                this.getPoiQueueInfo(2);
            }
        }
    },
    _pollisStoped: false,
    pollGetResult: function(delayTime) {
        var poiid = this.aosData.base.poiid;
        var self = this;
        delayTime = delayTime || 1000;
        setTimeout(function() {
            self.api.aosrequest('dinningQueueStatus', [{poiid: poiid, sign: 1}], function(res) {
                if (self._pollisStoped) {
                    return;
                }
                if (res.code == 1 && res.waiting == 1) {
                    return;
                }
                self._pollisStoped = true;
                if (res.code == 1 && res.serial_number) {
                    self.createMyQueueInfo(res);
                }
                // 取号失败显示排位信息
                else {
                    self.storeQueueInfo();
                    self.showWaitingInfo(self.queueWaitingInfo);
                }
            }, false, false, 'GET');
            if (!self._pollisStoped) {
                self.pollGetResult(delayTime + 750);
            }
        }, delayTime);
    },
    /**
     * 显示排号信息.
     * @param {String} html 排号信息html
     */
    createQueueHtml: function(html) {
        if (!html) {
            $('#dinningQueue').hide();
        }
        else {
            $('#dinningQueue').html(html).show();
        }
    },
    createQueueHead: function(state, getNo) {
        return '<h2 class="module_title_p"><img src="img/icon_queuing.png" class="queue_icon"/>排队状态' +
            (state ? '<span class="queue_state">(' + state + ')</span>' : '') +
            (getNo ? '<span ' + this.handleAttr +
                '="js_openQueueOrder" class="queue_start_queue more">' + getNo + '</span>' : '') +
        '</h2>';
    },
    createWaitInfoHtml: function(list) {
        if (!list || !list.length) {
            return '';
        }
        var html = '';
        var totalCount = 0;
        for (var i = 0, len = list.length, item = null; i < len; i++) {
            item = list[i];
            var waitTable = item.wait_table | 0;
            totalCount += waitTable;
            if (item && item.table_type) {
                html += '<li>' +
                       '<span class="queue_detail_type">' + item.table_type + '</span>' +
                       (item.people_num ? '<span class="queue_detail_people">(' + item.people_num + ')</span>' : '') +
                       '<span class="queue_detail_num"><span class="num">' + waitTable + '桌</span>等位</span>' +
                   '</li>';
            }
        }
        return totalCount ? '<ul class="queue_detail">' + html + '</ul>' : '';
    },
    // 显示我的排号信息
    createMyQueueInfo: function(res) {
        this.util.storeQueueInfo(false, res);
        var info = '<h2 class="module_title_p line-half more" ' + this.handleAttr + '="js_openQueueList">我的排号</h2>' +
            '<div class="queue_info_body flex">' +
                '<div class="flex1">' +
                    '<span class="num">' + res.queue_size + '</span><span>&nbsp;桌</span>' +
                    '<span class="desc">还需等待</span>' +
                '</div>' +
                '<div  class="flex1">' +
                    '<span class="num">' + res.serial_number + '</span>' +
                    '<span class="desc">我的排号</span>' +
                '</div>' +
            '</div>';
        this.createQueueHtml(info);
    },
    // 显示正在取号中状态
    showSelfIsWaiting: function() {
        this.createQueueHtml( this.createQueueHead('取号中') );
        this.util.storeQueueInfo(true);
        this.pollGetResult();
    },
    // 显示商家排号信息
    showWaitingInfo: function(res) {
        setTimeout(function() {
            POI.getPoiQueueInfo(2);
        }, 180000);

        if (res.code != '1' || !res.response) {
            return;
        }
        // 不支持手机排号时显示对应信息
        if (res.response.state != '0') {
            if (res.response.notice) {
                this.createQueueHtml( this.createQueueHead(res.response.notice) );
            }
            return;
        }

        this.queueWaitingInfo = res;

        var info = this.createWaitInfoHtml(res.response.wait_info);
        if (info) {
            var storageInfo = this.util.getStoredQueueInfo();
            var btnText = storageInfo && storageInfo.hasGot ? '重新排号' : '立即取号';
            this.waitingQueueInfo = res.response.wait_info;
            this.createQueueHtml( this.createQueueHead('', btnText)
                .replace('module_title_p', 'module_title_p line-half') + info );

            POI.headerToolBar.queue_flag = true;
            POI.headerToolBar.poiDinningToolBar({class_name:'header_queue', title: '排队'});
            POI.api.userAction("queueInfo", {type: "can"});
        }
        else {
            this.createQueueHtml( this.createQueueHead('不用排队') );
            POI.api.userAction("queueInfo", {type: "no"});
        }
    },
    /*---------------- end 美食不用等 ----------------*/

    /*---------------- 点击事件 ----------------*/
    js_openQueueOrder: function(elem, event) {
        this.api.userAction('getQueueNo', {status: elem.text() == '立即取号' ? 'getNow' : 'getAgain'});
        // event.preventDefault();  // 不用a标签了，不需要
        this.send({
            action: 'loginBind',
            type: 'phone'
        }, function(res) {
            if (!res.phone) {
                return;
            }
            var self = POI;
            /*self.api.aosrequest('queueOrderList', [{tid: self.extraUrl.tid, sign: 1}], function(aosres) {
                if (aosres.code == 1) {
                    var list = aosres.data;
                    var total = 0;
                    for (var i = 0, len = list.length; i < len; i++) {
                        var order_status = list[i] && list[i].order_status;
                        if (order_status == 2 || order_status == 4) {
                            total += 1;
                        }
                    }
                    if (total >= 2) {
                        self.api.promptMessage('请先取消一个已有排号～');
                        return;
                    }
                }*/
                self.util.setQueueKey(res.userid, self.aosData.base.poiid);
                var param = '?poiid=' + self.aosData.base.poiid +
                    '&phone=' + res.phone + '&userid=' + res.userid +
                    '&sid=' + self.dinningStoreId;
                if (self.waitingQueueInfo) {
                    param += '&waitingQueueInfo=' + encodeURIComponent(JSON.stringify(self.waitingQueueInfo));
                }
                self.util.locationRedirect('dinningQueueOrder.html' + param);
            // }, 1);
        });
    },
    js_openQueueList: function() {
        this.api.userAction('viewMyQueueList');
        this.util.locationRedirect('queueOrderList.html?poiid=' +
            this.aosData.base.poiid + '&userid=' + this.userid +
            '&showTitleBar=1');
    },
    js_diningShowBigPic : function() {
        this.getMenuData();
        this.api.userAction('dinningMenuPicTitle');
    },
    
    js_diningShowBigPicIndex : function(ele, evt) {
        var index = $(ele).index() + 1;
        this.getMenuData(index);
        this.api.userAction('dinningMenuPic', {index: index});
    },
    
    js_diningShowRankPage : function(ele) {
        var url = "exRankList.html?poiid=" + ele.attr("poiid") + "&listid=" + ele.attr("listid") + "&loc=" + user_loc + "&adcode=" + user_adcode;
        POI.util.locationRedirect(url);
        POI.api.userAction('dinningRank');
    },
    /*---------------- end 点击事件 ----------------*/

    diningPageList : function(recommendStr, rankStr, opentime2, tag_category) {
        var inst = this.index.introInstallation(tag_category,1);
        var introHtml = '';
        if( inst ){
            POI.api.userAction("diningIntroDetail", {business: POI.business});
            introHtml = '<section><h2 id="baseIntro" class="module_title_p hotel_title_p more">商家详情' + inst + '</h2></section>';
        } else {
            inst = opentime2 ? '营业时间：' + opentime2 : '';
            introHtml = this.index.moduleIntro(["商户图片", "商户介绍", "商户详情"], ["opentime2", "service", "tag_atmosphere"], inst);
        }
        var queueStr = '<section id="dinningQueue" style="display:none;"></section>';
        var allAry = this.index.moduleAll(['sendComment', recommendStr, this.get_yzjs() ,queueStr, 'alipayDiscount', 'rti', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'commentInfo', '<div style="display:none;" id="js_eta_module"></div>','indoorMap', 'banner', 'placeContribution']);
        this.pagebody.append(allAry.join("") + rankStr);
        POI.util.executeAfterDomInsert();
    },
    /*
        优质介绍模块
    */
    get_yzjs : function() {
        var deep = this.aosData.deep[0];
        var highlight = deep.highlight || {};
        if( highlight.pic_info && highlight.pic_info.length) {
            var pic_info = highlight.pic_info[0];
            var w = document.body.clientWidth;
            var h = w*0.51|0;
            if( pic_info.url ){
                this.api.userAction( 'goDinningPicjsShow' );
                return '<section class="yzjs">'+
                    '<article '+(highlight.recommend ? 'js_handle="js_goDinningPicjs"' : '')+'>'+
                    '<img src="'+this.util.imageUrlTransform(pic_info.url , w , h , 'merge' , 5)+'" width="100%"/>'+
                    '<em></em>'+
                    (highlight.title ? '<p class="lineDot">'+ highlight.title +'</p>':'')+
                    '</article>'+
                    '</section>';
            }
        }
        return '';
    },
    /*
        加载eta数据模块
        type: bus 或者 foot
    */
    load_eta_module : function(dt, type) {
        var self = this;
        var html = [];
        var distance = dt.distance;//距离
        var travel_time = dt.travel_time;
        var price = dt.taxi_price;
        var handleAttr = self.handleAttr;
        if( !distance || !travel_time ) {
            return ;
        }
        html.push( '<section class="eta_module eta_'+type+'">' );
        html.push( '<h2 class="eta_h2 module_title_p more" '+handleAttr+'="js_go_etapoint" data-type="'+type+'">当前位置<span>到</span><i>该餐厅</i></h2>' );
        html.push('<div class="eta_distance line">');
        html.push('<p>'+self._formatTime(travel_time)+'</p>');
        html.push('<p>'+self.util.formatDistance(distance).replace(/(米|公里)/,'<i>$1</i>')+'</p>');
        html.push('</div>');
        if( type == 'bus' ){
            var dining_park = self.aosData.deep[0].dining_park||0;
            //dining_park N 1 非空 0：无 餐厅停车 1：少量 2：足够
            html.push('<h2 class="eta_item module_title_p line-half more line" '+handleAttr+'="js_eta_search">'+(dining_park == 0? '点击查询附近停车场' : '停车场&nbsp;&nbsp;该餐厅自有停车场，到店可停')+'</h2>');
            if(price >= 1) {
                html.push('<h2 class="eta_item module_title_p more line" '+handleAttr+'="js_eta_dache">打车费&nbsp;&nbsp;约'+parseInt(price)+'元</h2>');
            }
        }
        html.push( '</section>' );
        $('#js_eta_module').replaceWith(html.join(''));
    },
    /*
        time : 秒
    */
    _formatTime : function( time ){
        if( time >= 60*60) {
            time = parseFloat(time/60/60).toFixed(2)+'<i>小时</i>';
        } else {
            time = (parseInt(time/60) || 1)+'<i>分钟</i>';
        }
        return time;
    },
    init : function() {

        if("1" == POI.aosData.rti.is_queue) {
            this.hasQueueInfo = true;
            this.initPoiQueueInfo();
        }
        var tags = '';
        if (POI.aosData.base.std_t_tag_0_v) {
            var arr = POI.aosData.base.std_t_tag_0_v.split(';');
            for (var i=0; i<arr.length; i++) {
                tags += this.index.moduleHeadItem(arr[i]);
            }
        }
        
        var price = "";
        if(POI.aosData.deep[0].price) {
            price = '人均<span class="min_money">¥' + POI.aosData.deep[0].price+'</span>';
        }
        if (POI.aosData.deep[0].is_24h == '1') {
            tags += this.index.moduleHeadItem('24H');
        }
        this.index.moduleDeepHead(tags, price);
        
        POI.api.getMapLocation(function(arg) {
            user_loc = arg.lon && arg.lat ? arg.lon + "," + arg.lat : "";
            user_adcode = arg.adcode;
            
            var deep = POI.aosData.deep[0],
                rti = POI.aosData.rti,
                cprInfo = rti.cpr_info || {},
                opentime2 = deep.opentime2 || "";
            
            POI.diningPageList(
                POI.recommendMenu(deep, rti),
                POI.diningRankList(rti),
                opentime2,
                deep.tag_category
            );
            
            if("1" === cprInfo.subscribe_flag){
                POI.api.commercialSubscribe(true);
            }
            
        });
    },
    /**
     * @version 722 开始支持
     * 菜单推荐菜点击改成二次请求，首页不展示，减少第一次请求
     * */
    getMenuData:function(idx) {
        POI.api.aosrequest({
            'urlPrefix' : 'dinningMenu',
            'poiInfo' : this.clientData.poiInfo,
            'method' : 'GET',
            'progress' : 1,
            'params' : [{'poiid': this.clientData.poiInfo.poiid,'sign':1}],
            'encrypt': '1',
            'goback' : '0',
            'showNetErr':'1'
        }, function(data) {
            if(1 == data.code){
                POI.exDinPiclist(data.menu_info, idx);
            }
        });
    },
    
    exDinPiclist:function(menu_info, idx){
        var dataObj = null, piclistArray = [];
        $.each(menu_info,function(key,values){
            var className = '', flag = false;
            if(values.specialty){
                className = 'hot';
            }else if(values.onsale){
                className = 'best';
            }else if(values.new){
                className = 'new';
            }
            values.price ? (values.price.slice(0,1) !== '0' ? flag = true : flag = false ) : flag = false;
            piclistArray.push(
                {
                    url:  (values.pic_cover ? values.pic_cover : '') ,
                    title: (values.name ? values.name : '') ,
                    message: (flag ? ('￥' + values.price  + '/' + (values.price_u?values.price_u:'')) :'')
                }
            );
        });
        dataObj = {
            module:"list",
            showMod:"2",
            index:"1",
            picList:piclistArray
        };
        if(idx) {
            dataObj.module = "single";
            dataObj.index = idx - 1;
        }
        //POI.util.storage('exPicList',JSON.stringify(dataObj));
        //POI.util.locationRedirect('public/picview/exPiclist.html?showTitleBar=1');
        POI.api.imagePreview(dataObj.module, dataObj.index, dataObj.picList);
        POI.api.userAction('recMenuPicList');
    },
    /*
        当前位置到该餐厅 点击
    */
    js_go_etapoint : function(obj){
        var type = obj.attr( 'data-type' );
        var type = type=='bus'?'car':'walk';
        this.api.searchRoute('', this.clientData.poiInfo, type);
        this.api.userAction('goEtapoint');
    },
    /*
        所有停车场
    */
    js_eta_search : function() {
        this.send({
            action:'searchCategory',
            category:'停车场',
            poiInfo:this.clientData.poiInfo
        });
        this.api.userAction('etaSearchCategory');
    },
    /*
        打车
    */
    js_eta_dache : function() {
        this.api.loadSchema((this.browser.ios ? 'iosamap':'androidamap')+'://openFeature?featureName=TakeTaxi&sourceApplication=poi');
        this.api.userAction('etaTakeTaxi');
    },
    /*
        优质介绍模块点击
    */
    js_goDinningPicjs : function() {
        var self = this;
        var deep = self.aosData.deep[0];
        var highlight = deep.highlight || {};
        if(highlight.recommend && highlight.title ){
            self.util.storage( 'dinning_pic_centent', highlight.recommend);
            self.util.locationRedirect("dinningPicjs.html?title="+encodeURIComponent( highlight.title ));
        }
        self.api.userAction( 'openDinningPicjs' );
    }
});


})(POI, Zepto);