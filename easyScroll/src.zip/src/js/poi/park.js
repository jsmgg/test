/**
 * 停车场.
 */
;(function(POI, $) {

'use strict';

var poiData;

/**
 * 显示头部信息.
 */
function showHeaderInfo() {//优化到index里面？
    var html = '';
    var deep = poiData.deep[0];

    if (POI.aosData.base.std_t_tag_0_v) {
      var arr = POI.aosData.base.std_t_tag_0_v.split(';');
      for (var i=0; i<arr.length; i++) {
          html += POI.index.moduleHeadItem(arr[i]);
      }
    }
    var price;
    if (deep.charge === '是') {
        price = '收费';
    } else if (deep.charge === '否') {
        price = '免费';
    }
    if (price) {
        html += POI.index.moduleHeadItem(price);
    }
    return html;
}
/**
 * 显示剩余车位信息.
 */
function carportLeft() {
    var parkInfo = poiData.rti.parking, source, src_info,deep = poiData.deep[0]||{},
        leftNum = parkInfo && parkInfo[0] && parkInfo[0].num_space_f;
    leftNum = parseInt(leftNum);
    var html = '', rtn = '';
    if (leftNum >= 0) {
        if (leftNum === 0) {
                html = '<span class="parking_noplace">暂无</span>停车位';
        } else {
            html = '空车位：<span class="' + (leftNum < 10 ? 'parking_noplace' :
                'parking_mutiplace') + '">' + leftNum + '</span>个';
        }
    }
    // 总车位信息
    if (deep.num_space > 0) {
        if (html) {
            html += '，';
        }
        html += '共' + deep.num_space + '个车位';
    }
    if (html) {
        rtn = '<section class="parking"><h2 class="module_title_p line-half">车位信息';
        // 显示紫光百汇来源信息
        source = ';' + deep.src_type_mix + ';';
        if (source.indexOf(';unispark;') > -1) {
            src_info = poiData.src_info.unispark;
            if (src_info && src_info.name_cn) {
                rtn += '<span class="title_source">来源：' + src_info.name_cn + '</span>'
            }
        }
        rtn += '</h2><p class="parking_con">' + html + '</p><p class="parking_tips">车位信息仅供参考，具体以实际为准</p>';
    }
    rtn += '</section>';
    return rtn;
}
/**
 * 收费标准.
 */
function priceStandard() {
    var html = '', deep = poiData.deep[0], reg = /^[0-9\.]+$/;
    // 小型车辆收费标准
    if (deep.prc_c_d_e || deep.prc_c_n_e) {
        html += '<article><h3 class="parking_subtitle">小型车辆';
        if (deep.prc_c_wm) {
            html += reg.test(deep.prc_c_wm) ? '（' + deep.prc_c_wm + '元/月）' : '（' + deep.prc_c_wm + '）';
        }
        html += '</h3>';
        html += formatPriceLine(deep.prc_c_d_e);
        html += formatPriceLine(deep.prc_c_n_e, true);
        html += '</article>';
    }
    // 大型车辆收费标准
    if (deep.prc_t_d_e || deep.prc_t_n_e) {
        html += '<article><h3 class="parking_subtitle">大型车辆';
        if (deep.prc_t_wm) { // 前段预留字段，cms中并无此字段，也不会展示出来
            html += reg.test(deep.prc_t_wm) ? '（' + deep.prc_t_wm + '元/月）' : '（' + deep.prc_t_wm + '）';
        }
        html += '</h3>';
        html += formatPriceLine(deep.prc_t_d_e);
        html += formatPriceLine(deep.prc_t_n_e, true);
        html += '</article>';
    }
    // 备注
    if (html && deep.remark) {
        html += '<article><h3 class="parking_subtitle">备注：</h3><div class="parking_charge">' + deep.remark + '</div></article>';
    }
    if (html) {
        html = '<section class="parking"><h2 class="module_title_p line-half">收费标准</h2>' + html + '</section>';
    }
    return html;
}
/**
 * 将收费标准价格转换为html代码.
 * @param {String} price 价格
 * @param {Boolean} [isNight=false] 是否为夜间价格，默认为否
 * @return {String} 无价格时返回空字符串
 */
function formatPriceLine(price, isNight) {
    if(!price) {
        return '';
    }
    var reg = /^[0-9\.]+$/;
    var UNIT  = reg.test(price) ? '元/小时' : '';
    var DAY   = '白天';
    var NIGHT = '夜间';

    if (!price) {
        return '';
    }
    return '<div class="parking_charge clearfix">' + (isNight ? NIGHT : DAY) + '<span class="parking_charge_mes">' + price + UNIT + '</span></div>';
}

$.extend(POI,{
    init: function() {
        var html, self = this,
            introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro"]);
        poiData = this.aosData||{};
        html = carportLeft();
        if (poiData.deep.charge !== '否') {
            html += priceStandard();
        }
        self.index.moduleDeepHead(showHeaderInfo());
        self.index.moduleAll(null, introHtml);
        self.util.executeAfterDomInsert();
        html && this.pagebody.prepend(html);
    }
});

})(POI, Zepto);
