/*
 * 事件类型poi
 */

;(function(POI, $) {

$.extend(POI, {
    
    showEventInfo: function(deep, pic) {
        if(!deep || !deep.event_type)
            return '';
        // event_type：事件类型，1：公众活动，2：突发事件，3：事件活动
        var event_type = +deep.event_type;
        
        if(1 === event_type || 3 === event_type) {
            var picStr = POI.util.imageUrlTransform(pic.cover ? (pic.cover.url || "") : "", 72, 90),
                dateStr = deep.date || "",
                priceStr = deep.price || "";
            if(dateStr) {
                dateStr = '<tr><td class="evePoi_td_title" valign="top" align="left">时间：</td><td>' + dateStr + '</td></tr>';
            }
            if(priceStr) {
                priceStr = '<tr class="evePoi_tr_last"><td class="evePoi_td_title" valign="top" align="left">票价：</td><td class="evePoi_td_price">' + priceStr + '</td></tr>';
            }
            
            if(dateStr || priceStr) {

                POI.util.executeAfterDomInsert(function() {
                    var coverImg = document.querySelector("#evePoi .evePoi_cover");
                    if(coverImg) {
                        var _img = new Image();
                        _img.onload = function() {
                            coverImg.style.cssText = "background-size: cover;background-image:url('" + this.src + "')";
                            this.onload = coverImg = _img = null;
                        };
                        _img.src = coverImg.getAttribute("data-src");
                    }
                });

                return '<section id="evePoi" class="evePoi">' +
                           '<h2 class="module_title">活动信息</h2>' +
                           '<article class="evePoi_con">' +
                               (picStr ? '<div class="evePoi_cover" data-src="' + picStr + '"></div>' : '') +
                               '<div class="evePoi_detail">' +
                                   '<p class="evePoi_title">' + this.clientData.poiInfo.name + '</p>' +
                                   '<table class="evePoi_list">' +
                                       dateStr +
                                       priceStr +
                                   '</table>' +
                               '</div>' +
                           '</article>' +
                        '</section>';
            }
        } else {
            return '';
        }
    },

    eventPageList : function(infoStr) {
        var htmlStr = infoStr;
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2"]);
        var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        this.pagebody.html(htmlStr + allAry.join(""));
        POI.util.executeAfterDomInsert();
    },

    init : function() {
        this.index.moduleDeepHead();
        var deep = this.aosData.deep[0],
            pic = this.aosData.pic || {};
        this.eventPageList(this.showEventInfo(deep, pic));
    }
});

})(POI, Zepto);