/*办事指南详情页*/
;(function(POI, $) {

$.extend(POI,{
    
    logPageId : "serviceDetail",
    
    data : null,
    
    keysLength : 0,
    
    currentActive: [],
    
    showIntro: function(desc) {
        if(!POI.util.bool(desc)) {
            return '';
        }
        return '<div class="sd_item line-half">' +
                   '<h2 class="sd_title">简介</h2>' +
                   '<div>' + desc + '</div>' +
               '</div>';
    },
    
    showPolicy: function(policy) {
        if(!POI.util.bool(policy)) {
            return '';
        }
        return '<div class="sd_item line-half">' +
                   '<h2 class="sd_title">最新消息</h2>' +
                   '<div class="sd_policy">' + policy + '</div>' +
               '</div>';
    },
    
    generateKeys: function(guiderList, idx, activeList) {
        idx = idx | 0;
        activeList = activeList || [];
        
        var activePartList = [];
        for(var i = 0; i < idx; i++) {
            if(POI.util.bool(activeList[i])) {
                activePartList.push(activeList[i]);
            }
        }
        var partLength = activePartList.length;
        
        var keysObj = {};
        for(var i = 0, len = guiderList.length, item = null; i < len; i++) {
            item = guiderList[i];
            if(!POI.util.bool(item.key)) {
                continue;
            }
            if(partLength) {
                if(this.isArrayEqual(activePartList, item.key, false)) {
                    keysObj[ item.key[idx] ] = 1;
                }
            } else {
                keysObj[ item.key[idx] ] = 1;
            }
        }
        var keysAry = [];
        for(var p in keysObj) {
            if(keysObj.hasOwnProperty(p)) {
                keysAry.push(p);
            }
        }
        return keysAry;
    },
    
    generateKeysAry: function(guiderList) {
        var keysAry = [];
        for(var i = 0, len = guiderList.length, item = null; i < len; i++) {
            item = guiderList[i];
            if(!POI.util.bool(item.key)) {
                continue;
            }
            for(var j = 0, _len = item.key.length, _item = null; j < _len; j++) {
                _item = item.key[j];
                if(!keysAry[j]) {
                    keysAry[j] = {};
                }
                if(!keysAry[j][_item]) {
                    keysAry[j][_item] = 1;
                }
            }
        }
        if(keysAry.length) {
            for(var i = 0, len = keysAry.length, item = null; i < len; i++) {
                var _ary = new Array();
                item = keysAry[i];
                for(var p in item) {
                    if(item.hasOwnProperty(p)) {
                        _ary.push(p);
                    }
                }
                keysAry[i] = _ary;
            }
        }
        return keysAry;
    },
    
    createKeyLis: function(keysAry, idx, activeText) {
        var lisStr = '';
        for(var i = 0, _len = keysAry.length, item = null; i < _len; i++) {
            item = keysAry[i];
            if(activeText === item) {
                lisStr += '<li><button class="canTouch active" idx="' + idx + '">' + item + '</button></li>';
            } else {
                lisStr += '<li><button class="canTouch" idx="' + idx + '">' + item + '</button></li>';
            }
        }
        return lisStr;
    },
    
    showKeysFirst: function(data) {
        /*
        <div class="sd_keys_con">
            <h2 class="sd_title">办理指南</h2>
            <div class="sd_keys">
                <div class="sd_key_item">
                    <h3>一方：</h3>
                    <ul><li><button class="active">北京居民</button></li></ul>
                </div>
                <div class="sd_key_item">
                    <h3>另一方：</h3>
                    <ul><li><button class="active">外省市居民</button></li><li><button>港澳台居民</button></li><li><button>华侨/出国人员</button></li><li><button>外国人</button></li></ul>
                </div>
                <div class="sd_key_item">
                    <h3>办理：</h3>
                    <ul><li><button class="active">登记</button></li><li><button>补办</button></li><li><button>网上预约</button></li></ul>
                </div>
            </div>
        </div>
        */
        if(POI.util.bool(data.guiderkey) && POI.util.bool(data.guider)) {
            var len = data.guiderkey.length;
            if(!len) {
                return;
            }
            this.keysLength = len;
            
            var itemStr = '';
            var lisStr = '';
            for(var i = 0, keysAry = null; i < len; i++) {
                keysAry = this.generateKeys(data.guider, i, this.currentActive);
                this.currentActive.push(keysAry[0]);
                lisStr = this.createKeyLis(keysAry, i, keysAry[0]);
                if(lisStr) {
                    itemStr += '<div class="sd_key_item">' +
                                   '<h3>' + data.guiderkey[i] + '：</h3>' +
                                   '<ul>' + lisStr + '</ul>' +
                               '</div>';
                }
            }
            if(itemStr) {
                $('#keys').html('<h2 class="sd_title">办理指南</h2>' +
                                '<div class="sd_keys">' +
                                    itemStr +
                                '</div>');
            }
        } else {
            return '';
        }
    },
    
    updateKeysShow: function(idx) {
        var keysItem = $("#keys .sd_keys .sd_key_item").eq(idx);
        var activeText = keysItem.find("button.active").text();
        var keysAry = this.generateKeys(this.data.guider, idx, this.currentActive);
        var newActiveText = keysAry[0];
        for(var i = 0, len = keysAry.length; i < len; i++) {
            if(activeText == keysAry[i]) {
                newActiveText = activeText;
                break;
            }
        }
        this.currentActive[idx] = newActiveText;
        var lisStr = this.createKeyLis(keysAry, idx, newActiveText);
        if(lisStr) {
            keysItem.find("ul").html(lisStr);
        }
    },
    
    isArrayEqual: function(ary1, ary2, isFull) {
        if(!(ary1 && ary2)) {
            return false;
        }
        if(isFull) {
            if(ary1.length !== ary2.length) {
                return false;
            }
        }
        var len = Math.min(ary1.length, ary2.length);
        var result = true;
        for(var i = 0; i < len; i++) {
            if(ary1[i] !== ary2[i]) {
                result = false;
                break;
            }
        }
        return result;
    },
    
    showDynamicDetail: function() {
        var activeDomAry = $(".sd_key_item button.active");
        var activeAry = [];
        for(var i = 0; i < activeDomAry.length; i++) {
            activeAry.push(activeDomAry[i].innerText);
        }
        var list = this.data.guider;
        var detailObj = null;
        for(var i = 0, len = list.length, item = null; i < len; i++) {
            item = list[i];
            if(this.isArrayEqual(activeAry, item.key, true)) {
                detailObj = item;
                break;
            }
        }
        if(detailObj) {
            /*
            <div class="sd_detail_con line-half">
                <h2 class="sd_title">办理条件</h2>
                <div class="sd_detail">
                    <!--接口返回数据-->
                    <div class="condition"><div class="checkbox1"><p>1、双方至少一方为北京户籍，另一方为外省市户籍；</p><p>2、男女双方自愿结婚;</p><p>3、男方年满22周岁，女方年满20周岁;</p><p>4、双方均无配偶;</p><p>5、均未患有医学上认为不应当结婚的疾病;</p><p>6、不属于直系血亲或者三代以内的旁系血亲关系。</p></div></div>
                    <!--接口返回数据-->
                </div>
            </div>
            */
            var detailModels = detailObj.models;
            if(POI.util.bool(detailModels)) {
                var htmlStr = '';
                for(var i = 0, len = detailModels.length; i < len; i++) {
                    htmlStr += '<div class="sd_detail_con line-half">' +
                                   '<h2 class="sd_title">' + detailModels[i].guidername + '</h2>' +
                                   '<div class="sd_detail">' +
                                       detailModels[i].guidervalue +
                                   '</div>' +
                               '</div>';
                }
                if(htmlStr) {
                    $("#dynamic").html(htmlStr);
                }
            }
        }
    },
    
    bindEvent: function() {
        $("#keys").on("click", ".sd_key_item button", function(evt) {
            var $ele = $(this);
            if($ele.hasClass("active")) {
                return;
            }
            $ele.parents(".sd_key_item").find("button.active").removeClass("active");
            $ele.addClass("active");
            var idx = $ele.attr("idx") | 0;
            POI.currentActive[idx] = $ele.text();
            for(var i = idx + 1; i < POI.keysLength; i++) {
                POI.updateKeysShow(i);
            }
            POI.showDynamicDetail();
            POI.imgDeal();
            POI.api.userAction("switchingCondition");
        });
        $("#dynamic,#static").on("click", "a", function(evt) {
            POI.api.userAction("openOtherUrl");
            POI.api.openThirdUrl($(this).attr("href"));
            return false;
        });
    },
    
    imgDeal: function() {
        var sd_detail_con = $(".sd_detail_con");
        var clientWidth = sd_detail_con.width() - (parseInt(sd_detail_con.css("padding-left")) * 2);
        var imgs = $("img");
        for(var i = 0, len = imgs.length, item = null; i < len; i++) {
            item = imgs[i];
            if(clientWidth < (item.getAttribute("width") | 0) || clientWidth < parseInt(item.style.width)) {
                item.style.width = "100%";
                item.style.height = "auto";
                item.removeAttribute("width");
                item.removeAttribute("height");
            }
        }
    },
    
    showServiceDetail: function() {
        var htmlStr = '';
        htmlStr += this.showIntro(this.data.desc);
        htmlStr += this.showPolicy(this.data.policy);
        
        if(htmlStr) {
            $("#static").html(htmlStr);
        }
        this.showKeysFirst(this.data);
        this.showDynamicDetail();
        this.imgDeal();
        this.bindEvent();
    },
    
    getServiceDetailData: function(adcode, type1, type2, title) {
        var _this = this;
        var params = [
            {adcode: adcode, sign: 1},
            {type1: type1},
            {type2: type2},
            {title: title}
        ];
        POI.api.aosrequest('serviceDetail', params, function(data) {
            if("1" == data.code) {
                _this.data = data.data;
                _this.showServiceDetail();
            }
        }, 1, true, "GET");
    },
    
    quickInit : function() {
        var params = POI.util.getUrlParam();
        var adcode = params.adcode;
        var type1 = params.type1;
        var type2 = params.type2;
        var title = params.title;
        POI.util.setPageTitle(title || "");
        if(adcode && type1 && type2 && title) {
            this.getServiceDetailData(adcode, type1, type2, title);
        }
    }
});

})(POI, Zepto)
