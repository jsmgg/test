;(function(POI, $){
'use strict';
$.extend(POI,{
    tuanPagenum : 1,
    tuanhuiList_poiid : '',
    tuanhuiList_pageSize : 20,
    tuanhuiList_page : null,
    tuanhuiList_busy : false,
    tuanhuiList_rander : function(poiid, discountLen, title , tuanlist, discount){
        var self = this;
        discountLen = discountLen||0;//self.util.getUrlParam('discountLen')||0;
        self.tuanhuiList_poiid = poiid;
        self.util.setPageTitle(title);
        if( poiid && tuanlist ){//传了poiid切有tuanlist认为有团购
            self.randerTuan(tuanlist,discountLen > 0, title);//优惠条数大于0，说明有优惠数据
        } else if( discount ) {
            self.randerHui( discount , title );
        }
        self.util.delegate($('#js_page'));
        self.api.userAction('tuanhuilistShow');
    },
    /*
        tuanlist:{
            code:1,
            tuan_list:[],
            total:6
        }
        hasDis: true/false
    */
    randerTuan : function(tuanlist, hasDis, title) {
        var self = this,
            header = '',
            html = [];
        if( hasDis ){
            header = '<div class="default_header"><div class="top"><i js_handle="js_close_scrollPage"></i><h2>'+title+'</h2></div><div class="tuanhui_nav"><i></i><p class="selected canTouch tuan" js_handle="js_tuanhuinav">团购</p><i></i><i></i><p class="canTouch hui" js_handle="js_tuanhuinav">优惠</p><i></i></div></div>';
        }
        html.push( '<section class="tuanList" id="js_tuanhuilist_tuan">' );
        html.push( self.get_tuanlist(tuanlist.tuan_list) );
        html.push( '</section>' );
        html.push( '<section class="youhuiList" id="js_tuanhuilist_hui"></section>' );
        self.tuanhuiList_page = self.scrollPage({
            defaultHeader : header ? '' : title,
            header : header,
            content : html.join('')
        })
        if( tuanlist.total > self.tuanhuiList_pageSize * self.tuanPagenum ) {
            self.tuanhuiList_page.load_more(function( box ){
                self.load_moretuan( box );
            });
        } else {
            self.tuanhuiList_page.load_end();
        }
        self.tuanhuiList_page.destroy( function(){
            self.tuanPagenum = 1;
            self.tuanhuiList_page = null;
        } );
    },
    load_moretuan : function( box ) {
        var self = this;
        if( self.tuanhuiList_busy ) return;
        self.tuanhuiList_busy = true;
        var params = [
            {poiid:self.tuanhuiList_poiid,sign:1},
            {pagesize:self.tuanhuiList_pageSize},
            {pagenum:self.tuanPagenum+1},
            {classify:0}
        ];
        self.api.aosrequest({
            params : params,
            urlPrefix:'nearbyTuanType',
            showNetErr: true,
            method : 'get'
        }, function( dt ) {
            if( dt.code == 1){
                self.tuanPagenum++;
                $( '#js_tuanhuilist_tuan' , box).append( self.get_tuanlist(dt.tuan_list) );
                if( dt.total <= self.tuanhuiList_pageSize*self.tuanPagenum ){
                    self.tuanhuiList_page.load_end();
                }
            }
            self.tuanhuiList_page.refresh();
            self.tuanhuiList_busy = false;
        });
    },
    get_tuanlist : function( tuan_list ) {
        var self = this;
        return tuan_list.map(function( item ){
            var html = [];
            html.push( '<article class="canTouch tuanhuiItem canTouch" js_handle="js_triggerTuanItem" tuanid="' + item.id + '" mergeid="' + item.mergeid + '" srctype="' + item.src + '">' );
            html.push( '<p'+( item.isappointment == 1 ? ' class="yuyue"':'' )+'><img src="'+self.util.imageUrlTransform(item.pic_url , 75 , 70 , 'merge' , 5)+'"></p>' );
            html.push( '<hgroup><h1>'+(item.shortname||'')+'</h1>' );
            html.push( '<p class="tuan_star"><i style="width:'+self.getStarsWidth(item.score)+'px;"></i></p>' );
            html.push( '<h5>' );
            item.price_current && html.push( '<span>'+item.price_current+'</span>' );
            item.price_previous && html.push( '<del>'+item.price_previous+'</del>' );
            item.brought && html.push( '<em>'+item.brought+'人已购买</em>' );
            html.push( '</h5></hgroup>' );
            html.push( '</article>' );
            return html.join('');
        }).join('');
    },
    getStarsWidth : function( score ){
        var width = 0, size = 12, cut = 2.5;
        score = score || 0;
        width = score * cut + score*size ;
        return width;
    },
    randerHui : function( discount , title ) {
        var self = this;
        var html = [ '<section class="youhuiList" id="js_tuanhuilist_hui" style="display:block;">' ];
        html.push( this.get_youhuilist( discount ) );
        html.push( '</section>' );
        $( '#js_page' ).html( html.join('') );
        self.tuanhuiList_page = self.scrollPage({
            defaultHeader : title,
            content : html.join('')
        })
        self.tuanhuiList_page.load_end();
        self.tuanhuiList_page.destroy( function(){
            self.tuanPagenum = 1;
            self.tuanhuiList_page = null;
        } );
        self.util.storage('discount', JSON.stringify(discount));
    },
    get_youhuilist : function( discount ){
        return discount.map(function( item ){
            var url = POI.util.bool( item.pic_info[0] ) ? item.pic_info[0].url : '';
            var html = [ '<article class="canTouch tuanhuiItem canTouch" js_handle="js_goDiscountDetail" did="' + (item.discount_gd_id || '') + '">' ];
            html.push( '<p>'+ (url ? '<img src="'+POI.util.imageUrlTransform(item.pic_info[0].url , 75 , 70 , 'merge' , 1)+'">' : '') +'</p>' );
            html.push( '<hgroup>' );
            html.push( '<h1>' + (item.discount_title || '') + '</h1>' );
            html.push( '<h5>' );
            item.price_dis && html.push( '<span>'+item.price_dis+'</span>' );
            item.price_ori && html.push( '<del>'+item.price_ori+'</del>' );
            html.push( '</h5>' );
            html.push( '</hgroup></article>' );
            return html.join( '' );
        }).join('');
    },
    _prev_scroll : 0,
    js_tuanhuinav : function( obj ){
        if( obj.hasClass( 'selected' ) ) return;
        obj.parent().find('p.selected').removeClass( 'selected' );
        obj.addClass( 'selected' );
        var fig = obj.hasClass( 'tuan' );
        var youhuilist = $( '#js_tuanhuilist_hui' );
        var self = this;
        $( '#js_tuanhuilist_tuan' ).css( 'display', fig?'block':'none' );
        youhuilist.css( 'display', fig?'none':'block' );
        if( youhuilist.find( 'article' ).length == 0 ){
            self.api.aosrequest({params: [{poiid:self.tuanhuiList_poiid,sign:1}], poiInfo:'', urlPrefix:'discountList', progress:1, showNetErr: true, method:'get'}, function(arg) {
                if (arg.code == -1 || arg.code == -2 || !arg.discount_info || !arg.discount_info.length) {
                    return;
                }
                self.util.storage('discount', JSON.stringify(arg.discount_info));
                youhuilist.html( self.get_youhuilist(arg.discount_info));
                self.tuanhuiList_page.refresh(1);
                self.tuanhuiList_page.load_end();
            });
        }
        self.tuanhuiList_page.refresh(1);
        self.api.userAction('tuanhuiChangeNav'+(fig?'tuan':'hui'));
    },
    js_triggerTuanItem : function( ele ) {
        var self=this;
        self.util.locationRedirect("exTuangou.html?type=tuan&tuangouID="+ele.attr("tuanid")+"&mergeID="+ele.attr("mergeid")+"&src_type=" + ele.attr("srctype") + "&source=poiIndex&showTitleBar=1");
        self.api.userAction('triggerTuanItem');
    },
    js_goDiscountDetail : function( ele ) {
        this.util.locationRedirect('exCouponDetail.html?did=' + ele.attr('did')+'&showTitleBar=1');
        this.api.userAction('goDiscountDetail');
    }
});
})(POI, Zepto);