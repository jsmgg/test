/**
 * 医院科室列表页面.
 */
;(function(POI, $) {
'use strict';

// 科室信息
var departmentData;

$.extend(POI, {
	logPageId: 'hospitalDepartList',
	handleAttr: 'js_handle',

	quickInit: function() {
		this.util.delegate( $('#js_pagebody') );
		this.api.userAction('pv');

		var listData = this.util.storage('hospital.departmentList');
		localStorage.removeItem('hospital.departmentList');
		listData = JSON.parse(listData);
		departmentData = listData;
		var html = '';
		var list = listData.department;
		for (var i = 0, len = list.length; i < len; i++) {
			if (!list[i].child_department) {
				continue;
			}
			for (var j = 0, len2 = list[i].child_department.length; j < len2; j++) {
				html += tplDepartmentItem(list[i].child_department[j], i + '-' + j);
			}
		}
		$('#departList').html(html);
	},
	// 打开科室详情页面
	js_openDepartDetail: function(elem) {
		var self = this;
		var index = elem.attr('data-index');
		index = index.split('-');
		var obj = departmentData.department[ index[0] ].child_department[ index[1] ];

		// 获取科室医生列表
		var depart_id = departmentData.department[index[0]].id;
		var param = [
			{poiid     : departmentData.poiid, sign: 1},
			{depart_id : depart_id},
			{child_id  : obj.child_id},
			{pagesize  : 10}
		];
		this.api.userAction('openDepartDetail',
			{poiid_departId_childId: departmentData.poiid + '_' + depart_id + '_' + obj.child_id});
		if (!obj.doctor_count || obj.doctor_count <= 0) {
			self.api.promptMessage('暂无医生数据');
			return;
		}
		this.api.aosrequest('hospitalDrInfo', param, function(res) {
			if (res.code != '1' || !res.doctors) {
				self.api.promptMessage('请稍后重试');
				return;
			}
			res.poiid = departmentData.poiid;
			res.depart_id = departmentData.department[index[0]].id;
			res.child_id = obj.child_id;
			res.child_name = obj.child_name;
			res.child_desc = obj.child_desc;
			self.util.storage('hospital.departmentInfo', JSON.stringify(res));
			self.util.locationRedirect('hospital_depart_detail.html');
		}, 1, true, 'get');
	}
});

/**
 * 生成列表元素模板.
 * @param {Object} obj 科室对象
 * @param {String} index 科室的索引
 * @return {String} html
 */
function tplDepartmentItem(obj, index) {
	if (!obj) {
		return '';
	}
	var hasDetail = obj.doctor_count > 0;
	return '<li class="line-half" ' +
			POI.handleAttr + '="js_openDepartDetail" data-index="' + index + '">' +
			obj.child_name +
			(hasDetail ? '<small> (' + obj.doctor_count + '人)</small>' : '') +
		'</li>';
}

})(POI, $);
