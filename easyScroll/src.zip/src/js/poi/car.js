//易车
;(function(POI, $) {

$.extend(POI, {
    init : function() {
        this.index.moduleDeepHead();
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "tag_special", "tag_car"]);
        this.index.moduleAll(null, introHtml);
    }
});

})(POI, Zepto);