/*场馆*/
;(function(POI, $) {

$.extend(POI,{
    init : function(){
        var self = this;
        self.index.moduleDeepHead();
        
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro"]),
            introAry = self.index.moduleAll(['nbaHotSearch', 'alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        self.pagebody.append(introAry.join(''));
        self.util.executeAfterDomInsert();
    }
});

})(POI, Zepto);
