;(function(POI, $) {
$.extend(POI, {

    // 买点page标识
    logPageId : "",

    tuanName:'',
    curPrice:'',
    rawPrice:'',
    quickInit : function() {
        var self = this;
        if(window.location.search){
            self.logPageId = 'tuangouFromLink';
            self.tuanGou(self.util.getUrlParam());
        }else{
            self.logPageId = 'tuangou';
            if(self.browser.and){
                self.send({"action":"tuanGou"}, self.tuanGou);
            }
        }
    },
    tuanGou : function(arg) {
        var self = this,
            params = [{'mergeid':arg.mergeID,'sign':1} ,
                {'groupid':arg.tuangouID,'sign':1} ,
                {'src_type':arg.src_type,'sign':1}];
        self.api.aosrequest({'params':params,'poiInfo':'','urlPrefix':'tuangouUrl','method':'GET','progress': 1, showNetErr: true} , function(dt){
            if (dt.code == -1 || dt.code == -2) {
                return;
            }
            self.exTuangou(dt,arg);
        });
    },
    //团购详情页
    exTuangou:function(infoItem, params){
        var self = this,
            tuangouID= params.tuangouID,
            mergeID= params.mergeID,
            src_type= params.src_type,
            source= params.source;
        try{
            if(self.fillData(infoItem,tuangouID, mergeID, src_type, source)){
                self.api.registShareBtn(self.getShareContent(tuangouID,mergeID,src_type)); 
            }
        }catch(e){
            self.notValidMono();
        }
        self.api.userAction('groupPv',
            {tuangouID:tuangouID,mergeID:mergeID,srcType:src_type}
        );
    },
    fillData : function(infoItem,tuangouID,mergeID,src_type,source){
        var self = this;
        if(infoItem.groupbuy && infoItem.groupbuy.group){
            var groupbuy=infoItem.groupbuy,
                shop=groupbuy.shop,
                groupInfo=groupbuy.group;
            self.groupInfo=groupInfo;
            if(shop&&shop.name){
                var titleName = shop.name;
                var keepPosi = titleName.lastIndexOf('(');
                if(keepPosi>0){
                    titleName = titleName.substring(0,keepPosi);
                }
                shop.name=titleName;
                document.title=self.tuanName=shop.name;//title设置
            }
            //图片
            if(groupInfo.master_pic){
                $('#toutuC').html( self.createImg(groupInfo.master_pic) ); 
            }
            //标题
            if(groupInfo.group_desc){
                $("#desc").html(groupInfo.group_desc).show();
            }
            //支持过期是否退、团购倒计时模块
            self.fill_group_refund(groupInfo);
            ////显示【适用分店】信息   全部31家店铺
            if(groupbuy.shopcount && groupbuy.shopcount>0){
                self.fill_nearestShop(groupbuy,tuangouID,mergeID,src_type);
            }
            //团购内容、购买须知
            self.fill_tuan_content(groupInfo);
            //到[大众点评]查看图文详情
            self.go_piclist(groupInfo,shop);
            //查看本店其他团购模块
            if(groupbuy.groupcount&&groupbuy.groupcount>1){//本店团购项大于1时，才显示此数据
                self.fill_others(groupbuy,tuangouID,mergeID)
            }
            //抢购按钮Fix层
            self.fixed_footerbtn(groupInfo,tuangouID,mergeID,src_type,source);
            // android平台底部固定适配
            self.browser.and && self.footer_hack();
            return true;
        }else{
            self.notValidMono();
            return false;
        }
        return false;
    },
    getShareContent:function(tuangouID,mergeID,src_type){
        var shareUrl=this.activityUrl.tuanGouShare
                +'?tuangouID='+tuangouID
                +'&mergeID='+mergeID
                +'&src_type='+src_type,
            shareMsg='超值团购：['+this.tuanName+']原价'+this.rawPrice+'，现价'+this.curPrice+'，快来抢购！',
            cont = [
                {type: 'weibo', message:'#来买我#'+shareMsg, title: '我用高德地图发现了一个超值团购，快来抢购！', url: shareUrl},
                {type: 'weixin', message:shareMsg, title: '用高德地图团购，每天有惊喜！', url: shareUrl},
                {type: 'pengyou', message:shareMsg, title:shareMsg, url: shareUrl}
            ];
        return cont;
    },
    notValidMono : function() {
        $('.tuangou').html($("#noDataC").html());
    },
    /*
        delete groupInfo.group_refund_expired;//过期
        delete groupInfo.group_refund_anytime;//随时
        groupInfo.group_free_appointment=1;//免预约
        delete groupInfo.group_sold_num;//销量
        支持过期是否退、团购倒计时模块
    */
    fill_group_refund : function(groupInfo){
        var self = this , infosArr=[];
        if(groupInfo.group_refund_expired==1){//支持过期退
            infosArr.push('<p class="iconTrue">支持过期退</p>');
        }else if(groupInfo.group_refund_expired==0){//不支持过期退
            infosArr.push('<p class="iconFalse">不支持过期退</p>');
        }
        if(groupInfo.group_refund_anytime==1){//支持随时退
            infosArr.push('<p class="iconTrue">支持随时退</p>');
        }else if(groupInfo.group_refund_anytime==0){//不支持过期退
            infosArr.push('<p class="iconFalse">不支持随时退</p>');
        }
        //免预约
        if(groupInfo.group_free_appointment==1){
            infosArr.push('<p class="iconTrue">免预约</p>');
        }
        //已购买人数
        if(groupInfo.group_sold_num){
            infosArr.push('<p class="iconPerson">'+groupInfo.group_sold_num+'人已购买</p>');
        }
        //活动结束倒计时
        if(groupInfo.group_time_end){
            infosArr.push('<p id="restTime" class="iconClock"></p>');
        }
        $("#activityInfos").html(infosArr.join(''));
        self.adjustPW();//信息定位
        $('#microInfo').show();
        //活动结束倒计时
        if(groupInfo.group_time_end){
            var timeEnd=new Date(groupInfo.group_time_end.replace(/-/g,'/') ).getTime();
            //var timeEnd= new Date("2013-10-13 18:04:00");
            self.setRestTime(timeEnd);
            var restTimer = setInterval(function(){
                if(self.setRestTime(timeEnd)){
                    clearInterval(restTimer);
                }
            },1000);
        }
    },
    adjustPW:function (){
        var w = ($(window).width()-26 - 48)/2;
            $p =$("#activityInfos p").css('width',w+'px'),
            len=$p.length;
        $p.eq(len-1).css('width','auto');
    },
    formateRestTime : function(restTime){
        var days= Math.floor(restTime/(3600000*24));
        if(days>99){
            return days+"天";
        }
        restTime=restTime%(3600000*24);
        var hours = Math.floor(restTime/3600000);
        restTime=restTime%3600000;
        var mins=Math.floor(restTime/60000);
        restTime=restTime%60000;
        var secs=Math.floor(restTime/1000);
        return days+"天"+hours+"小时"+mins+"分钟";//+secs+"秒"
    },
    setRestTime : function(timeEnd){
        var now =new Date().getTime();
        var restTime=timeEnd-now;
        if(restTime<0){
            $("#restTime").html("活动已结束");
            isRuning=false;
            return true;
        }else{
            $("#restTime").html(this.formateRestTime(restTime)+"结束");
            return false;
        }
    },
    fill_nearestShop : function(groupbuy,tuangouID,mergeID,srcType){//显示【适用分店】信息
        var self = this;
        if(groupbuy.shopcount>1){//店铺数量大于1时，才显示更多店铺链接
            $('#shopList h2').addClass('canTouch');
            $("#shopList em").html("全部"+groupbuy.shopcount+"家店铺");
            if(self.browser.ios) {
                $("#shopList h2").click(function(){
                        self.send({'action':'tuanGou','tuangouID':tuangouID,'mergeID':mergeID,'src_type':srcType});
                        self.api.userAction('tuangouShop');
                });
            } else {
                self.touchNoMove( $("#shopList h2"),function(){
                        self.send({'action':'tuanGou','tuangouID':tuangouID,'mergeID':mergeID,'src_type':srcType});
                        self.api.userAction('tuangouShop');
                });
            }
        }
        //获得最近分店信息
        self.send({'action':'getMapLocation','forceReturnValue':1},function(arg){
            var params=[{'tuanid':tuangouID,'sign':1} ,
                        {'mergeid':mergeID,'sign':1} ,
                        {'src':srcType,'sign':1} ,
                        {'latitude':arg.lat,'sign':0} ,
                        {'longitude':arg.lon,'sign':0} ,
                        {'pagesize':1,'sign':0} ,
                        {'pagenum':1,'sign':0}];
            self.api.aosrequest({'params':params,'poiInfo':'','urlPrefix':'nearestShop','method':'GET'},function(arg){
                self.exNearestShop(arg);
            });
        });
    },
    _kilometer : function(str){
        str+='';
        if( !str ){
            return str+'';
        }
        var tmp = parseFloat(str);
        if(tmp>1000){
            return (tmp/1000).toFixed(1) + 'km';
        }else{
            return tmp.toFixed(0) + 'm';
        }
    },
    //团购最近分店
    exNearestShop:function(shopData){
        if(shopData.shop_list && shopData.shop_list[0]){
            var self = this, shop=shopData.shop_list[0] , tmpA=[];
            //店名
            if(shop.name){
                tmpA.push("<p id='nearest'>"+shop.name+"</p>");
            }
            //地址、距离
            tmpA.push('<p>'+shop.address);
            if(self._kilometer(shop.meters)!="0m"){
                tmpA.push("<em>"+self._kilometer(shop.meters)+"</em>");
            }
            tmpA.push("</p>");
            $("#shopList article div").html(tmpA.join(""));
            $("#shopList").show();
            
            //联系电话
            if(shop.tel){
                $('#touchTel').bind('click',function(){
                    self.api.showPanellist(shop.tel.split(";"));
                    self.api.userAction('groupTel');
                }).addClass('canTouch');
            }else{//没有联系电话
                $('#touchTel').addClass('disabled');
            }
            //打开POI点
            $('#searchRoute').bind('click',function(){
                self.api.openPoiInfo(shop.poiid, shop.name, shop.address, '', '', shop.tel, shop.x, shop.y);
                self.api.userAction('openPoi');
            });
        }
    },
    touchNoMove : function($elem,fn){
        var self = this;
        $elem.bind("touchstart",function(){
            $elem.attr('touchNoMove_startY',self.getCoord('Y'));
        }).bind('touchend',function(){
            if( Math.abs( self.getCoord('Y') - $elem.attr('touchNoMove_startY') )<=2 ){
                fn();
            }
        });
    },
    getCoord : function(c){
        var e=window.event,org = e.originalEvent,ct = e.changedTouches;
        return ct || (org && org.changedTouches) ? (org ? org.changedTouches[0]['page' + c] : ct[0]['page' + c]) : e['page' + c];
    },
    createImg:function(url){
        var ret=[];
        ret.push('<img ');
        if(url){
            ret.push(' class="img-loading" ')
            ret.push(' src="'+ url+ '" ');
            ret.push(' onerror=" this.src=\'img/empty.png\'; this.className=\'img-err\'; " ');
            ret.push(' onload=" if(this.className!=\'img-err\'){this.className=\'\'}; " ');
        }else{//没有url参数
            ret.push('class="img-def"  src=\'img/empty.png\' ');
            ret.push(' "');
        }
        ret.push(' />');
        return ret.join("");
    },
    fill_tuan_content : function(groupInfo){
        if(groupInfo.src_name && groupInfo.group_content && groupInfo.group_content.trim()){
            $("#xsnr h3").html("凭"+groupInfo.src_name+"团购券可享受以下内容");
            var dataStr = groupInfo.group_content.replace(/(\r\n)|(\n\r)|(\r)/g, "\n");
            var dataArr = dataStr.split('\n');
            dataStr = '<p>' + this.filterNullStr(dataArr).join('</p><p>') + '</p>';
            $("#xsnrTxt").html(dataStr);
            $("#xsnr").show();
            this.viewMoreInfo({id:'xsnrTxt',showLines:4});
        }
        //购买须知,有" "这种数据
        if(groupInfo.group_detail && groupInfo.group_detail.trim()){
            var tmpA = groupInfo.group_detail.split("\n");
            tmpA = this.filterNullStr(tmpA);
            $("#gmxzTxt").html( '<p>'+tmpA.join("</p><p>")+'</p>' );
            $("#gmxz").show();
            this.viewMoreInfo({id:'gmxzTxt',showLines:5});
        }
    },
    //滤掉空字符串
    filterNullStr : function(tmpA){
        return $.grep(tmpA, function(item){
            return item && item.trim().length>0;
        });
    },
    viewMoreInfo:function(options) {
        options = $.extend({
            showLines:3,
            minStateBtnText:'查看全文',
            maxStateBtnText:'收起全文'
        },options);
        
        function getNum(val) {
            return parseInt(val) || 0;
        }
        function innerHeight($obj){
            var h = $obj.height();
            var pt = getNum($obj.css('paddingTop')), 
                pb = getNum($obj.css('paddingBottom')), 
                mt = getNum($obj.css('marginTop')), 
                mb = getNum($obj.css('marginBottom'));
            return h - (pt + pb + mt + mb);
        }
        
        var self = this, $maxT = $('#' + options.id), showLines = options.showLines,
            oldHtml=$maxT.html(), lineH = innerHeight($maxT.html('<p>国</p>')),//单行高度
            initH= showLines*lineH,//初始化高度
            actualH=innerHeight( $maxT.html(oldHtml) );//实际高度
        if(actualH>initH){
            var $minT = $('<div style="display:block;overflow:hidden;">' + oldHtml + '</div>');
            $minT.insertBefore($maxT).height(initH);
            $maxT.hide().removeClass('lineDot');
        
            var $minStateBtn = $('<p class="note" style="display:block;">'+options.minStateBtnText+'</p>'), 
                $maxStateBtn = $('<p class="note" style="display:none;">'+options.maxStateBtnText+'</p>');
            $minStateBtn.insertAfter($maxT);
            $maxStateBtn.insertAfter($maxT);
            $minStateBtn.bind('click', function() {
                        $maxT.show();
                        $maxStateBtn.show();
                        $minStateBtn.hide();
                        $minT.hide();
                        self.api.userAction(options.id+'_openTxt');
                    });
            $maxStateBtn.bind('click', function() {
                        $maxT.hide();
                        $maxStateBtn.hide();
                        $minStateBtn.show();
                        $minT.show();
                        self.api.userAction(options.id+'_closeTxt');
                    });
        }
    },
    go_piclist : function(groupInfo,shop){//到[大众点评]查看图文详情按钮点击处理
        var self = this, ggdUrl = groupInfo.group_graphic_detail_url;
        if( groupInfo.src_name && ggdUrl ){
            $("#viewGraph").html("到"+groupInfo.src_name+"查看图文详情").click(function(){
                if(self.browser.and && groupInfo.group_graphic_detail_gotoH5 == 1) { // 图文详情
                    var sendParam={
                        'srcType':groupInfo.src_type,
                        'actType':self.actType||'',
                        'rawPrice':groupInfo.group_price_ori,
                        'curPrice':groupInfo.group_price,
                        'graphUrl':ggdUrl,
                        'buyUrl': groupInfo.group_compete_buy_wapurl,
                        'marginTop':groupInfo.group_graphic_detail_title_height
                    },tt = 'http://wap.amap.com/tuangou/tuangouGraphPage.html?'
                        +'tuanName='+shop.name
                        +'&params='+decodeURIComponent( Base64.encode( JSON.stringify(sendParam) ) );
                    self.api.getAppPara('','', tt );
                    self.api.userAction('ggdH5_' + ggdUrl );
                } else {
                    self.api.getAppPara('','', ggdUrl );
                    self.api.userAction('ggd_' + ggdUrl );
                }
            }).parent().show();
        }
    },
    fill_others : function(groupbuy,tuangouID,mergeID){//查看本店其他团购模块
        var self = this ,
            params=[{'poiid':groupbuy.poiid,sign:1},
                    {pagesize:2},
                    {pagenum:1},
                    {classify:0},
                    {classify_data:'sort_rule=2'}];
        //请求本店其他团购
        self.api.aosrequest({'params':params,'urlPrefix':'nearbyTuanType','method':'GET'},function(arg){
            self.shopOtherTuan(arg,tuangouID,mergeID);
        });
        $("#otherCount").html(groupbuy.groupcount).parent().click(function(){
            self.api.triggerFeature('tuangouList', {poiid: groupbuy.poiid||''}, {source:'shopMore'});
            self.api.userAction('viewOthers');
        }).parent().show();
    },
    //本店其他团购
    shopOtherTuan:function(tuanInfo,tuangouID,mergeID){
        if(tuanInfo && tuanInfo.tuan_list){
            var self = this, tuanArr = [], item ,
                list = tuanInfo.tuan_list || [],
                len = list.length;
            if(len){
                for (var i = 0; i < len; i++) {
                    item = list[i];
                    if(item.id==tuangouID && item.mergeid==mergeID){//排除本单
                        continue;
                    }
                    tuanArr.push('<article class="splitLine flexBox canTouch " oid="'+item.id+'" mergeid="'+item.mergeid+'" src_type="' + item.src + '">');
                    tuanArr.push('<div>');
                    tuanArr.push( self.createImg(item.pic_url) );
                    if (item.isappointment== "1") {
                        tuanArr.push('<i>免预约</i>');
                    }
                    tuanArr.push('</div>');
                    tuanArr.push('<hgroup>');
                    if(item.description){
                        tuanArr.push('<h4 class="content linesDot">' + item.description + '</h4>');
                    }
                    if(item.price_current && item.price_previous){
                        tuanArr.push('<h5><span>' +item.price_current
                                + '</span><del>' + item.price_previous+ '</del>');
                        if(item.brought && item.brought>0 ){
                            tuanArr.push('<em>'+item.brought + '人已购买'+'</em>');
                        }
                        tuanArr.push('</h5>');
                    }
                    tuanArr.push('</hgroup>');
                    tuanArr.push('</article>');
                    break;
                }
                $('#viewOthers').append(tuanArr.join("")).on('click', 'article.splitLine', function() {
                    var obj = $(this);
                    obj.attr('oid').length && (location.href = 'exTuangou.html?type=tuan&tuangouID='+obj.attr('oid')+'&mergeID='+obj.attr('mergeid')+'&src_type=' + obj.attr('src_type') + '&source=shopOthers' + (window.hasWebPageTitleBar ? '&showTitleBar=1' : ''));
                     self.api.userAction('tuan_tuan');
                });
            }
        }
    },
    fixed_footerbtn : function(groupInfo,tuangouID,mergeID,srcType,source){//底部抢购按钮模块点击效果控制
        var self = this;
        if(groupInfo.group_price&&groupInfo.group_price_ori) {
            self.curPrice=groupInfo.group_price;
            self.rawPrice=groupInfo.group_price_ori;
            $("#curPrice").html('<i>'+groupInfo.group_price+'</i>');
            $("#rawPrice").html('<del>'+groupInfo.group_price_ori+'</del>');
            if(groupInfo.group_compete_buy_wapurl) {
                $("#buy").click(function(){
                    self.api.userAction('groupbuyButtonClick',{tuangouID:tuangouID,mergeID:mergeID,srcType:srcType});
                    self.api.userAction('rb_'+source+'_'+ groupInfo.group_compete_buy_wapurl,{tuangouID:tuangouID,mergeID:mergeID,srcType:srcType});
                    self.api.getAppPara('','',groupInfo.group_compete_buy_wapurl);
                });
            } else {
                $("#buy").hide();
            }
            if(groupInfo.act_id){
                if(groupInfo.act_id==1){//三方自己搞的立减活动
                    self.showFlag({type:'lijian',offsale:groupInfo.offsale});
                }else if(groupInfo.act_id>1){
                    if(groupInfo.act_type!=undefined){
                        if(groupInfo.act_type==0){
                            self.showFlag({type:'lijian',offsale:groupInfo.offsale});
                        }
                    }
                }
            }
            $("footer").css("display","-webkit-box");
        } else {
            $('body').css("paddingBottom","10px");
        }
    },
    showFlag:function(flagObj){
        var type=flagObj.type;
        if(type=='lijian'){
            var offsale = flagObj.offsale;
            if(offsale && offsale>0){
                this.addCssTxt(".tuangou footer.lijian i:after {content: '立减 ￥"+offsale+"';}");
            }
            $("footer").addClass(type);    
        }
    },
    addCssTxt:function(styleTxt){
            var style = document.createElement('style');
        style.rel = 'stylesheet';
        style.type = 'text/css';
        style.innerText=styleTxt;
        document.getElementsByTagName('head')[0].appendChild(style);
    },
    footer_hack : function(){//底部固定适配
        var timer = null , isUserOP=true;
        document.body.scrollTop=1;
        setTimeout(function(){
            document.body.scrollTop=0;
        },1);
        //fix：小米滑动屏幕，出现白条时，点不到fixed上的按钮
        $(window).bind('scroll',function(){
            clearTimeout(timer);
            if(isUserOP){
                timer = setTimeout(function(){
                    isUserOP=false;
                    document.body.scrollTop=document.body.scrollTop;
                    clearTimeout(timer);
                },600);
            }else{
                isUserOP=true;
            }
        });
    }
});
})(POI, Zepto)