/**
 * 幼儿园详情页.
 */
;(function(POI, $) {
'use strict';

$.extend(POI, {
	init: function() {
		var self = this;
		var deep = self.aosData.deep[0];

		var classify = self.index.moduleHeadItem(deep.nature) + self.index.moduleHeadItem(deep.level);
		self.index.moduleDeepHead(classify);

		var introHtml = self.index.moduleIntro(['幼儿园图片', '', '幼儿园概况'], 'intro');
		var html = self.index.moduleAll(['alipayDiscount', tplPage(deep),
			'rti', 'stopStrategy', 'shoppingGuide', 'guidePicList',
			'activityInfo', introHtml, 'impression', 'commentInfo',  'indoorMap', 'banner', 'placeContribution']);
		self.pagebody.html( html.join('') );
		self.util.executeAfterDomInsert();
	}
});

/**
 * 幼儿园所有模板.
 * @param {Object} deep
 * @return {String} html
 */
function tplPage(deep) {
	return tplSpecialInfo(deep.tag_special) + tplEnrollment(deep.enrollment);
}
/**
 * 幼儿园特色模板.
 * @param {Array} list 特色列表
 * @return {String} html
 */
function tplSpecialInfo(list) {
	if (!list || !list.length) {
		return '';
	}
	var itemList = '';
	for (var i = 0, len = list.length; i < len; i++) {
		itemList += tplSpecialItem(list[i]);
	}

	return '<section class="kindergarten-special">' +
			'<h3 class="title">幼儿园特色</h3>' +
			'<div class="special">' +
				'<ul class="special-list clearfix" style="width:' + 7 * list.length + 'rem;">' +
					itemList +
				'</ul>' +
			'</div>' +
		'</section>';
}
function tplSpecialItem(obj) {
	var specialIcon = {
		'数学': 1,
		'英语启蒙': 2,
		'双语教学': 3,
		'阅读': 4,
		'纸工创意': 5,
		'泥工创意': 6,
		'美术艺术': 7,
		'外教': 8,
		'幼儿舞蹈': 9
	};
	var icon = specialIcon[obj.spe_desc];
	if (!icon) {
		return '';
	}
	return '<li>' +
			'<cite class="icon icon' + icon + '"></cite>' +
			'<p class="text">' + obj.spe_desc + '</p>' +
		'</li>';
}
/**
 * 招生信息模板.
 * @param {Object} obj
 * @return {String} html
 */
function tplEnrollment(obj) {
	if (!obj) {
		return '';
	}

	return '<section class="kindergarten-enrollment">' +
			'<h3 class="title">招生信息</h3>' +
			'<div class="info line-half">' +
				(obj.enro_num ? '<div>招生人数<p class="value">' + obj.enro_num + '人</p></div>' : '') +
				(obj.class_num ? '<div>班级数量<p class="value">' + obj.class_num + '个</p></div>' : '') +
				(obj.care_fee ? '<div>保育费<p class="value">' + obj.care_fee + '元</p></div>' : '') +
				(obj.meals ? '<div>伙食费<p class="value">' + obj.meals + '元</p></div>' : '') +
			'</div>' +
			'<article class="intro">' +
				(obj.enro_way ? '<div class="line">' +
						'<span class="left">招生方式</span>' +
						'<div class="right">' + obj.enro_way + '</div>' +
					'</div>' : '') +
				(obj.fee_desc ? '<div class="line">' +
						'<span class="left">费用说明</span>' +
						'<div class="right">' + obj.fee_desc + '</div>' +
					'</div>' : '') +
				(obj.notes ? '<div class="line">' +
						'<span class="left">注意事项</span>' +
						'<div class="right">' + obj.notes + '</div>' +
					'</div>' : '') +
			'</article>' +
		'</section>';
}

})(POI, $);
