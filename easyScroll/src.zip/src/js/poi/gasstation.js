/**
 * 加油站相关
 */
;(function(POI, $){

$.extend(POI, {
    
    //油价信息
    showGasInfo : function(gaslist) {
        if(!gaslist || 0 === gaslist.length)
            return '';
        var list = [],
            oilName = "",
            gasMap = {
                "o_89" : "90",
                "o_92" : "93",
                "o_95" : "97"
            };
        for(var j = 0,lens = gaslist.length, priceList = null; j < lens; j++) {
            priceList = gaslist[j].price_list;
            for(var i = 0,len = priceList.length; i < len; i++) {
                var priceItem = priceList[i],
                    gastype = parseFloat(priceItem.gastype);
                if(gastype || 0 === gastype) {
                    oilName = 40 > gastype ? "柴油" : "汽油";
                    var origas = gasMap["o_" + gastype],
                        gasName = origas ? gastype + "#" + oilName + '(原' + origas + '#)' : gastype + oilName;
                    list.push('<li>' + gasName + '<span class="oilprices_con_right"><span>' + (priceItem.price ? priceItem.price : "") + '</span>元/升</span></li>');
                }
            }
        }
        if(list.length) {
            return '<section class="oilprices">' +
                       '<h2 class="module_title_p line-half">参考油价</h2>' +
                       '<ul class="oilprices_con">' + 
                           list.join('') + 
                       '</ul>' +
                   '</section>';
        } else {
            return '';
        }
    },
    
    showGasService:function(service){
        // service = '加油卡,便利店,柴油自助加油,便利店,便利店';
        if(!service)
            return '';
        
        var serviceArr = service.split(','),
            strArr = [];
        for(var i = 0, len = serviceArr.length; i < len ; i++){
            strArr.push(serviceArr[i] ? '<li class="oilservice_li half-border">' + serviceArr[i] + '</li>' : '');
        }

        POI.util.executeAfterDomInsert(function() {
            var $serviecDetail = $('#serviecDetail'),
                $checkMore = $('#checkMore');
            var oHeight = $serviecDetail.height();
            if(oHeight > 72){
                $serviecDetail.addClass('limits');
                $checkMore.show();
                new POI.util.toggleContent($checkMore,$serviecDetail,{eleContent:{showAll:'查看更多',hidePort:'收起'}});
            }else {
                $checkMore.hide();
            }
        });

        return '<section class="oilservice">' +
                   '<h2 class="module_title_p line-half">服务</h2>' +
                   '<div id="serviecDetail">' +
                       '<ul class="oilservice_con">' + strArr.join('') + '</ul>' +
                   '</div>' +
                   '<div id="checkMore" name="more" class="introFold">查看更多</div>' +
               '</section>';
    },
    
    gasstationPageList : function(gasInfoStr, gasServiceStr) {
        var htmlStr = gasInfoStr + gasServiceStr;
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2"]);
        var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        this.pagebody.html(htmlStr + allAry.join(""));
        POI.util.executeAfterDomInsert();
    },
    
    init : function() {
        var base = this.aosData.base;
        var headInfo = this.index.moduleHeadItem(base.brand_title);
        this.index.moduleDeepHead(headInfo);
        this.gasstationPageList(
            this.showGasInfo(this.aosData.rti.gasstation),
            this.showGasService(this.aosData.deep[0].service)
        );
    }

});

})(POI, Zepto);
