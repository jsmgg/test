/**
 * 首页团购优惠入口相关
 */
(function(POI, $) {
  'use strict';
  $.extend(POI, {
    groupData : '',
    discountData : '',
    couponData : '',
    isGroup : false,
    isDiscount : false,
    isCoupon : false,
    // fInitGroup: function() {},
    fSerializeGroupData: function() {
      //团购 优惠
      var self = this,
        deep = self.aosData.deep[0],
        rti = self.aosData.rti,
        coupon = deep.coupon || [],
        groupbuy = rti.groupbuy || {},
        _discount = rti.discount || [],
        discountLen = _discount.length,
        aDataBefore = ['<div id="tuanContainer"><aside id="gro_dis"><div>'],
        aDataAfter = ['</div></aside><div>'];

      var _fShowGroupData = function() {
          return '<section class="sale_sec">' +
                     '<h2 class="sale_title module_title_p line-half'+ (groupbuy.amount > 1 ? ' more' : '') +'" '+ (  groupbuy.amount > 1 ? self.handleAttr + '="js_triggerGroup"' : '') +'>团购&nbsp;' +
                         (groupbuy.amount > 0 ? '<span class="small_text">(共' + groupbuy.amount + '个)</span>' : '') +
                     '</h2>' +
                     '<div class="sale_wrapper canTouch" ' + self.handleAttr + '="js_triggerGroupItem" tuanid="' + groupbuy.groupid + '" mergeid="' + groupbuy.mergeid + '" srctype="' + groupbuy.src_type + '">' +
                         '<div class="sale_common sale_price">' +
                             (groupbuy.group_price > 0 ? '<p class="sale_price_now' + (groupbuy.group_price > 999 ? ' small' : '') + '">￥' + groupbuy.group_price + '&nbsp;</p>' : '') +
                             (groupbuy.group_price_ori > 0 ? '<p class="sale_price_ori">' +groupbuy.group_price_ori  + '</p>' : '') +
                         '</div>' +
                         '<div class="sale_detail">' +
                             '<p class="sale_main lineDot">' + (groupbuy.group_desc || '') + '</p>' +
                             ((groupbuy.group_sold_num | 0) ? '<p class="sale_count">已售：' + groupbuy.group_sold_num + '份</p>' : '') +
                         '</div>' +
                     '</div>' +
										 ((rti.scenic_ticket_flag && rti.scenic_ticket_flag.length || rti.scenic_guide) ? '<div class="scenic-group-more" js_handle="js_triggerGroup">查看全部</div>' : '') + 
                 '</section>';
        },
        _fShowDiscountData = function() {
            var discount = _discount[0];
            if (!discount.discount_title && !discount.discount_desc) {
              return '';
            }
            var desc = discount.discount_title || discount.discount_desc;
            
            var _desc = desc.length > 20 ? (desc.substring(0, 20) + '...') : desc;
            return '<section class="sale_sec">' +
                       '<h2 class="sale_title module_title_p line-half' + (rti.discount_total > 1 ? ' more' : '') + '" '+( rti.discount_total > 1 ? self.handleAttr+'="js_triggerDiscountList"' : '')+'>优惠&nbsp;' +
                           (rti.discount_total > 0 ? '<span class="small_text">(共' + rti.discount_total + '个)</span>' : '') +
                       '</h2>' +
                       '<div class="sale_wrapper canTouch" '+self.handleAttr+'="js_triggerDiscount">' +
                           '<div class="sale_common sale_discount"><p class="sale_discount_icon">惠</p></div>' +
                           '<div class="sale_discount_wrapper">' +
                               '<p class="sale_detail_discount">' + (_desc || '') + '</p>' +
                           '</div>' +
                       '</div>' +
                   '</section>';
        },
        _fShowHospitalDiscountData = function() {
          var register_btn = deep.order_url?'<div class="reserve more" ' + POI.handleAttr + '="js_open3Order"><span class="icon"></span>预约挂号</div>':'';
          if (discountLen <= 0) {
            if (register_btn.length > 0) {
              return '<section class="hospital_discount_reserve  divide-line all-line">'+
                       register_btn+
                     '</section>';
            } else {
              return '';
            }
          }
          var discount = _discount[0];
          var handdle = 'js_triggerDiscountList';
          if (!discount.discount_shortname) {
            if (register_btn.length > 0) {
              return '<section class="hospital_discount_reserve  divide-line all-line">'+
                       register_btn+
                     '</section>';
            } else {
              return '';
            }
          }
          if (discount.src_type == 'hospital_yuguo_api') {
            handdle = 'js_triggerHospitalDis';
          }
          var title = discount.discount_shortname;
          var num_str = rti.discount_total && rti.discount_total != 0?'<p class="discount_num"><span>共'+rti.discount_total+'条信息</span></p>':'';

          return '<section class="hospital_discount_reserve  divide-line all-line">'+
                   '<div class="discount  divide-line all-line more" '+POI.handleAttr+'="'+handdle+'" data-type="'+discount.src_type+'">'+
                     '<span class="icon"></span>'+
                     '<p class="cont">'+title+'</p>'+
                     num_str+
                   '</div>'+
                   register_btn+
                  '</section>';
        },
        _fShowCouponData = function() {
            var lowPrice = Number(rti.group_coupon_price_lowest);
            lowPrice = lowPrice > 0 ? ',' + lowPrice + '元起!' : '';
            return '<section class="sale_sec">' +
                       '<h2 class="sale_title module_title_p line-half more" '+self.handleAttr+'="js_triggerCoupon">优惠券</h2>' +
                       '<div class="sale_wrapper canTouch" '+self.handleAttr+'="js_triggerCoupon">' +
                           '<div class="sale_common sale_coupon"><p class="sale_discount_icon">券</p></div>' +
                           '<div class="sale_discount_wrapper"><p class="sale_detail_discount">购买影院兑换券' + lowPrice + '</p></div>' +
                       '</div>' +
                   '</section>';
        }

      if (groupbuy.amount) {
        self.groupData = _fShowGroupData();
        POI.api.userAction('tuanlogshow');
      }

      if (self.business != 'cinema') {
        if (self.business == 'hospital') {//770新增，医院行业，优惠
          self.discountData = _fShowHospitalDiscountData();
          POI.api.userAction('hospitalhuilogshow');
        } else {
          if (discountLen > 0) {
            self.discountData = _fShowDiscountData();
            POI.api.userAction('huilogshow');
          }
        }        
      }
      if (self.business == 'cinema' && coupon.length > 0) {
        self.couponData = _fShowCouponData();
        POI.api.userAction('quanlogshow');
      }
      
      return self.groupData + self.discountData + self.couponData;
    },
    dinningGroupopen : function(){
        //团购 优惠
        var self = this,
            html = [],
            rti = self.aosData.rti,
            groupbuy = rti.groupbuy || {},
            _discount = rti.discount || [],
            discountLen = _discount.length;
        if( groupbuy.amount ) {//团购
            html.push( '<div class="tuan_item canTouch" js_handle="js_triggerGroupItem" tuanid="' + groupbuy.groupid + '" mergeid="' + groupbuy.mergeid + '" srctype="' + groupbuy.src_type + '">' );
            html.push( '<i class="tuan_icon"></i>' );
            html.push( '<p class="tuan_desc">'+ (groupbuy.group_desc || '') +'</p>' );
            html.push( '<em class="tuan_price">'+ (groupbuy.group_price > 0 ? '￥'+groupbuy.group_price : '') +'</em>' );
            html.push( '<em class="tuan_price_ori">'+ (groupbuy.group_price_ori||'') +'</em>' );
            (groupbuy.group_sold_num | 0) && html.push( '<em class="tuan_count">已售：'+(groupbuy.group_sold_num | 0)+'份</em>' );
            html.push( '</div>' );
            self.api.userAction('tuanModShow');
        }
        if( discountLen ) {
            var discount = _discount[0];
            var desc = discount.discount_title || discount.discount_desc;
            html.push( '<div class="hui_item canTouch" js_handle="js_triggerDiscount">' );
            html.push( '<i class="hui_icon"></i>' );        
            html.push( '<p class="hui_desc">'+(desc||'')+'</p>' );
            html.push( '</div>' );
            self.api.userAction('discountModShow');
        }
        if( groupbuy.amount || discountLen ) {
            html.unshift( '<section class="tuan_hui" id="js_dinning_tuanhui">' );//topline
            if( groupbuy.amount>1 || rti.discount_total>1 ){
                html.push( '<div class="tuan_hui_more canTouch" js_handle="js_tuanhui_list"><span>全部团购优惠</span></div>' );
            }
            html.push( '</section>' );
            self.api.userAction('moreTuanBtnShow');
        }
        return html.join( '' );
    },
    js_triggerHospitalDis: function(ele) {
      var self = this;
      var type = ele.attr('data-type');
      var poiid = self.clientData.poiInfo.poiid;
      
      self.api.userAction('showYuGuoDetail',{type:type});
      
      self.util.loadResources(['css/hospital_vip.css','js/poi/hospitalVip.js'],function(){
          POI.yuGuoDetail && POI.yuGuoDetail.show(type);
      });
      var params = [
        {poiid: poiid || '', sign : 1},
        {src_type: type}
      ];
      
      self.api.aosrequest('discountList', params, function(arg) {
        if (arg.code == -1 || arg.code == -2 || !arg.discount_info || !arg.discount_info.length) {
          return;
        }
        self.util.storage('yuguoData', JSON.stringify(arg.discount_info));
      }, 1, true, "GET");
    },
    //医院预约挂号
    js_open3Order: function() {
        this.api.userAction('open3Order');
        this.api.openThirdUrl(this.aosData.deep[0].order_url);
    },
    js_triggerGroup:function(){
        this.js_tuanhui_list( 'groupbuy' );
        return false;
    },
    js_triggerGroupItem:function(ele) {
        var self=this,Api=self.api,Obj = self.clientData;
        Api.userAction('groupbuyItem',{tuanid:ele.attr("tuanid")});
        POI.util.locationRedirect("exTuangou.html?type=tuan&tuangouID="+ele.attr("tuanid")+"&mergeID="+ele.attr("mergeid")+"&src_type=" + ele.attr("srctype") + "&source=poiIndex&showTitleBar=1");
        return false;
    },
    js_triggerDiscountList:function() {
        this.js_tuanhui_list( 'discountList' );
        return false;
    },
    js_triggerDiscount:function() {
        var self=this,
            rti = self.aosData.rti;
      self.util.loadResources("js/poi/discount.js", function() {
        try{self.show_discountlist( rti.discount );}catch(e){}
      });
      self.api.userAction('discount');
      return false;
    },
    js_triggerCoupon:function(){
      var self=this;
      self.util.locationRedirect('exMovieTuan.html?poiid='+ self.clientData.poiInfo.poiid + "&showTitleBar=1");
      self.api.userAction('movieQuan');
      return false;
    },
    _groupopen_tuanhui_cache : {},
    js_tuanhui_list : function( log ) {
        var self = this,key,
            poiid = self.clientData.poiInfo.poiid,
            rti = self.aosData.rti,
            groupbuy = rti.groupbuy || {},
            _discount = rti.discount || [],
            discountLen = _discount.length;
        if( groupbuy.amount > 0 ) {//如果有团购数据，则先请求一屏团购数据
            var params = [
                {poiid:poiid,sign:1},
                {pagesize:20},
                {pagenum:1},
                {classify:0}
            ];
            key = 'nearbyTuanType'+JSON.stringify(params);
            if( self._groupopen_tuanhui_cache[ key ] ) {
                tuan(self._groupopen_tuanhui_cache[ key ]);
            } else {
                self.api.aosrequest({
                    params : params,
                    urlPrefix:'nearbyTuanType',
                    progress:1, showNetErr: true,
                    method : 'get'
                }, tuan);
            }
        } else {
            var params = [{poiid:poiid,sign:1}];
            key = 'discountList'+JSON.stringify(params);
            if( self._groupopen_tuanhui_cache[ key ] ) {
                hui(self._groupopen_tuanhui_cache[ key ]);
            } else {
                self.api.aosrequest({params: params, poiInfo:'', urlPrefix:'discountList', progress:1, showNetErr: true, method:'get'}, hui);
            }
        }
        self.util.loadResources(["css/tuanhuiList.css","js/poi/tuanhuiList.js"]);
        self.api.userAction( typeof log == 'string' ? log : 'groupTuanhuiList' );
        function tuan( dt ) {
            if( dt.code == 1){
                self.util.loadResources(['css/tuanhuiList.css','js/poi/tuanhuiList.js'], function(){
                    self.tuanhuiList_rander(poiid, discountLen, self.aosData.base.name , dt, null);
                });
                self._groupopen_tuanhui_cache[ key ] = dt;
            }
        }
        function hui(arg) {
            if (arg.code == -1 || arg.code == -2 || !arg.discount_info || !arg.discount_info.length) {
                return;
            }
            self.util.loadResources(['css/tuanhuiList.css','js/poi/tuanhuiList.js'], function(){
                self.tuanhuiList_rander(poiid, discountLen, self.aosData.base.name , null, arg.discount_info);
            });
            self._groupopen_tuanhui_cache[ key ] = arg;
        }
    }
  });
})(POI, Zepto);
