/**
 * NBA热搜词模块
 */
;
(function(POI, $) {

'use strict';
$.extend(POI, {
	nbaHotSearch: {
		get_html: function() {
			var that = this;
            var rti = POI.aosData.rti;
            
            if (!rti.nba_keywords || (rti.nba_keywords && rti.nba_keywords.length < 1)) {
            	return '';
            }

            POI.util.executeAfterDomInsert(function() {
            	var html = '';
            	html = that.makeNbaSearchHtml(rti.nba_keywords);
            	$('#nbaSearchDom').replaceWith(html);
            	POI.api.userAction('showNBAHotSearch');
            });

            return '<div id="nbaSearchDom"></div>';
		},
	    makeNbaSearchHtml: function(arr) {
	    	var that = this;
	    	var handleAttr = POI.handleAttr;
	    	var li_arr = [];

	    	var pre_section = '<section class="nba_search">'+
	    					  '<h2 class="module_title_p line-half">NBA热词</h2>'+
	    					  '<ul class="nbashenma_list">';
	    	var last_section = '</ul></section>';

	    	for (var i=0; i<arr.length; i++) {
		        var li_str = '<li data-url="'+arr[i].url+'" '+handleAttr+'="js_goToShenmaSearchNBA" data-name="'+arr[i].keyword+'"><span>'+arr[i].keyword+'</span></li>';
		        li_arr.push(li_str);
		    }
		    
		    return pre_section+li_arr.join('')+last_section;
	    }
	},
	js_goToShenmaSearchNBA: function(ele) {
    	var url = ele.data('url');
    	var name = ele.data('name');
    	
    	POI.api.openThirdUrl(url);
      	POI.api.userAction('NBAShenmaSerach', {name: name});
    }
});

})(POI, Zepto);
