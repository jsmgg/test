/**
 * 淘宝商家信息.
 */
;(function(POI, $) {

'use strict';

/**
 * 获取优惠和热销商品信息.
 * @param {Object} shop 商品信息
 */
function getGood(shop) {
    POI.api.aosrequest('taobaoshopActivity', [
        {id            : shop.shopid, sign: 1},
        {nick          : shop.nick, sign: 1},
        {coupon_count  : 1},
        {hotsell_count : 3}
    ], function(res) {
        if (res.code != '1') {
            return;
        }
        $('#taobao').append(tplCoupon(res.coupon_data) + tplHot(res.hotsell_data));
    }, 0, 0, 'get');
}

function tplCoupon(list) {
    if (!list || !list.length) {
        return '';
    }
    var html = '';
    for (var i = 0, len = list.length; i < len; i++) {
        if (list[i] && list[i].name) {
            html += '<h3 class="preferential module_title_p line-half-after lineDot">' +
                list[i].name + '</h3>';
        }
    }
    POI.api.userAction('taobaoCouponShow');
    return html;
}
function tplHot(list) {
    if (!list || !list.length) {
        return '';
    }
    var html = '';
    for (var i = 0, len = list.length; i < len; i++) {
        html += tplHotItem(list[i]);
    }
    POI.api.userAction('taobaoHotShow');
    return '<article class="sell-well">' +
            '<h2 class="module_title_p line-half-after">热销商品</h2>' +
            '<ul>' + html + '</ul>' +
        '</article>';
}
function tplHotItem(obj) {
    if (!obj) {
        return '';
    }
    return '<li js_handle="js_openShopGood" data-url="' + obj.url + '">' +
            '<div class="head-pic" style="background-image:url(' + obj.pic + ');">' +
                '<p class="price">￥' + obj.final_price + '</p>' +
            '</div>' +
            (obj.name ? '<p class="sale_name linesDot">' + obj.name + '</p>' : '') +
            '<p class="sales lineDot">月销：' + getSoldCount(obj.sold_count || 0) + '笔</p>' +
        '</li>';
}

function getShopLevel(score) {
    score = Number(score);
    if (score < 4) {
        return '';
    }
    var levelScore = [10, 40, 90, 150, 250,
            500, 1000, 2000, 5000, 10000,
            20000, 50000, 100000, 200000, 500000,
            1000000, 2000000, 5000000, 10000000];
    var level = 0;
    for (var len = levelScore.length; level < len; level++) {
        if (score <= levelScore[level]) {
            break;
        }
    }
    return '<div class="store-level level' + (Math.floor(level / 5) + 1) +
            ' num' + (level % 5 + 1) + '"></div>';
}

function getSoldCount(count) {
    count = count | 0;
    if(9999 < count) {
        count = count / 10000;
        count = count.toFixed(1) + "万";
    }
    return count;
}

POI.taobao = {
    
    isTmall : false, // 是否是天猫店铺
    
    moduleInit: function(taobao) {
        this.isTmall = POI.util.bool(taobao.is_b2c_shop);
        getGood(taobao);
        if(this.isTmall) {
            // 天猫店铺
            POI.api.userAction('tmallShow');
            return '<section id="taobao" class="taobao-store tmall">' +
                       '<h2 class="module_title_p title lineDot">' +
                           '<span>' + taobao.title + '</span>' +
                           '<cite class="goto-store" data-url="' + taobao.url +
                               '" js_handle="js_openShop">进店逛逛</cite>' +
                       '</h2>' +
                       '<article class="store-info">' +
                           '<cite class="store-type lineDot">' + (taobao.m_catlist && taobao.m_catlist[0] || '') + '</cite>' +
                       '</article>' +
                   '</section>';
        } else {
            // 淘宝店铺
            POI.api.userAction('taobaoShow');
            return '<section id="taobao" class="taobao-store taobao">' +
                       '<h2 class="module_title_p title lineDot">' +
                           '<span>' + taobao.title + '</span>' +
                           '<cite class="goto-store" data-url="' + taobao.url +
                               '" js_handle="js_openShop">进店逛逛</cite>' +
                       '</h2>' +
                       '<article class="store-info">' +
                           getShopLevel(taobao.sell_score) +
                           '<span>好评率：</span><i class="percent">' +
                               (Number(taobao.g_percent) || 0) + '%</i>' +
                           '<cite class="store-type lineDot">' + (taobao.m_catlist &&
                               taobao.m_catlist[0] || '') + '</cite>' +
                       '</article>' +
                   '</section>';
        }
    }
};
$.extend(POI, {
    // 打开店铺
    js_openShop: function(elem) {
        this.api.userAction('taobaoOpenShop');
        this.api.openThirdUrl(elem.attr('data-url'));
    },
    // 打开商品页面
    js_openShopGood: function(elem) {
        this.api.userAction('taobaoOpenShopGood');
        this.api.openThirdUrl(elem.attr('data-url'));
    }
})

})(POI, $);
