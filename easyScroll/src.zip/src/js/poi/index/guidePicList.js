/*
    导览图模块代码
*/
;(function(POI, $) {
'use strict';

/* loading模块开始*/
function Loading(selector){
    this.dom = typeof selector === 'string' ? document.querySelector(selector) : selector;
    if(!this.dom) throw selector + 'not found!!!';
    this.scale = window.devicePixelRatio || 1;
    this.width = this.dom.offsetWidth * this.scale;
    this.height = this.dom.offsetHeight * this.scale;
    this.init();
}
Loading.prototype = {
    init : function() {
        var canvas = document.createElement('canvas');
        canvas.width = this.width;
        canvas.height = this.height;
        this.dom.appendChild(canvas);
        canvas.style.webkitTransformOrigin='left top';
        canvas.style.webkitTransform = 'scale(' + (1 / this.scale) + ')';
        this.ctx = canvas.getContext('2d');
        this.rect();
        this.arc();
    },
    refre : function(count) {
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.rect();
        this.arc();
        this.loading_arc( count );
    },
    rect : function() {//中间小方块
        var ctx = this.ctx, scale = this.scale, width = 6 * scale, height = 6 * scale;//方块宽高
        ctx.beginPath();
        ctx.lineJoin="round";
        ctx.fillStyle = '#fff';
        ctx.fillRect((this.width - width) / 2, (this.height - height) / 2, width, height);
        ctx.fill()
    },
    arc : function() {//外面的圆弧
        var scale = this.scale, ctx = this.ctx, r = 10* scale, lineWidth = 1* scale;
        ctx.beginPath();
        ctx.lineJoin="round";
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = lineWidth;
        ctx.arc(this.width / 2, this.height / 2, r, 0, Math.PI*2);
        ctx.stroke();
    },
    loading_arc : function( count ) {
        var ctx = this.ctx, lineWidth = 2* this.scale+0.5, r = 9 * this.scale,
            now_radius = Math.PI*2*count -Math.PI*0.5;
        ctx.beginPath();
        ctx.lineJoin="round";
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = lineWidth;
        ctx.arc(this.width / 2, this.height / 2, r, -Math.PI*0.5, now_radius);
        ctx.stroke();
    }
};
var loading = function(el) {
    var l = new Loading(el);
    return {
        refre : function(count) {
            l && l.refre(count);
        }
    }
};
/* end loading*/
//var i = 0;/////////////////////////////////////////////// 测试
$.extend(POI, {
    getDownloadFromUrlStatus : function(urls, fn) {
        /*var dt = [];/////////////////////////////////////////////// 测试
        urls.forEach( function( url ) {
            dt.push( {status: parseInt( Math.random() * 3)+1, url : url, downSize : ((i+=1)%101), totalSize : 100, targetUrl: 'targetUrl'} );//
        } );
        return fn({statusList:dt});*/
        POI.send({
            action : 'getDownloadFromUrlStatus',
            urls : urls,
            type : 'shopGuide'
        }, function(dt){
            fn(dt);
        });
    },
    guidePicList : {
        get_html : function() {
            var self = this, urls;
            if( POI.business == 'scenic' ){//景区特殊显示
                /*if( urls.length ) {
                    POI.getDownloadFromUrlStatus(urls, function(dt) {
                        self.rander_scenic(dt.statusList || []);
                    });
                    return '<section id="guidePicList" style="display:none;"></section>';
                } else {
                    return self.rander_scenic() || '';
                }*/
                return self.rander_scenic() || '';
            } else {
                urls = self.get_data();
                urls.length && POI.util.executeAfterDomInsert(function() {
                    POI.getDownloadFromUrlStatus(urls, function(dt) {
                        self.rander(dt.statusList || []);
                    });
                });
                return urls.length ? '<section id="guidePicList" style="display:none;"></section>' : '';
            }
        },
        /*
            景区：scenic
            购物：shopping
        */
        get_data : function() {
            var self = this, business = POI.business, aosData = POI.aosData, dt,
                cache_list = self.cache_list, url, urls = [];
            if( POI.aosData.spec.sp_pic && POI.aosData.spec.sp_pic.length ) {
                  POI.aosData.spec.sp_pic.forEach(function(item) {
                    if(item && item.pic_info instanceof Array && item.pic_info.length && item.floor){
                        item.pic_info.forEach(function(tmp) {
                            if(tmp && tmp.url) {
                                cache_list.push( {url: tmp.url, floor: item.floor, _tmpurl : POI.util.imageUrlTransform(tmp.url, 50, 50)} );
                                urls.push( self.get_downurl( tmp.url ) );// 给客户端下载使用的地址
                            }
                        })
                    }
                });
            }
            return urls;
        },
        cache_list : [],
        get_maxpic : function( fig ) {//获取一屏最大显示图片个数
            var width = $(window).width() - 30 + 10, item = 60;
            if( fig ) {//最大可现实多少张完整图片
                return (width - width % item) / item;
            }else{
                return (width - width % item) / item + (width % item > 0 ? 1 : 0);
            }
        },
        /*
            status : -1下载失败 0未开始、3下载中、4已完成
        */
        rander : function(statusList) {
            var self = this, len = statusList.length , cache = self.cache_list, tmp,
                max = self.get_maxpic(),
                box = $('#guidePicList'),
                html = ['<h2 class="module_title_p line-half">网友实拍导览图<em class="small_text">(' + len + ')</em></h2><article><div class="box"><ul style="width:'+ (len*60 - 10) +'px">'];
            statusList.forEach(function(item, i) {
                tmp = cache[i] || {};
                if(tmp){
                    html.push('<li><div class="load_lazy js_class" ind="' + i +'" '+ ( item.status == 4 ? POI.handleAttr + '="js_openShopGuideImage" url="'+ (item.targetUrl || '') +'"' : '') +'>');
                    html.push(item.status == 4 ? '' : '<span '+ POI.handleAttr +'="js_downShopGuideImage" ind="' + i + '" url="'+ self.get_downurl( tmp.url ) +'">下载</span>');
                    html.push('</div>');
                    tmp.floor && html.push('<i class="lineDot">'+ tmp.floor +'</i>');
                    html.push('</li>');
                }
            });
            html.push('</ul></div></article>');
            len && box.html( html.join('') ).show() && self.init_event( box , self.get_maxpic( true ) < len );
        },
        rander_scenic : function(){
            var self = this, html = [], aosData = POI.aosData ,info = aosData.rti.scenic_guide,
                deep = POI.aosData.deep[0],
                fit,url,
                handleAttr = POI.handleAttr;
            info && ( url = info.hand_pic_url);
            fit = (url && info && info.is_txt_tts == 1 && deep && deep.heat_map == 1) ? '' : ' aide_ul_li_one'
            if(url) {
                POI.api.userAction("guideImageShow");
                html.push('<li class="aide_ul_li canTouch' + fit + '" '+ handleAttr +'="js_show_imagebox" url="'+ url +'"><div class="aide_icon aide_icon_1"></div>景区导览图</li>');
            }
            if(info && info.is_txt_tts == 1) {
                POI.api.userAction("guideVoiceShow");
                html.push( '<li class="aide_ul_li canTouch' + fit + '" '+ handleAttr +'="js_openVoiceGuide"><div class="aide_icon aide_icon_2"></div>语音导游</li>' );
            }
            if(deep && deep.heat_map == 1) {
                POI.api.userAction("guideHotShow");
                html.push( '<li class="aide_ul_li canTouch' + fit + '" '+ handleAttr +'="js_search_cat"><div class="aide_icon aide_icon_3"></div>景区热力图</li>' );
            }
            if( html.length ){
                html.unshift( '<section id="scenic_guide"><h2 class="aide_title module_title">景区助手</h2><ul class="aide_ul">' );
                html.push( '</ul></section>' );
            }
            return html.join('');
        },
        show_down_dialog : function( item ){//弹出下载景区导览图
            var handleAttr = POI.handleAttr,
                aosData = POI.aosData ,info = aosData.rti.scenic_guide||{},
                cpname = info.show_name || '',
                cpurl = (info.third_url || {})[ POI.browser.ios ? 'ios_appurl' : 'android_appurl' ],
                html = [],
                box = $('#js_scenic_dialog');
            if( box.length ) {
                return box.show();
            }
            html.push('<div id="js_scenic_dialog">');
            html.push('<div class="guidePic_scenic_guidebg" '+ handleAttr +'="js_secenic_closedialog"></div>');
            html.push('<div class="guidePic_scenic_guidepic" '+( cpname ? '' : 'style="height:190px;margin-top:-95px;"')+'>');
            html.push('<p class="guidePic_scenic_imgbox'+ (item.status == 4 ? ' end' : '') +'">');
            html.push('<img src="' +POI.util.imageUrlTransform(item.url, 250, 85)+ '" width="250" height="85" />');
            html.push('<span></span>');
            html.push('</p>');
            html.push('<div class="guidePic_scenic_btns canTouch">');
            html.push('<p class="'+ (item.status == 4 ? 'uploaded' : '') +'">');
            html.push('<span '+ handleAttr +'="js_scenic_downstart" url="'+ item.url +'">下载导览图到本地</span>');
            html.push('<span>已完成1%</span>');
            html.push('<span '+ handleAttr +'="js_openShopGuideImage_scenic" '+ ( item.status == 4 ? 'url="'+ item.targetUrl +'"' : '' ) +'>查看</span>');
            html.push('</p>');
            html.push('</div>');
            if( cpname ) {//  cpurl
                html.push('<p class="guidePic_scenic_adlink' + (cpurl ? ' canTouch' : '') + '" '+ (cpurl ? handleAttr + '="js_scenic_adlink" url="'+ cpurl +'"' : '') +'>');
                html.push('数据来源：<i>'+ cpname +'</i>');
                html.push('</p>');
            }
            html.push('<span class="guidePic_scenic_close canTouch" '+ handleAttr +'="js_secenic_closedialog"></span>');
            html.push('</div>');
            html.push('</div>');
            POI.pagebody.append( html.join( '' ) );
            $('#js_scenic_dialog').bind('touchmove', function(){
                return false;
            });
        },
        init_event : function( box , _scroll ) {//初始化事件
            var self = this, timer,
                escroll = _scroll ? POI.easyScroll($('.box', box)[0], {
                    align:'x',
                    preventDefault : false,
                    move_callback : function(x) {
                        self.loadlazy(box, x);
                    }
                }) : null;
            escroll && $(window).resize(function() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    escroll.refresh();
                }, 80);
            }).bind('orientationchange', function() {
                clearTimeout(timer);
                timer = setTimeout(function() {
                    escroll.refresh();
                }, 80);
            });
            self.loadlazy( box, 0);//主动触发首屏加载
        },
        lazy_timer : null,
        loadlazy : function(box, x) {//延迟加载后面的图片
            var self = this, cache = self.cache_list;
            clearTimeout(self.lazy_timer);
            self.lazy_timer = setTimeout(function() {
                var left = $(window).width() - 30 + 10 - x, item = 60,
                    min = parseInt( -x / item ),
                    max = (left - left % item) / item + (left % item > 0 ? 1 : 0),
                    items = $('div.load_lazy', box);
                    if( items.length ){
                        items.each(function() {
                            var o = $(this), ind = parseInt( o.attr('ind') ),img;
                            if( ind < max && ind >= min){
                                img = new Image();
                                img.onload = function() {
                                    o[0].style.backgroundImage = 'url('+ cache[ind]._tmpurl +')';
                                    img.onload = null, img = null, o= null;
                                };
                                img.src = cache[ind]._tmpurl;
                                o.removeClass('load_lazy');
                            }
                        });
                    } else {
                        self.loadlazy = function(){};
                    }
            }, 200);
        },
        get_downurl : function( url ) {//获取给客户端下载使用的url
            return url.indexOf( '?' ) >-1 ? url : ( url + '?type=pic' );
        }
    },
    downPicList : {//下载模块
        downlist : [],//下载队列
        time : 300,//查询进度间隔
        timer : null,
        downing : null,//正在下载的元素的元素dom对象
        loading : null,//下载动画对象
        downShopGuideImage : function( obj ) {
            var self = this, url = obj.attr('url'),
                fig = self.remove_fromlist( obj ), type;
            if( !url ) return '';
            if( fig ) {
                obj.html( '下载' );
                return 0;
            }
            if( obj[0] === self.downing ) {//取消下载
                clearTimeout( self.timer );
                self.downloadFromUrl( url , false );
                obj.html( '下载' );
                self.downStart( self.downlist.shift() );
                type = 0;//取消下载
            } else if( self.downing ) {
                self.downlist.push( obj );
                obj.html( '等待中' );
                type = 1;//下载
            } else {
                self.downStart( obj );
                type = 1;//下载
            }
            return type;
        },
        remove_fromlist : function( obj ) {//从队列中删除当前文件,同时返回是否存在
            var clone = [], fig = false;
            this.downlist.forEach( function(item) {
                if( item[0] !== obj[0] ) {
                    clone.push( item );
                }else{
                    fig = true;
                }
            });
            this.downlist = clone;
            return fig;
        },
        downStart : function( obj ) {//开始下载
            var self = this;
            self.downing = (obj || [])[0];
            if( !obj ) return;
            obj.html( '' );
            self.downing = obj[0];
            self.downloadFromUrl( obj.attr('url') , true );
            self.loading = loading( obj[0] );
            self.pross( obj );//启动进度动画
        },
        pross : function( obj ) {//进度条
            var self = this;
            clearTimeout( self.timer );
            self.timer = setTimeout(function() {
                POI.getDownloadFromUrlStatus([ obj.attr('url') ], function(dt) {
                    var count;
                    dt = ( dt.statusList || [] )[0];
                    if( dt ) {
                        count = (dt.downSize && dt.totalSize) ? dt.downSize / dt.totalSize : 0;
                        if( dt.status == 4 ) {
                            self.downEnd( obj , dt );
                        }else if( dt.status == -1 || (dt.status === 0 && POI.browser.and) ) {
                            self.downError( obj , status);
                        } else {
                            self.loading.refre( count );
                            self.pross( obj );
                        }
                    }
                });
            }, self.time);
        },
        downEnd : function( obj , dt ) {//下载完成
            var self = this, div = obj.parents('.js_class').eq(0), attr = {};
            self.loading.refre( 1 );
            obj.removeAttr( POI.handleAttr );
            setTimeout( function() {
                obj.remove();
                obj = null;
            }, 150);
            attr.url = dt.targetUrl || '';
            attr[ POI.handleAttr ] = 'js_openShopGuideImage';
            div.attr( attr );
            POI.browser.ios && POI.api.promptMessage( '下载成功!' );
            self.downStart( self.downlist.shift() );//启动下一个下载
        },
        downError : function( obj , status ) {//下载失败
            var self = this;
            obj.html( status == -1 ? '下载失败' : '下载' );
            status == -1 && POI.browser.ios && POI.api.promptMessage( '下载失败!' );
            self.downStart( self.downlist.shift() );//启动下一个下载
        },
        downloadFromUrl  : function( url , fig) {//下载或者取消下载
            POI.send({
                action : 'downloadFromUrl',
                poiname: '' + POI.clientData.poiInfo.name,
                event : fig ? '0' : '1',
                url : url,
                type : 'shopGuide'
            });
        }
    },
    js_downShopGuideImage : function( obj ) {//下载处理函数
        var type = this.downPicList.downShopGuideImage( obj );
        this.api.userAction('downShopGuideImage', {type_name : [type,this.clientData.poiInfo.name||''].join('_')});
    },
    js_openShopGuideImage : function( obj ) {
        var self = this;
        if( self.browser.and ) {
            self.send({
                action : 'openResourceByPath',
                type : 'picture',
                path : obj.attr('url') || ''
            });
        } else {
            self.api.promptMessage( '导览图已下载，请在相册查看!' );
        }
        self.api.userAction('openResourceByPath', {name : self.clientData.poiInfo.name||''});
    },
    /*打开语音导览图*/
    js_openVoiceGuide: function() {
        /*this.send({
            action: 'showVoiceGuide',
            poiInfo: this.clientData.poiInfo
        });*/
        var level = 17;
        try{ level = this.aosData.spec.mining_shape.level || 17; } catch(e) {}
        this.api.loadSchemaNew( 'amapuri://search/idq?frompage=2&poiid='+this.aosData.base.poiid+'&zoomlevel='+level+'&action=4&funtype=1&poiname='+encodeURIComponent(this.aosData.base.name) );
        this.api.userAction('showVoiceGuide');
    },
    js_search_cat : function(){//景区热力图点击
        /*this.send({
            action: 'searchCategory',
            category : this.aosData.base.poiid,
            keywords : this.aosData.base.name,
            params : {transfer_pdheatmap : '1'},
            queryType : 'IDQ'
        });*/
        var level = 17;
        try{ level = this.aosData.spec.mining_shape.level || 17; } catch(e) {}
        this.api.loadSchemaNew( 'amapuri://search/idq?frompage=2&poiid='+this.aosData.base.poiid+'&zoomlevel='+level+'&action=3_1&funtype=1&poiname='+encodeURIComponent(this.aosData.base.name) );
        this.api.userAction('scenicSearchCat',{poiid_name:this.aosData.base.poiid+'_'+this.aosData.base.name});
    },
    js_show_imagebox : function( obj ) {//显示景区导览图下载框
        var self = this,
            url = obj.attr('url');
        self.getDownloadFromUrlStatus([self.guidePicList.get_downurl( url )], function(dt) {
            var item = dt.statusList[0];
            item.url = url;
            self.guidePicList.show_down_dialog( item );
        });
        self.api.userAction('showImagebox');
    },
    js_scenic_downstart : function( obj ) {//开始下载景区导览图
        var self = this, div = obj.parents('.guidePic_scenic_btns'), timer;
        div.removeClass( 'canTouch' );
        obj.parent().addClass( 'uploading' );
        setTimeout( function() {
            self.downPicList.downloadFromUrl( self.guidePicList.get_downurl( obj.attr('url') ) , true );
            self.scenic_down_pross( obj );//景区导览图下载进度
        }, 1000);
        self.api.userAction('downScenicGuideImage', {type_name : [1,self.clientData.poiInfo.name||''].join('_')});
    },
    js_openShopGuideImage_scenic : function( obj ) {
        var self = this,
            p = obj.parent(), span = p.find('span');
        self.getDownloadFromUrlStatus([ self.guidePicList.get_downurl( span.eq(0).attr('url') )], function( dt ) {
            var item = dt.statusList[0] || {};
            if( item.status == 4 ) {
                self.js_openShopGuideImage( obj );//这里有埋点了，所以不用重复埋点哦
            } else {
                span.eq(1).html( '已完成1%' );
                p.removeClass( 'uploaded' );
                self.js_scenic_downstart( span.eq(0) );//这里有埋点了，所以不用重复埋点哦
            }
        });
    },
    js_scenic_adlink : function( obj ) {//景区导览图下载弹框 数据来源连接点击
        this.api.userAction('scenicGuideImageCp');
        //this.util.locationRedirect( obj.attr('url') );
        this.api.getAppPara('', '', obj.attr('url'));
    },
    js_secenic_closedialog : function() {
        $('#js_scenic_dialog').hide();
    },
    scenic_down_pross : function( obj ) {
        var self = this, div = obj.parents('.guidePic_scenic_btns'),
            pross = div.find('span').eq(1);
        clearTimeout( self.scenic_down_timer );
        self.scenic_down_timer = setTimeout(function() {
            self.getDownloadFromUrlStatus([ self.guidePicList.get_downurl( obj.attr('url') ) ], function(dt) {
                var count;
                dt = ( dt.statusList || [] )[0];
                if( dt ) {
                    count = (dt.downSize && dt.totalSize) ? dt.downSize / dt.totalSize : 0;
                    count = (count * 100) | 0;
                    if( dt.status == 4 ) {
                        pross.html( '下载成功' );
                        $('.guidePic_scenic_imgbox').addClass('end');
                        setTimeout( function() {
                            obj.parent().addClass( 'uploaded' );
                            div.addClass( 'canTouch' );
                            div.find('span').eq(2).attr('url',dt.targetUrl);
                        },2000);
                        self.browser.ios && self.api.promptMessage( self.aosData.base.name+'导览图下载成功，请在相册查看!' );
                    }else if( dt.status == -1 || (dt.status === 0 && self.browser.and) ) {
                        self.api.promptMessage( '下载失败，请重试!' );
                        obj.parent().removeClass( 'uploading' );
                        setTimeout(function(){
                            pross.html( '已完成1%' );
                        },300);
                    } else {
                        pross.html( '已完成'+ (Math.min(99,Math.max(count,1))) +'%' );
                        self.scenic_down_pross( obj );
                    }
                }
            });
        }, 300);
    }
});

})(POI, $);
