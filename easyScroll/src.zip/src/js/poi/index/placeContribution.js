/**
 * 地点贡献模块.
 */
;(function(POI, $) {
'use strict';

var placeContribution = {
    contributionList :  [],
    sortListByTime : function(list) {
        var reg = /^(\d{4})-(\d{1,2})-(\d{1,2})[\s]?(\d{0,2})[:]?(\d{0,2})[:]?(\d{0,2})$/;
        var timeFunction = new Function('ary', 'return new Date(ary[0] || 0, ary[1] || 0, ary[2] || 0, ary[3] || 0, ary[4] || 0, ary[5] || 0)');
        var sortFunction = function(a1, a2) {
            var time1Ary = a1.time.match(reg);
            var time2Ary = a2.time.match(reg);
            if(1 < time1Ary.length && 1 < time2Ary.length) {
                time1Ary.shift();
                time2Ary.shift();
                return timeFunction(time2Ary) - timeFunction(time1Ary);
            } else {
                return 0;
            }
        };
        list.sort(sortFunction);
    },
    generateContributionList : function() {
        if(POI.util.bool(POI.aosData.spec.place_contribution)) {
            var contributionAry = POI.aosData.spec.place_contribution;
            for(var i = 0, len = contributionAry.length, item = null; i < len; i++) {
                item = contributionAry[i];
                // 首图数据
                if(POI.util.bool(item.first_pic)) {
                    item.first_pic.data_type = 1;
                    this.contributionList.push(item.first_pic);
                    continue;
                }
                // 地点添加数据
                if(POI.util.bool(item.user_add)) {
                    // 768版本没有地点添加数据，先不解析
                    //item.user_add.data_type = 2;
                    //this.contributionList.push(item.user_add);
                    continue;
                }
                // 地点修改数据
                if(POI.util.bool(item.user_revise)) {
                    // 768版本没有地点修改数据，先不解析
                    //for(var j = 0, _len = item.user_revise.length; j < _len; j++) {
                    //    item.user_revise[j].data_type = 3;
                    //    this.contributionList.push(item.user_revise[j]);
                    //}
                }
            }
            this.sortListByTime(this.contributionList);
        }
    },
    avatarFormat : function(url) {
        return POI.util.bool(url) ? 'style="background-image:url(' + url + ')"' : '';
    },

    timeFormat : function(time) {
        if (time) {
            var timeRes = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(time);
            if (timeRes && timeRes.length === 4) {
                return timeRes[1] + '年' + timeRes[2] + '月' + timeRes[3] + '日';
            }
        }
        return time;
    },

    createFirstPicLiHtml : function(obj) {
        var avatarStr = this.avatarFormat(obj.author_profileurl);
        var timeStr = this.timeFormat(obj.time);
        return '<li class="contribution_item">' +
                   '<i class="contribution_avatar" ' + avatarStr + '></i>' +
                   '<span class="contribution_desc">' + (obj.nickname || obj.author || '高德用户') + '于' + timeStr + '上传了首张图片</span>' +
               '</li>';
    },

    createUserAddLiHtml : function(obj) {
        var avatarStr = this.avatarFormat(obj.author_profileurl);
        var timeStr = this.timeFormat(obj.time);
        return '<li class="contribution_item">' +
                   '<i class="contribution_avatar" ' + avatarStr + '></i>' +
                   '<span class="contribution_desc">' + (obj.nickname || obj.author || '高德用户') + '于' + timeStr + '添加了该地点</span>' +
               '</li>';
    },

    createUserReviseLiHtml : function(obj) {
        var avatarStr = this.avatarFormat(obj.author_profileurl);
        var timeStr = this.timeFormat(obj.time);
        return '<li class="contribution_item">' +
                   '<i class="contribution_avatar" ' + avatarStr + '></i>' +
                   '<span class="contribution_desc">' + (obj.nickname || obj.author || '高德用户') + '于' + timeStr + '修改了该地点</span>' +
               '</li>';
    },

    createFirstReviewLiHtml : function(obj) {
        var avatarStr = this.avatarFormat(obj.author_profileurl);
        var timeStr = this.timeFormat(obj.time);
        return '<li class="contribution_item">' +
                   '<i class="contribution_avatar" ' + avatarStr + '></i>' +
                   '<span class="contribution_desc">' + (obj.nickname || obj.author || '高德用户') + '于' + timeStr + '发表了首个评论</span>' +
               '</li>';
    },

    createLiHtml : function(list) {
        if(POI.util.bool(list)) {
            var resHtml = '';
            for(var i = 0, len = list.length, item = null; i < len; i++) {
                item = list[i];
                switch (item.data_type) {
                    case 1:
                        resHtml += this.createFirstPicLiHtml(item);
                        break;
                    case 2:
                        resHtml += this.createUserAddLiHtml(item);
                        break;
                    case 3:
                        resHtml += this.createUserReviseLiHtml(item);
                        break;
                    case 4:
                        resHtml += this.createFirstReviewLiHtml(item);
                        break;
                    default :
                        break;
                }
            }
            return resHtml;
        } else {
            return '';
        }
    },

    showFirstReview : function(firstReview) {
        firstReview.data_type = 4;
        this.contributionList.push(firstReview);
        this.sortListByTime(this.contributionList);
        var liStr = this.createLiHtml([ this.contributionList[0] ]);
        var sectionHtml = this.getSectionHtml( liStr, !!(1 < this.contributionList.length) );
        var $placePontribution = $("#placePontribution");
        $placePontribution.replaceWith(sectionHtml);
        //if($placePontribution.hasClass("none")) {
        //    $placePontribution.find(".contribution_list").html(reviewHtml);
        //    $placePontribution.removeClass("none");
        //} else {
        //    $placePontribution.find(".contribution_list").append(reviewHtml);
        //}
	    POI.api.userAction("placePontribution");
    },
    
    getSectionHtml : function(liStr, hasMore) {
        return '<section id="placePontribution" ' + (liStr ? '' : 'class="none"') + '>' +
                   '<h2 class="module_title_p line-half">地点贡献</h2>' +
                   '<div>' +
                       '<ul class="contribution_list">' + liStr + '</ul>' +
                       (hasMore ? '<div class="contribution_list_more canTouch" ' + POI.handleAttr + '="js_showAllPlacePontribution"><span>全部贡献</span></div>' : '') +
                   '</div>' +
               '</section>';
    },
    
    get_html : function() {
        var liStr = '';
        this.generateContributionList();
        var len = this.contributionList.length;
        if(0 < len) {
            liStr = this.createLiHtml([ this.contributionList[0] ]);
        }
        return this.getSectionHtml( liStr, !!(1 < len) );
    }
};

$.extend(POI, {
    placeContribution : placeContribution,
    
    js_showAllPlacePontribution : function() {
        var _pc = POI.placeContribution;
        var list = _pc.contributionList;
        var lisHtml = "";
        if(0 < list.length) {
            lisHtml = _pc.createLiHtml(list);
        }
        if(lisHtml) {
            POI.scrollPage({
                defaultHeader: "全部贡献",
                content: '<ul class="contribution_list scroll_list">' + lisHtml + '</ul>'
            });
        }
    }
});

})(POI, Zepto);