/**
 * 用户印象
 */
;
(function(POI, $) {

'use strict';

POI.impression = {
    
    resize : function() {
        
        var moreTagLink = $("#show_more_tag"),
            outer = $(".userTag_div").css({'height': 'auto','max-height': "70px"}),
            inner = $(".userTag_ul"),
            outerH = outer.height(),
            innerH = inner.height(),
            hasMore = innerH > outerH + 10,
            moreTxt = "查看更多",
            backTxt = "收起";
            
        if (hasMore) {
            $(".show-more-tag").removeClass("hidden");
            if ( $('#show_more_tag').text() == backTxt ) {
                outer.css({height: innerH, 'max-height': '210px'});
            }
            
        } else {
            if (!$(".show-more-tag").hasClass("hidden")) {
                $(".show-more-tag").addClass("hidden");
            }
        }
        moreTagLink.off('click').on("click", function() {
            var h = innerH,
                curTxt = moreTxt;
            if (hasMore) {
                if (innerH > outer.height() + 10) {
                    h = innerH;
                    curTxt = backTxt;
                } else {
                    h = outerH;
                    curTxt = moreTxt;
                }
                $(this).text(curTxt);
                outer.css({
                    height: h,
                    "max-height": "210px"
                });
            }
        });
    },
    
    showImpression : function() {
        return '';
        var aosData = POI.aosData || POI.util.getStorageData() || {},
            spec = aosData.spec;
        if(!spec || !spec.groupbuy_meituan2_api) {
            return '';
        }
        
        var tagAry = [];
        for (var i = 0, l = spec.groupbuy_meituan2_api.length; i < l; i++) {
            if(!spec.groupbuy_meituan2_api[i].re_level || "0" === spec.groupbuy_meituan2_api[i].re_level) {
                tagAry.push('<li class="half-border">' + spec.groupbuy_meituan2_api[i].review + '</li>');
            }
        }
        
        if(!tagAry.length) {
            return '';
        }
        
        POI.util.executeAfterDomInsert(function() {
            POI.impression.resize();
            $(window).on('resize', POI.impression.resize);
        });
        
        var moreTxt = "查看更多",
            backTxt = "收起",
            tagHtml = ['<h2 class="module_title_p line-half">用户印象</h2><div class="userTag_div"><ul class="userTag_ul">'];
        Array.prototype.push.apply(tagHtml, tagAry);
        tagHtml.push("</ul></div>");
        tagHtml.push("<p class='show-more-tag hidden'><a id='show_more_tag'>" + moreTxt + "</a></p>");
        
        return '<section class="userTag">' + tagHtml.join("") + '</section>';
        
        
    }
    
};

})(POI, Zepto);