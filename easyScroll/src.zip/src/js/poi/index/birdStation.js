/**
 * 菜鸟驿站模块
 */
 ;
 (function(POI, $) {
'use strict';
	$.extend(POI, {
		birdStation: {
			get_html: function() {
				var that = this;
				var obj = POI.aosData.deep_common;

				if (obj && obj[0] && obj[0].service && obj[0].service.length > 0) {
					var res = that.makeBirdHtml(obj[0].service);
					POI.api.userAction('showBirdStation');
				} else {
					return '';
				}
				return res;
			},
			makeBirdHtml: function(str) {
				var that = this;
				var arr = str.split('|');

				var li_arr = [];

		    	var pre_section = '<section class="postType">'+
		    					  '<h2 class="module_title_p line-half bird postType_title">服务类型</h2>'+
		    					  '<ul>';
		    	var last_section = '</ul></section>';

		    	for (var i=0; i<arr.length; i++) { 
		    		var li_str ='<li class="half-border"><span>'+arr[i]+'</span></li>';
					li_arr.push(li_str); 
				}
				return pre_section+li_arr.join('')+last_section;
			}

		}

	});

 })(POI, Zepto);