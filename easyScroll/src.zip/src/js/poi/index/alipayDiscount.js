/**
 * 支付宝优惠模块
 */

;
(function(POI, $) {

'use strict';
$.extend(POI, {
	alipayDiscount: {
		get_html: function() {
            var that = this;
            var rti = POI.aosData.rti;
            var idDictionaries = POI.aosData.idDictionaries;
            if(!rti.alipay_koubei_url) {
                return '';
            }
            if(!(idDictionaries && idDictionaries.alipay_koubei_id)) {
            	POI.api.userAction('showNodataAlipay');
                return '<div id="alipayDom" class="alipay">' + that.nodata_html() + '</div>'
            }
			var params = [
				{
					shop_id: idDictionaries.alipay_koubei_id,
					sign: 1
				}
			];
			
			POI.util.executeAfterDomInsert(function(){
                window.t1 = new Date();
				POI.api.aosrequest('alipayDiscount', params, function(data) {
					var html = '';
					if (data.code == 1 && data.data.length > 0) {
						html = that.make_html(data);
					} else {
						POI.api.userAction('showNodataAlipay');
						html = that.nodata_html();
					}
					$('#alipayDom').replaceWith(html);
                    $('#js_dinning_tuanhui').length && $('#js_dinning_tuanhui').addClass( 'topline' );
                    POI.api.userAction('showHasdataAlipay');
				}, null, null, "GET");
			});

			return '<div id="alipayDom"></div>';
		},
		nodata_html: function() {
			var handleAttr = POI.handleAttr;

			var pre_section = '<section class="alipay">'+
							  '<h2 class="module_title_p divide-line">'+
							  '<img src="img/alipay.png" class="alipay_img"/><span>支付宝买单</span>'+
							  '<button id="alipayNowPay" class="discount_btn canTouch" ' + handleAttr + '="js_goToAlipay">立即买单</button>'+
							  '</h2>';
			var last_section = '</section>';

			var nodata_str = '<div class="no-info">支付宝快捷支付</div>';

			return pre_section+nodata_str+last_section;
		},
		make_html: function(data) {
			var that = this;
			var arr = [];

			for (var i=0; i<data.data.length; i++) {
				if (data.data[i].description != undefined) {
					arr.push(data.data[i]);
				}
			}
			var discount_div = '';
			var first_item = '';
			var handleAttr = POI.handleAttr;
			var more_discount = arr.length === 5?'<div class="more_discount canTouch" ' + handleAttr + '="js_goToAlipay" id="alipayDiscountDetail">更多优惠详情</div>':'';
			var toggle_html = arr.length > 1?'<div class="toggle" id="toggle_btn" ' +handleAttr+ '="js_getMoreDiscount"><span class="check_more">查看更多优惠</span><span class="toggle_icon"></span></div>':'';

			var pre_section = '<section class="alipay">'+
							  '<h2 class="module_title_p divide-line">'+
							  '<img src="img/alipay.png" class="alipay_img"/><span>支付宝买单</span>'+
							  '<button class="discount_btn canTouch" ' + handleAttr + '="js_goToAlipay" id="alipayDiscountPay">优惠买单</button>'+
							  '</h2>';
			var last_section = '</section>';

			var pre_discount_cont = '<div class="discount_cont">'+
							        '<p class="title">优惠详情</p>'+
							        '<div class="diacount_container divide-line">';

			var last_discount_cont = '</div>'+toggle_html+'</div>';

			if (arr.length > 0) {
				var first_item_p2 = (arr[0].promotion_type === 'item') && (!!Number(arr[0].sales_quantity) == true) ?'<p class="p2"><span class="person_num">'+arr[0].sales_quantity+'</span>人已享</p>':'';

				first_item = (arr[0].promotion_type === 'item')?'<div class="first-cont"><p class="p1">1.'+arr[0].description+'</p>'+first_item_p2+'</div>':'<div class="first-cont"><div>1.'+arr[0].description+'</div></div>';
			}
			

			if (arr.length > 1) {
				var li_arr = [];
				var pre_discount_div = '<div class="discount_div">'+
									   '<ul class="discount_list">';

				var last_discount_div = '</ul>'+more_discount+'</div>'



				for (var i=1; i<arr.length; i++) {
					var p2 = (arr[i].promotion_type === 'item') && (!!Number(arr[i].sales_quantity) == true)?'<p class="p2"><span class="person_num">'+arr[i].sales_quantity+'</span>人已享</p>':'';

					var li_str = (arr[i].promotion_type === 'item')?'<li><p class="p1">'+(i+1)+'.'+arr[i].description+'</p>'+p2+'</li>':'<li><div>'+(i+1)+'.'+arr[i].description+'</div></li>';
					li_arr.push(li_str);
				}
				discount_div = pre_discount_div+li_arr.join('')+last_discount_div;
			}

			return pre_section+pre_discount_cont+first_item+discount_div+last_discount_cont+last_section;
		}
	},
	js_goToAlipay: function(obj) {
        var rti = POI.aosData.rti;
        var aliSchema = rti.alipay_koubei_url;
        
	    POI.api.loadSchemaNew(aliSchema, "alipay", function(data) {
	    	if (data.status == '1') {
	    		
	    	} else {
	    		
	    	}
	    });

	    var log_str = obj.attr('id');
	    POI.api.userAction(log_str);
	},
	js_getMoreDiscount: function(obj) {
		obj.find('.toggle_icon').toggleClass('unfold');
		$('.discount_div').toggle();

		if (obj.find('.toggle_icon').hasClass('unfold')) {
			obj.find('.check_more').html('收起');
			POI.api.userAction('alipayCheckMoreDiscount');
		} else {
			obj.find('.check_more').html('查看更多优惠');
			POI.api.userAction('alipayUnfold');
		}
	}
});

})(POI, Zepto);