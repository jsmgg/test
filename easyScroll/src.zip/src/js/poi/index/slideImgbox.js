/**
 * 景区酒店
 */
;
(function(POI, $) {

'use strict';

$.extend(POI,{
    slideImgbox : {
        index : 0,
        /*
            data:{
                list : [{
                    url:'http://www.test.com/1.jpg'
                },{
                    url:'http://www.test.com/1.jpg'
                }],
                count : 43
            }// data数据结构
            options : {
                showList : true,//显示进入列表按钮，切可以右滑进入列表
                showCount : true,//显示相册数量
                click : true // 图片点击进入大图预览
            }
        */
        get_html : function( data, options ) {
            var fit = 320/180;//图片宽高比
            var imgWidth = $(window).width();
            var imgHeight = imgWidth/fit|0;
            var self = this;
            var key = 'slideImgbox'+self.index;
            if( !data || !data.list || !data.list.length ){
                return '';
            }
            self.index++;
            options = $.extend({
                showList : true,//显示进入列表按钮，切可以右滑进入列表
                showCount : true,//显示相册数量
                click : true // 图片点击进入大图预览
            },options||{});
            options.imgW = imgWidth;
            options.imgH = imgHeight;
            POI.util.executeAfterDomInsert(function() {
                if( window.PicSlide ){
                    self.initSlideImgbox( key, options );
                } else {
                    POI.util.loadResources('js/lib/slide.js', function(){
                        self.initSlideImgbox( key, options );
                    });
                }
            });
            return self.htmlStr( key, data, options );
        },
        htmlStr : function( key, data, options ) {
            var html = [ '<article class="scenicImgbox_imgs" id="'+key+'"'+ ( options.click ? ' js_handle="js_slideBigImgView"' : '') +'>' ];
            html.push( '<ul>' );
            data.list.forEach(function( item, i ){
                html.push( '<li'+ ( i <= 1 ? '' : ' class="img-loading" data-url="'+POI.util.imageUrlTransform(item.url, options.imgW, options.imgH)+'"') +'>'+(i <= 1 ? '<img src="'+POI.util.imageUrlTransform(item.url, options.imgW, options.imgH)+'" width="'+options.imgW+'" height="'+options.imgH+'"/>' : '' )+'</li>' );
            });
            html.push( '</ul>' );
            if( options.showList ){
                html.push( '<p class="scenicImgbox_showlist" js_handle="js_slideListImgView"></p><p class="scenicImgbox_tips">滑动查看相册列表</p>' );
            }
            if( options.showCount && data.count ) {
                html.push( '<p class="scenicImgbox_count">相册('+data.count+')</p><p class="scenicImgbox_bg"></p>' );
            }
            data.list.length > 1 && html.push( '<p class="scenicImgbox_indexs"><i class="selected">'+ (new Array(data.list.length).join('</i><i>')) +'</i></p>' );            
            html.push( '</article>' );
            return html.join( '' );
        },
        initSlideImgbox : function( key, options ) {
            var self = this;
            var box = $('#'+key);
            var tips = $('.scenicImgbox_tips',box);
            var max = 50;
            new PicSlide(box[0], {
                startIndex : 0,
                isLoop : false,
                afterFun : function(i, item){
                    box.find('i.selected').removeClass( 'selected' );
                    box.find('i').eq(i).addClass( 'selected' );
                    item = $( item ).next();
                    item.length && item.hasClass( 'img-loading' ) && self.loading( item, options );
                },
                lastMoreFun : function( deltaX ){
                    if( !options.showList ) return;
                    if( deltaX >= max ){
                        self.goPicView( 'list' );
                        POI.api.userAction( 'slideImgboxAutoList' , {business:POI.business});
                    }
                    setTimeout(function(){
                        $('.scenicImgbox_showlist',box).css( 'opacity',1 );
                    },300);
                },
                moveoutFun : function( out ) {
                    if( !options.showList ) return;
                    $('.scenicImgbox_showlist',box).css('opacity', Math.max(0,(30-out)/30));
                    out = Math.max(out,0);
                    tips.css({
                        right : (out-47)+'px',
                        opacity: Math.min(1,out/max)
                    });
                    tips.text(out>max?'松手查看相册列表':'滑动查看相册列表')
                }
            });
        },
        loading : function( o, options) {
            var src = o.data( 'url' );
            new POI.util.loadImage( src,o[0], function(){
                o.html( '<img src="'+src+'" width="'+options.imgW+'" height="'+options.imgH+'"/>' );
            });
        },
        goPicView : function(showType, index) {
            POI.util.getPicData( {
                showType : showType,
                poiid : POI.clientData.poiInfo.poiid,
                startIndex : index||0,
                type : 'poiface'
            } );
        }
    },
    js_slideBigImgView : function( obj ) {//图片点击，跳转到大图预览
        var index = obj.find('.scenicImgbox_indexs i').index( obj.find('i.selected').eq(0) );
        this.slideImgbox.goPicView('detail', index);
        this.api.userAction( 'slideImgboxBig', {business:this.business});
    },
    js_slideListImgView : function() {//列表图标点击，跳转图片列表预览页
        this.slideImgbox.goPicView('list');
        this.api.userAction( 'slideImgboxList', {business:this.business});
        return false;
    }
});

})(POI, Zepto);