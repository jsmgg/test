/*
 首页评论模块
 */
;(function(POI, $) {
    'use strict';
    /**
     * 获取评论.
     * @param {Function} handler
     * @param {Boolean} sellPoint 是否请求标签信息
     * @param {Integer} pageSize 每页的条数
     * @param {Boolean} showNetErr 是否显示网络错误提示
     */
    function getComments(handler, sellPoint, pageSize, showNetErr, sellpoint_count, at_once_flag) {
        //POI.clientData代表首页调用，getUrlParam代表评论列表页调用
        var poiid = POI.clientData ? POI.clientData.poiInfo.poiid : POI.util.getUrlParam('pageId');
        var params = [
            {poiid: poiid, sign: 1},
            {pagenum: 1},
            {pagesize: pageSize || PAGE_SIZE},
            {is_sellpoint: sellPoint ? '1' : '0'},
            {is_myreview: '1'},
            {select_mode: '4'},
            {like_flag: '1'}
        ];
        if( sellpoint_count ) {//首页取6个tag
            params.push({sellpoint_count:9});
        }
        if(at_once_flag) {
            params.push({at_once_flag:1});
        }
        // dev url http://100.69.198.235:8086/ws/valueadded/deepinfo/review_list/
        POI.api.aosrequest('getCommentsUrl', params, handler, false, showNetErr);
    }

// index 页面显示评论信息
    function showInIndex(res) {
        var handleAttr = POI.handleAttr;
        var secHtml = '';
        if("1" == res.code) {
            if(0 == res.rec_count && !POI.util.bool(res.my_review) && !POI.util.bool(res.sellpoints) && !POI.util.bool(res.review_list)) {
                var firstHtml = getFirstCommentHtml();
                if(firstHtml) {
                    $('#commentDom').html(firstHtml);
                }
                return;
            }
            
            secHtml += createRate(res);
            secHtml += createStars();

            var commonCommentCount = 1;
            if(POI.util.bool(res.my_review)) {
                secHtml += createMyComment(res.my_review, !!secHtml);
                commonCommentCount = 1;
            } else {
                commonCommentCount = 2;
            }
            secHtml += createCommonComment(res, commonCommentCount, !!secHtml);

            if(secHtml) {
                var moreStr = '';
                if(res.rec_count && (commonCommentCount < res.rec_count)) {
                    POI.api.userAction("commentAllBtnShow", {business : POI.business});
                    moreStr = '<div class="comment_more canTouch" ' + handleAttr + '="js_open_commentlist">全部评论</div>';
                }
                secHtml = '<section>' + secHtml + moreStr + '</section>';
                $('#commentDom').html(secHtml);
                POI.util.executeAfterDomInsert();
                new POI.util.toggleContent($('.comment_toggle'), $('.comment_cont'), {isConClick: true});
            }
//res.first_review = {"author":"胡志明","author_profileurl":"http://cdn.duitang.com/uploads/item/201509/27/20150927191624_2tnMS.jpeg","time":"2016-03-03 16:45:34","uid":"","recommend":"","review":"","pic_info":[]}
            if(POI.util.bool(res.first_review)) {
                showFirstReview(res.first_review);
            }
        } else {
            var firstHtml = getFirstCommentHtml();
            if(firstHtml) {
                $('#commentDom').html(firstHtml);
            }
        }
    }
    
    function createRate(res) {
// res.review_rate = [
   // {"good":"1","bad":"0","moderate":"0","bad_rate":"0.015","good_rate":"0.5","proportion":"50","start_time":"2016-03-03 16:45:34","end_time":"2016-03-08 16:45:34"},
   // {"good":"1","bad":"0","moderate":"0","bad_rate":"0.065","good_rate":"0.5","proportion":"60","start_time":"2016-03-03 16:45:34","end_time":"2016-03-08 16:45:34"},
   // {"good":"1","bad":"0","moderate":"0","bad_rate":"0.025","good_rate":"0.5","proportion":"0","start_time":"2016-03-03 16:45:34","end_time":"2016-03-08 16:45:34"},
   // {"good":"1","bad":"0","moderate":"0","bad_rate":"0.03","good_rate":"0.5","proportion":"10","start_time":"2016-03-03 16:45:34","end_time":"2016-03-08 16:45:34"}
// ];
// res.negative_rate = "1";
// res.positive_rate = "0";
        // 全好评
        if(POI.util.bool(res.positive_rate) && 1 == res.positive_rate) {
            var specialHtml = '<i class="rate_all_good"></i>' +
                              '<span class="rate_all_text">最近两个月好评如潮！</span>';
            return specialRate(0, specialHtml);
        }
        // 全差评
        if(POI.util.bool(res.negative_rate) && 1 == res.negative_rate) {
            var specialHtml = '<i class="rate_all_bad"></i>' +
                              '<span class="rate_all_text">我的天呐！该店最近两个月的评论全是差评！</span>';//我的天呐！<br/>该店最近两个月的评论<br/>全是差评！
            return specialRate(100, specialHtml);
        }
        // 好、差评全为0
        if(!POI.util.bool(res.negative_rate) && !POI.util.bool(res.positive_rate)) {
            if(POI.util.bool(res.review_rate)) {
                if(4 == res.review_rate.length) {
                    var specialHtml = '<i class="rate_all_mid"></i>' +
                                      '<span class="rate_all_text">说出来你可能不信该店近两个月全是中评</span>';//说出来你可能不信<br/>该店近两个月全是中评
                    return specialRate(0, specialHtml);
                } else {
                    var specialHtml = '<i class="rate_all_good"></i>' +
                                      '<span class="rate_all_text">暂无差评率。如果你曾经来过这个地点，说说你的感受？</span>';//暂无差评率。如果你曾<br/>经来过这个地点，说说<br/>你的感受？
                    return specialRate(0, specialHtml, "#bcbdbe");
                }
            } else {
                var specialHtml = '<i class="rate_all_good"></i>' +
                                  '<span class="rate_all_text">暂无差评率。如果你曾经来过这个地点，说说你的感受？</span>';
                return specialRate(0, specialHtml, "#bcbdbe");
            }
        }
        if(POI.util.bool(res.review_rate)) {
            var ratePreStr = res.negative_rate;
            if(1 > ratePreStr) {
                ratePreStr = (ratePreStr * 100).toFixed(0);
            }
            var rate100Class = 10 > ratePreStr ? 'rate_good_100' : '';
            var rateStr = '<div class="good_rating divide-line">' +
                              '<div class="rate_num"><span class="' + rate100Class + '">' + ratePreStr + '<i>%</i></span><p>差评率</p></div>' +
                              '<div class="rate_canvas">' +
                                  '<canvas id="comment_canvas" height="140" width="400"></canvas>' +
                              '</div>' +
                          '</div>';
            var _rateAry = [];
            var texts = ["八周前", "六周前", "四周前", "二周前"];
            for(var i = 0, len = res.review_rate.length; i < len; i++) {
                _rateAry.push({
                    num : parseFloat(res.review_rate[i].bad_rate) || 0,
                    txt : texts[i]||''
                });
            }
            POI.util.executeAfterDomInsert(function(rateAry) {
                var obj_w = $(window).width();
                var w = obj_w - 117;
                var h = 70;// Math.floor(obj_w*140/640);
                var dom = $("#comment_canvas");
                var ctx = dom[0].getContext("2d");
                new CommentDraw(dom[0],{
                    width : w,
                    height : h,
                    data : rateAry
                });
                //部分安卓机器如小米4c 页面跳转后 回退到当前页面，canvas渲染空白，增加如下hack代码
                POI.browser.and && $(window).on('pageshow',function(){
                    dom.removeClass( '__canvas_hack__' ).addClass( '__canvas_hack__' );
                    ctx.getImageData(0,0,1,1);
                });
            }, _rateAry);

            return rateStr;
        } else {
            return '';
        }
    }
    function specialRate(rate, specialHtml, rateColor) {
        var rate100Class = 10 > rate ? 'rate_good_100' : 'rate_bad_100';
        var colorStyle = rateColor ? 'style="color:' + rateColor + '"' : '';
        return '<div class="good_rating divide-line">' +
                   '<div class="rate_num no_border"><span class="' + rate100Class + '" ' + colorStyle + '>' + rate + '<i>&nbsp;%</i></span><p>差评率</p></div>' +
                   '<div class="rate_all">' +
                       specialHtml +
                   '</div>' +
               '</div>';
    }
    function createStars() {
        if(POI.jsMap[POI.business] && !/^(bus|subway|event)$/.test(POI.business)) {
            var handleAttr = POI.handleAttr;
            POI.api.userAction( 'starButtonShow' , {business: POI.business});
            return '<div class="sendComment divide-line">' +
                       '<div class="comment_gray">' +
                           '<div class="sendComment_gray">' +
                               '<p ' + handleAttr + '="js_checksStar" star="1"></p>' +
                               '<p ' + handleAttr + '="js_checksStar" star="2"></p>' +
                               '<p ' + handleAttr + '="js_checksStar" star="3"></p>' +
                               '<p ' + handleAttr + '="js_checksStar" star="4"></p>' +
                               '<p ' + handleAttr + '="js_checksStar" star="5"></p>' +
                           '</div>' +
                           '<div class="sendComment_tips"><button ' + handleAttr + '="js_checksWriteBtn">写评论</button></div>' +
                       '</div>' +
                   '</div>';
        } else {
            return '';
        }
        
    }
    
    /**
     * 显示评论信息头部.
     * @param {Object} 评论列表 按时间降序
     * @return {String} html代码
     */
    function createTags(data) {
        var html = '';

        //if (html) {
        //    return '<div class="userTag_div"><ul class="userTag_ul" id="userTag_ul">' + html + '</ul></div><p class="show-more-tag hidden"><a class="canTouch" id="show_more_commont">查看更多</a></p>';
        //    //return '<section class="userTag comment_pd0">' + ( title || '') + html +'</section>';
        //}else{
        //    return '';
        //}
    }
    
    var imageRect = null;
    function getCommentImageRect() {
        if(imageRect) {
            return imageRect;
        } else {
            var bodyWidth = document.body.clientWidth || 320;
            var imgWidth = (bodyWidth - 50) / 3;
            var imgHeight = imgWidth * 2 / 3;
            imageRect = {
                width: Math.floor(imgWidth),
                height: Math.floor(imgHeight)
            };
            return imageRect;
        }
    }
    
    function createSingleComment(data, isMine) {
        var html = '';
        
        var avatarStr = '';
        if(data.author_profileurl) {
            avatarStr = '<img src="' + data.author_profileurl + '" />';
        }
        
        var nameStr = data.author || "高德用户";
        
        var scoreNum = parseFloat(data.score) || "";
        
        var picStr = '';
        if(POI.util.bool(data.pic_info)) {
            var imgRectObj = getCommentImageRect();
            var index = 0;
            if (data.pic_info.length == 4) {
                for(var i = 0, len = 6 ; i < len; i++) {
                    if (i == 2 || i == 5){
                        picStr += '<div class="box" style="width:' + imgRectObj.width + 'px;height:' + imgRectObj.width + 'px;" ></div>';
                    }
                    else {
                        picStr += '<div class="box" style="width:' + imgRectObj.width + 'px;height:' + imgRectObj.width + 'px;" ' + POI.handleAttr + '="js_openCommentNativeImage" ori="' + data.pic_info[index].url + '" idx="' + index + '"><img src="' + POI.util.imageUrlTransform(data.pic_info[index].url, imgRectObj.width, imgRectObj.height) + '"></div>';
                        index++;
                    }
                }
            }
            else {
                for(var i = 0, len = data.pic_info.length; i < len; i++) {
                    picStr += '<div class="box" style="width:' + imgRectObj.width + 'px;height:' + imgRectObj.width + 'px;" ' + POI.handleAttr + '="js_openCommentNativeImage" ori="' + data.pic_info[i].url + '" idx="' + i + '"><img src="' + POI.util.imageUrlTransform(data.pic_info[i].url, imgRectObj.width, imgRectObj.height) + '"></div>';
                }
            }

        }
        var timeStr = '';
        if (data.time) {
            var timeRes = /(\d{4})-(\d{1,2})-(\d{1,2})/.exec(data.time);
            if (timeRes && timeRes.length === 4) {
                timeStr = timeRes[1] + '年' + timeRes[2] + '月' + timeRes[3] + '日&nbsp;';
            }
        }
        
        var likeNum = parseInt(data.like_num) || 0;
        if(POI.mostTingCount < likeNum) {
            POI.mostTingCount = likeNum;
        }
        return '<li>' +
                   '<div class="head">' +
                        '<div class="img">' + avatarStr + '</div>' +
                        (nameStr ? '<p class="name lineDot">' + nameStr + '</p>' : '') +
                        (scoreNum ? '<div class="star"><p><i style="width:' + (scoreNum * 100 / 5) + '%"></i></p><span>' + scoreNum + '分</span></div>' : '') +
                        (isMine ? '<div cid="' + data.review_id + '" class="delete_comment" ' + POI.handleAttr + '="js_myCommentDelete">删除</div>' : '') +
                    '</div>' +
                    '<div class="comment_cont limits">' + data.review + '</div>' +
                    '<div class="comment_toggle">查看全文</div>' +
                    (picStr ? '<div class="comment_imgs">' + picStr + '</div>' : '') +
                    '<div class="time_resource">' +
                        timeStr +
                        (data.src_name ? '<span>来自于' + data.src_name + '</span>' : '') +
                        (likeNum ? '<span class="ting_count"><span>' + data.like_num + '个</span>&nbsp;好友挺他</span>' : '') +
                    '</div>' +
               '</li>';
    }
    
    function createMyComment(data, hasFront) {
        data = data[0];
        var myCommentStr = createSingleComment(data, true);
        if(myCommentStr) {
            var frontStr = '';
            if(!hasFront) {
                frontStr = 'style="margin-top:1rem"';
            }
            return '<div class="my_comments divide-line" ' + frontStr + '>' +
                       '<div class="title">我的评论</div>' +
                       '<ul class="comment_list">' +
                           myCommentStr +
                       '</ul>' +
                    '</div>';
        } else {
            return '<div class="my_comments"></div>';
        }
    }
    
    function createCommonComment(data, count, hasFront) {
        // 标签列表
        var html='';
        var review = data.review_list;
        if (data.sellpoints && data.sellpoints.length) {
            var buttonHtml='';
            for (var i = 0, len = data.sellpoints.length; (i < len) && (i < 9)  ; i++) {
                var point = data.sellpoints[i];
                var type = point.type;
                var level = point.level;
                var className = (type== 1 ? ' activeTag': '') + ' '+(level == 3 ? 'badTag': '');
                if (point.name) {
                    POI.tagList.push(point.name);
                    buttonHtml += '<button '+ 'tag_name="'+point.name+'"' + (type== 1 ? 'js_handle="js_openTagsBtn"' : '') + ' class="'+ className + '">' + point.name + '' + point.count + '</button>';
                }
            }
            html += '<div class="comments_tags">' +  '<div class="title">大家认为</div>'+ buttonHtml + '</div>';
        }
        else {
            html += (POI.util.bool(review))? ('<div class="comments_tags">' +  '<div class="title">大家认为</div></div>') : '';
        }
        if(!POI.util.bool(review)) {
            return '';
        }
        var commentStr = '';
        var len = Math.min(review.length, count);
        for(var i = 0; i < len; i++) {
            commentStr += createSingleComment(review[i], false);
        }
        if(commentStr) {
            var frontStr = '';
            if(!hasFront) {
                frontStr = 'style="padding-top:0.5rem"';
            }
            return  html+ '<div class="other_comments" ' + frontStr + '>'+
                        '<ul class="comment_list divide-line">' +
                           commentStr +
                        '</ul>'+
                    '</div>';
        } else {
            return '';
        }
    }
    
    function updateCommentInfo() {
        POI.commentUtil.updateStorageInfo(POI.clientData.poiInfo.poiid, false);
        getComments(showInIndex, {scenic:1,dining:1,hotel:1}[POI.business] ? 1 : 0, 2, 0, 1, 1);
    }
    
    function getFirstCommentHtml() {
        if(POI.jsMap[POI.business] && !/^(bus|subway|event)$/.test(POI.business)) {
            POI.api.userAction( 'firstWriteCommentShow' , {business: POI.business});
            return '<div id="commentDom">' +
                       '<section class="newversion_comment">' +
                           '<div class="first_comment">' +
                               '<img src="img/comment_no.png" />' +
                               '<p class="title">首个评论!</p>' +
                               '<p>把您的经历告诉更多的人，在该地点贡献榜留下您的大名！</p>' +
                               '<button ' + POI.handleAttr + '="js_openNativeCommentWrite">写评论</button>' +
                           '</div>' +
                           '<div class="my_comments"></div>' +
                       '</section>' +
                   '</div>';
        } else {
            return '';
        }
        
    }

    var hasShownFirstReview = false;
    function showFirstReview(firstReview) {
        if(!hasShownFirstReview) {
            hasShownFirstReview = true;
            POI.placeContribution.showFirstReview(firstReview);
        }
    }
    
    
/*
    好评率走势图
*/
function CommentDraw(dom,options) {
    var w = options.width || dom.width;
    var h = options.height || dom.height;
    this.dom = dom;
    this.data = options.data;
    this.scale = window.devicePixelRatio*2;
    this.width = w * this.scale;
    this.height = h * this.scale;
    this.pixy = 0;//Y方向的实际数字对应尺寸的比例
    this.min = 0;
    this.checky = 0;
    this.pointx = null;
    this.ctx = null;
    this.textHeight =  25*this.scale;
    this.textFontSize = 13*this.scale;
    this.lineWidth = 2*this.scale;
    this.maxRadius = 5*this.scale;//大圆圈的半径
    this.left = this.data[0].txt.length*this.textFontSize/2|0;
    this.init();
}
CommentDraw.prototype = {
    constructor : CommentDraw,
    init : function() {
        this.init_view();
        this.translate();
        this.check_pixy();
        this.check_pointx();
        this.draw_text();
        this.draw_ploy();
        this.draw_num();
    },
    init_view : function() {
        var dom = this.dom;
        var pstyle = dom.parentNode.style;
        var _scale = (1/this.scale).toFixed(6);
        dom.width = this.width;
        dom.height = this.height;
        pstyle.width = this.width/this.scale+'px';
        pstyle.height = this.height/this.scale+'px';
        pstyle.overflow = 'hidden';
        dom.style.webkitTransformOrigin = 'left top';
        dom.style.webkitTransform = 'scale('+_scale+','+_scale+') translateZ(0)';
        this.ctx = dom.getContext( '2d' );
    },
    /*
        翻转坐标到合适状态，便于后续操作
    */
    translate : function() {
        this.ctx.scale(1,-1);//翻转Y正负轴
        this.ctx.translate(this.left,this.textHeight-this.height);
        this.ctx.save();
    },
    check_pixy : function() {//计算y方向的对应比值
        var yheight = this.height - (this.textFontSize + this.maxRadius + this.textHeight );//上下都有文字 还有线条的宽度
        var max = ((this.data[0].num*1000|0)/1000).toFixed(3);
        var min = max;
        this.data.forEach(function( item ){
            item.num = parseFloat(item.num||0).toFixed(3);
            max = Math.max( item.num, max );
            min = Math.min( item.num, min );
        });
        var limit = max - min;
        if( limit == 0 ) {
            this.pixy = yheight;
            this.min = 0;
        } else if( limit > 0.1*max ){
            this.pixy = yheight/limit;
            this.min = min;
        } else {
            this.checky = max * yheight/2;
            this.pixy = limit ? yheight/limit/2 : 0;
            this.min = min;
        }
    },
    check_pointx : function() {
        var xwidth = this.width - this.left - this.data[this.data.length-1].txt.length * this.textFontSize / 2;
        var cut = xwidth/(this.data.length-1)|0;
        var pointx = [];
        this.data.forEach(function( item , i ){
            pointx.push( i * cut );
        });
        this.pointx = pointx;
    },
    draw_text : function() {
        var self = this;
        var ctx = this.ctx;
        var pointx = this.pointx;
        ctx.save();
        ctx.scale(1,-1);
        ctx.beginPath();
        ctx.fillStyle = '#666';
        ctx.font = 'lighter '+self.textFontSize+'px  sans-serif';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        this.data.forEach(function(item,i){
            ctx.fillText(item.txt, (pointx[i]-item.txt.length * self.textFontSize / 2)|0 , self.textHeight - self.textFontSize -2);
        });
        ctx.closePath();
        ctx.restore();
    },
    draw_ploy : function() {
        var self = this;
        var ctx = this.ctx;
        ctx.beginPath();
        ctx.strokeStyle = '#3faeff';
        ctx.lineWidth = this.lineWidth;
        this.data.forEach(function( item , i ){
            if( i == 0 ){
                ctx.moveTo(self.pointx[i],(item.num-self.min)*self.pixy+self.checky);
            } else {
                ctx.lineTo(self.pointx[i],(item.num-self.min)*self.pixy+self.checky);
            }
        });
        ctx.stroke();
        ctx.closePath();
        this.data.forEach(function( item , i ){
            ctx.beginPath();
            ctx.fillStyle = '#3faeff';
            ctx.arc(self.pointx[i],(item.num-self.min)*self.pixy+self.checky,self.maxRadius,0,Math.PI*2);
            ctx.fill();
            ctx.closePath();
            ctx.beginPath();
            ctx.fillStyle = '#ffffff';
            ctx.arc(self.pointx[i],(item.num-self.min)*self.pixy+self.checky,self.maxRadius/2,0,Math.PI*2);
            ctx.fill();
            ctx.closePath();
        });
    },
    draw_num : function() {
        var self = this;
        var ctx = self.ctx;
        ctx.scale(1,-1);
        ctx.beginPath();
        ctx.font = 'bold '+ self.textFontSize +'px  sans-serif';
        ctx.fillStyle = '#3faeff';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        self.data.forEach(function( item , i ){
            var num = item.num *1000 || 0;
            var txt = (num%10 == 0 ? parseInt(num/10) : parseFloat(num/10).toFixed(1))+'%';
            var cut = (txt.length+1)* self.textFontSize/4;//垂直手机%竟然占了一个汉字的宽度
            ctx.fillText(txt, self.pointx[i]-cut, -self.textFontSize-self.maxRadius- parseInt((item.num-self.min) * self.pixy+self.checky)-self.maxRadius/2);
        });
        ctx.closePath();
        ctx.restore();
    }
}
//end 好评率走势图
    $.extend(POI, {
        tagList : [],
        //771需求，当前选中的标签
        nameTag : null,
        tagsCount:[0,0,0,0],
        comment : {
            // poi 详情页面显示1条评论
            getIndexComment: function() {
                var aosdt = POI.util.getStorageData(),
                    count = (aosdt.rti || {}).review_count || 0,
                    html = '<div id="commentDom"></div>',
                    handleAttr = POI.handleAttr;

                var isInCacheTime = POI.commentUtil.getRefreshStatus(POI.clientData.poiInfo.poiid);

                if(isInCacheTime || count || {scenic:1,dining:1,hotel:1}[POI.business]){
                    POI.mostTingCount = 0; // poi点挺数最多的评论的挺数
                    POI.util.executeAfterDomInsert( function() {//酒店行业优先显示 买点
                        getComments(showInIndex, {scenic:1,dining:1,hotel:1}[POI.business] ? 1 : 0, 2, 0, 1, isInCacheTime);
                    });
                } else {
                    html = getFirstCommentHtml();
                }
                return html;
            }
        },
        star_animate : function( star , objs , end ) {
            var self = this, queue = self.queue(), j = 0,
                wait = 50;
            for(var i = 0; i < star; i++){
                if( !objs.eq(i).hasClass('selected') ){
                    queue.add((function( o ){
                        return function(){
                            o.addClass('min');
                            var q = self.queue();
                            q.add(function(){
                                o.removeClass('min').addClass('selected').addClass('max');
                            },wait)
                            .add(function(){
                                o.removeClass('max');
                            },wait).star();
                        }
                    })(objs.eq(i)),queue.length ? wait : 1);
                }
            }
            for( j=4; j >=star; j--){
                if( objs.eq(j).hasClass('selected') ){
                    queue.add((function( o ){
                        return function() {
                            o.addClass('min');
                            var q = self.queue();
                            q.add(function(){
                                o.removeClass('min').removeClass('selected').addClass('max');
                            },wait)
                            .add(function(){
                                o.removeClass('max');
                            },wait).star();
                        }
                    })( objs.eq(j) ), queue.length ? wait : 1);
                }
            }
            queue.add(end,100).star();
        },
        queue : function(fn, time){
            var fns = fn ? [fn] : [],
                times = fn ? [ time||300 ] : [];
            return {
                add : function(fn, time){
                    fns.push( fn );
                    times.push( time || 300);
                    this.length++;
                    return this;
                },
                star : function(){
                    var self = this,
                        fn = fns.shift(),
                        time = times.shift();
                    if( fn ) {
                        setTimeout(function(){
                            fn();
                            self.star();
                        },time);
                    }
                },
                length : fn?1:0
            }
        },
        js_checksStar : function( obj ){
            this.api.userAction( 'gotoWriteComment' , {type_business: "star_" + POI.business});
            var star = obj.attr('star');
            this.star_animate( star , $('.sendComment_gray p') , function(){
                POI.commentUtil.openNativeCommentEditor(star, POI.business, "Detailstar", updateCommentInfo, POI.clientData.poiInfo);
            } );
        },
        js_checksWriteBtn : function() {
            this.api.userAction( 'gotoWriteComment' , {type_business: "button_" + POI.business});
            POI.commentUtil.openNativeCommentEditor(0, POI.business, "Detailbutton", updateCommentInfo, POI.clientData.poiInfo);
        },
        js_openNativeCommentWrite : function() {
            this.api.userAction( 'gotoWriteComment' , {type_business: "first_" + POI.business});
            this.api.getAmapUserId({
                onlyGetId: 0
            }, function(data) {
                if(POI.util.bool(data.userid)) {
                    POI.commentUtil.openNativeCommentEditor(0, POI.business, "Firstcommon", updateCommentInfo, POI.clientData.poiInfo);
                }
            });
        },
        //hyr 2016-5-11 点击tags标签
        js_openTagsBtn : function(obj){
            var self = this;
            self.nameTag = $(obj).attr('tag_name');
            POI.util.storage("COMMENT_POIINFO", JSON.stringify(self.clientData.poiInfo));
            //发给客户端的需要变
            self.api.userAction(self.nameTag, {business: POI.business});
            self.util.loadResources(['css/comment_list.css','js/poi/commentList.js'], function(){
                self.commentlist_show(self.business,self.clientData.poiInfo.poiid);
            });
        },
        js_open_commentlist : function() {
            var self = this;
            //window.removeEventListener("pageshow", POI.js_comment_page_show, false);
            //window.addEventListener("pageshow", POI.js_comment_page_show, false);
            POI.util.storage("COMMENT_POIINFO", JSON.stringify(self.clientData.poiInfo));
            self.api.userAction('exComment', {business: POI.business});
            //self.util.locationRedirect('exComment.html?business='+self.business+'&pageId='+ self.clientData.poiInfo.poiid);
            self.util.loadResources(['css/comment_list.css','js/poi/commentList.js'], function(){
                self.commentlist_show(self.business,self.clientData.poiInfo.poiid);
            });
        },
        js_comment_page_show : function() {
            //window.removeEventListener("pageshow", POI.js_comment_page_show, false);
            var deleteCommentId = POI.util.storage("COMMENT_CHANGE_ID");
            if(deleteCommentId) {
                POI.util.storage("COMMENT_CHANGE_ID", "");
                updateCommentInfo();
            }
        },
        js_myCommentDelete : function(ele) {
            this.api.userAction( 'showDeleteDialog' );
            $("#js_poi_page").append('<div class="comment_delete_mask" ontouchmove="javascript:event.preventDefault();event.stopPropagation();">' +
                                         '<div class="cont">' +
                                             '<p>确认删除自己的评论吗</p>' +
                                             '<div class="btn_box">' +
                                                 '<div ' + POI.handleAttr + '="js_deleteComment" cid="' + ele.attr("cid") + '">删除</div>' +
                                                 '<div ' + POI.handleAttr + '="js_cancelDelete">取消</div>' +
                                             '</div>' +
                                         '</div>' +
                                     '</div>');
        },
        js_deleteComment : function(ele) {
            this.api.userAction( 'deleteCommentConfirm' );
            var cid = ele.attr("cid");
            POI.send({
                action: "getExtraUrl"
            }, function(data) {
                POI.commentUtil.updateStorageInfo(POI.clientData.poiInfo.poiid, true);
                var tid = data.tid;
                var params = [
                    {comment_id: cid, sign: 1},
                    {tid: tid, sign: 1}
                ];
                POI.api.aosrequest('commentDelete', params, function(res) {
                    if("1" == res.code) {
                        //$(".my_comments").html("");
                        updateCommentInfo();
                    } else {
                        POI.api.promptMessage("删除评论失败，请稍后再试！");
                    }
                }, 0, false, "GET");
            });
            $(".comment_delete_mask").remove();
        },
        js_cancelDelete : function() {
            this.api.userAction( 'hideDeleteDialog' );
            $(".comment_delete_mask").remove();
        },
        js_openCommentNativeImage : function(ele) {
            this.api.userAction( 'commentPrevImgIndex' );
            var $imgs = ele.parent().find(".box");
            var imgList = [];
            for(var i = 0, len = $imgs.length; i < len; i++) {
                imgList.push({
                    url: $imgs.get(i).getAttribute("ori")
                });
            }
            if(imgList.length) {
                POI.api.imagePreview("single", ele.attr("idx") | 0, imgList);
            }
        }
    })

})(POI, Zepto);
