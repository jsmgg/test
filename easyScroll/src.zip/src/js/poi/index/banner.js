/**
 * 详情页banner
 */
;
(function(POI, $) {

'use strict';

POI.banner = {
    
    showBanner : function(data) {
        if(!data.data || !data.data.length) return;
        var banner = $("#banner");
        new POI.util.loadImage(data.data[0].resource[0].content, banner[0], function() {
            banner.find("img").attr("act", data.data[0].action.url).attr("src", data.data[0].resource[0].content).show();
            banner.show();
            POI.api.userAction("bannershow", {business_id: POI.business + "_" + data.data[0].id});
            banner.on("click", "img", function() {
                POI.api.userAction("banner", {business_id: POI.business + "_" + data.data[0].id});
                var act = this.getAttribute("act"),
                    urlRegAry = act && act.match(/url=([\w\:%\.]+)&?/);
                //if(1 < urlRegAry.length) {
                //    var url = urlRegAry[1];
                //    url = encodeURIComponent(decodeURIComponent(url).replace("${poiinfo}", JSON.stringify(Matrix.poiInfo)));
                //    act = act.replace(urlRegAry[1], url);
                //}
                POI.util.loadSchema(act);
            });
        });
    },
    
    reqBanner : function() {
        POI.util.executeAfterDomInsert(function() {
            var aosData = POI.aosData || POI.util.getStorageData() || {},
                base = aosData.base;
            if(!base || 0 === Object.keys(base).length) {
                return '';
            }
            var params = [
                {x: base.x, sign: 1},
                {y: base.y, sign: 1},
                {page_id: '6'},
                {poiid: base.poiid},
                {poi_type: POI.business}
            ];
            POI.api.aosrequest("bannerUrl", params, POI.banner.showBanner, false, false, "GET");
        });
        
        return '<aside id="banner"><img></img></aside>'
    }
    
};

})(POI, Zepto);