/**
 * 头部导航栏模块
 */
 ;
 (function(POI, $) {

 'use strict';
 $.extend(POI, {
 	headerToolBar: {
 		scenicaround_flag: false,//766新增，景区，周边标志位
        bookroom_flag: false,//766新增，酒店类，订房标志位
        hotelaround_flag: false,//766新增，酒店类，周边标志位
        discount_flag: false,//766新增，美食类，优惠标志位
        queue_flag: false,//766新增，美食类，排队标志位
        building_news_flag: false,//769新增，小区行业，小区新闻标志
        hotelToolBarArr: [],
        _poiScenicToolBar : null,
        _poiScenicToolBarStr : '',
        toolbarAlipay: false,
        toolbarDiscount: false,
 		get_html: function() {
 			var self = POI;
 			var toolbar_html = '';
 			if (self.business == 'scenic') {
                if (self.aosData) {
                    if (this._poiScenicToolBar) {
                        toolbar_html = this._poiScenicToolBarStr;
                    } else {
                        this.poiScenicToolBar();
                        toolbar_html = '<div id="scenic_bar"></div>'; 
                    }
                }
            } else if (self.business == 'hotel') {
                if (self.aosData) {
                    this.poiHotelToolBar();
                    toolbar_html = '<div id="hotel_bar"></div>';
                }
                
            } else if (self.business == 'dining') {
                if (self.aosData) {
                    this.poiDinningToolBar();
                    toolbar_html = '<div id="discount_bar"></div>'; 
                }
            } else if (self.business == 'airport') {
                if (self.aosData) {                   
                    toolbar_html = this.poiAirportToolBar();; 
                }
            } else if (self.business == 'residential') {
                if (self.aosData) {
                    this.poiCommunityToolBar();
                    toolbar_html = '<div id="building_bar"></div>'; 
                }
            }
            return toolbar_html;
 		},
        //机场航站楼，导航栏信息
        poiAirportToolBar: function() {
            if ($('.poihead_cont').hasClass('tool_bar')) {
                return;
            }
            var self = POI;
            var html = '';
            var class_arr = [];
            var aosData = POI.aosData;
            var deep = self.aosData.deep[0];

            if (deep.line_type_info && (POI.util.bool(deep.line_type_info["1"]) || POI.util.bool(deep.line_type_info["0"]) || POI.util.bool(deep.line_type_info["2"]))) {
                class_arr.push({class_name:'airport_routeline', title: '线路'});
            }

            if (deep.air_info && deep.air_info.length > 0) {
                class_arr.push({class_name:'airport_company', title: '柜台'});
            }

            if (self.aosData.rti.review_count > 0) {
                class_arr.push({class_name:'header_comment', title: '评论'});
            }

            if (class_arr.length >=3) {
                html = this.poiToolBarUlHtml(class_arr);
                POI.api.userAction('showToolbar', {business: POI.business}); 
            }
            return html;
        },
        //小区行业，导航栏信息
        poiCommunityToolBar: function(obj) {
            if ($('.poihead_cont').hasClass('tool_bar')) {
                return;
            }
            var self = POI;
            var html = '';
            var class_arr = [];
            var deep = self.aosData.deep[0];
            var rti = self.aosData.rti;
            var object = rti.residential ? rti.residential[0] : {};

            if (POI.util.bool(deep.index_trans) || POI.util.bool(deep.index_dining) || POI.util.bool(deep.index_life) || POI.util.bool(deep.index_edu)) {
                class_arr.push({class_name:'building_around', title: '周边'});
            }
            if (POI.util.bool(object.price_trend) && ((object.price_trend['4'] && object.price_trend['4'].length > 0) || (object.price_trend['1'] && object.price_trend['1'].length > 0) || (object.price_trend['2'] && object.price_trend['2'].length > 0) || (object.price_trend['3'] && object.price_trend['3'].length > 0) || (object.price_trend['5'] && object.price_trend['5'].length > 0))) {
                class_arr.push({class_name:'building_price', title: '售价'});
            }
            if (self.aosData.rti.review_count > 0) {
                class_arr.push({class_name:'header_comment', title: '评论'});
            }

            if (obj) {
                this.hotelToolBarArr.push(obj);
            }
            
            if (this.building_news_flag) {
                var l = class_arr.length;
                if (class_arr[l-1].title == '评论') {
                    class_arr.splice(l-1,0,obj);
                } else {
                    class_arr.push(obj);
                }
                
                if (class_arr.length >=3) {
                    html = this.poiToolBarUlHtml(class_arr);
                    $('#building_bar').replaceWith(html);
                    POI.api.userAction('showToolbar', {business: POI.business}); 
                }
                this.hotelToolBarArr = [];
            }
        },
 		//景区行业，导航栏信息
        poiScenicToolBar: function(obj) {
            if ($('.poihead_cont').hasClass('tool_bar')) {
                return;
            }
            var self = POI;
            var html = '';
            var class_arr = [];
            var aosData = POI.aosData;
            var info = aosData.rti.scenic_guide;
            var deep = self.aosData.deep[0];
            var url;
            info && (url = info.hand_pic_url);          
            
            if (self.aosData.rti.scenic_ticket_flag && self.aosData.rti.scenic_ticket_flag.length) {
                class_arr.push({class_name:'tickets', title: '订票'});
            }
            if (url || (info && info.is_txt_tts == 1) || (deep && deep.heat_map == 1)) {
                class_arr.push({class_name:'tourist', title: '导游'});
            }
            if (deep.travels_info && self.util.bool(deep.travels_info.travel_qa) && self.util.bool(deep.travels_info.travel_notes)) {
                class_arr.push({class_name:'notes', title: '游记'});
            }
            
            if (self.aosData.rti.review_count > 0) {
                class_arr.push({class_name:'header_comment', title: '评论'});
            }

            if (obj) {
                this.hotelToolBarArr.push(obj);
            }
            
            if (this.scenicaround_flag) {
                if (this.hotelToolBarArr.length > 0 && this.hotelToolBarArr[0].class_name == 'scenic_around') {
                    class_arr.push(obj);
                }
                if (class_arr.length > 4) {
                    class_arr.splice(1,1);
                }

                if (class_arr.length >=3) {
                    html = this.poiToolBarUlHtml(class_arr);
                    $('#scenic_bar').replaceWith(html);
                    POI.api.userAction('showToolbar', {business: POI.business});
                }
                
                this._poiScenicToolBar = true;
                this._poiScenicToolBarStr = html;
                this.hotelToolBarArr = [];
            }
        },
        //酒店行业，导航栏信息
        poiHotelToolBar: function(obj) {
            if ($('.poihead_cont').hasClass('tool_bar')) {
                return;
            }
            var self = POI;
            var html = '';
            var class_arr = [];
            var deep = self.aosData.deep[0];

            if (deep.detail_facilities || deep.service) {
                class_arr.push({class_name:'header_facilities', title: '设施'});
            }
            if (self.aosData.rti.review_count > 0) {
                class_arr.push({class_name:'header_comment', title: '评论'});
            }
            if (obj) {
                this.hotelToolBarArr.push(obj);
            }
            
            if (this.bookroom_flag && this.hotelaround_flag) {
                if (this.hotelToolBarArr.length > 0 && this.hotelToolBarArr[0].class_name == 'header_room') {
                    class_arr.splice(0, 0, this.hotelToolBarArr[0]);
                    if (this.hotelToolBarArr.length > 1) {
                        class_arr.splice(1, 0, this.hotelToolBarArr[1]);
                    }
                    
                } else if (this.hotelToolBarArr.length > 0 && this.hotelToolBarArr[0].class_name != 'header_room'){
                    class_arr.splice(0, 0, this.hotelToolBarArr[1]);
                    if (this.hotelToolBarArr.length > 1) {
                        class_arr.splice(1, 0, this.hotelToolBarArr[0]);
                    }
                    
                }
                if (class_arr.length >=3) {
                    html = this.poiToolBarUlHtml(class_arr);
                    $('#hotel_bar').replaceWith(html);
                    POI.api.userAction('showToolbar', {business: POI.business}); 
                }
                this.hotelToolBarArr = [];            
            }
        },
        //美食行业，导航栏信息
        poiDinningToolBar: function(obj) {
            if ($('.poihead_cont').hasClass('tool_bar')) {
                return;
            }
            var self = POI;
            var html = '';
            var class_arr = [];
            var rti = POI.aosData.rti;
            var groupbuy = rti.groupbuy || {};
            var _discount = rti.discount || [];
            var discountLen = _discount.length;

            if (rti.alipay_koubei_url) {
                this.toolbarAlipay = true;
            }
            if (groupbuy.amount || discountLen) {
                this.toolbarDiscount = true;
            }

            if (this.toolbarAlipay || this.toolbarDiscount) {
                class_arr.push({class_name:'header_discount', title: '优惠'});
            }
            if (self.aosData.rti.review_count > 0) {
                class_arr.push({class_name:'header_comment', title: '评论'});
            }
            if (obj) {
                this.hotelToolBarArr.push(obj);
            }
            
            if (this.queue_flag) {
                if (this.hotelToolBarArr.length > 0 && this.hotelToolBarArr[0].class_name == 'header_queue') {
                    if (class_arr.length > 1) {
                        class_arr.splice(1, 0, this.hotelToolBarArr[0]);
                    } else {
                        class_arr.splice(0, 0, this.hotelToolBarArr[0]);
                    }
                }
                
                if (class_arr.length >=3) {
                    html = this.poiToolBarUlHtml(class_arr);
                    $('#discount_bar').replaceWith(html);
                    POI.api.userAction('showToolbar', {business: POI.business});
                }
                this.hotelToolBarArr = [];             
            }
        },
        poiToolBarUlHtml: function(class_arr) {
            var pre_html = '<div class="tool_bar divide-line all-line"><ul>';
            var last_html = '<li class="flex"></li></ul></div>';
            var li_arr = [];
            for (var i=0; i<class_arr.length; i++) {
                /*var flex = i == (class_arr.length - 1)?'':'<li class="flex"></li>';*/
                var li_str = '<li class="flex"></li>'+
                             '<li class="'+class_arr[i].class_name+'" ' + POI.handleAttr + '="js_' + class_arr[i].class_name + '"><i></i><span>'+
                             class_arr[i].title+'</span></li>';
                li_arr.push(li_str);
            }
            
            return pre_html+li_arr.join('')+last_html;
        }
 	},
    js_header_discount : function() {
        var alipay = POI.index.toolbarAlipay;
        var discount = POI.index.toolbarDiscount;
        var domStr = '';
        if (alipay) {
            domStr = $('.alipay');
        } else if (discount) {
            domStr = $('#js_dinning_tuanhui');
        } else if (alipay && discount) {
            domStr = $('.alipay');
        }
        POI.api.userAction('toolBarDiscount');
        document.body.scrollTop = domStr.offset().top - POI.util.getTitleBarHeight();
    },
    js_header_queue : function() {
        POI.api.userAction('toolBarDiningQueue', {business: POI.business});
        $(".queue_start_queue").click();
    },
    js_header_comment : function() {
        POI.api.userAction('toolBarHeaderComment', {business: POI.business});        
        document.body.scrollTop = $("#commentDom").offset().top - POI.util.getTitleBarHeight();
    },
    js_header_room : function() {
        POI.api.userAction('toolBarBookRoom', {business: POI.business});
        document.body.scrollTop = $("#hotel").offset().top - POI.util.getTitleBarHeight();
    },
    js_header_around : function() {
        POI.api.userAction('toolBarHotelAround', {business: POI.business});
        document.body.scrollTop = $("#hotel_easy").offset().top - POI.util.getTitleBarHeight();
    },
    js_header_facilities : function() {
        POI.api.userAction('toolBarHotelFacilities', {business: POI.business});
        $("#baseIntro").click();
    },
    js_tourist : function() {
        POI.api.userAction('toolBarShowVoiceGuide', {business: POI.business});
        document.body.scrollTop = $("#scenic_guide").offset().top - POI.util.getTitleBarHeight();
    },
    js_notes : function() {
        POI.api.userAction('toolBarTravelNotes', {business: POI.business});
        document.body.scrollTop = $("#notesAndQa").offset().top - POI.util.getTitleBarHeight();
    },
    js_scenic_around : function() {
        POI.api.userAction('toolBarScenicAround', {business: POI.business});
        document.body.scrollTop = $("#scenic_around").offset().top - POI.util.getTitleBarHeight();
    },
    js_tickets : function() {
        POI.api.userAction('toolBarTicketBooking_up', {business: POI.business});
        POI.js_toggleScenicMore();
    },
    js_airport_routeline: function() {
        POI.api.userAction('toolBarAirportLine', {business: POI.business});
        document.body.scrollTop = $("#air_routeline").offset().top - POI.util.getTitleBarHeight(); 
    },
    js_airport_company: function() {
        POI.api.userAction('toolBarAirportCompany', {business: POI.business});
        document.body.scrollTop = $("#airCompany").offset().top - POI.util.getTitleBarHeight();
    },
    js_building_around: function() {       
        POI.api.userAction('toolBarCommunityAround', {business: POI.business});
        document.body.scrollTop = $("#building_livable").offset().top - POI.util.getTitleBarHeight();
    },
    js_building_price: function() {
        POI.api.userAction('toolBarCommunityPrice', {business: POI.business});
        document.body.scrollTop = $("#building_price").offset().top - POI.util.getTitleBarHeight();
    },
    js_building_news: function() {        
        POI.api.userAction('toolBarCommunityNews', {business: POI.business});
        document.body.scrollTop = $("#community_news").offset().top - POI.util.getTitleBarHeight();
    }
 });

 })(POI, Zepto);