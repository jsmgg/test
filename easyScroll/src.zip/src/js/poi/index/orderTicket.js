/**
 * 景点首页相关
 */

(function(POI, $) {
    'use strict';
    var travelItem = {
        scenic_busy : false,//门票请求锁
        aTotalTicketList: {}, //表示2次请求所有的订票列表数据
        nTicketPriceList: [], //用来存储票价
        travel_page : null,
        /*订票首页返回html结构总入口*/
        fSerializeTravelData: function() {
            var self = this,
                handleAttr = POI.handleAttr,
                spec = POI.aosData.spec;
            /*展示一块去那儿的入口*/
            var _fShowUrlData = function() {
                    if (spec.scenic_yikuaiqu_api && spec.scenic_yikuaiqu_api.order_url) {
                        return '<section '+ handleAttr +'="js_goTravelUrl"><h2 class="module_title_p more">订门票</h2></section>';
                    } else {
                        return '';
                    }
                },
                /*展示订门票的模块*/
                _fShowOrderTicketData = function() {
                    var scenicFlag = POI.aosData.rti.scenic_ticket_flag || [],
                        len = scenicFlag.length;
                    if (!len) return '';
                    for (var i = 0; i < len; i++) {
                        if (scenicFlag[i].status == 1) {
                            self.requestTicketData(1, 1, 0, 1);
                            POI.util.loadResources("js/lib/iscroll.js");
                            POI.api.userAction("orderTicketShow");
                            return '<section id="ticketBooking" style="display:none;">'+
                                       '<h2 class="scenicTicket_title module_title">订门票</h2>'+
                                       '<div id="js_scenicTicket_box"></div>'+
                                   '</section>'+
                                   '<section id="testViewMore" class="scenicTicket_switch canTouch" style="display:none" '+ handleAttr +'="js_toggleScenicMore">' +
                                       '<a href="javascript:void(0);">查看全部<i></i></a>' +
                                   '</section>';
                        }
                    }
                    if (i == len) {
                        return '';
                    }
                };
            // 有订票模块就要把一块去的入口隐藏
            var ticketData = _fShowOrderTicketData();
            var txt = ticketData ? ticketData : _fShowUrlData();
            return txt ? '<div id="travel">' + txt + '</div>' : '';

        },
        data_cache : {},
        /*请求首页订票数据*/
        requestTicketData: function(pagenum, pagesize, pages, is_tag, tag, fn) {
            var self = this,
                param = [{
                    poiid: POI.aosData.base.poiid,
                    sign: 1
                }, {
                    pmode: '0,1',
                    sign: 0
                }];
            if( self.scenic_busy ) return;
            pagenum && param.push({
                pagenum: pagenum,
                sign: 0
            });
            pagesize && param.push({
                pagesize: pagesize,
                sign: 0
            });
            is_tag && param.push({
                is_tag: is_tag,
                sign: 0
            });
            pages && param.push({
                pages: pages,
                sign: 0
            });
            tag && param.push({
                tag: tag,
                sign: 0
            });
            self.scenic_busy = true;
            var key = JSON.stringify( param );
            if( self.data_cache[ key ] ) {
                cb(self.data_cache[ key ]);
            } else {
                POI.api.aosrequest("scenicTickets", param, cb , fn?1:0, true, "GET");
            }
            function cb(arg) {
                if(1 == arg.code) {
                    self.responseTicketData(arg, is_tag?1:0, fn);
                    self.data_cache[ key ] = arg;
                    self.scenic_busy = false;
                }
                self.scenic_busy = false;
            }
        },
        key_index : 0,
        /*响应并解析订票数据*/
        responseTicketData: function(arg, is_tag, fn) {
            var len = arg.ticket_list && arg.ticket_list.length,
                scenicList = arg.ticket_list,
                ticketList = [],unitList,cache_key,
                man_ticket_typeid = '101',//成人票id，与服务端约定的
                navs = '',
                typeid = '',
                key,
                list_key = '',
                obj,
                self = this;
            if (arg.code != 1 || !len) return;
            for (var i = 0, len = scenicList.length; i < len; i++) {
                typeid = scenicList[i].typeid;
                //门票动态价格取成人票中最低价展示，若没有成人票则取静态价格
                typeid == man_ticket_typeid && self.nTicketPriceList.push(scenicList[i].current_price);
                cache_key = 'scenic_order_key_' + self.key_index++;//缓存数据唯一key, 与弹框的id也是一一对应
                unitList = self.modelTicketUI(scenicList[i], cache_key);
                ticketList.push(unitList);
                self.aTotalTicketList[ cache_key ] = scenicList[i];//缓存数据
            }
            var selected = $('.default_header .scenicTicket_item_nav p.selected').length ?  $('.default_header .scenicTicket_item_nav p.selected') : $('.scenicTicket_item_nav p.selected');
            key = selected.length ? selected.attr( 'id' ) : arg.tags[0].typeid;
            if( is_tag && arg.tags && arg.tags.length ) {
                navs = self.get_item_nav( arg.tags , key );
            }
            list_key = 'js_scenicelist_key'+key;
            if( fn ){
                fn( navs , '<ul id="'+ list_key +'_page" class="js_scenic_ticketlist" total="'+ arg.total +'">'+ (ticketList.join('')||'') + '</ul>');
            } else {
                if( $('#'+list_key).length ) {
                    $('#'+list_key).append( ticketList.join('')||'' );
                } else {
                    $('#js_scenicTicket_box').append(navs + '<ul id="'+ list_key +'" class="js_scenic_ticketlist" total="'+ arg.total +'">'+ (ticketList.join('')||'') + '</ul>');
                }
                $('#testViewMore').css('display', arg.total > 1 ? 'block' : 'none');
                if(arg.total > 1) {
                    POI.api.userAction("orderTicketMoreShow");
                }
                if($('#js_switchGroup_nav').hasClass( 'active' )) {
                    $('#testViewMore').attr('data-display',$('#testViewMore').css('display')).hide()
                }
                is_tag && $('#ticketBooking').show();
                
                if( is_tag ) {//给第一个选中的标签加选中样式
                    obj = $( '.scenicTicket_item_nav p.selected' );
                    obj.find( 'canvas' ).length ==0 && obj.append( self.get_scenic_navbg( obj.width() ) );
                    POI.api.userAction("orderTicketTagShow");
                }
            }

            POI.business==='scenic' && typeid == man_ticket_typeid && self.calculateMinTicketPrice(); //计算最低票价
        },
        get_item_nav : function( tags , key) {
            var item_nav  = [], handleAttr = POI.handleAttr, count;
            item_nav.push( '<article class="scenicTicket_item_nav">' );
            tags.forEach( function( item , i ) {
                item.typetag && item_nav.push( '<p' + ( item.typeid==key ? ' class="selected canTouch"' : ' class="canTouch"') + ' '+ handleAttr +'="js_secicTicket_nav" id="'+ item.typeid +'" tag="'+ ( item.typetag || '') +'">'+( item.typetag )+'</p>' );
            } );
            count = 4 - (item_nav.length -1);
            count >0 && item_nav.push( '<p class="empty">' + ( new Array( count )).join( '</p><p class="empty">' ) + '</p>' );
            item_nav.push( '</article>' );
            return item_nav.join('');
        },
        update_nav : function( obj ) {//切换门票分类标签
            var self = this, id = obj.attr( 'id' ), tag = obj.attr( 'tag' ) , box;
            if( self.scenic_busy ) return;
            if( !self.travel_page ){
                box = $('#js_scenicelist_key'+id);
                if( !box.length ) {
                    self.requestTicketData(1, 1, 0, 0, tag);
                }
                $( 'ul.js_scenic_ticketlist' ).hide();
                box = $('#js_scenicelist_key'+id);
                box.length && $('#testViewMore').css('display', box.attr('total') > 1 ? 'block' : 'none');
                box.length && box.show();
            } else {
                box = $('#js_scenicelist_key'+id+'_page');
                if( !box.length ) {
                    self.requestTicketData(0, 0, 0, 0, tag, function(nav,content){
                        $( '#js_travel_pagebox ul.js_scenic_ticketlist' ).hide();
                        $('#js_travel_pagebox').append( content );
                        self.travel_page.refresh(1);
                        self.travel_page.load_end();
                    });
                } else {
                    $( '#js_travel_pagebox ul.js_scenic_ticketlist' ).hide();
                    box.show();
                    self.travel_page.refresh(1);
                    self.travel_page.load_end();
                }
            }
            obj.parent().find( 'p.selected' ).removeClass( 'selected' );
            obj.addClass( 'selected' );
            obj.find( 'canvas' ).length ==0 && obj.append( self.get_scenic_navbg( obj.width() ) );
        },
        get_scenic_navbg : function(width) {
            return new POI.util.DialogBox({
                width: width,
                height: 30,
                borderWidth: 1,
                borderColor: "#0091ff",
                borderRadius: 2,
                arrowDirection: 0,
                arrowDistance:  (width - 10)/2,
                arrowWidth: 10,
                arrowHeight: 5
            });
        },
        /*计算最低票价*/
        calculateMinTicketPrice: function(){
            var that = this,classify = POI.aosData.base.classify,level = POI.aosData.deep[0].level;
            var miniestPrice = Math.min.apply(null,that.nTicketPriceList);
            var tags = '';

            if (POI.aosData.base.std_t_tag_0_v) {
                var arr = POI.aosData.base.std_t_tag_0_v.split(';');
                for (var i=0; i<arr.length; i++) {
                    tags += POI.index.moduleHeadItem(arr[i]);
                }
            }
            POI.index.moduleDeepHead(tags,'门票<span class="min_money">¥' + miniestPrice +'</span>起');
        },
        /*请求订票须知的接口*/
        requestTicketDetailData: function(key) {
            var that = this,ticketid, srctype, cache = that.aTotalTicketList;
            ticketid = cache[key].ticketid, srctype = cache[key].src_type;
            if (!ticketid || !srctype) {
                return;
            }
            var Params = [{
                poiid: POI.aosData.base.poiid,
                sign: 1
            }, {
                ticketid: ticketid,
                sign: 1
            }, {
                src_type: srctype,
                sign: 1
            }, {
                is_calendar: 0,
                sign: 0
            }, {
                mode: 0,
                sign: 0
            }];
            POI.api.aosrequest("scenicSendTickets", Params, function(arg) {
                that.responseDetailLayerData(arg,key);
            }, 1, true, "GET");
        },
        responseDetailLayerData : function(arg, key) {
            var self = this, html;
            if (!arg || arg.code != 1 || !arg.ticket_info) {
                return;
            }
            html = self._get_detailLayerHtml( arg.ticket_info , key );
            $('#js_poi_page').append( html );
            self.invokeIScroll( key );
        },
        _get_detailLayerHtml : function( ticket , key ) {//获取浮层html
            var self = this, handleAttr = POI.handleAttr,
                html = [ '<div class="scenicTicket_dialog" id="' + key + '" '+ handleAttr +'="js_closeTravelLayer">' ],
                data_map = self._get_data_map( ticket.notice );
            html.push( '<div class="scenicTicket_dialog_wrap" '+ handleAttr +'="js_preventDefault"><div class="scenicTicket_dialog_scroll"><article>' );
            html.push( '<h2 class="scenicTicket_dialog_title">预订须知</h2>' );
            html.push( '<h3>'+ (ticket.name || '')+'</h3>' );
            
            if( ticket.latest_time ) {//预订时间
                html.push( '<div class="scenicTicket_dialog_item"><h2>预订时间</h2>' );
                html.push( '<span>'+ ( ticket.advance_day>0 ? '需要提前' + ticket.advance_day + '天在'+ ticket.latest_time +'之前订票': ticket.latest_time + '前可预订当日票') +'</span>' );
                html.push( '请尽早预订，以免耽误行程。</div>' );
            }
            
            // scenic_17u_api:同程； scenic_ctrip_api：携程
            if( ticket.src_type == 'scenic_17u_api' && ticket.gmode ) {//同程
                html.push('<div class="scenicTicket_dialog_item"><h2>兑换方式</h2>' + ticket.gmode + '</div>');
            } else if( data_map[ '兑换方式' ] ){//否则认为是 携程
                html.push('<div class="scenicTicket_dialog_item"><h2>兑换方式</h2>' + data_map[ '兑换方式' ] + '</div>');
            }

            if( ticket.src_type == 'scenic_17u_api' && data_map[ '温馨提示' ] ) {
                html.push( '<div class="scenicTicket_dialog_item"><h2>温馨提示</h2>' + data_map[ '温馨提示' ] + '</div>' );
            } else if( data_map[ '费用包含' ] || data_map[ '重要条款' ] ) {
                html.push( '<div class="scenicTicket_dialog_item"><h2>温馨提示</h2>' + (data_map[ '费用包含' ] || '') + (data_map[ '重要条款' ] || '') + '</div>' );
            }
            
            if( data_map[ '退改规则' ] ) {
                html.push( '<div class="scenicTicket_dialog_item"><h2>退改规则</h2>' + data_map[ '退改规则' ] + '</div>' );
            }
            html.push('</article></div>');// end .scenicTicket_dialog_scroll
            
            html.push( '<div class="scenicTicket_dialog_footer"><div class="scenicTicket_dialog_pricebox">' );
            
            html.push( '<p class="scenicTicket_dialog_price">' + ((ticket.current_price && ticket.current_price > 0) ? '￥' + self.limitPrice(ticket.current_price) : ' ') + '</p>' );
            
            html.push( '<p class="scenicTicket_dialog_oprice">' + ((ticket.original_price && ticket.original_price > 0) ? '￥' + self.limitPrice(ticket.original_price) : ' ') + '</p>' );
            
            if(POI.util.bool(ticket.src_name)) {
                html.push( '<p class="scenicTicket_dialog_tips">来源：' + ticket.src_name + '</p>' );
            } else {
                if(ticket.pmode == 0 || ticket.pmode == 1){// pmode : 0 现场支付  1 在线支付
                    html.push( '<p class="scenicTicket_dialog_tips">'+ (ticket.pmode == 0? '现场支付' : '在线支付') +'</p>' );
                }
            }
            html.push('</div>');// end .scenicTicket_dialog_pricebox
            html.push( '<p class="scenicTicket_dialog_btn canTouch"  ' + handleAttr+ '="js_openTravelOrderPage" ticketID="' + ticket.ticketid + '" srcType="' + ticket.src_type + '" orderUrl="' + ticket.order_url + '" fromLayer="true" canLocalOpen="' + ticket.can_resell + '">预订</p>' );
            html.push('</div>' );// end .scenicTicket_dialog_footer
            html.push('</div>');// end.scenicTicket_dialog_wrap
            html.push( '</div>' );// end .scenicTicket_dialog
            return html.join('');
        }, 
        _get_data_map : function( notice ) {//获取浮层展示数据key-value形式数据
            var datamap = {};
            ( notice || []).forEach( function( item ) {
                (item.ninfo || []).forEach( function( obj ) {
                    datamap[ obj.nname ] = obj.ncontent||'';
                } );
            } );
            return datamap;
        },
        /*使用IScroll控件*/
        invokeIScroll: function( key ) {
            POI.util.loadResources("js/lib/iscroll.js", function() {
                var box = $('#'+key+' div.scenicTicket_dialog_scroll');
                new IScroll(box[0], {
                    scrollbars: true,
                    mouseWheel: true,
                    interactiveScrollbars: true,
                    shrinkScrollbars: 'scale',
                    fadeScrollbars: true
                });
                $('#'+key).bind('touchmove', function(e) {
                    e.preventDefault();
                });
            });
        },
        /*格式化订票模块中的价格*/
        limitPrice: function(price) {
            var _price = Number(price),
                testPrice = /^(\d+\.{1}\d+)$/;
            if (testPrice.test(_price)) {
                //说明是小数
                return _price.toFixed(2);
            } else {
                return _price;
            }
        },
        /*格式化订票模块中的日期*/
        limitDay: function(d) {
            var day = '';
            switch (d) {
                case '0':
                    day = '当日';
                    break;
                case '1':
                    day = '明日';
                    break;
                default:
                    day = d + '日后';
                    break;
            }
            return day;
        },
        /*组件化订票模块中的单元*/
        modelTicketUI: function(slist, cache_key) {
            var that = this,
                handleAttr = POI.handleAttr;
            return '<li class="scenicTicket_item canTouch" '+ handleAttr+'="js_openTravelLayer" key="'+ cache_key +'">' +
                       '<div class="scenicTicket_detail">' +
                           '<p class="scenicTicket_name lineDot">' + (slist.typename ? '【'+slist.typename+'】' : '') +(slist.name || '') + '</p>' +
                           ((slist.advance_day && slist.latest_time) ?
                           '<p class="scenicTicket_explain">' + slist.latest_time + '前可预订' + that.limitDay(slist.advance_day) + '门票</p>' : '') +
                       '</div>' +
                       '<div class="scenicTicket_price">' +
                           '<p class="scenicTicket_now">' + ((slist.current_price && slist.current_price > 0) ? '￥' + that.limitPrice(slist.current_price) : ' ') + '</p>' +
                           '<p class="scenicTicket_ori">' + ((slist.original_price && slist.original_price > 0) ? '￥' + that.limitPrice(slist.original_price) : ' ') + '</p>' +
                       '</div>' +
                       '<div ' + handleAttr+ '="js_openTravelOrderPage" class="scenicTicket_btn half-border canTouch" ticketID="' + slist.ticketid + '" srcType="' + slist.src_type + '" orderUrl="' + slist.order_url + '" fromLayer="true" canLocalOpen="' + slist.can_resell + '">' +
                           '<p class="scenicTicket_book">预订</p>' +
                           '<p class="scenicTicket_type">' + (slist.pmode == 0 ? '现场支付' : (slist.pmode == 1 ? '在线支付' : ' ')) + '</p>' +
                       '</div>' +
                   '</li>';
        },
        cpOrderAdd : function(srcType, orderUrl) {
            var self = this, poiInfo = POI.aosData;
            if (!poiInfo) {
                poiInfo = POI.aosData = POI.util.getStorageData();
            }
            poiInfo = poiInfo.base;
            var param = [
                {cp_source    : srcType, sign: 1},
                {poi_id       : poiInfo.poiid, sign: 1},
                {longitude    : poiInfo.x},
                {latitude     : poiInfo.y},
                {poi_name     : poiInfo.name},
                {poi_address  : poiInfo.address},
                {poi_tel      : (poiInfo.telephone||'').replace(/\/|;/g, ',')},
                {url          : orderUrl}
            ];
            POI.api.aosrequest('scenicCPOrderAdd', param, function(res) {
                if("14" == res.code || "27" == res.code) {
                    POI.api.loginBind('phone', function(userInfo) {
                        if (!userInfo.phone) {
                            POI.api.promptMessage('为了方便预订和订单查询，请先登录并绑定手机号');
                            return;
                        }
                        self.cpOrderAdd(srcType, orderUrl);
                    });
                }
                if (res.code != '1') {
                    return;
                }
                POI.api.getAppPara('', '', res.url);
                POI.api.userAction('getScenicTicket',{way_src:'url_'+orderUrl});
            }, false, true);
        }
    };

    $.extend(POI,{
        travelItem : travelItem,
        /*打开下单页面*/
        js_openTravelOrderPage: function( tar ) {
            var self = POI,
                canLocalOpen = tar.attr('canLocalOpen'),
                ticketID = tar.attr('ticketID'),
                srcType = tar.attr('srcType'),
                orderUrl = tar.attr('orderUrl'),
                fromLayer = tar.attr('fromLayer'),
                dialogs = $('.scenicTicket_dialog');
            dialogs.length && dialogs.hide();
            if (canLocalOpen == 1) {
                //本地下单
                var oAllOrderArg = {
                    'ticketID' : ticketID,
                    'srcType' : srcType
                }
                oAllOrderArg.poiInfo = self.clientData.poiInfo;
                var exTravelUrl = encodeURI('exTravelOrder.html?oAllOrderArg='+JSON.stringify(oAllOrderArg));
                self.util.locationRedirect(exTravelUrl);
                self.api.userAction('getScenicTicket',{way_src:'loc_'+fromLayer});
            } else if(2 == canLocalOpen) {
                //第三方订单回传流程
                self.travelItem.cpOrderAdd(srcType, orderUrl);
            } else {
                //跳转第三方下单
			    self.api.getAppPara('', '', orderUrl);
			    self.api.userAction('getScenicTicket',{way_src:'url_'+orderUrl});
			}
            return false;//这里要返回false  阻止代理事件往上查找，避免触发了购买须知的弹窗
        },
        /*打开订票须知浮层*/
        js_openTravelLayer: function( obj ) {
            var that = travelItem,
                key = obj.attr( 'key' ),
                dialog = $('#'+key);
            if ( dialog.length ) {
                dialog.css('display','-webkit-box');
            } else {
                that.requestTicketDetailData(key);
            }
            this.api.userAction('showfloatLayer');
        },
        js_closeTravelLayer : function( obj ) {//关闭购买须知浮层
            obj.hide();
        },
        js_preventDefault : function() {
            return false;
        },
		/*打开一块去旅行入口*/
		js_goTravelUrl: function() {
			var orderurl = this.aosData.spec.scenic_yikuaiqu_api.order_url;
			this.api.getAppPara('', '', orderurl);
			this.api.userAction('travelTicket');
		},
		/*切换查看收起列表*/
		js_toggleScenicMore: function( obj ) {
            var self = this,
                nav = $('.scenicTicket_item_nav p.selected');
            if( self.travelItem.scenic_busy ) return;
            self.travelItem.requestTicketData(0, 0, 0, 1, nav.attr( 'tag' ), function(nav, content){
                self.travelItem.travel_page = self.scrollPage({
                    defaultHeader : '订门票',
                    content : nav+'<div id="js_travel_pagebox" style="padding-bottom:44px;">'+content+'</div>'
                });
                var obj = $( '.scrollPage .scenicTicket_item_nav p.selected' );
                obj.find( 'canvas' ).length ==0 && obj.append( self.travelItem.get_scenic_navbg( obj.width() ) );
                self.travelItem.travel_page.load_end();
                self.travelItem.travel_page.destroy(function(){
                    self.travelItem.travel_page = null;
                });
                
            });
            self.api.userAction('ticketBooking_up');
        },
        js_secicTicket_nav : function(obj) {//订票模块切换门票类型
            var self = this;
            if( !obj.hasClass( 'selected' ) ) {
                self.travelItem.update_nav( obj );
                self.api.userAction('secicTicketCat',{name:obj.attr( 'tag' )});
            }
        }
    });

})(POI, Zepto);
