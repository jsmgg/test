/**
 * 详情页banner
 */
;
(function(POI, $) {

'use strict';

POI.spGuide = {
    
    indoorData : null,
    
    poiBase : null,
    
    keyMap : {
        "美食"     : "ms",
        "服饰鞋包" : "fsxb",
        "休闲娱乐" : "xxyl",
        "化妆品"   : "hzp",
        "运动户外" : "ydhw",
        "家电数码" : "jdsm",
        "珠宝首饰" : "zbss",
        "母婴用品" : "myyp",
        "家居建材" : "jjjc",
        "其他"     : "qt"
    },
    
    shoppingGuideScroll : function() {
        POI.easyScroll(".shopping_guide_scroll", {
            align: "x",
            preventDefault: false
        });
    },
    
    showShoppingGuide : function(shoppingGuide) {
        var keyMap = POI.spGuide.keyMap;
        var len = shoppingGuide.length;
        var html = '';
        var partHtml = '';
        for(var i = 0, name = ""; i < len; i++) {
            name = shoppingGuide[i].name;
            if(0 === i % 5) {
                if(partHtml) {
                    html += '<div class="shopping_guide_s_con">' + partHtml + '</div>';
                    partHtml = '';
                }
                html += '<li class="shopping_guide_item big ' + keyMap[name] + '" ' + POI.handleAttr + '="js_shoppingOpenList" maintype="' + name + '"><i class="shopping_guide_icon_' + keyMap[name] + '"></i><span>' + name + '</span></li>';
            } else {
                partHtml += '<li class="shopping_guide_item ' + keyMap[name] + '" ' + POI.handleAttr + '="js_shoppingOpenList" maintype="' + name + '"><button><span>' + name + '</span></button></li>';
            }
        }
        if(partHtml) {
            html += '<div class="shopping_guide_s_con">' + partHtml + '</div>';
            partHtml = '';
        }
        if(html) {
            POI.api.userAction("spGuideShow");
            POI.util.executeAfterDomInsert(POI.spGuide.shoppingGuideScroll);
            // 标签展示5个一组，lastCount表示最后一组的数量
            var lastCount = len % 5;
            // 目前5个一组的宽度是282,每个标签宽80，间距4
            var ulWidth = 282 * Math.floor(len / 5) + (4 > lastCount ? lastCount * 94 : 282) + 4;
            return '<section class="shopping_guide">' +
                       '<h2 class="shopping_guide_title line-half">购物指南</h2>' +
                       '<div>' +
                           '<article class="shopping_guide_scroll">' +
                               '<ul class="shopping_guide_ul" style="width: ' + (ulWidth / 10) + 'rem">' + html + '</ul>' +
                           '</article>' +
                       '</div>' +
                   '</section>';
        } else {
            return '';
        }
    },
    
    floorGuideItemWidth : 0,
    
    getDefaultBrandHtml : function(name) {
        if(!name) return '';
        var width = POI.spGuide.floorGuideItemWidth * 0.6;
        var zoom = width / 36;
        return '<button class="' + POI.spGuide.keyMap[name] + '" style="-webkit-transform: translateY(-50%) scale(' + zoom + ');">' + name + '</button>';
    },
    
    showFloorGuide : function(floorGuide) {
        var html = '';
        var itemHtml = '';
        var _liHtml = '';
        var count = 0;
        var width = (document.body.clientWidth - 44) / 4;
        POI.spGuide.floorGuideItemWidth = width;
        for(var i = 0, len = floorGuide.length, item = null; i < len; i++) {
            item = floorGuide[i];
            _liHtml = '';
            for(var j = 0, _len = item.poilist.length, _poi = null, _imgHtml = ''; j < _len; j++) {
                _poi = item.poilist[j];
                if(POI.util.bool(_poi.brand_logo)) {
                    _imgHtml = '<img ori-src="' + _poi.brand_logo + '?type=pic" style="display: none;" category="' + _poi.category + '"/>';
                } else {
                    _imgHtml = POI.spGuide.getDefaultBrandHtml(_poi.category);
                }
                _liHtml += '<li style="width: ' + width + 'px;" ' + POI.handleAttr + '="js_gotoMainMap" poi=\'' + JSON.stringify(_poi) + '\' flno="' + item.fl_no + '">' +
                               '<div class="floor_guide_item_logo" style="width: ' + width + 'px;height: ' + width + 'px;">' + _imgHtml + '</div>' +
                               '<p class="floor_guide_item_name lineDot">' + _poi.name.replace(/[\(（].*[）\)]/, '') + '</p>' +
                           '</li>';
            }
            if(_liHtml) {
                itemHtml += '<h3 class="floor_guide_item_title more" ' + POI.handleAttr + '="js_shoppingOpenList" flname="' + item.name + '" flno="' + item.fl_no + '"><span>' + item.name + '</span>' + item.main_type + '</h3>';
                itemHtml += '<ul class="floor_guide_item_ul">' + _liHtml + '</ul>';
            }
            if(itemHtml) {
                count += 1;
                if(3 < count) {
                    // 详情页最多展示三个楼层，所以多余的注释掉
                    //html += '<div class="floor_guide_item none">' + itemHtml + '</div>';
                } else {
                    html += '<div class="floor_guide_item">' + itemHtml + '</div>';
                }
                itemHtml = '';
            }
        }
        if(html) {
            POI.api.userAction("fGuideShow");
            POI.util.executeAfterDomInsert(POI.spGuide.floorGuideImageLoad);
            return '<section class="floor_guide">' +
                       '<h2 class="floor_guide_title line-half">楼层导览</h2>' +
                       html +
                       (3 < count ? '<a class="floor_guide_btn canTouch" href="javascript:void(0);" ' + POI.handleAttr + '="js_shoppingFloorGuideAll"><span>查看全部楼层<i class="arrow close"></i></span></a>' : '') +
                   '</section>';
        } else {
            return '';
        }
    },
    
    floorGuideImageLoad : function() {
        var imgs = $(".floor_guide img[ori-src]");
        for(var i = 0, len = imgs.length, item = null; i < len; i++) {
            item = imgs[i];
            new POI.util.loadImage(item.getAttribute("ori-src"), item, POI.spGuide.floorGuideImageLoadSuccess, POI.spGuide.floorGuideImageLoadError);
        }
    },
    
    floorGuideImageLoadSuccess : function(ele, img) {
        ele.src = img.src;
        ele.style.display = "";
        img = null;
        ele.removeAttribute("ori-src");
    },
    
    floorGuideImageLoadError : function(ele, img) {
        var errorHtml = POI.spGuide.getDefaultBrandHtml(ele.getAttribute("category"));
        $(ele).replaceWith(errorHtml);
    },
    
    addEvent : function() {
        $.extend(POI, {
            js_shoppingOpenList : function(ele, e) {
                var mainType = ele.attr("maintype"),
                    flName = ele.attr("flname"),
                    flno = ele.attr("flno"),
                    params = {},
                    logkey = "";
                if(mainType) {
                	params.main_type = mainType;
                	logkey = "shoppingGuide";
                }
                if(flName) {
                	params.fl_name = flName;
                	logkey = "floorGuide";
                }
                if(logkey) {
                	POI.api.userAction(logkey, {
                		name_key : POI.spGuide.poiBase.name + "_" + (mainType || flno || "")
                	});
                }
                POI.api.triggerFeature("shoppingList", POI.spGuide.poiBase, params);
            },
            
            js_gotoMainMap : function(ele, e) {
                var poi = null;
                try {
                    poi = JSON.parse(ele.attr("poi"));
                } catch(e) {}
                if(poi) {
                    var param = {
                        poiInfo: {
                            poiid: poi.poiid,
                            name: poi.name,
                            new_type: poi.new_type,
                            lon: poi.x,
                            lat: poi.y,
                            x: poi.pixelx,
                            y: poi.pixely
                        },
                        showIndoorMap: true,
                        floor : ele.attr("flno"),
                        status: '3'
                    };
                    POI.api.userAction('gotoMainMap', {mname_mpoiid_name_poiid: POI.spGuide.poiBase.name + "_" + POI.spGuide.poiBase.poiid + "_" + poi.name + "_" + poi.poiid});
                    POI.api.openPoi(param);
                }
            },
            
            js_shoppingFloorGuideAll : function(ele, e) {
                //if(ele.find("i").hasClass("open")) {
                //    $("body").scrollTop(0);
                //    setTimeout(function() {
                //        POI.spGuide.floorGuideHideDoms.addClass("none");
                //        ele.html('<span>查看全部楼层<i class="arrow"></i></span>');
                //    }, 0);
                //} else {
                //    if(!POI.spGuide.floorGuideHideDoms) {
                //        POI.spGuide.floorGuideHideDoms = $(".floor_guide .floor_guide_item.none");
                //    }
                //    POI.spGuide.floorGuideHideDoms.removeClass("none");
                //    ele.html('<span>收起<i class="arrow open"></i></span>');
                //}
                //POI.api.loadSchema("amapuri://webview/local?url=indoor.html");
                POI.api.userAction('floorGuideAll');
                POI.util.locationRedirect("indoor.html?poiid=" + POI.aosData.base.poiid + "&poiname=" + encodeURIComponent(POI.aosData.base.name) + "&showTitleBar=1");
            }
        });
    },
    
    
    
    getHtml : function() {
        POI.spGuide.poiBase = POI.aosData.base;
        var html = '';
        //html += POI.spGuide.shoppingGuide(POI.aosData.rti.shopping_guide);
        //html += POI.spGuide.floorGuide(POI.aosData.rti.floor_guide);
        if(POI.util.bool(POI.aosData.rti.shopping_guide)) {
            html += POI.spGuide.showShoppingGuide(POI.aosData.rti.shopping_guide);
        }
        if(POI.util.bool(POI.aosData.rti.floor_guide)) {
            html += POI.spGuide.showFloorGuide(POI.aosData.rti.floor_guide);
        }
        if(html) {
            POI.spGuide.addEvent();
            return html;
        } else {
            return '';
        }
    }
    
};

})(POI, Zepto);