/**
 * 停车攻略
 */
;
(function(POI, $) {

'use strict';

POI.stop = {
    
    stopStrategy: function() {
        var aosData = POI.aosData || POI.util.getStorageData() || {},
            spec = aosData.spec;
        var strategy = spec && spec.parking_psiji_api && spec.parking_psiji_api.p_strategy;
        if (!strategy) {
            return '';
        }
        
        POI.util.executeAfterDomInsert(function() {
            var parkRaiders = $('#parkRaiders');
            new POI.util.toggleContent(parkRaiders.find('a.introFold'), parkRaiders.find('.limits'));
        });
        
        return '<section id="parkRaiders">' +
                   '<h2 class="module_title_p line-half">停车攻略</h2>' +
                   '<article>' +
                       '<p class="limits">' + strategy + '</p>' +
                       '<a class="introFold">查看全文</a>' +
                   '</article>' +
               '</section>';
    }
    
};

})(POI, Zepto);