(function(POI, $) {

'use strict';

var bookRoom = {
    /** 首页初始最多显示的房型数目 */
    TYPE_NUM: 5,
    hotelDate: null, // 从订酒店页面进入详情页面时传递的日期信息
    roomList: null, // 酒店信息列表

    /**
     * 将日期格式化为 'MM-dd'.
     * @param {Date} 格式化的日期
     * @return {String} 格式化后的字符串
     */
    _formatHotelDate: function(date) {
        return date.replace(/\d+-0?(\d{1,2})-0?(\d{1,2})/, '$1月$2日');
    },
    /**
     * 预订模块入口方法.
     * @return {String} 页面html
     */
    initPage: function() {
        this.isHourlyRoom = POI.clientData.isHourlyRoom == '1';
        this.initDate();
        return this.initHtml();
    },
    initHtml: function() {
        var self = POI;
        var html = '';
        html += '<section id="hotel" class="hotelBook">';
        
        // 钟点房不显示日期选择按钮
        if (!this.isHourlyRoom) {
            //html += '<div class="book-date line-half canTouch">' +
            //        '<a data-date="in" class="date-item"><span>入住</span><span class="date"></span></a>' +
            //        '<a data-date="out" class="date-item"><span>离店</span><span class="date"></span></a>' +
            //    '</div>';
            html += '<div class="book-date line-half">' +
                        '<div class="book-in">' +
                            '<span class="book-time">12月10日</span><span class="book-flag">住</span>' +
                        '</div>' +
                        '<div class="book-num">' +
                            '<p>共<span>2</span>晚</p>' +
                        '</div>' +
                        '<div class="book-out">' +
                            '<span class="book-time">12月12日</span><span class="book-flag">离</span>' +
                        '</div>' +
                    '</div>';
        }
        html += '<ul class="type-list"></ul>' +
                '<div id="moreRoomType" class="type-toggle more-bottom-blue none">查看全部房型</div>' +
                '<aside class="dataLoading">' +
                    '<div><i></i><img src="img/loading_getmore.gif" /><label>正在获取实时精准房型数据…</label></div>' +
                '</aside>' +
            '</section>' +
            '<section class="canTouch" js_handle="js_gotoHotelBookTips"><p class="book-tips">订酒店小贴士</p></section>';
        return html;
    },
    /**
     * 初始化选择日期为今天到明天.
     */
    initDate: function() {
        var self = POI;
        var _this = this;
        self.api.nativeStorage('hotelDate', function(res) {
            var now = new Date();
            var nowStr = self.util.formatDate(now, 'yyyy-MM-dd');
            if (res.value && !_this.isHourlyRoom) {
                var arr = res.value.split('|');
                if (nowStr !== arr[2]) {
                    defaultDate();
                }
                else {
                    _this.hotelDate = {
                        inDate: arr[0],
                        outDate: arr[1]
                    };
                }
            }
            else {
                defaultDate();
            }
            _this.requestHotelInfo();

            // 今天为入住日期，明天为离店日期
            function defaultDate() {
                now.setDate(now.getDate() + 1);
                var outDateStr = self.util.formatDate(now, 'yyyy-MM-dd');
                _this.hotelDate = {
                    inDate: nowStr,
                    outDate: outDateStr
                };
                // self.api.nativeStorage('hotelDate', nowStr + '|' + outDateStr + '|' + nowStr);
            }
        });
    },
    /**
     * 初始化酒店查询相关事件.
     */
    initEvents: function() {
        var self = this;
        // 日期选择按钮事件
        if (!this.isHourlyRoom) {
            $('#hotel > .book-date').on('click', function(event) {
                event.preventDefault();
                POI.api.openCalendar();
                POI.api.userAction('selectDate');
            });
        }
        // 显示更多房型事件
        $('#moreRoomType').bind('click', function() {
            var that = self;
            var $type = $('#hotel > .type-list > li');
            var i = that.TYPE_NUM, n = $type.length;
            if ( !$(this).hasClass('up') ) {
                $(this).addClass('up').text('收起');
                POI.api.userAction('hotel-more-show');
            } else {
                // 折叠第5条以后的展开的详细房型
                for (; i < n; i++) {
                    var $item = $type.eq(i).children().eq(0);
                    if ($item.hasClass('up')) {
                        $item.removeClass('up').next().hide();
                    }
                }
                $(this).removeClass('up').text('查看全部房型');
                POI.api.userAction('hotel-more-hide');
            }
            for (i = that.TYPE_NUM; i < n; i++) {
                $type.eq(i).toggle();
            }
        });

        // 钟点房房型信息行点击效果
        POI.js_openHourlyDetail = function($this, event) {
            // 点击旧行，在下面显示更多或进入房型详情页面
            if ( !$(event.target).hasClass('type-name') ) {
                // 点击右侧箭头时切换显示下面的不同来源的数据
                var logInfo = '';
                if ($this.hasClass('up')) {
                    $this.removeClass('up').next().hide();
                    logInfo = 'fold';
                } else {
                    $this.addClass('up').next().show();
                    logInfo = 'unfold';
                }
                
                POI.api.userAction('hotel-price', {action: logInfo});
            }
            // 进入房型详情页面
            else {
                var typeid = $this.attr('data-roomTypeId');
                var typeName = $this.find('.type-name').text().replace("<i></i>", "");
                self._openTypeDetail(typeid, typeName);
            }
        };

        this.bookEvent();

        // 点击房型条目，进入房型详情页面
        POI.js_openHotelTypeDetail = function(elem) {
            var loaded = elem.attr("loaded");
            if(!loaded) {
                var typeid = elem.attr('data-roomTypeId');
                var typeName = elem.find('.type-name').text().replace("<i></i>", "");
                self._openTypeDetail(typeid, typeName);
                POI.api.userAction('type-room-click', {type: "load"});
            } else {
                self._toggleRoomListDisplay(elem);
            }
        };
        
        
        // 显示更多房间事件
        POI.js_toggleRoomList = function(ele, e) {
            var that = self;
            var roomList = ele.prev(".room-list");
            var rooms = roomList.find("li");
            var i = that.TYPE_NUM, n = rooms.length;
            if ( !ele.hasClass('up') ) {
                ele.addClass('up').text('收起');
            } else {
                // 折叠第5条以后的展开的详细房型
                for (; i < n; i++) {
                    var $item = rooms.eq(i).children().eq(0);
                    if ($item.hasClass('up')) {
                        $item.removeClass('up').next().hide();
                    }
                }
                ele.removeClass('up').text('查看全部');
                document.body.scrollTop = ele.closest('.type-item').offset().top - POI.util.getTitleBarHeight();
            }
            for (i = that.TYPE_NUM; i < n; i++) {
                rooms.eq(i).toggle();
            }
            POI.api.userAction('room-more');
        };
        POI.js_gotoHotelBookTips = function(ele, e) {
            POI.util.locationRedirect("hotel_tips.html");
        };
    },
    _toggleRoomListDisplay: function(ele) {
        var roomList = ele.next(".room_con");
        if(ele.hasClass("up")) {
            ele.removeClass("up");
            roomList.hide();
            POI.api.userAction('type-room-click', {type: "hide"});
        } else {
            ele.addClass("up");
            roomList.show();
            POI.api.userAction('type-room-click', {type: "show"});
        }
    },
    _updatePageDate: function() {
        // 更新酒店查询日期选择显示
        $('#hotel .book-in > .book-time').text( this._formatHotelDate(this.hotelDate.inDate) );
        $('#hotel .book-out > .book-time').text( this._formatHotelDate(this.hotelDate.outDate) );
        $('#hotel .book-num span').text( Math.round(
            (this._ymd2Date(this.hotelDate.outDate) -
            this._ymd2Date(this.hotelDate.inDate)) /
            (1000 * 3600 * 24) ) );
    },
    /**
     * 打开房型详情页面.
     * @param {String} typeId 房型id
     * @param {String} typeName 房型名称
     */
    _openTypeDetail: function(typeId, typeName) {
        if (!typeId) {
            return;
        }
        var params = [
            {poiid: POI.clientData.poiInfo.poiid, sign: 1},
            {indate: this.hotelDate.inDate},
            {outdate: this.hotelDate.outDate},
            {gd_roomid: typeId},
            {mode: 2}
        ];
        if (this.isHourlyRoom) {
            params.push({is_hours: 1});
        }
        var self = POI;
        var _this = this;
        self.api.aosrequest('hotelSearch', params, function(res) {
            if (!res || res.code != 1 || !res.roomlist || !res.roomlist[0]) {
                self.api.promptMessage('获取房间信息失败');
                return;
            }
            $(".type-item[data-roomTypeId=\"" + typeId + "\"] .type-con").attr("loaded", "1");
            self.util.storage('hotelRoomList', JSON.stringify(res));
            _this.roomList = res.roomlist;
            self.bookRoom._showRoomPics(typeId, res);
            self.bookRoom._showRoomList(typeId, res);
            self.api.userAction('hotel-type');
        }, 1, true);
    },
    _showRoomPics: function(typeId, res) {
        var info = res.roomlist[0].room_info || {};
        var picList = info ? info.pic_info : null;
        if(picList) {
            if(5 < picList.length) {
                picList = picList.slice(0, 5);
            }
            var picHtml = POI.slideImgbox.get_html({
                    list : picList
                },{
                    showList : false,//显示进入列表按钮，切可以右滑进入列表
                    showCount : false,//显示相册数量
                    click : false // 图片点击进入大图预览
                });
            $(".type-item[data-roomTypeId=\"" + typeId + "\"] .room_con").prepend('<div class="room-pics">' + picHtml + '</div>');
            POI.util.executeAfterDomInsert();
        }
    },
    _showRoomList: function(typeId, res) {
        var htmlStr = '';
        var roomsObj = res.roomlist[0];
        var typeName = roomsObj.RoomTypeName;
        var roomList = roomsObj.multilist || [];
        var isShowSrc = '1' == res.show_src_name;
        var activity = res.promotion_content;
        var frag = document.createDocumentFragment();
        var len = roomList.length;
        for(var i = 0; i < len; i++) {
            this._formatRoomInfo(roomList[i], 0, i, isShowSrc, activity).appendTo(frag);
        }

        if(len && frag) {
            var romms = $('<ul/>').addClass('room-list');
            romms.append(frag);
            var roomConDom = $(".type-item[data-roomTypeId=\"" + typeId + "\"] .room_con");
            roomConDom.append(romms);
            if(len > 5) {
                roomConDom.append('<div class="type-toggle more-bottom-blue" js_handle="js_toggleRoomList">查看全部</div>');
            }
            
            var $list = roomConDom.find(".room-list li");
            for (var j = this.TYPE_NUM, numj = $list.length; j < numj; j++) {
                $list.eq(j).hide();
            }

            if ($list.length > this.TYPE_NUM) {
                roomConDom.find("type-toggle").show();
            } else {
                roomConDom.find("type-toggle").hide();
            }
            this._toggleRoomListDisplay($(".type-con[data-roomTypeId=\"" + typeId + "\"]"));
        }
    },
    /**
     * 动态查询请求.
     */
    requestHotelInfo: function() {
        this._updatePageDate();
        // 移除旧的查询结果
        $('#hotel > .type-list').html('');
        $('#hotel > .type-toggle').addClass('none');
        // 显示正在载入提示
        $('#hotel > .dataLoading label').text('正在获取实时精准房型数据…');
        $('#hotel > .dataLoading').removeClass('noData').show();

        var params = [
            {poiid: POI.clientData.poiInfo.poiid, sign: 1},
            {indate: this.hotelDate.inDate},
            {outdate: this.hotelDate.outDate}
        ];
        if (this.isHourlyRoom) {
            params.push({mode: 1}, {is_hours: 1});
        } else {
            params.push({mode: 3});
        }
        var self = this;
        POI.api.aosrequest('hotelSearch', params, function(res) {
            self.searchResult(res);
            POI.headerToolBar.bookroom_flag = true;
            POI.headerToolBar.poiHotelToolBar({class_name:'header_room', title: '订房'});
        });
    },
    /**
     * 选择日期后，更新日期和房间信息.
     * @param {Object} info 客户端返回的日期信息
     */
    updateDateRoom: function(info) {
        if (!info.inDate) {
            return;
        }
        // 选择的日期没变时不再进行查询
        if (this.hotelDate.inDate == info.inDate && this.hotelDate.outDate == info.outDate) {
            return;
        }
        this.hotelDate.inDate = info.inDate;
        this.hotelDate.outDate = info.outDate;

        this.requestHotelInfo();
    },
    /**
     * 将 yyyy-MM-dd 格式的字符串转换为时间戳.
     * @param {String} ymd 年月日时间字符串
     * @return {Integer} 时间戳
     */
    _ymd2Date: function(ymd) {
        if (!ymd) {
            return new Date();
        }
        var arr = ymd.split('-');
        return new Date(arr[0], arr[1] - 1, arr[2]);
    },
    /**
     * 显示首页酒店查询结果.
     * @param {Object} res 请求结果
     */
    searchResult: function(res) {
        var self = this;
        // 获取周边可订的酒店
        function getCanBookHotel() {
            if (POI.business != 'hotel') {
                return;
            }
            self.formatHotelPhone();
        }

        if (!res || res.code != 1 || !res.roomlist || !res.roomlist[0]) {
            $('#hotel > .dataLoading').addClass('noData');
            $('#hotel > .dataLoading label').text('所选酒店满房或不可订，请选择其它日期或酒店');
            getCanBookHotel();
            return;
        }
        else {
            $('#hotel > .dataLoading').hide();
        }

        // 有全部满房标识时，推荐周边酒店
        if (res.status == 'false') {
            getCanBookHotel();
        }
        // 更新400电话
        if (res.phone_info && res.phone_info.tel && !this.get400Phone) {
            this.formatHotelPhone({
                title: (res.phone_info.name_cn || '') + '(' + res.phone_info.tel + ')',
                content: '' + res.phone_info.tel
            });
            // 400 电话只更新一次
            this.get400Phone = true;
        }
        if (this.isHourlyRoom) {
            this._formatTypeWithRoom(res);
        } else {
            this._formatOnlyType(res.roomlist);
        }
    },
    // 格式化旧的酒店房型，每个房型下显示聚合的房型
    _formatTypeWithRoom: function(res) {
        var list = res.roomlist,
            isShowSrc = '1' == res.show_src_name,
            activity = res.promotion_content,
            formatMoney = POI.util.formatMoney,
            moneyFlag = POI.util.moneyFlag,
            frag = $('<div></div>');//document.createDocumentFragment();
        this.roomList = list;
        var listStr = '';
        for (var i = 0, num = list.length; i < num; i++) {
            //var $cont = $('<li/>').appendTo(frag);
            //// 标题
            //var $title = $('<h3/>').addClass('title more-bottom-blue up')
            //    .attr('data-roomTypeId', list[i].roomgroup_id || '')
            //    .attr('js_handle', 'js_openHourlyDetail')
            //    .attr('data-ind', i).appendTo($cont);
            //// 名称
            //var $name = $('<span/>').addClass('type-name lineDot')
            //    .text(list[i].RoomTypeName).appendTo($title);
            //if (list[i].is_pic == '1') {
            //    $name.addClass('hasImg');
            //}
            //// 房型满房标识
            //if ('false' == list[i].room_status) {
            //    $('<i class="type-full">满房</i>').appendTo($title);
            //}
            //// 价格
            //$('<span/>').addClass('type-price').text(
            //    moneyFlag(list[i].price_lowest_currency) +
            //    formatMoney(list[i].price_lowest) ).appendTo($title);
            
            listStr = this.tplTypeItem(list[i]);
            $(listStr).appendTo(frag);
            
            // 房间列表
            var $rooms = $('<ul/>').addClass('room-list');
            for (var j = 0, numj = list[i].multilist && list[i].multilist.length; j < numj; j++) {
                this._formatRoomInfo(list[i].multilist[j], i, j, isShowSrc, activity).appendTo($rooms);
            }
            $(frag).find('.room_con').append($rooms);
        }
        this._showRoomType(frag.html(), num);

        // 钟点房展开所有房型
        var typeHead = $('#hotel > h1');
        if (num > this.TYPE_NUM) {
            $('#hotel > a.showMore').click();
        }
        for (var idx = num - 1; idx >= 0; idx--) {
            unfoldType(typeHead.eq(idx));
        }

        /**
         * 展开房型.
         * @param {Zepto} $elem 要展开的房型
         */
        function unfoldType($elem) {
            if (!$elem.hasClass('full')) {
                $elem.addClass('revert').next().show();
            }
        }
    },
    tplTypeItem: function(obj) {
        var areaStr = obj.room_info ? (obj.room_info.area || "") : "";
        var bedStr = obj.room_info ? (obj.room_info.bed || "") : "";
        var floorStr = obj.room_info ? (obj.room_info.floor || "") : "";
        var hasImgClass = obj.is_pic == '1' ? ' img' : '';
        var loadedAttr = this.isHourlyRoom ? ' loaded="1"' : '';
        var upClass = this.isHourlyRoom ? ' up' : '';
        areaStr && (areaStr = areaStr + "&nbsp;");
        return '<li class="type-item line-half' + hasImgClass + '" data-roomTypeId="' + obj.roomgroup_id + '">' +
                   '<div class="type-con more' + upClass + '" js_handle="js_openHotelTypeDetail" data-roomTypeId="' + obj.roomgroup_id + '"' + loadedAttr + '>' +
                       '<div>' +
                           '<p class="type-name lineDot">' + obj.RoomTypeName + '<i></i></p>' +
                           ((areaStr || bedStr) ? '<p class="type-desc">' + (areaStr + bedStr)  + '</p>' : '') +
                           (floorStr ? '<p class="type-desc">' + (floorStr + '层') + '</p>' : '') +
                       '</div>' +
                       '<div class="type-price"><p>' + POI.util.moneyFlag(obj.price_lowest_currency) + POI.util.formatMoney(obj.price_lowest) + '<span>起</span></p></div>' +
                       (obj.room_status === 'false' ? '<button class="type-full">满房</button>' : '') +
                   '</div>' +
                   '<div class="room_con"></div>' +
		       '</li>';
    },
    // 格式化新的酒店房型，只有房型
    _formatOnlyType: function(list) {
        var html = '';
        for (var i = 0, num = list.length; i < num; i++) {
            html += this.tplTypeItem(list[i]);
        }
        this._showRoomType(html, num);
    },
    /**
     * 显示房型信息.
     * 数量超出时，重置显示更多按钮状态，隐藏超出的信息
     * @param {String|HTML Element} html 房型html或房型元素
     * @param {Integer} num 房型数量
     */
    _showRoomType: function(html, num) {
        POI.api.userAction("hotelBookAllShow");
        $('#hotel > .type-list').html(html);
        var $moreType = $('#moreRoomType');
        if (num > this.TYPE_NUM) {
            $moreType.removeClass('none');
            if ( $moreType.hasClass('up') ) {
                $moreType.click();
            } else {
                var $type = $('#hotel > .type-list > li');
                for (var i = this.TYPE_NUM; i < num; i++) {
                    $type.eq(i).hide();
                }
            }
        }
    },
    /**
     * 显示酒店特有的电话格式.
     * @param {Object} [phone400] 400电话
     */
    formatHotelPhone: function(phone400) {
        var self = POI;
        var phones = self.index.getBasePhones();
        // 没有电话时，不再处理
        if (!phones.length && !phone400) {
            return;
        }
        // 如果已经获显示过400电话，则不再处理普通电话
        if (this.get400Phone) {
            return;
        }

        var list = [];
        for (var i = 0, num = phones.length; i < num; i++) {
            list[i] = {
                title: '前台电话(' + phones[i] + ')',
                content: phones[i]
            };
        }
        if (phone400) {
            list.unshift(phone400);
        }
        self.index.updateBasePhones(list);
    }
    
};

if (POI.bookRoom) {
    $.extend(POI.bookRoom, bookRoom);
} else {
    POI.bookRoom = bookRoom;
}

})(POI, $);
