;(function(POI, $) {

var cache = {};
var page = 1;//当前页码
var pagesize = 10; //一页显示数量
var busy = false;
var index = 0;
var loadMore = null; //更多控件
var totalIndex = 1;

$.extend(POI, {
    //埋点page标识
    logPageId : "communityNewsList",
    listParams: null,
    quickInit: function() {
        var that = this;

        if (window.location.search) {
            that.getNewsListData(POI.util.getUrlParam());
            that.listParams = POI.util.getUrlParam();
        }
        that.bindEvent();
    },
    getNewsListData: function(arg) {
        if(busy) {
           return; 
        }
        busy = true;
        var that = this;

        var params = [
            {
                'poiid': arg.poiid,
                'sign': 1
            },
            {
                'x': arg.lon,
                'sign': 1
            },
            {
                'y': arg.lat,
                'sign': 1
            },
            {
                'adcode': arg.adcode,
                'sign': 1
            },
            {
                'page_num': page
            },
            {
                'count': pagesize
            }
        ];
        POI.util.setPageTitle(arg.name);//设置页面title
        POI.api.aosrequest('communityNewsList', params, function(data) {
            data.threads = data.threads || [];

            that.makeListHtml(data);
            var page_total = Math.ceil(Number(data.res_data.total)/Number(data.res_data.count));
            if (page == 1 && page_total > page) {
                loadMore = new POI.util.PullUpGetMore(function() {
                    that.getNewsListData(that.listParams);
                });
            }

            if (data.threads.length == 0 || page_total <= page) {
                loadMore && loadMore.destory();
                $('.no_data').show();
            } else {
                loadMore && loadMore.refresh();
            }

            if (page > 1) {
                POI.api.userAction('flipOperation');
            }

            page = page + 1;
            busy = false;
        }, page == 1 ? 1 : 0, true, "GET");
    },
    makeListHtml: function( data ) {
        if (data.threads.length < 1) {
            return;
        }
        var that = this;
        var list = data.threads;
        var box = $('#news_list_container');
        var html_arr = [];
        var key;

        for (var i=0; i<list.length; i++) {
            key = 'item' + index++;
            var imgurl = list[i].pic_url && list[i].pic_url[0];
            var date = that.formateDate(list[i].repo_time, data.res_data.timestamp).date;
            var time = that.formateDate(list[i].repo_time, data.res_data.timestamp).time;
            var date_html = date.length > 0? '<span class="date">'+date+'</span>': '';

            imgurl = POI.util.imageUrlTransform(imgurl, 80, 60);

            if (imgurl) {
                var li_str = '<li class="has_img divide-line" key="'+key+'" totalIndex="' + totalIndex + '">'+
                             '<div class="list_img">'+
                             '<img src="'+imgurl+'"/>'+
                             '</div>'+
                             '<div class="cont">'+
                             '<p class="title">'+list[i].title+'</p>'+
                             '<p class="paper">'+
                             '<span class="name">'+list[i].orig+'</span>'+
                             date_html+
                             '<span class="time">'+time+'</span>'+
                             '</p>'+
                             '</div>'+
                             '</li>';
            } else {
                var li_str = '<li class="divide-line" key="'+key+'" totalIndex="' + totalIndex + '">'+
                             '<p class="title">'+list[i].title+'</p>'+
                             '<p class="paper">'+
                             '<span class="name">'+list[i].orig+'</span>'+
                             date_html+
                             '<span class="time">'+time+'</span>'+
                             '</p>'+
                             '</li>';
            }
            totalIndex += 1;
            html_arr.push(li_str);
            cache[key] = list[i];//用于点击事件的使用，跳转到小区要闻详情页
        }
        box[ page == 1 ? 'html' : 'append' ](html_arr.length ? html_arr.join('') : '');

    },
    formateDate: function(compaer_time, timestamp) {
        var that = this;

        var date = compaer_time.split(' ')[0];
        var time = compaer_time.split(' ')[1];
        var time_arr = time.split(':');

        var year1 = Number(date.split('-')[0]);
        var month1 = date.split('-')[1];

        if (String(month1).length === 2 && String(month1).charAt(0) === '0') {
            month1 = Number(String(month1).charAt(1)) - 1;
        } else {
            month1 = Number(month1) - 1;
        }
        var date1 = Number(date.split('-')[2]);

        var date_obj = new Date(timestamp*1000);

        var year2 = date_obj.getYear();
        var month2 = date_obj.getMonth();
        var date2 = date_obj.getDate();

        if (year1 === year2 && month1 === month2 && date1 === date2) {
            var true_date = '';
        } else {
            var true_date = (month1+1)+'月'+date1+'日';
        }

        return {
            date: true_date,
            time: time_arr[0]+':'+time_arr[1]
        }
    },
    bindEvent: function() {
        var that = this;

        $('#news_list_container').on('click', 'li', function() {
            var li = $(this);
            var item;
            if (li.length && (key = $(this).attr('key'))) {
                item = cache[key];

                if(!item || !item.tid) {
                    return;
                }
                POI.api.userAction('communityNewsList', {poiid_tid_index: POI.poiid + '_' + item.tid+ '_'+li.attr('totalIndex')});
                //暂时写本地地址，可能改为在线地址
                POI.util.locationRedirect('community_news_detail.html?id='+item.tid + '&stt=3');
            }
        });
    }
});
})(POI, Zepto);