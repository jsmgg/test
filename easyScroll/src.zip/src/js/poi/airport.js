/**
  * 飞机场
  */
;(function(POI, $) {

$.extend(POI, {
    
    price : function(num1, num2) {
        num1 = parseFloat(num1 || 0);
        num2 = parseFloat(num2 || 0);
        var priceStr = '免费';
        if(0 !== num1 || 0 !== num2) {
            priceStr = (num1 === num2 ? num1 : (Math.min(num1, num2) + "-" + Math.max(num1, num2)));
            return '<span class="airport_subtitle_price">' + priceStr + '</span>' + "元";
        } else {
            return '<span class="airport_subtitle_price">' + priceStr + '</span>';
        }
        
    },
    
    time : function(srart, end) {
        if(void(0) === srart || void(0) === end) {
            return '';
        }
        srart = ("0000" + srart).slice(-4).replace(/(\d\d)$/, ":$1");
        end = ("0000" + end).slice(-4).replace(/(\d\d)$/, ":$1");
        if(("00:00" === srart && "24:00" === end) || ("00:00" === end && "24:00" === srart)) {
            //return "24小时";
            return '<span class="airport_time_start">00:00</span><span class="airport_time_end">24:00</span>';
        } else {
            //return srart + "-" + end;
            return '<span class="airport_time_start">' + srart + '</span><span class="airport_time_end">' + end + '</span>';
        }
    },
    
    createLineBtn : function(lineId, frontName, terminalName, startTime, endTime) {
        return '<div class="airport_link_item half-border" line_id="' + lineId.trim() + '" ' + this.handleAttr + '="js_airPortShowLine">' +
                   '<div class="airport_line">' + frontName + '<span class="airport_line_arrow"></span>' + terminalName + '</div>' +
                   '<div class="airport_time">' + this.time(startTime, endTime) + '</div>' +
               '</div>';
    },
    
    createLinesHtml : function(/*ferryList, busList, subwayList*/) {
        var returnStr = '',
            tmpStr = '',
            l = arguments.length,
            titStr = '', pStr = '', lineNumStr = '';
        for(var j = 0, itemList = null, len = 0; j < l; j++) {
            itemList = arguments[j];
            try {
                len = itemList.length;
                if(1 > len) {
                    continue;
                }
                
                if(0 === j) {
                    titStr = '<h2 class="airport_type">摆渡车</h2>';
                } else if(1 === j) {
                    titStr = '<h2 class="airport_type">机场大巴</h2>';
                } else if(2 === j) {
                    titStr = '<h2 class="airport_type">机场快轨</h2>';
                }
                
                tmpStr = titStr + 
                         (itemList[0].key_name ? '<p class="airport_title">' + itemList[0].key_name + '</p>' : '') +
                         '<p class="airport_subtitle">' +
                            (itemList[0].interval ? ('发车间隔：不超过' + itemList[0].interval + '分钟&nbsp;&nbsp;') : '') +
                            '票价：' + this.price(itemList[0].basic_price, itemList[0].total_price) +
                         '</p>';
                
                for(var i = 0, item = null, hgroupStr = ''; i < len; i++) {
                    item = itemList[i];
                    hgroupStr += this.createLineBtn(item.line_id, item.front_name, item.terminal_name, item.start_time, item.end_time);
                }
                
                tmpStr = '<article>' + 
                             tmpStr +
                             '<div class="airport_link">' +
                                 hgroupStr +
                             '</div>' +
                         '</article>';
                returnStr += tmpStr;
            } catch(e) {

            }
        }
        
        return returnStr;
    },
    
    // 展示机场、航站楼摆渡车、公交、机场快轨
    showLinesInfo : function(deep) {
        try {
            var linesInfo = deep.line_type_info;
            if(!linesInfo) {
                return '';
            }
            var htmlStr = this.createLinesHtml(linesInfo["1"], linesInfo["0"], linesInfo["2"]);
            if(htmlStr) {
                var len = (linesInfo["1"] ? (linesInfo["1"].length || 0) : 0) +
                          (linesInfo["0"] ? (linesInfo["0"].length || 0) : 0) +
                          (linesInfo["2"] ? (linesInfo["2"].length || 0) : 0);
                var moreHtml = 2 < len ?
                                   '<article class="canTouch" ' + this.handleAttr + '="js_airPortShowLinesPage">' +
                                       '<p class="module_title_p">机场线路信息<a class="airport_right_link" href="javascript:void(0);">查看全部</a></p>' +
                                   '</article>'
                               : '';
                return  '<section id="air_routeline">' + moreHtml + '<div class="airport_sec">' + htmlStr + '</div>' + '</section>';
            } else {
                return '';
            }
        } catch(e) {
            //alert(e);
            return '';
        }
    },
    
    // 展示航站楼航空公司列表
    showAirlineCompanyList : function(deep) {
        try {
            var companyList = deep.air_info,
                len = companyList.length;
            if(1 > len) {
                return '';
            }
            /*
            <article class="canTouch">
                <aside class="half-border"><img src="http://cache.amap.com/h5/activity/payError/logoIndex.jpg"></aside>
                <p>春秋航空公司<i>K48-49</i></p><em></em>
            </article>
            */
            var htmlStr = '<h2 class="airCompany_title module_title">' + this.clientData.poiInfo.name + '航空公司</h2>';
            for(var i = 0, item = null, articleStr = ''; i < len; i++) {
                item = companyList[i];
                articleStr += '<article ' + this.handleAttr + '="js_airPortShowTelPanel" class="airCompany_con ' + (item.air_tel ? 'canTouch' : '') + '" phone="' + (item.air_tel || '') + '" cname="' + (item.airways || '') + '">' +
                                  '<p class="airCompany_name">' + item.airways + '<i class="airCompany_bar">' + (item.cuss || '') + '</i></p>' +
                                  (item.air_tel ? '<a href="javascript:void(0)" class="airCompany_call half-border">打电话</a>' : '') +
                              '</article>';
            }
            if(articleStr) {
                return ('<section class="airCompany" id="airCompany">' + htmlStr + articleStr + (3 > len ? '' : '<article ' + this.handleAttr + '="js_airPortShowCompanyPage" class="airCompany_switch canTouch"><a class="airCompany_a">查看更多信息<i class="airCompany_arrow"></i></a></article>') + '</section>');
            } else {
                return '';
            }
            
        } catch(e) {
            //alert(e);
            return '';
        }
    },
    
    // 展示航空公司的机场设施
    showTerminalInfo : function(rti) {
        try {
            /*
            <article class="more lineDot">
                <span class="terminal">T1航站楼</span><span class="company">东方航空、海南航空、天津航空、首都航空</span>
            </article>
            */
            var terminalAry = rti.airport_info.terminal_info,
                len = terminalAry.length;
            if(1 > len) {
                return '';
            }
            var htmlStr = '';
            //console.dir(terminalAry);
            for(var i = 0,  item = null, articleStr = ''; i < len; i++) {
                item = terminalAry[i];
                try {
                    articleStr = '<span class="terminal_name">' + item.tag.child_shortname[0].v + '</span>';
                } catch(ee) {
                    articleStr = '<span class="terminal_name">' + item.name + '</span>';
                }
                companyAry = item.air_info || [];
                for(var j = 0, l = companyAry.length, companyStr = ''; j < l; j++) {
                    companyStr += '、' + companyAry[j].airways;
                }
                companyStr = '<p class="terminal_com lineDot">' + companyStr.replace('、', '') + '</p>';
                htmlStr += '<li ' + this.handleAttr + '="js_airPortShowTerminalPoi" poiid="' + (item.poiid || '') + '" poiname="' + (item.name || '') + '" address="' + (item.address || '') + '" lon="' + (item.x || '') + '" lat="' + (item.y || '') + '" class="terminal_li half-border">' + articleStr + companyStr + '</li>';
            }
            if(htmlStr) {
                return '<section>' +
                           '<h2 class="terminal_title module_title">航站楼</h2>' +
                           '<ul class="terminal_ul">' +
                               htmlStr +
                           '</ul>' +
                       '</section>';
            } else {
                return '';
            }
        } catch(e) {
            //alert(e);
            return '';
        }
    },
    
    // 展示航站楼机场设施（机场入口、机场出口、停车场）
    showPoisList : function(rti) {
        try {
            var poiAry = rti.airport_info.pois_list,
                len = poiAry.length;
            if(1 > len) {
                return '';
            }
            var htmlStr = '',
                entranceStr = '',
                exitStr = '',
                parkStr = '',
                luggageStr = '',
                lockerRoomStr = '',
                otherAry = [],
                count = 0;
            for(var i = 0, item = null, tmpStr = '', disName = ''; i < len; i++) {
                item = poiAry[i];
                try {
                    disName = item.tag.child_shortname[0].v || item.name || '';
                } catch(e) {
                    disName = item.name || '';
                }
                tmpStr = '<div class="facilities_link_item" ' + this.handleAttr + '="js_airPortShowChildPoi" poiid="' + (item.poiid || '') + '" poiname="' + (item.name || '') + '" address="' + (item.address || '') + '" lon="' + (item.x || '') + '" lat="' + (item.y || '') + '" type="' + (item.type || '') + '"><a class="facilities_link_btn canTouch half-border lineDot">' + disName + '</a></div>';
                switch(parseInt(item.type || 0, 10)) {
                    // 进站口
                    case 43:
                    case 105: entranceStr += tmpStr; break;
                    // 出站口
                    case 44:
                    case 106: exitStr += tmpStr; break;
                    // 停车场
                    case 41:
                    case 305: parkStr += tmpStr; break;
                    default:
                        var floorStr = "",
                            locationStr = "",
                            detailStr = "";
                        try {
                            floorStr = item.airport_faci.airport_info[0].floor.replace('null', '');
                            if(floorStr) {
                                floorStr = '<i class="f_luggage_floor">' + floorStr + '&nbsp;</i>';
                            }
                        } catch(e) {
                            floorStr = "";
                        }
                        try {
                            locationStr = item.airport_faci.airport_info[0].location.replace('null', '');
                        } catch(e) {
                            locationStr = "";
                        }
                        try {
                            detailStr = item.airport_faci.intro.replace('null', '');
                            if(detailStr) {
                                detailStr = '<p class="f_luggage_detail">' + detailStr + '</p>';
                            }
                        } catch(e) {
                            detailStr = "";
                        }
                        otherAry.push('<article class="facilities_luggage">' +
                                          '<p class="f_luggage_tit">' + item.name + '</p>' +
                                          '<p class="f_luggage_desc">' + floorStr + locationStr + '</p>' +
                                          detailStr +
                                      '</article>');
                    break;
                }
            }
            if(entranceStr) {
                count++;
                htmlStr += '<div><p class="facilities_title">机场入口</p><div class="facilities_link">' + entranceStr + '</div></div>';
            }
            if(exitStr) {
                count++;
                htmlStr += '<div><p class="facilities_title">机场出口</p><div class="facilities_link">' + exitStr + '</div></div>';
            }
            if(parkStr) {
                count++;
                htmlStr += '<div><p class="facilities_title">停车场</p><div class="facilities_link">' + parkStr + '</div></div>';
            }
            if(htmlStr) {
                var moreStr = '';
                if(otherAry.length) {
                    this.airPortLuggageDom = $(otherAry.join(""));
                    moreStr = '<article ' + this.handleAttr + '="js_airPortFacilitiesAll" class="facilities_switch canTouch" state="1"><a class="facilities_switch_a" href="javascript:void(0);">所有设施<i class="facilities_switch_arrow"></i></a></article>';
                }
                return ('<section class="facilities"><h2 class="module_title">机场设施</h2>' + '<article>' + htmlStr + '</article>' + moreStr + '</section>');
            } else {
                return '';
            }
        } catch(e) {
            //alert(e);
            return '';
        }
    },
    
    // 发送请求枢纽列表的请求
    requestTransbay : function(cityCode) {
        POI.util.executeAfterDomInsert(function(_cityCode) {
            var params = [{city: _cityCode, sign: 1}];
            POI.api.aosrequest("transbayList", params, POI.showTransbay, false, false, "GET");
        }, cityCode);
        return '<section id="trafficHub" class="train_sec"></section>';
    },
    
    // 展示去往其他枢纽
    showTransbay : function(data) {
        try {
            if(1 != data.code) {
                return;
            }
            var transbayList = data.transbay_list,
                len = transbayList.length;
            if(1 > len) {
                return;
            }
            //console.dir(transbayList);
            var htmlStr = '<h2 class="module_title_p line-half">去往其他枢纽</h2>';
            for(var i = 0, item = null, linkStr = ''; i < len; i++) {
                item = transbayList[i];
                if(POI.clientData.poiInfo.poiid !== item.poiid) {
                    linkStr += '<div class="train_link_item" ' + this.handleAttr + '="js_airPortTrafficHubRoute" param=\''+JSON.stringify(item)+'\'><a class="train_link_btn canTouch half-border lineDot">' + item.name + '</a></div>';
                }
            }
            //只含有自己，以后看这种情况能否让aos 处理下。
            if(!linkStr){
                return;
            }
            htmlStr = htmlStr + '<article><div class="train_link">' + linkStr + '</div></article>';
            $("#trafficHub").html(htmlStr);
        } catch(e) {
            //alert(e.message);
        }
    },
    
    /* -------------------------------------事件处理函数 start-------------------------------------------- */
    js_airPortShowLine : function(ele, e) {
        POI.api.userAction("airportLine", {
            parentId_lineId: this.clientData.poiInfo.poiid + "_" + ele.attr("line_id")
        });
        POI.api.openBusLine(ele.attr("line_id"), this.clientData.poiInfo.cityCode);
    },
    
    js_airPortShowLinesPage : function(ele, e) {
        POI.api.userAction("airportLineMore");
        POI.util.locationRedirect("airlines.html?" + this.clientData.poiInfo.poiid + "_" + this.clientData.poiInfo.cityCode);
    },
    
    js_airPortShowTelPanel : function(ele, e) {
        var phone = ele.attr("phone");
        if(phone) {
            POI.api.userAction("airportCompany", {
                parentId_cName: this.clientData.poiInfo.poiid + "_" + ele.attr("cname")
            });
            POI.api.showPanellist([ phone ]);
        }
    },
    
    js_airPortShowCompanyPage : function(ele, e) {
        POI.api.userAction("airportCompanyMore");
        POI.util.locationRedirect("airlineCompanyList.html?" + this.clientData.poiInfo.poiid + "_" + encodeURIComponent(this.clientData.poiInfo.name));
    },
    
    js_airPortShowTerminalPoi : function(ele, e) {
        POI.api.userAction("airportFacilities", {
            currentId_childId: this.clientData.poiInfo.poiid + "_" + ele.attr("poiid")
        });
        POI.api.openPoiInfo(ele.attr("poiid"), ele.attr("poiname"), ele.attr("address") || "", "", "", "", ele.attr("lon") || "", ele.attr("lat") || "", "1");
    },
    
    js_airPortShowChildPoi : function(ele, e) {
        POI.api.userAction("terminalFacilities", {
            currentId_childId_type: this.clientData.poiInfo.poiid + "_" + ele.attr("poiid") + "_" + ele.attr("type")
        });
        POI.api.openPoiInfo(ele.attr("poiid"), ele.attr("poiname"), ele.attr("address"), "", "", "", ele.attr("lon"), ele.attr("lat"));
    },
    
    js_airPortFacilitiesAll : function(ele, e) {
        if("1" == ele.attr("state")) {
            ele[0]._scroll_top = $(window).scrollTop();
            POI.api.userAction("terminalFacilitiesMore_open");
            ele.attr("state", "0");
            ele.before(this.airPortLuggageDom);
            ele.find("a").html('收起<i class="facilities_switch_arrow" style="-webkit-transform: rotateZ(180deg);"></i>');
        } else {
            $(window).scrollTop( ele[0]._scroll_top );
            POI.api.userAction("terminalFacilitiesMore_close");
            ele.attr("state", "1");
            this.airPortLuggageDom.remove();
            ele.find("a").html('所有设施<i class="facilities_switch_arrow"></i>');
        }
    },
    
    js_airPortTrafficHubRoute : function(ele, e) {
        var param = JSON.parse(ele.attr("param"));
        param.lon = param.x;
        param.lat = param.y;
        delete param.x;
        delete param.y;
        POI.api.userAction("airportTrafficHub", {
            currentId_childId: this.clientData.poiInfo.poiid + "_" + param.poiid
        });
        POI.api.searchRoute(this.clientData.poiInfo, param);
    },
    
    /* -------------------------------------事件处理函数 end-------------------------------------------- */

    airportPageList : function(terminalStr, poisListStr, linesStr, companysStr, transbayStr) {
        var htmlStr = terminalStr + poisListStr + linesStr + companysStr + transbayStr;
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2"]);
        var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        this.pagebody.html(htmlStr + allAry.join(""));
        this.util.executeAfterDomInsert();
    },

    init : function() {
        
        this.index.moduleDeepHead();
        
        var deep = this.aosData.deep[0],
            rti = this.aosData.rti,
            poiInfo  = this.clientData.poiInfo;
        
        this.airportPageList(
            this.showTerminalInfo(rti),
            this.showPoisList(rti),
            this.showLinesInfo(deep),
            this.showAirlineCompanyList(deep),
            this.requestTransbay(poiInfo.cityCode)
        );
    }
});

})(POI, Zepto);