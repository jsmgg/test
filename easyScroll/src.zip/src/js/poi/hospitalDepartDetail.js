/**
 * 医院科室详情页面.
 */
;(function(POI, $) {
'use strict';

var poiid;
var depart_id = '';
var child_id = '';
var pageNum = 2;
var getMoreWiget; // 上拉加载更多控件

$.extend(POI, {
	logPageId: 'hospitalDepartList',
	handleAttr: 'js_handle',

	quickInit: function() {
		this.util.delegate( $('#js_pagebody') );

		var data = this.util.storage('hospital.departmentInfo');
		localStorage.removeItem('hospital.departmentInfo');
		data = JSON.parse(data);

		this.util.setPageTitle(data.child_name || '科室详情');

		poiid = data.poiid;
		depart_id = data.depart_id;
		child_id = data.child_id;

		if (child_id) {
			this.logPageId = 'hospitalDrList';
		}
		this.api.userAction('pv');

		var html = tplDepartmentIntro(data.child_desc) + tplDrList(data.doctors);

		if (data.page_total > 1) {
			getMoreWiget = new this.util.PullUpGetMore(getDrList);
		}

		$('#js_pagebody').html(html);
	},
	// 打开医生详情页面
	js_openDrDetail: function(elem) {
		var self = this;

		// 获取科室医生详情信息
		var param = [
			{poiid       : poiid, sign: 1},
			{doctor_id   : elem.attr('data-id')},
			{visit_flag  : 1},
			{review_flag : 1}
		];
		this.api.userAction('openDrDetail', {doctor_id: elem.attr('data-id')});
		this.api.aosrequest('hospitalDrInfo', param, function(res) {
			if (res.code != '1' || !res.doctors) {
				self.api.promptMessage('请稍后重试');
				return;
			}
			self.util.storage('hospital.doctorInfo', JSON.stringify(res));
			self.util.locationRedirect('hospital_dr_detail.html');
		}, 1, true, 'get');
	}
});

/**
 * 生成科室简介.
 * @param {String} intro 科室简介
 * @return {String} html
 */
function tplDepartmentIntro(intro) {
	if (!intro) {
		return '';
	}
	return '<section class="intro">' +
			'<article class="intro_con">' +
				'<h1 class="intro_title">科室简介</h1>' +
				'<p id="introSpec" class="intro_desc limits">' + intro + '</p>' +
				'<a class="introFold none"></a>' +
			'</article>' +
		'</section>';
}
/**
 * 生成医生列表模板
 * @param {Array} list 医生列表
 * @return {String} html
 */
function tplDrList(list) {
	var html = '';
	for (var i = 0, len = list.length; i < len; i++) {
		html += tplDrItem(list[i]);
	}
	return '<section>' +
			'<ul class="doctor-list2">' + html + '</ul>' +
		'</section>';
}
/**
 * 生成医生列表模板
 * @param {Object} obj 医生对象
 * @return {String} html
 */
function tplDrItem(obj) {
	var visit = '';
	if (obj.today_status == '1') {
		visit = '<span class="visit"></span>';
	}
	else if (obj.today_status == '0') {
		visit = '<span class="visit not"></span>';
	}

	return '<li class="line-half" ' + POI.handleAttr +
				'="js_openDrDetail" data-id="' + obj.doc_id + '">' +
			'<h2 class="name-info">' +
				obj.doc_name + '<small class="office">' + (obj.doc_title || '') + '</small>' +
				'<cite class="recommend"><i class="red">' + (obj.total_vote || 0) + '</i>人推荐</cite>' +
				visit +
			'</h2>' +
			(obj.doc_speciality ? '<p class="intro-text linesDot">擅长：' + (obj.doc_speciality) + '</p>' : '') +
		'</li>';
}

function getDrList() {
	// 获取科室医生列表
	var param = [
		{poiid     : poiid, sign: 1},
		{depart_id : depart_id},
		{child_id  : child_id},
		{pagenum   : pageNum},
		{pagesize  : 10}
	];
	POI.api.aosrequest('hospitalDrInfo', param, function(res) {
		if (res.code != '1' || !res.doctors) {
            getMoreWiget.hide();
			return;
		}

		var html = '';
		for (var i = 0, len = res.doctors.length; i < len; i++) {
			html += tplDrItem(res.doctors[i]);
		}
		$('.doctor-list2').append(html);

		if (pageNum >= res.page_total) {
			getMoreWiget.destory();
		}
		else {
			pageNum += 1;
			getMoreWiget.refresh();
		}
	}, 1, true, 'get');
}

})(POI, $);
