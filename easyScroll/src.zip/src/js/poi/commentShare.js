/*
 * 评论成功页
 */
;(function(POI, $){

var star = 1;
var business = "";
var c = "";
var n = 1;
var poiInfo = {};

$.extend(POI, {
    logPageId : "commentSendSuccess",
    showData : {
        dining: [
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉一般般，告诉没来过的小伙伴",
            "太好吃了！告诉小伙伴我又发现一家好店",
            "太好吃了！告诉小伙伴我又发现一家好店"
        ],
        hotel: [
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉一般般，告诉没来过的小伙伴",
            "酒店太棒了！给小伙伴们炫耀一下",
            "酒店太棒了！给小伙伴们炫耀一下"
        ],
        scenic: [
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉一般般，告诉小伙伴我到此一游",
            "感觉棒棒哒！告诉小伙伴我又发现一个好去处",
            "感觉棒棒哒！告诉小伙伴我又发现一个好去处"
        ],
        other: [
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉被坑了？马上集齐X个好友的支持，你的评论即可在热评榜置顶",
            "感觉一般般，告诉没来过的小伙伴",
            "太棒啦！告诉小伙伴我又发现一个好地方",
            "太棒啦！告诉小伙伴我又发现一个好地方"
        ]
    },
    showNoXData : {
        dining: [
            "太坑了！要告诉全世界这顿饭吃得非常不开心！"
        ],
        hotel: [
            "多么痛的领悟！告诉小伙伴千万别选这家酒店"
        ],
        scenic: [
            "太坑了！告诉小伙伴别来啦"
        ],
        other: [
            "多么痛的领悟！告诉小伙伴别来啦"
        ]
    },
    shareData : {
        dining: [
            "太坑了！这顿饭吃得非常不开心！",
            "太坑了！这顿饭吃得非常不开心！",
            "感觉一般般，小伙伴们可以试一试",
            "又发现一家好吃的！只能帮你们到这儿了",
            "又发现一家好吃的！只能帮你们到这儿了"
        ],
        hotel: [
            "花钱买教训！再也不选这家酒店",
            "花钱买教训！再也不选这家酒店",
            "感觉一般般，要求不高可以试试",
            "超值的享受！小伙伴们不可错过哦",
            "超值的享受！小伙伴们不可错过哦"
        ],
        scenic: [
            "世界那么大，总要被坑几次",
            "世界那么大，总要被坑几次",
            "感觉一般般，本人到此一游，不带走一片云彩",
            "感觉棒棒哒！小伙伴们不可错过哦",
            "感觉棒棒哒！小伙伴们不可错过哦"
        ],
        other: [
            "人生中总有些地方，这辈子不想来下回",
            "人生中总有些地方，这辈子不想来下回",
            "感觉一般般，人生需要不断尝试",
            "又发现一个好地方，一般人我不告诉他~",
            "又发现一个好地方，一般人我不告诉他~"
        ]
    },
    
    showImage : function() {
        var imgDoms = $("#userTracks .userTracks_img");
        if(!imgDoms.length) {
            return;
        }
        var rectObj = imgDoms[0].getBoundingClientRect();
        function imgLoadSuccess(ele, img) {
            ele.style.backgroundImage = 'url("' + img.src + '")';
            ele.style.backgroundSize = 'cover';
        }
        var imgUrl = '';
        for(var i = 0, len = imgDoms.length; i < len; i++) {
            imgUrl = imgDoms[i].getAttribute("ori");
            if(imgUrl) {
                imgUrl = POI.util.imageUrlTransform(imgUrl, rectObj.width, rectObj.height);
                new POI.util.loadImage(imgUrl, imgDoms[i], imgLoadSuccess);
            }
        }
    },
    
    poiListCache : null,
    
    showUserFoot : function(data) {
        if("1" == data.code) {
            var poiList = data.list;
//poiList = [
//    {poi_id: "B000ABCD12341", star: "1", comment_num: "123", cover: "http://store.is.autonavi.com/showpic/55224e540a63d562cf20170c07c880eb", visit_time: "2016-03-12 13:12:12", base: {name: "测试的名称", business: "dining", telephone: "1234", x: "119.123124", y: "38.23432"}},
//    {poi_id: "B000ABCD12342", star: "2", comment_num: "124", cover: "http://store.is.autonavi.com/showpic/55224e540a63d562cf20170c07c880eb", visit_time: "2016-03-12 13:12:12", base: {name: "测试的名称", business: "dining", telephone: "1235", x: "119.123125", y: "38.23432"}},
//    {poi_id: "B000ABCD12343", star: "3", comment_num: "125", cover: "http://store.is.autonavi.com/showpic/55224e540a63d562cf20170c07c880eb", visit_time: "2016-03-12 13:12:12", base: {name: "测试的名称", business: "dining", telephone: "1236", x: "119.123126", y: "38.23432"}},
//    {poi_id: "B000ABCD12344", star: "4", comment_num: "126", cover: "http://store.is.autonavi.com/showpic/55224e540a63d562cf20170c07c880eb", visit_time: "2016-03-12 13:12:12", base: {name: "测试的名称", business: "dining", telephone: "1237", x: "119.123127", y: "38.23432"}}
//];
            if(POI.util.bool(poiList)) {
                POI.poiListCache = poiList;
                var poiBase = null;
                var liStr = '';
                for(var i = 0, len = poiList.length, item = null; i < len; i++) {
                    item = poiList[i];
                    poiBase = item.base;
                    if(poiBase.name) {
                        liStr += '<li class="userTracks_item line-half" idx="' + i + '">' +
                                     '<i class="userTracks_img" ori="' + item.cover + '"></i>' +
                                     '<div class="userTracks_main">' +
                                         '<p class="userTracks_name">' + poiBase.name + '</p>' +
                                         '<div class="userTracks_grade">' +
                                             (item.star ? 
                                             '<span class="userTracks_star"><span class="highlight" style="width:' + (parseFloat(item.star) / 5 * 100) + '%"></span></span>' +
                                             '<span class="userTracks_score">' + parseFloat(item.star) + '分</span>' : ' ') +
                                         '</div>' +
                                         '<div class="userTracks_comment">' +
                                             '<a class="userTracks_write" idx="' + i + '" href="javascript:void(0);">去评论</a>' +
                                             '<p class="userTracks_review">' + (item.comment_num ? (item.comment_num + '条评论') : ' ') + '</p>' +
                                         '</div>' +
                                     '</div>' +
                                 '</li>';
                    }
                }
                if(liStr) {
                    POI.api.userAction('showUserFoot');
                    var userTracksDom = $("#userTracks");
                    userTracksDom.find("ul").html(liStr);
                    userTracksDom.show();
                    POI.showImage();
                    userTracksDom.on("click", ".userTracks_item", function(evt) {
                        if("a" == evt.target.nodeName.toLowerCase()) {
                            return;
                        }
                        POI.api.userAction('userFootToPoi');
                        var idx = this.getAttribute("idx") | 0;
                        var poi = POI.poiListCache[idx];
                        POI.api.openPoiInfo(poi.poi_id, poi.base.name, '', '' ,'', poi.base.telephone, poi.base.x, poi.base.y, 1, '');
                    });
                    userTracksDom.on("click", ".userTracks_write", function(evt) {
                        POI.api.userAction('userFootToWrite');
                        var idx = this.getAttribute("idx") | 0;
                        var poi = POI.poiListCache[idx];
                        var _poiInfo = poi.base;
                        _poiInfo.poiid = poi.poi_id;
                        _poiInfo.lon = _poiInfo.x;
                        _poiInfo.lat = _poiInfo.y;
                        _poiInfo.address = !!_poiInfo.address ? _poiInfo.address : "";
                        _poiInfo.business = !!_poiInfo.business ? _poiInfo.business : "other";
                        POI.commentUtil.openNativeCommentEditor(0, _poiInfo.business, "Recommend", function(data) {
                            if(POI.util.bool(data.comment)) {
                                star = data.comment.score | 0;
                                business = _poiInfo.business;
                                c = data.comment.id;
                                n = 0;
                                poiInfo = _poiInfo;
                                showMain();
                            }
                        }, _poiInfo);
                    });
                }
            } else {
                var userTracksDom = $("#userTracks");
                userTracksDom.hide().find("ul").html("");
            }
        }
    },
    
    getUserFoot : function() {
        var self = POI;
        var diu = '';
        self.send({action : 'getExtraUrl'}, function(res) {
            diu = res.diu;
            self.api.aosrequest('commentUserFoot', [{diu: diu, sign: 1}], POI.showUserFoot, false, true, "GET");
        });
        
    }
    
});

function showMain() {
    POI.getUserFoot();
    var showWordsAry = null;
    var words = "";
    if((0 == n) && (3 > star)) {
        words = POI.showNoXData[(business ? business : "other")][0];
    } else {
        if(business) {
            showWordsAry = POI.showData[business];
            if(!showWordsAry) {
                showWordsAry = POI.showData["other"];
            }
        } else {
            showWordsAry = POI.showData["other"];
        }
        words = showWordsAry[star - 1];
        words = words.replace("X", n);
    }
    
    $("#words").text(words);
}

$(function() {
    star = parseInt(POI.util.getUrlParam("star") || 1);
    business = POI.util.getUrlParam("business");
    c = POI.util.getUrlParam("c");
    n = (parseInt(POI.util.getUrlParam("n")) || 0) + 1;
    poiInfo = JSON.parse(POI.util.storage("COMMENT_POIINFO"));
    var shareHtmlUrl = /amap\.com/i.test(POI.aosPrefixUrl.commentUserFoot) && !/testing/i.test(POI.aosPrefixUrl.commentUserFoot) ? 'http://wap.amap.com/commentShare/index.html' : 'http://group.testing.amap.com/deming.zhu/commentShare/index.html';
    
    showMain();
    
    $("#shareCon i").on("click", function(evt) {
        var ele = $(this);
        var self = POI;
        
        self.send({action : 'getExtraUrl'}, function(res) {
            var t = res.tid;
            var shareUrl = shareHtmlUrl + '?id=' + poiInfo.poiid + '&t=' + t + '&c=' + c + '&name=' + encodeURIComponent(poiInfo.name) + '&x=' + poiInfo.lon + '&y=' + poiInfo.lat + '&b=' + business + '&n=' + n + '&star=' + star,
                title = poiInfo.name,
                img = 'http://cache.amap.com/h5/amapshare.png',
                img_weibo = 'http://cache.amap.com/h5/other/amapshare_weibo.jpg',
                starstr = {1:'★,',2:'★★,',3:'★★★,',4:'★★★★,',5:'★★★★★,'}[star],
                content,
                msg = '我点评了' + poiInfo.name + ':' + starstr + (POI.shareData[business] ? POI.shareData[business][star - 1] : POI.shareData["other"][star - 1]);
            if(3 > star) {
                msg = '我点评了' + poiInfo.name + ':' + starstr + '又被坑了！小伙伴们快来挺我！';
            }
            if( ele.hasClass( 'weixin' ) ){
                content = [{type : 'weixin', message : msg, title: title,url: shareUrl,imgUrl:img}];
            } else if( ele.hasClass( 'pengyou' ) ) {
                content = [{type : 'pengyou', message : msg, title: msg,url: shareUrl,imgUrl:img}]
            } else {
                content = [{type : 'weibo', message : msg, title: title,url: shareUrl,imgUrl:img_weibo}];
            }
            self.send({
                action : "share",
                content : content,
                useCustomUrl :'1' ,
                urlType : '1',
                loadDirectly : '1',
                poiInfo : ''
            }, function( res ){
                if( res.result == 'ok'){
                    self.api.userAction('shareCommontSuccess',{type:content[0].type});
                }
            });
            self.api.userAction('shareCommont',{type:content[0].type});
        });
    });
});
})(POI, Zepto);