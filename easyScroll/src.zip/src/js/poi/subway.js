/**
 * 公交地铁相关
 */
;(function(POI, $) {
$.extend(POI, {
    traffic_lines : [],//给报错功能提供线路名称列表
    subway_change : false,//标志是否可以换成
    init: function(){
        //650地铁线路图代码开始
        var self = this,
            subway_info = ((self.aosData||{}).rti||{}).subway_info||{},
            base = self.aosData.base;
        this.subway_cityCode = this.clientData.poiInfo.cityCode;
        subway_info.pois_list && (self.subway_pois_list = subway_info.pois_list);
        self.showSubCrossLines(function() {
            self.reqNearbyStations(base.poiid,base.x,base.y);
            self.index.moduleDeepHead(self.index.moduleHeadItem(self.aosData.base.poi_status || ( self.subway_change ? '可换乘' : '')));
        });
    },
    cache_subwayAlleyway : {},
    /*
    出入口信息模块
    <article>
        <strong>A(东北口)</strong>
        <div>
            <aside><b></b>周围地标</aside>
            <ul class="half-border">
                <li class="more"><em class="lineDot">北京教育学院海淀分院</em></li>
                <li class="more"><em class="lineDot">维特天天幼儿园</em></li>
            </ul>
        </div>
    </article>
    */
    get_subwayAlleyway : function(){
        return '';//750先不展示地铁出入口信息了
        var self = this, html = [], data = self.cache_subwayAlleyway, num = 0,
            pois_list = self.subway_pois_list||[], handleAttr = self.handleAttr;
        pois_list.forEach(function(item , i) {
            if(item.subway_entr_info && item.subway_entr_info.length) {
                item.tag = item.tag || {};
                item.tag.child_shortname = item.tag.child_shortname||[{}];
                html.push('<article' + (num > 0 ? ' class="lazyload"' : '') + '>');
                html.push('<strong>' + (item.tag.child_shortname[0].v || item.name || '') + '</strong>');
                html.push('<div><aside><b></b>周围地标</aside>');
                html.push('<ul class="half-border">');
                item.subway_entr_info.forEach(function(info) {
                    html.push('<li class="more" poiid="'+info.poiid+'" '+ handleAttr +'="js_openAlleyway"><em class="lineDot">' + (info.name || '') + '</em></li>');
                    data[info.poiid] = info;
                });
                html.push('</ul></div>');// end ul; end div;
                html.push('</article>');
                num++;
            }
        });
        if(num > 0) {
            num > 1 && html.push('<a class="showMore down canTouch" '+ handleAttr +'="js_subwayAlleyway">查看更多</a>');
            return '<section id="subwayAlleyway" class="js_hidemorelist"><h2>出入口信息</h2>' + html.join('') + '</section>';
        }else{
            return '';
        }
    },
    js_subwayAlleyway : function(obj) {
        var self = this, box = $('#subwayAlleyway'), fig = box.hasClass('js_hidemorelist');
        obj[fig ? 'addClass' : 'removeClass']('up')[fig ? 'removeClass' : 'addClass']('down').html( fig ? '收起' : '查看更多');
        box[fig ? 'removeClass' : 'addClass']('js_hidemorelist');
        if(!fig){
            $(window).scrollTop(box.offset().top);
        }
        self.api.userAction('moreAlleyway', {fig : fig ? 'show' : 'hide' });
    },
    js_openAlleyway : function(obj) {
        var self = this, data = self.cache_subwayAlleyway, item = data[obj.attr('poiid')||''];
        if(item) {
            self.api.userAction('subwayAlleyway', {poiid : item.poiid});
            self.api.openPoiInfo(item.poiid, item.name, item.address, '', '', '', item.x, item.y);
        }
    },
    subway_crossTrafficLines : function(data, callback) {
        var self = this, html = ['<section class="subwayCrossLines">'+ self.get_nav(data)],
            len = data.length, str, els;
        data.forEach(function(item, i) {
            html.push(self.getCrossItem(item, i+1, len));
        });
        str = self.get_subwayAlleyway();
        html.push('</section>'+str);
        //$('body').append('<p style="padding:1px; position:fixed;top:-10000px;"></p>');//为了解决小米1s报错图标感叹号不显示，增加这个标签hack
        self.pagebody.append(html.join(''));
        self.layout_cross();
        //初始化初始状态
        self.js_subway_nav($('.subwayCrossLines_art1 p').eq(0), 1);
        typeof callback == 'function' && callback();
    },
    js_subway_nav : function(obj, fig) {//途经线路切换按钮
        var self = this, box = $('.subwayCrossLines_nav'), id = obj.attr('id'), old = box.find('p.selected'),end,
            oid = old.attr('id');
        !obj.find('canvas').length && obj.append(self.get_subway_navbg(obj.width()));
        if( id != oid || fig === 1){
            old.length && $('#' + oid + '_view,' + '#' + oid + '_lines').hide();
            $('#' + id + '_view,' + '#' + id + '_lines').show();
            old.length && old.removeClass('selected');
            obj.addClass('selected');
        }
        id != oid && oid && self.api.userAction('subwayTabChange');
    },
    js_changestation : function(li) {//显示换乘信息
        var self = this, ul = li.parent(),
            changes = '<b>换乘</b>&nbsp;' + (li.attr('changes').split(',')||[]).join('&nbsp;|&nbsp;'),
            tips = ul.find('li.subwayCrossLines_ul_tips'), fit = tips.find('em');
        tips.find('span').html(changes);
        self.set_tips(tips, fit, li.attr('index')||0);
    },
    js_subwayline : function(obj) {
        var self = this, lineid = obj.attr('lineId'),
            cityCode = self.subway_cityCode||'';
        if(lineid){
            self.api.openBusLine(lineid, cityCode);
            self.api.userAction('crossSubwayLine', {lineid : lineid});
        }
    },
    liwidth : 60,//线路模块一个li的宽度
    layout_cross : function() {
        var self = this, box, uls = $('.subwayCrossLines_ul'),
            winwidth = document.documentElement.clientWidth,
            nav = $('#js_subway_crossnav'), nav_width = 0,
            scrolls = [], timer, nav_scroll;
        nav.find('p').each(function(i, item){
            nav_width += $(item).width();
            i>0 && (nav_width += 10);
        });
        if( nav_width > $('.subwayCrossLines_art1').width()-15) {
            nav.width(nav_width+15);
            nav_scroll = self.easyScroll(nav.parent()[0], {
                align : 'x',
                preventDefault : false
            });
        }
        uls.each(function(){//先显示出来，下面才能动态计算相关标签尺寸进行定位
            $(this).parent().show();
        }).each(function(){
            var ul = $(this), tips = ul.find('li.subwayCrossLines_ul_tips'), fit = tips.find('em'),
                box = ul.parent(),
                selected = ul.find('li.nowsection').eq(0),
                liwidth = self.liwidth,
                index = selected.attr('index')||0,
                scrollLeft, selectleft;
            selectleft = liwidth * index + liwidth / 2;
            scrollLeft = selectleft - winwidth / 2;
            
            ul.width() > ul.parent().width() && scrolls.push([self.easyScroll(ul.parent()[0], {
                align : 'x',
                preventDefault : false,
                moveto : scrollLeft > 0 ? -scrollLeft : 0
            }), box]);
            
            if(selected.length == 0){
                tips.hide();
            }else{
                if(selected.hasClass('change')){
                    self.set_tips(tips, fit, index);
                }else{
                    tips.hide();
                }
            }
            box.hide();
        });
        $(window).resize(resize).bind('orientationchange', resize);
        function resize () {
            clearTimeout(timer);
            timer = setTimeout(function() {
                scrolls.forEach( function( item ) {
                    var fig = item[1].css('display') == 'none';
                    fig && item[1].show();
                    item[0].refresh();
                    fig && item[1].hide();
                    self.js_subway_nav( $('.subwayCrossLines_nav p.selected') , 1 );
                } );
                nav_scroll && nav_scroll.refresh();
            }, 80);
        }
    },
    set_tips : function(tips,fit,index){//根据当前li位置设置tips位置
        var self = this, tipswidth, fitwidth, selectleft, left,
            liwidth = self.liwidth,
            ulwidth = tips.parent().find('li').not('.subwayCrossLines_ul_tips').length * liwidth;
        tips.show();
        selectleft = liwidth * index + liwidth / 2;
        tipswidth = tips.width(), fitwidth = fit.width();
        left = selectleft - tipswidth / 2;
        if(left < 2){//想右挪2px，防止边线太靠屏幕边界
            left = 2;
        }else if( (left + tipswidth + 2) > ulwidth){//想左挪2px，防止边线太靠屏幕边界
            left = ulwidth - tipswidth - 2;
        }
        left = Math.max(left, 2);
        tips.css('left', left + 'px');
        fit.css('left', (selectleft - left) + 'px');
    },
    /*
    <article class="subwayCrossLines_art2">
        <p><span class="subwayCrossLines_art2_endname">开往<i>金台路</i>方向</span><span class="subwayCrossLines_art2_stime">05:00</span><span class="subwayCrossLines_art2_endtime">22:00</span></p>
        <p><span class="subwayCrossLines_art2_endname">开往<i>望京</i>方向</span><span class="subwayCrossLines_art2_stime">05:00</span><span class="subwayCrossLines_art2_endtime">22:00</span></p>
        <p><span class="subwayCrossLines_art2_price">票价3-5元</span><em class="subwayCrossLines_art2_map">北京地铁线路图</em></p>
        <h2 class="subwayCrossLines_h2">途经站点</h2>
    </article>
    <article class="subwayCrossLines_art3">
        <ul class="subwayCrossLines_ul">
            <li><p class="subwayCrossLines_ul_firstp"></p><i>善各庄</i></li>
            <li class="selected nowsection"><p></p><i>善各庄</i></li>
            <li><p></p><i>善各庄善各庄</i></li>
            <li class="change"><p></p><i>善各庄</i></li>
            <li><p></p><i>善各庄</i></li>
            <li><p></p><i>善各庄</i></li>
            <li><p></p><i>善各庄</i></li>
            <li><p class="subwayCrossLines_ul_lastp"></p><i>善各庄</i></li>
            <li class="subwayCrossLines_ul_tips half-border"><b>换乘</b>&nbsp;15号线&nbsp;|&nbsp;13号线<em></em></li>
        </ul>
    </article>
    */
    getCrossItem : function(obj, index,total) {
        var self = this, html = [], lines = obj.lines ,first = lines[0]||{}, handleAttr = self.handleAttr,
            poiname = ((self.clientData.poiInfo || {}).name || '').replace('(地铁站)', ''),
            stations = first.stations||[], changenames=[], slen = stations.length, lineids = [];
        html.push('<article class="subwayCrossLines_art2" id="js_item'+index+'_view"'+ (index>1? ' style="display:none;"' : '') +'>');

        lines.forEach(function(item) {
            item.start_time = item.current_start_time || item.start_time;
            item.end_time = item.current_end_time || item.end_time;
            html.push('<p '+ handleAttr +'="js_subwayline" lineId="' + item.id + '" class="line canTouch half-border"><span class="subwayCrossLines_art2_endname">开往<i>'+ item.terminal_name +'</i>方向</span>');
            item.start_time && html.push('<span class="subwayCrossLines_art2_stime">'+ (item.start_time.length==4? (item.start_time.substr(0,2)+":"+item.start_time.substr(2,2)) : item.start_time) +'</span>');
            item.end_time && html.push('<span class="subwayCrossLines_art2_endtime">'+ (item.end_time.length==4? (item.end_time.substr(0,2)+":"+item.end_time.substr(2,2)) : item.end_time) +'</span></p>');
            lineids.push( item.id );
        });
        
        obj.name && self.traffic_lines.push( obj.name + ',' + lineids.join('|') );
        
        if( obj.base_price ) {
            html.push('<p class="module_title line-half"><span class="subwayCrossLines_art2_price">票价' + obj.base_price + (obj.total_price && obj.total_price != obj.base_price ? '-' + obj.total_price : '') + '元</span>'+ (self.subway_cityCode ? '<em class="subwayCrossLines_art2_map canTouch" '+ handleAttr +'="js_open_subwaymap">地铁线路图</em>' : '') +'</p>');
        } else if( obj.total_price ) {
            html.push('<p class="module_title line-half"><span class="subwayCrossLines_art2_price">总价' + obj.total_price + '元</span>'+ (self.subway_cityCode ? '<em class="subwayCrossLines_art2_map canTouch" '+ handleAttr +'="js_open_subwaymap">地铁线路图</em>' : '') +'</p>');
        }
        
        html.push('<h2 class="module_title_p">途经站点</h2>');
        html.push('</article>');// end article
        html.push('<article class="subwayCrossLines_art3" id="js_item'+index+'_lines"'+ (index > 1 ? ' style="display:none;"' : '') +'>');
        html.push('<ul style="width:' + this.liwidth * slen + 'px;" class="subwayCrossLines_ul">');
        
        stations.forEach(function(item, i) {
            
            html.push('<li class="'+(poiname == item.name ? 'nowsection selected':'')+(item.changes?' change':'')+'"' + (item.changes ? ' changes="' + item.changes.join(',') + '"' : '') +' index="'+i+'" '+ (item.changes? handleAttr + '="js_changestation"' : '') +'>');
            
            html.push('<p' + (i == 0 ? ' class="subwayCrossLines_ul_firstp"' : (slen == (i+1) ? ' class="subwayCrossLines_ul_lastp"' : '')) + '></p>');
            
            html.push('<i>' + item.name + ( item.status_text ? '<br />(' + item.status_text +')' : '' ) + '</i>');
            
            html.push('</li>');
            
            if(poiname == item.name && item.changes){
                changenames = item.changes;
                self.subway_change = true;
            }
        });
        html.push('<li class="subwayCrossLines_ul_tips half-border"><span class="lineDot"><b>换乘</b>&nbsp;' + (changenames||[]).join('&nbsp;|&nbsp;') + '</span><em></em></li>');
        html.push('</ul>');
        html.push('</article>');
        return html.join('');
    },
    /*
    <article class="subwayCrossLines_art1">
        <p class="half-border selected"><span class="lineDot">2号线</span><i></i></p>
        <p class="half-border"><span class="lineDot">4号大兴线</span><i></i></p>
        <p class="half-border"><span class="lineDot">5号线</span><i></i></p>
    </article>
        or 
    <article class="subwayCrossLines_art1">
        <p class="half-border selected onlyone">2号线<i></i></p>
    </article>
    */
    get_nav : function(data) {
        var self = this, html = [], handleAttr = self.handleAttr;
        html.push('<article class="subwayCrossLines_art1"><nav class="subwayCrossLines_nav" id="js_subway_crossnav">');
        data.forEach(function(item, i) {
            html.push('<p class="half-border canTouch' + (i == 0 ? ' selected' : '') + '" id="js_item' + ( i + 1 ) + '" '+ handleAttr +'="js_subway_nav"><span>'+ (item.name||'') +'</span><i></i></p>');
        });
        html.push('</nav></article>');
        return html.join('');
    },
    //展现途径线路首末时间等信息
    showSubCrossLines:function(callback){
        var self = this, params, str;
        if(self.aosData.base.poiid){//公交站如果没有站台信息不显示线路信息
            params = [{poiid : self.aosData.base.poiid, sign :1},
                        {data_type : 'subway'},
                        {ensure_ascii : 'false'},
                        {adcode : self.clientData.poiInfo.cityCode||''}
                    ];
            self.api.aosrequest({'params':params,'urlPrefix':'trafficCrossLines' ,'method':'get'},function(data){
                if(data && data.busline_list && data.busline_list.length){
                    self.subway_crossTrafficLines(data.busline_list||[], callback);
                }else{
                    str = self.get_subwayAlleyway();
                    str && self.pagebody.append(str);
                    typeof callback == 'function' && callback();
                }
            });
        }else{
            str = self.get_subwayAlleyway();
            str && self.pagebody.append(str);
            typeof callback == 'function' && callback();
        }
    },
    /**
     * 请求获取附近公交、地铁站点数据
     * poiid:poiid点(当传入时，此poi点的站点信息不显示出来，对应的pageSize+1、传入空时，所有站点都显示出来),
     * x:经度,y:纬度
     */
    reqNearbyStations:function(poiid,x,y){
        var self = this, params=[];
        params.push({longitude:x,sign:1});
        params.push({latitude:y,sign:1});
        params.push({range:2000});
        params.push({pagesize:6});
        params.push({pagenum:1});
        params.push({sort_rule:1});
        params.push({category:'150500|150700'});
        //获取附近公交车站，附近公交车站里边根据本站途径线路ID集合(businfo_lineids)获取公交线路信息
        self.api.aosrequest({'params':params,'urlPrefix':'trafficSearch','method':'GET'},function(arg){
            self.outputNearbyTrafficStation(arg,poiid);
        });
    },
    near_cache : {},
    /*输出附近公交
<section class="subwayNearStations">
    <h2 class="subwayNearStations_h2">附近公交站</h2>
    <article class="subwayNearStations_art">
        <div class="subwayNearStations_div">
            <p>西八间房(公交站)</p><span>177m</span>
        </div>
        <em class="subwayNearStations_em">401路、403路、632路</em>
    </article>
    <article class="subwayNearStations_art">
        <div class="subwayNearStations_div">
            <p>西八间房(公交站)</p><span>177m</span>
        </div>
        <em class="subwayNearStations_em">401路、403路、632路</em>
    </article>
</section>
    */
    outputNearbyTrafficStation:function(data,poiid){
        if(data && data.bus_list){
            var self = this, busA=[], near_cache = self.near_cache, handleAttr = self.handleAttr;
            
            $.each(data.bus_list,function(index,item){

                if(item.id!=poiid){//展现非本站点数据

                    if(item.name&&item.lines&&item.typeflag==1){
                        var key = 'index'+index;
                        near_cache[key] = item;
                        busA.push('<article class="subwayNearStations_art canTouch half-border" ' + handleAttr + '="js_openNearTraffic" index="' + key + '">');
                        busA.push('<div class="subwayNearStations_div"><p>'+item.name+'</p><span>'+ self.subway_kilometer(item.distance)+'</span></div>');
                        busA.push('<em class="subwayNearStations_em lineDot">'+self.filterSameLines(item.lines)+'</em>');
                        busA.push('</article>');
                    }
                }
            });
            busA.length>0 && self.pagebody.append('<section class="subwayNearStations"><h2 class="module_title_p line-half">附近公交站</h2>' + busA.join("") + '</section>');
        }
    },
    subway_kilometer : function(str){
        var tmp = parseFloat(str+'');
        if(tmp>1000){
            return (tmp/1000).toFixed(1) + 'km';
        }else{
            return tmp.toFixed(0) + 'm';
        }
    },
    filterSameLines:function (str){
        if(str){
            var oTmp={},ret=[];
            $.each(str.replace(/\|/g,";").split(";"),function(index,item){
                if(item && !oTmp[item]){
                    oTmp[item]=1;
                    ret.push(item);
                }
            });
            return ret.join("、");
        }
        return '';
    },
    get_subway_navbg : function(width) {
        return new POI.util.DialogBox({
            width: width,
            height: 30,
            borderWidth: 1,
            borderColor: "#0091ff",
            borderRadius: 2,
            arrowDirection: 0,
            arrowDistance:  (width - 10)/2,
            arrowWidth: 10,
            arrowHeight: 5
        });
    },
    js_openNearTraffic : function(obj) {
        var item = this.near_cache[obj.attr('index')];
        if(item) {
            this.api.openPoiInfo(item.id, item.name, item.address, item.areacode, item.newtype, item.tel, item.x, item.y);
            this.api.userAction('nearStation', {poiid : item.id});
        }
    },
    js_open_subwaymap : function(){//打开地铁图
        var self = this, cityCode=self.subway_cityCode,
            new_poiInfo = $.extend({}, self.clientData.poiInfo)
            c2 = cityCode.substring(0,2);
        if(c2=='11' || c2=='31' || c2=='12' || c2=='50'){//北京、上海、天津、重庆四个直辖市特殊处理，因cityCode可能返回的是市，也可能到区
            cityCode=c2+'0000';
        }
        new_poiInfo.cityCode = cityCode;
        self.api.triggerFeature('subway', new_poiInfo);
        self.api.userAction('subwayLine', {cityCode : cityCode});
    }
});
})(POI, Zepto);