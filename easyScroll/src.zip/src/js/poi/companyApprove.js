;(function(POI, $) {
	$.extend(POI, {
		//埋点page标识
    	logPageId : "companyApprovePage",
    	quickInit: function() {
    		var that = this;

    		if (window.location.search) {
    			that.getCompanyApproveData(POI.util.getUrlParam());
    		}
    	},
    	getCompanyApproveData: function(arg) {
    		var that = this;

    		var params = [
    			{poiid: arg.id, sign: 1},
                {mode: 2},
                {deepcount: 1},
                {src: arg.source}
    		];
    		
    		POI.api.aosrequest('deepUrl', params, function(res) {
    			
    			if (res.code != 1 || !res.poiinfo || !res.poiinfo.deep || !res.poiinfo.deep[0]) {
                    return;
                }
                
                that.makeCompanyApproveHtml(res, arg.name);
                
    		}, 1, true, "GET");
    	},
    	makeCompanyApproveHtml: function(res, name) {
    		var that = this;
    		var deep = res.poiinfo.deep[0];
    		
            $('.approve_name').html(name+
                           '：<span class="zhehang">诚信通 第 <span>'+deep.cxt_per+'</span> 年<span id="company_intro" data-url="'+deep.intro_wapurl+'"><i></i></span></span>');
            $('.address').html('店铺地址：<span data-url="'+deep.store_wapurl+'">'+deep.store_wapurl+'</span>');

    		if (deep.auth_type && deep.auth_type.length > 0) {
    			$('.company_logo').show();
                if(deep.auth_time && deep.auth_time.length > 0) {
                   $('.approve_info').html('此商户于'+deep.auth_time+'通过'+deep.auth_type); 
                }
    		}          

            $('.business_name').html('公司名称：'+deep.regist_name);

            $('.regis_address').html('注册地址：'+deep.regist_addr);

            $('.regis_num').html('注册号：'+deep.regist_no);

            $('.regis_money').html('注册资本：人民币'+deep.regist_cap+'万元');

            $('.time').html('成立时间：'+deep.fouding_time);

            $('.person').html('法定代表人：'+deep.legal_rep);

            $('.company_type').html('企业类型：'+deep.tag_category);

            $('.deadline').html('营业期限：'+deep.business_per_beg+'至'+deep.business_per_end);

            $('.scope').html('经营范围：'+deep.scope);

            POI.api.userAction('showCompanyApprovePage');

    		that.bindEvent();

    	},
    	bindEvent: function() {
    		$('.address').on('click', function() {
    			var url = $(this).find('span').data('url');
                
    			POI.api.openThirdUrl(url);
    			POI.api.userAction('shopUrl', {url: url});
    		});

    		$('#company_intro').on('click', function() {
    			var url = $(this).data('url');
    			POI.api.openThirdUrl(url);
    			POI.api.userAction('introUrl', {url: url});
    		});
    	}
	});

})(POI, Zepto);