/**
 * 医院详情页.
 */
;(function(POI, $) {
'use strict';

var hasInfo = false;

/**
 * 生成特色科室文档结构.
 * @param {Object} deep 深度信息
 * @return {String} html
 */
function tplDeptment(deep) {
    if (!deep.tag_special) {
        return '<div id="hospitalCon"></div>';
    }
    var tag_special = deep.tag_special.replace(/\s*\|\s*/g, '</li><li class="half-border">');
    return '<div id="hospitalCon">' +
               '<section class="hospital-department">' +
                   '<h2 class="module_title_p line-half more" '+( hasInfo ?  POI.handleAttr +
                           '="js_openDepartList"' :'')+'>特色科室' +
                       (hasInfo ? '<i class="right-text hospital-right-text">全部</i></h2>' : '</h2>') +
                   '<ul class="department-list clearfix">' +
                       '<li class="half-border">' + tag_special + '</li>' +
                   '</ul>' +
               '</section>' +
           '</div>';
}
/**
 * 著名医生列表.
 * @return {String} html
 */
function tplDoctor(list) {
    var html = '';
    for (var i = 0, len = list.length; i < len; i++) {
        html += tplDoctorItem(list[i]);
    }
    return '<section class="hospital-doctor" id="hospitalDoctor">' +
            '<h2 class="module_title_p line-half more" ' + POI.handleAttr + '="js_openDrList">著名医师' +
                '<i class="right-text hospital-right-text">更多</i></h2>' +
            '<ul class="doctor-list">' + html + '</ul>' +
        '</section>';
}
function tplDoctorItem(obj) {
    var img = obj.pic_info && obj.pic_info[0] && obj.pic_info[0].url || 'img/img-def.png';
    var visit = '';
    if (obj.today_status == '1') {
        visit = '<p class="visit"></p>';
    }
    else if (obj.today_status == '0') {
        visit = '<p class="visit not"></p>';
    }

    return '<li class="line-half clearfix" data-id="' + obj.doc_id + '" ' +
                POI.handleAttr + '="js_openDrDetail">' +
            '<aside class="pic-info img-def">' +
                // '<img src="' + img + '" alt="">' +
                visit +
            '</aside>' +
            '<div class="info">' +
                '<h3 class="name-info">' +
                    obj.doc_name +
                    '<small class="office">' + (obj.doc_title || '') + '</small>' +
                    (obj.child_name ? '<cite class="department">' + obj.child_name + '</cite>' : '') +
                '</h3>' +
                (obj.doc_speciality ? '<p class="intro-text linesDot">擅长：' +
                    obj.doc_speciality + '</p>' : '') +
            '</div>' +
        '</li>';
}

function getDrList() {
    var param = [
        {poiid    : POI.aosData.base.poiid, sign: 1},
        {pagesize : 3}
    ];
    POI.api.aosrequest('hospitalDrInfo', param, function(res) {
        if (res.code != '1' || !res.doctors || !res.doctors.length) {
            return;
        }

        $('#hospitalCon').append( tplDoctor(res.doctors) );
        if ($('#hospitalCon .hospital-department').length > 0) {
           $('.hospital-doctor').css('margin-top', '10px'); 
        }
        
        // 处理头像加载失败与成功
        var $imgs = $('#hospitalDoctor .img-def');
        for (var i = 0, len = res.doctors.length; i < len; i++) {
            var obj = res.doctors[i];
            var img = obj.pic_info && obj.pic_info[0] && obj.pic_info[0].url;
            new POI.util.loadImage(img, $imgs[i], imgLoadSuccess);
        }

        function imgLoadSuccess(elem, img) {
            $(elem).css({
                backgroundImage: 'url(' + img.src + ')',
                backgroundPosition: 'center 0',
                backgroundSize: 'cover'
            });
        }
    }, 0, 0, 'get');
}

$.extend(POI, {
    init: function() {
        var self = this;
        var base = self.aosData.base;
        var deep = self.aosData.deep[0];

        if (deep.is_depart == '1') {
            hasInfo = true;
            getDrList();
        }

        var price = deep.price ? '￥' + deep.price + '起' : '';
        var introHtml = self.index.moduleIntro(['医院图片', '', '医院简介'], 'intro');
        
        var tags = '';
        if (POI.aosData.base.std_t_tag_0_v) {
            var arr = POI.aosData.base.std_t_tag_0_v.split(';');
            for (var i=0; i<arr.length; i++) {
                tags += this.index.moduleHeadItem(arr[i]);
            }
        }
        self.index.moduleDeepHead(tags, price);
        
        var html = self.index.moduleAll(['alipayDiscount', 'rti', tplDeptment(deep), 'stopStrategy', 'shoppingGuide', 'guidePicList',
            'activityInfo', introHtml, 'impression', 'commentInfo',  'indoorMap', 'banner', 'placeContribution']);
        self.pagebody.html( html.join('') );

        self.util.executeAfterDomInsert();
    },
    // 打开科室列表页面
    js_openDepartList: function() {
        var self = this;
        var poiid = POI.aosData.base.poiid;
        // 获取科室列表
        var param = [{poiid: poiid, sign: 1}];
        self.api.userAction('allDepartList');
        self.api.aosrequest('hospitalDepartInfo', param, function(res) {
            if (res.code != '1' || !res.department) {
                self.api.promptMessage('请稍后重试');
                return;
            }
            res.poiid = poiid;
            self.util.storage('hospital.departmentList', JSON.stringify(res));
            self.util.locationRedirect('hospital_depart_list.html');
        }, 1, true, 'get');
    },
    // 打开医生列表页面
    js_openDrList: function() {
        var self = this;
        var poiid = POI.aosData.base.poiid;

        // 获取医生列表
        var param = [
            {poiid: poiid, sign: 1},
            {pagesize : 10}
        ];
        self.api.userAction('allDrList');
        this.api.aosrequest('hospitalDrInfo', param, function(res) {
            if (res.code != '1' || !res.doctors) {
                self.api.promptMessage('请稍后重试');
                return;
            }
            res.poiid = poiid;
            self.util.storage('hospital.departmentInfo', JSON.stringify(res));
            self.util.locationRedirect('hospital_dr_list.html');
        }, 1, true, 'get');
    },
    // 打开医生详情页面
    js_openDrDetail: function(elem) {
        var self = this;
        var poiid = self.aosData.base.poiid;

        // 获取科室医生详情信息
        var param = [
            {poiid       : poiid, sign: 1},
            {doctor_id   : elem.attr('data-id')},
            {visit_flag  : 1},
            {review_flag : 1}
        ];
        self.api.userAction('drDetail', {doctor_id: elem.attr('data-id')});
        this.api.aosrequest('hospitalDrInfo', param, function(res) {
            if (res.code != '1' || !res.doctors) {
                self.api.promptMessage('请稍后重试');
                return;
            }
            self.util.storage('hospital.doctorInfo', JSON.stringify(res));
            self.util.locationRedirect('hospital_dr_detail.html');
        }, 1, true, 'get');
    }
});

})(POI, $);
