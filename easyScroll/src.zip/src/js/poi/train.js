;(function(POI, $) {

$.extend(POI, {
    
    poiList: [],
    
    arriveList: [],
    
    leaveList: [],
    
    tpl: {
        getShortName: function(poiInfo) {
            var shortName = poiInfo.name;
            if(poiInfo.tag && poiInfo.tag.child_shortname && poiInfo.tag.child_shortname[0] && poiInfo.tag.child_shortname[0].v) {
                shortName = poiInfo.tag.child_shortname[0].v;
            }
            return shortName;
        },
        getTitle : function(title) {
            if(!title) return "";
            return '<p class="train_title">' + title + '</p>';
        },
        getDesc : function(desc, desc2) {
            return '<p class="train_subtitle">' + desc + (desc2 ? '<span class="train_subtitle_span">' + desc2 + '</span>' : '') + '</p>';
        },
        getLinkItem : function(poiid, name, recoCode) {
            if(!name) return "";
            return '<code class="train_link_item"><a href="javascript:void(0);" ' + POI.handleAttr + '="js_trainShowPoi" poiid="' + poiid + '" reco="' + recoCode + '" class="train_link_btn canTouch half-border lineDot">' + name + '</a></code>';
        },
        getLink : function(ary, recoCode) {
            var str = '<div class="train_link">';
            for(var i = 0, len = ary.length, relPoi = null; i < len; i++) {
                relPoi = ary[i];
                str += this.getLinkItem(relPoi.poiid, this.getShortName(relPoi), recoCode);
            }
            return str + '</div>';
        },
        getSwitch : function() {
            return '<article ' + POI.handleAttr + '="js_trainMoreSwitch" class="switch canTouch"><a href="javascript:void(0);">所有设施<i></i></a></article>';
        }
    },
    
    listConvert: function(ary) {
        var _tmpAry = [],
            _code = ary[0].reco_code;
        for(var i = 0, len = ary.length; i < len; i++) {
            if(_code == ary[i].reco_code) {
                _tmpAry.push(ary[i]);
            } else {
                +_code < 4 ? this.arriveList.push(_tmpAry) : this.leaveList.push(_tmpAry);
                _code = ary[i].reco_code;
                _tmpAry = [ ary[i] ];
            }
        }
        +_code < 4 ? this.arriveList.push(_tmpAry) : this.leaveList.push(_tmpAry);
    },
    
    findPoiById : function(id) {
        var poiInfo = null;
        for(var i = 0, len = this.poiList.length; i < len; i++) {
            if(id === this.poiList[i].poiid) {
                poiInfo = this.poiList[i];
                break;
            }
        }
        return poiInfo;
    },
    
    create_1: function(ary, recoCode, ishide) {
        if(!ary.length) return "";
        var _html = '<article ' + (ishide ? 'class="hide"' : '') + '>',
            item = ary[0];
        _html += this.tpl.getTitle(item.reco_info)
               + this.tpl.getDesc(item.guide_info);
        
        var relAry = [];
        for(var i = 0, len = ary.length; i < len; i++) {
            relAry.push(this.findPoiById(ary[i].rel_poiid));
        }
        
        _html += this.tpl.getLink(relAry, recoCode);
        return _html + '</article>';
    },
    
    create_2: function(ary, recoCode, ishide) {
        if(!ary.length) return "";
        var _html = '<article ' + (ishide ? 'class="hide"' : '') + '>',
            _linkHtml = '<div class="train_link">',
            item = ary[0],
            relPoi = null;
        
        _html += this.tpl.getTitle(item.reco_info)
               + this.tpl.getDesc(item.guide_info, item.name);
        
        relPoi = this.findPoiById(item.rel_poiid);
        _linkHtml += this.tpl.getLinkItem(relPoi.poiid, this.tpl.getShortName(relPoi), recoCode);
        
        for(var i = 1, len = ary.length; i < len; i++) {
            item = ary[i];
            _html += this.tpl.getDesc(item.guide_info, item.name);
            
            relPoi = this.findPoiById(item.rel_poiid);
            _linkHtml += this.tpl.getLinkItem(relPoi.poiid, this.tpl.getShortName(relPoi), recoCode);
        }
        
        return _html + _linkHtml + '</div></article>';
    },
    
    createHtml: function(flag) {
        /*
         *1：送人临时停靠点（出发）
         *2：最近公交站（出发）
         *3：最近地铁站（出发）
         *4：接人临时停靠点（到达）
         *5：换乘最近公交站（到达）
         *6：搭乘最近地铁站（到达）
         *7：出租车接客点（到达）
         */
        var _list = flag ? this.arriveList : this.leaveList,
            _listLen = _list.length,
            htmlStr = '';
        
        if(_listLen) {
            htmlStr = '<h2 class="module_title_p line-half mb10">' + (flag ? '去往' : '离开') + this.clientData.poiInfo.name + '攻略</h2>';
        }

        for(var i = 0, aryItem = null, code = 0, ishide = false; i < _listLen; i++) {
            ishide = 2 < i;
            aryItem = _list[i];
            code = aryItem[0].reco_code;
            if(/^1|2|3|4$/.test(code)) {
                htmlStr += this.create_1(aryItem, code, ishide);
            } else if(/^5|6|7/.test(code)) {
                htmlStr += this.create_2(aryItem, code, ishide);
            }
        }

        if(3 < _listLen) {
            htmlStr += this.tpl.getSwitch();
        }
        if(htmlStr) {
            return '<section id="' + (flag ? 'trainStationArrive' : 'trainStationLeave') + '" class="train_sec">' + htmlStr + '</section>';
        } else {
            return '';
        }
    },
    
    createPublic: function() {
        var publicPoiAry = [];
        for(var i = 0, len = this.poiList.length; i < len; i++) {
            if(/停车|售票|广场/.test(this.poiList[i].name)) {
                publicPoiAry.push(this.poiList[i]);
            }
        }
        if(publicPoiAry.length) {
            return '<section id="infrastructure" class="train_sec">' + 
                       '<h2 class="module_title_p line-half">公共设施</h2>' + 
                       '<article>' + 
                           this.tpl.getLink(publicPoiAry, "-1") + 
                       '</article>' + 
                   '</section>';
        } else {
            return '';
        }
    },
    
    // 发送请求枢纽列表的请求
    requestTransbay : function(cityCode) {
        POI.util.executeAfterDomInsert(function(_cityCode) {
            var params = [{city: _cityCode, sign: 1}];
            POI.api.aosrequest("transbayList", params, POI.showTransbay, false, false, "GET");
        }, cityCode);
        return '<section id="trafficHub" class="train_sec"></section>';
    },
    
    // 展示去往其他枢纽
    showTransbay : function(data) {
        try {
            if(1 != data.code) {
                return;
            }
            var transbayList = data.transbay_list,
                len = transbayList.length;
            if(1 > len) {
                return;
            }
            //console.dir(transbayList);
            var htmlStr = '<h2 class="module_title_p line-half">去往其他枢纽</h2>';
            for(var i = 0, item = null, linkStr = ''; i < len; i++) {
                item = transbayList[i];
                if(POI.clientData.poiInfo.poiid !== item.poiid) {
                    linkStr += '<div class="train_link_item" ' + this.handleAttr + '="js_trainTransbayRoute" param=\''+JSON.stringify(item)+'\'><a class="train_link_btn canTouch half-border lineDot">' + item.name + '</a></div>';
                }
            }
            //只含有自己，以后看这种情况能否让aos 处理下。
            if(!linkStr){
                return;
            }
            htmlStr = htmlStr + '<article><div class="train_link">' + linkStr + '</div></article>';
            $("#trafficHub").html(htmlStr);
        } catch(e) {
            //alert(e.message);
        }
    },
    
    hasStrategy : function(poiid) {
        POI.util.executeAfterDomInsert(function(_poiid) {
            var params = [{poiid: _poiid, sign: 1}];
            POI.api.aosrequest("hasStrategy", params, function(data) {
                if(1 == data.code && 1 == data.is_raiders){
                    $("#aide").html('<h2 class="aide_title module_title">出行指南</h2>' +
                                    '<ul class="aide_ul">' +
                                        '<li class="aide_ul_li canTouch" ' + POI.handleAttr + '="js_trainInquiries"><div class="aide_icon aide_icon_4"></div>列车查询</li>' +
                                        '<li class="aide_ul_li canTouch" ' + POI.handleAttr + '="js_trainStrategy"><div class="aide_icon aide_icon_5"></div>出行指南</li>' +
                                    '</ul>').removeClass("more").show();
                } else {
                    $("#aide").attr(POI.handleAttr, "js_trainInquiries").html('<h2 class="module_title_p more">列车查询</h2>').show();
                }
            }, false, false, "GET");
        }, poiid);
        //return '<section id="strategy"><h1 class="more link"><a href="exStrategy.html?poiid=' + POI.aosData.base.poiid + '">出行指南</a></h1></section>';
        return '<section id="aide" class="aide more hid"></section>';
    },

    /* --------------------点击事件----------------------- */
    js_trainInquiries : function(ele, e) {
        POI.api.userAction('trainInquiries');
        POI.api.triggerFeature("trainInquiries", POI.clientData.poiInfo);
    },
    js_trainStrategy : function() {
        POI.util.locationRedirect("exStrategy.html?poiid=" + POI.aosData.base.poiid);
    },
    js_trainShowPoi : function(ele, e) {
        var poiid = ele.attr("poiid"),
            reco = parseInt(ele.attr("reco")),
            flag = 0 < reco ? (4 > reco ? 0 : 1) : 2;
        POI.api.userAction("trainOpenPOI", {
            pageId_text_reco_flag: POI.clientData.poiInfo.poiid + "_" + ele.html() + "_" + reco + "_" + flag
        });
        if(poiid) {
            var poiData = this.findPoiById(poiid);
            POI.api.openPoiInfo(poiData.poiid, poiData.name, poiData.address ? poiData.address : "", "" ,"" ,"" , poiData.x, poiData.y, "", "");
        }
    },

    js_trainMoreSwitch : function(ele, e) {
        if(ele.hasClass("on")) {
            $("#trainStationLeave").find(".show").removeClass("show").addClass("hide");
            ele.removeClass("on").find("a").innerHTML = '所有设施<i></i>';
        } else {
            $("#trainStationLeave").find(".hide").removeClass("hide").addClass("show");
            ele.addClass("on").find("a").innerHTML = '收起<i></i>';
        }
    },

    js_trainTransbayRoute : function(ele, e) {
        var param = JSON.parse(ele.attr("param"));
        param.lon = param.x;
        param.lat = param.y;
        delete param.x;
        delete param.y;
        POI.api.userAction("trainTrafficHub", {
            parentId_poiid: this.clientData.poiInfo.poiid + "_" + param.poiid
        });
        POI.api.searchRoute(POI.clientData.poiInfo, param);
    },
    /* --------------------点击事件 end----------------------- */

    trainPageList: function(strategyStr, arriveStr, leaveStr, publicStr, transbayStr) {
        var htmlStr = strategyStr + arriveStr + leaveStr + publicStr + transbayStr,
            introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2"]),
            allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', introHtml, 'impression', 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
        this.pagebody.html(htmlStr + allAry.join(""));
        POI.util.executeAfterDomInsert();
    },

    init: function() {
        this.index.moduleDeepHead();
        var rtiData = this.aosData.rti,
            stationData = rtiData.station_info;
        if(POI.util.bool(stationData)) {
            this.poiList = stationData.pois_list;
            this.listConvert(stationData.entrance_info);
            this.trainPageList(
                this.hasStrategy(this.clientData.poiInfo.poiid),
                this.createHtml(1),
                this.createHtml(0),
                this.createPublic(),
                this.requestTransbay(this.clientData.poiInfo.cityCode)
            );
        } else {
            this.trainPageList(
                this.hasStrategy(this.clientData.poiInfo.poiid),
                '',
                '',
                '',
                this.requestTransbay(this.clientData.poiInfo.cityCode)
            );
        }
    }
    
});

})(POI, Zepto);