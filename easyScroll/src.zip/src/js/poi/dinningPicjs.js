;(function(POI, $){
    var dt = POI.util.storage( 'dinning_pic_centent' );
    localStorage.removeItem( 'dinning_pic_centent' );
    $( '#js_page section' ).html( dt || '');
    POI.util.setPageTitle( POI.util.getUrlParam( 'title' ) || 'ͷ��' );
    POI.logPageId = 'dinningPicjs';
    POI.api.userAction( 'pv' );
})(POI,Zepto);