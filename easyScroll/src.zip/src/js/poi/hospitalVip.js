/**
*	医院育果会员卡详情(770新增)
**/
;(function(POI, $) {
    $.extend(POI, {
        yuGuoDetail: {
            type: '',
            show: function(type) {
                var that = this;
                var params = [
                    {
                        'cp_source': type,
                        'sign': 1
                    },
                    {
                        'diu': POI.clientDiu,
                        'sign': 1
                    }
                ];
                that.type = type;
                POI.api.aosrequest('getYuGuoCardInfo', params, function(data) {
                    if (data.code == 1 || data.code == 7) {
                        that.makeCardHtml(data);
                    }
                }, 1, true, "GET");

            },
            makeCardHtml: function(data) {
                var that = this;
                var listData = POI.util.storage('yuguoData');
                listData = JSON.parse(listData);
                var list_str = that.makeDiscountList(listData);
                var card_num = that.formateCardNum('8888888888888888');
                var name = '育果医生';
                var time = that.formateTime('2016-03-01 00:00:00')+'&nbsp;&nbsp;(样卡)';
                var btn_class = 'canTouch';

                if (data.code == 1) {
                    card_num = that.formateCardNum(data.data.card_no);
                    name = '高德用户';
                    time = that.formateTime(data.data.create_time);
                    btn_class = 'off';
                }

                var card_str = '<div class="gaps"></div>'+
                               '<div class="vip_card">'+
                               '<div class="card_cont" id="yuguo_info">'+
                               '<p class="card_num">'+card_num+'</p>'+
                               '<p class="doctors_info">'+
                               '<span class="name">'+name+'</span>'+
                               '<span class="time">'+time+'</span>'+
                               '</p>'+
                               '</div>'+
                               '<div id="receive_btn" class="'+btn_class+'" js_handle="js_receiveCard"></div>'+
                               '<div class="use">'+
                               '<p class="title">使用方式</p>'+
                               '<p class="content">'+(listData[0].usage || '')+'</p>'+
                               '</div>'+
                               '</div>';
                POI.scrollPage({
                    defaultHeader : '会员卡详情',
                    content : '<section class="hospital_vip">'+list_str+card_str+'</section>'
                }).load_end();

                var w = $(window).width();

                var card_w = Math.floor((580*w)/640);
                var card_h = Math.floor((284*w)/640);
                var paading_top = Math.floor((w-card_w)/2);

                $('.card_cont').width(card_w).height(card_h).css('margin-bottom', paading_top+'px');
                $('#receive_btn').width(card_w);
                $('.vip_card').css('padding-top', paading_top+'px');
                POI.api.userAction('ShowYuGuoDetailPage');
            },
            formateCardNum: function(num) {
                var that = this;
                var arr = [];

                arr.push(num.substring(0,4));
                arr.push(num.substring(4,8));
                arr.push(num.substring(8,12));
                arr.push(num.substring(12, 16));
                
                return arr.join('  ');
            },
            formateTime: function(time) {
                var that = this;

                time = time.split(' ')[0];

                return time.replace(/-/g, ' ');
            },
            makeDiscountList: function(data) {
                var that = this;
                
                var pre_ul = '<ul class="discount_list">';
                var last_ul = '</ul>';
                var li_arr = [];

                for (var i=0; i<data.length; i++) {
                    if (data[i].discount_typecode == 3 || data[i].discount_typecode == 7) {
                        var li_class = i == data.length-1?'<li class="divide-line all-line">':'<li class="divide-line">';
                        var btn_str = data[i].discount_typecode == 3?'<button class="discount_icon">优惠</button>':'<button class="gift_icon">礼品</button>';

                        var li_str = li_class+btn_str+'<span>'+data[i].discount_details+'</span></li>';
                        li_arr.push(li_str);
                    }
                    
                }
                return pre_ul+li_arr.join('')+last_ul;
            }
        },
        js_receiveCard: function(ele) {
            if (ele.hasClass('off')) {
                return;
            }
            POI.api.userAction('receiveYuGuoCard');
            var that = this;
            var params = [
                {
                    'cp_source': that.yuGuoDetail.type,
                    'sign': 1
                },
                {
                    'diu': POI.clientDiu,
                    'sign': 1
                }
            ];

            POI.api.aosrequest('receiveYuGuoCard', params, function(data) {
                if (data.code == 1) {
                    var num = POI.yuGuoDetail.formateCardNum(data.data.card_no);
                    var time = POI.yuGuoDetail.formateTime(data.data.create_time);
                    $('#yuguo_info .card_num').html(num);
                    $('#yuguo_info .name').html('高德用户');
                    $('#yuguo_info .time').html(time);
                    ele.addClass('off').removeClass('canTouch');
                    POI.api.userAction('receiveYuGuoCardSuccess');
                } else {
                    POI.api.promptMessage('领取失败！');
                    POI.api.userAction('receiveYuGuoCardFailed');
                }
            });
        }        
    });

})(POI, Zepto);