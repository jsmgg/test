;(function(POI, $) {

'use strict';

$.extend(POI, {
    handleAttr: 'js_handle',
    logPageId : 'dinningQueueOrder', // 用于埋点统计详情页的page

    quickInit: function() {
        this.util.delegate($('#js_poi_page'), this.handleAttr);

        this.urlParam = this.util.getUrlParam();
        $('#phoneNo').text( this.urlParam.phone );

        this.util.setQueueKey(this.urlParam.userid, this.urlParam.poiid);

        // 数字范围为 [1, 50]
        $('#userNum').on('input', function() {
            var val = $(this).val();
            var num = parseInt(val);
            var $btn = $('#getQueueNo');
            if (!val) {
                $('#queueErrorMsg').hide();
                $btn.addClass('disabled');
            }
            else if (!/^[1-9]\d?$/.test(val) || num < 1) {
                showErr('输入有误，请重新输入');
            }
            else if (num > 50) {
                showErr('不能超过50人');
            }
            else {
                $btn.removeClass('disabled');
                $('#queueErrorMsg').hide();
            }

            function showErr(msg) {
                $('#queueErrorMsg').text(msg).show();
                $btn.addClass('disabled');
            }
        }).on('blur', function() {
            $(window).scrollTop( $(window).scrollTop() + 1 );
        }).on('focus', function() {
            var _this = this;
            setTimeout(function() {
                _this.setSelectionRange(0, _this.value.length)
            });
        });
    },
    // 立即取号按钮事件
    js_getQueueNo: function($elem) {
        if ($elem.hasClass('disabled')) {
            return;
        }
        var self = this;

        var peopleNum = $('#userNum').val();
        if (self.hasEmptyTable(peopleNum)) {
            return;
        }

        self.waitingGetNo();
        self.api.aosrequest('dinningQueueSubmit', [
            {sid: this.urlParam.sid, sign: 1},
            {poiid: this.urlParam.poiid},
            {p: peopleNum}
        ], function(res) {
            if (res.code == '1') {
                self.pollGetResult();
                return;
            }

            var errorCodeMessage = {
                0: '商家繁忙，请稍候再试',
                3: '餐厅空位不足，请稍后再试',
                14: '需重新登录',
                148: '餐厅有空位，直接去就餐吧',
                149: '请先取消已有排号'
            };
            self.stopWatiing();
            if (res.code >= 0) {
                self.api.promptMessage(errorCodeMessage[res.code] || errorCodeMessage[0]);
            }
        }, false, true, 'GET');

        self.api.userAction('getNumber');
    },
    // 查看我的排号
    js_viewMyQueueNo: function($elem) {
        if ($elem.hasClass('disabled')) {
            return;
        }
        var back = '';
        if ($elem.parent().attr('id') == 'orderSuccessPage') {
            back = 'jump=1&';
            this.api.userAction('viewMyQueue', 'dinningQueueSuccess');
        }
        else {
            this.api.userAction('viewMyQueue');
        }
        this.util.locationRedirect('queueOrderList.html?' + back + 'poiid=' +
            this.urlParam.poiid + '&userid=' + this.urlParam.userid +
            '&showTitleBar=1');
    },
    /**
     * 当前输入的人数对应的桌型是否需要排号.
     * @param {String|Integer} peopleNum 用户输入的人数
     * @return {Boolean} 不需要排号时返回true
     */
    hasEmptyTable: function(peopleNum) {
        var self = this;
        if (!self.urlParam.waitingQueueInfo) {
            return false;
        }
        peopleNum = parseInt(peopleNum);
        var waitingQueueInfo = JSON.parse(self.urlParam.waitingQueueInfo);
        for (var i = 0, len = waitingQueueInfo.length; i < len; i++) {
            var obj = waitingQueueInfo[i];
            if (obj.wait_table == '0' && obj.people_num) {
                var arr = obj.people_num.match(/\d+/g);
                if ((arr && arr.length == 1 && peopleNum >= arr[0]) ||
                        (arr && arr.length == 2 && peopleNum >= arr[0] && peopleNum <= arr[1])) {
                    self.api.promptMessage('餐厅有空位，直接去就餐吧');
                    return true;
                }
            }
        }
    },
    // 显示正在获取排号结果状态
    waitingGetNo: function() {
        var times = 0;
        var waitingText = '正在取号';
        var $btn = $('#getQueueNo');
        $('#viewMyQueueNo').addClass('disabled');
        $btn.text(waitingText).addClass('disabled');
        $('#userNum').attr('disabled', 'disabled');

        this.waitingInterval = setInterval(function() {
            times += 1;
            var text = waitingText;
            for (var i = 0, len = times % 4; i < len; i++) {
                text += '.';
            }
            $btn.text(text);
        }, 500);

        this.util.storeQueueInfo(true);
    },
    // 停止正在等待状态
    stopWatiing: function(queueInfo) {
        clearInterval(this.waitingInterval);
        $('#viewMyQueueNo').removeClass('disabled');
        $('#getQueueNo').text('立即取号').removeClass('disabled');
        $('#userNum').removeAttr('disabled');
        this.util.storeQueueInfo(false, queueInfo);
    },
    // 轮询排号结果
    _pollisStoped: false,
    pollGetResult: function(delayTime) {
        var poiid = this.urlParam.poiid;
        var self = this;
        delayTime = delayTime || 1000;
        setTimeout(function() {
            self.api.aosrequest('dinningQueueStatus', [{poiid: poiid, sign: 1}], function(res) {
                if (self._pollisStoped) {
                    return;
                }
                if (res.code == 1 && res.waiting == 1) {
                    return;
                }
                self._pollisStoped = true;
                var queueInfo;
                if (res.code == 1 && res.serial_number) {
                    self.queueSuccess(res);
                    queueInfo = res;
                }
                else if (res.code >= 0) {
                    self.api.promptMessage('商家繁忙，请稍候再试');
                }
                self.stopWatiing(queueInfo);
            }, false, false, 'GET');
            if (!self._pollisStoped) {
                self.pollGetResult(delayTime + 750);
            }
        }, delayTime);
    },
    // 显示取号成功页面
    queueSuccess: function(res) {
        var orderInfo = {
            orderPoiName: 'poi_name',
            orderQueueLen: 'queue_size',
            orderNum: 'serial_number',
            orderType: 'type',
            orderTime: 'create_time'
        };
        for (var key in orderInfo) {
            $('#' + key).text( res[orderInfo[key]] == null ? '' : res[orderInfo[key]] );
        }
        $('#orderInputPage').hide();
        $('#orderSuccessPage').show();
        this.api.userAction('pv', 'dinningQueueSuccess');
    }
});

})(POI, $);
