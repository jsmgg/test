/**
 * 公交地铁相关
 */
;(function(POI, $) {
$.extend(POI,{
    cross_page : 1,//途经公交线路页面数 第几页
    cross_pagesize : 5,
    traffic_lines : [],//给报错功能提供线路名称列表
    init:function(){
        this.index.moduleDeepHead();
        //this.index.moduleAll();
        //this.util.executeAfterDomInsert();
        this.showBusCrossLines(0);
    },
    //展现途径线路首末时间等信息
    showBusCrossLines:function(fig){//http://maps.testing.amap.com/ws/mapapi/poi/poibusline
        var self = this, base = self.aosData.base, params;
        if(base.poiid){//公交站如果没有站台信息不显示线路信息
            params = [{poiid : base.poiid, sign :1},
                        {data_type : 'bus'},
                        {ensure_ascii : 'false'},
                        {page : self.cross_page},  
                        {pagesize : self.cross_pagesize} 
                    ];
            self.api.aosrequest({'params':params, progress : fig, showNetErr : fig ,urlPrefix:'trafficCrossLines' ,method:'get'},function(data){
                self.cross_page == 1 && self.reqNearbyStations(base.poiid,base.x,base.y);                
                if(data && data.busline_list){
                    self.show_crossTrafficLines(data);
                }
            });
        }
    },
    show_crossTrafficLines: function(result,total){//显示途经公交站信息
        var self = this, params ={},fig=0,save=false;
        if(result.busline_list.length==0)return;
        self.send({
            action:'userHomeAndCompany'
        },function(data){
            data = data||{};
            if(data.home){
                params.home = data.home;
            }else if(data.homePoi){
                params.homePoi = data.homePoi,fig+=1;
                self.api.aosrequest({
                    method:'GET',
                    poiInfo:'',
                    urlPrefix:'trafficSearch',
                    params:[{"longitude":data.homePoi.lon,"sign":1},{"latitude":data.homePoi.lat,"sign":1},{"range":"1000"},{"pagesize":3}]
                },function(data){
                    if(data.bus_list){
                        params.home={},save=true;
                        data.bus_list.forEach(function(item,i){
                            var lines=(item.businfo_lineids||'').replace(/\|/g,',').replace(/;/g,',').split(',') , name = item.name;
                            lines.forEach(function(line){
                                !params.home[line] && (params.home[line] ={busLineid:line,name:name});
                            });
                        });
                    }
                    fig-=1,(fig===0 && self.show_cross(params,result,save));
                });
            }
            if(data.company){
                params.company = data.company;
            }else if(data.companyPoi){
                params.companyPoi = data.companyPoi,fig+=1;
                self.api.aosrequest({
                    method:'GET',
                    poiInfo:'',
                    urlPrefix:'trafficSearch',
                    params:[{"longitude":data.companyPoi.lon,"sign":1},{"latitude":data.companyPoi.lat,"sign":1},{"range":"1000"},{"pagesize":3}]
                },function(data){
                    if(data.bus_list){
                        params.company={},save=true;
                        data.bus_list.forEach(function(item,i){
                            var lines=(item.businfo_lineids||'').replace(/\|/g,',').replace(/;/g,',').split(',') , name = item.name;
                            lines.forEach(function(line){
                                !params.company[line] && (params.company[line] ={busLineid:line,name:name});
                            });
                        })
                    }
                    fig-=1,(fig===0 && self.show_cross(params,result,save));
                });
            }
            fig===0 && self.show_cross(params,result,save);
        });//获取途经家、公司附近公交线路信息
    },
    /*
        存储家和公司附近公交路线到客户端，同时显示路线列表
        if(type==2 || type==3 || type==10){//地铁
            subArr=subArr.concat(tmpA);
        }else{//公交
            busArr=busArr.concat(tmpA);
        }
        params : Object 家和公司附近公交路线信息
        result.busline_list : Array 途经公交站信息列表
        save ：Boolean 是否需要向客户端保存家和公司附近公交路线
    */
    show_cross : function(params,result,save){
        var self = this, busArr=[], more, handleAttr = self.handleAttr,
            total = Math.ceil(result.total/self.cross_pagesize),
            busline_list = result.busline_list,
            cache = {},home,company, lineids;
        busline_list.forEach(function(item,i){
            busArr.push('<article>');
            busArr.push('<h3><span class="name">'+(item.name||'')+'</span>');
            if( item.base_price ) {
                if( item.total_price ) {
                    busArr.push('<span class="price">票价'+item.base_price + (item.total_price != item.base_price ? '-' + item.total_price : '')+'元</span>');
                } else {
                    busArr.push('<span class="price">起步价' + item.base_price + '元</span>');
                }
            } else if( item.total_price ) {
                busArr.push('<span class="price">总价' + item.total_price + '元</span>');
            }
            item.interval && busArr.push('<span class="time">约'+ self.get_interval( item.interval ) +'一班车</span>');
            busArr.push('</h3>');
            lineids = [];
            (item.lines||[]).forEach(function(line,i){
                lineids.push( line.id );
                busArr.push('<div class="canTouch line half-border'+(i>0?' two" ':'" ' )+ handleAttr+'="js_cross_openbusline" lineid="'+line.id+'">')
                busArr.push('<p>'+(line.front_name||'')+'<i></i>'+(line.terminal_name||''));
                busArr.push('</p>');
                if( line.start_time ){
                    busArr.push('<span class="startTime">');
                    busArr.push((line.start_time||'').substr(0,2)+":"+(line.start_time).substr(2,2)); 
                    busArr.push('</span>');
                }
                if( line.end_time ) {
                    busArr.push('<span class="endTime">');
                    busArr.push((line.end_time||'').substr(0,2)+":"+(line.end_time).substr(2,2)); 
                    busArr.push('</span>');
                }
                busArr.push('</div>');

                home = (params.home && params.home[line.id])?params.home[line.id].name:null;
                company = (params.company && params.company[line.id])?params.company[line.id].name:null;
                
                if(home || company){//控制显示家和公司途经路线
                    busArr.push('<p class="address">');
                    home && busArr.push( '<addr>' + home+'</addr>站点距您家最近'+(company?'；':'。'));
                    company && busArr.push('<addr>' + company+'</addr>站点距您公司最近。');
                    busArr.push('</p>');
                }
            });
            item.name && self.traffic_lines.push( item.name + ',' + lineids.join('|') );// 记录线路名字给报错功能使用
            busArr.push('</article>');
        });
        
        if(busArr.length){
            if(self.cross_page ==1){
                total > 1 && busArr.push('<aside class="more-bottom-blue" '+ handleAttr +'="js_moreBusline" id="js_moreBusline">查看更多</aside>');
                self.pagebody.prepend('<section class="busCrossLines"><h2 class="module_title_p line-half">途经公交线路</h2>'+busArr.join('')+'</section>');
                save && self.send({action:"userHomeAndCompany",params:params});//存储数据到客户端
            }else{
                more = $('#js_moreBusline');
                more.before(busArr.join(''));
                (total <= self.cross_page) && more.hide();
            }
        }
        self.cross_page+=1;
    },
    get_interval : function( interval ){
        var str = '', h , m;
        interval = parseInt( interval, 10);
        h = parseInt(interval / 60);
        m = interval % 60;
        h && (str += h+'小时');
        m && (str += m+'分钟');
        return str;
    },
    js_cross_openbusline : function(obj) {//打开途经公交线路
        var self = this, lineid = obj.attr('lineid'),cityCode = self.clientData.poiInfo.cityCode||'';
        if(!lineid) return;
        self.api.userAction('openBusLine', {lineid: lineid});
        self.api.openBusLine(lineid, cityCode);
    },
    js_moreBusline : function() {
        this.showBusCrossLines(1);
        this.api.userAction('morecrossline');
    },
    reqNearbyStations:function(poiid,x,y){
        var self = this, params=[];
        params.push({longitude:x,sign:1});
        params.push({latitude:y,sign:1});
        params.push({range: 2000});
        params.push({pagesize: 6});
        params.push({pagenum:1});
        params.push({sort_rule:1});
        params.push({category:'150500|150700'});
        //获取附近公交车站，附近公交车站里边根据本站途径线路ID集合(businfo_lineids)获取公交线路信息
        self.api.aosrequest({'params':params,'urlPrefix':'trafficSearch','method':'GET'},function(arg){
            self.outputNearbyTrafficStation(arg,poiid);
        });
    },
    //输出附近公交、地铁站点
    outputNearbyTrafficStation:function(data,poiid){
        if(data && data.bus_list && data.bus_list.length){
            var self = this, busA=[], subwayA=[], handleAttr = self.handleAttr;//是公交站
            $.each(data.bus_list,function(index,item){ 
                if(item.id!=poiid){
                    if(item.name&&item.lines){
                        self.get_near_html(item,busA,subwayA);
                    }
                }
            });
            busA.length>1 && busA.push('<aside class="more-bottom-blue" '+ handleAttr +'="js_near_morebusline">查看更多公交站</aside>');
    
            busA = busA.length>0 ? ( '<section id="nearbyBusStationBus" class="nearbyStations"><h2 class="module_title_p line-half">附近公交站</h2>' + busA.join("") + '</section>') : '';

            subwayA.length>1 && subwayA.push('<aside class="more-bottom-blue" '+ handleAttr +'="js_near_moreSubWayline">查看更多地铁站</aside>');
            subwayA = subwayA.length>0 ? ('<section id="nearbySubwayStationBus" class="nearbyStations"><h2 class="module_title_p line-half">附近地铁站</h2>' + subwayA.join("") + '</section>') : '';
            (busA || subwayA) && self.pagebody.append(busA+subwayA);
        }
    },
    near_cache : {},
    /*
        获取附近公交站、地铁站html
        item : 一条站点信息
        busA : 公交站点html列表
        subwayA : 地图路线html列表
    */
   
    get_near_html : function(item,busA,subwayA){
        var arr=[],tmp,index=0,typeflag = item.typeflag ,
            list = typeflag==2?subwayA:busA,k=0,check={},
            businfo_lineids,cache = this.near_cache, handleAttr = this.handleAttr;      
        arr.push('<article'+(list.length>0?' class="hide"':'')+'><h3 class="canTouch" name="'+item.id+'" typeflag="'+typeflag+'" '+ handleAttr +'="js_bus_opennearpoi">'+item.name+'</h3>'+'<ul>');
        tmp = (item.lines||'').replace(/\|/g,";").split(";");
        businfo_lineids = (item.businfo_lineids||'').replace(/\|/g,";").split(";");
        cache[item.id] = {poiid:item.id,poiname:item.name,address:item.address,citycode:item.areacode,newtype:item.newtype,tel:item.tel,lon:item.x,lat:item.y};//缓存打开公交站图面需要参数
        $.each(tmp,function(i,line){
            if(line && !check[line]){
                if(index%4==0){
                    arr.push('<li>');
                    k=0;
                }
           
                arr.push('<span class="lineDot canTouch " name="'+businfo_lineids[i]+'" citycode="'+item.areacode+'" typeflag="'+typeflag+'" '+ handleAttr +'="js_bus_openline">'+line+'</span>');
                k++;
                if((index+1)%4==0){
                    arr.push('</li>');
                }
                index++,check[line]=true;
            }
        });
        if(k==1){
            arr.push('<span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span><span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span><span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span></li>');
        }else if(k==2){
            arr.push('<span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span><span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span></li>');
        }else if(k==3){
            arr.push('<span class="nearbyStations_empty">&nbsp;&nbsp;&nbsp;</span></li>');

        }
        arr.push('</ul></article>');
        list.push(arr.join(''));
    },
    
    js_near_morebusline : function(obj) {         
        var self = this, fig = obj.hasClass('up'),titleBar=0,
            p = obj.parents('section').eq(0);
        self.api.userAction('moreBusline', {fig: fig ? 'show' : 'hide'});
        obj[fig?'removeClass':'addClass']('up');
        obj.text(fig?'查看更多公交站':'收起');
        if(!fig){
            obj[0]._scroll_top = $(window).scrollTop();
        } else {
            $(window).scrollTop( obj[0]._scroll_top );
        }
        p[fig?'removeClass':'addClass']('showall');
    },
    js_near_moreSubWayline : function( obj ) {
        var self = this, fig = obj.hasClass('up'),titleBar=0;
        self.api.userAction('moreBusline', {fig: fig ? 'show' : 'hide'});
        obj[fig?'removeClass':'addClass']('up');
        obj.text(fig?'查看更多地铁站':'收起');
        obj.parents('section').eq(0)[fig?'removeClass':'addClass']('showall')
        if(!fig){
            $(window).scrollTop(obj.parents('section').eq(0).offset().top);
        }
    },
    js_bus_opennearpoi : function(obj) {//附近公交地铁站名称点击事件
        var self = this, cache = self.near_cache , item = cache[obj.attr('name')],
            typeflag = obj.attr('typeflag');
        self.api.userAction('openPoiInfo', {type: typeflag==2 ? 'subway' : 'bus'});
        if(item){
            if(POI.browser.ios){
                self.api.openPoiInfo(item.poiid,item.poiname,item.address,item.citycode,item.newtype,item.tel,item.lon,item.lat);
            }else{
                self.api.openPoiInfo(item.poiid,'','','','','','','');
            }
        }
    },
    js_bus_openline : function(o) {//点击附近公交、地铁线路
        var self = this, id = o.attr('name'), cityCode = o.attr('citycode'),
            typeflag = o.attr('typeflag');
        self.api.userAction('openLineList', {type : typeflag == 2 ? 'subway' : 'bus'});
        self.api.openBusLine(id, cityCode);
    }
});
})(POI, Zepto);