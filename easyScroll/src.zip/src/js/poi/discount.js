/*
 * 优惠列表页
 */
;(function(POI, $) {

$.extend(POI, {

    // 买点page标识
    logPageId : "exCouponList",

    quickInit: function() {
        var discount = this.util.storage('discount'),
            poiData = this.util.getStorageData();
        if (!poiData || !discount) return;
        discount = JSON.parse(discount);
        if (discount === undefined || !discount.length) {
            return;
        }
        
        discount.sort(function(p, n) {
            var pp = p.discount_priority || 35,
                np = n.discount_priority || 35;
            return (pp - np);
        });
        var totalCount = discount.length,
            pageindex = 0,
            pagesize = totalCount, // 20
            totalPage = Math.floor(totalCount / pagesize),
            endIndex = (pageindex + 1) * pagesize,
            container = $('#container');
        function showData(container) {
            var dis, html = [];
            for (var i = pageindex * pagesize, j = endIndex; i < j; i++) {
                if (i >= totalCount) {
                    break;
                }
                dis = discount[i];
                dis.picUrl = '';
                if (dis.pic_info && dis.pic_info[0]) {
                    dis.picUrl = POI.util.imageUrlTransform(dis.pic_info[0].url , 75 , 70 , 'merge' , 1);
                }
                html.push('<article class="canTouch splitLine flexBox" did="' + (dis.discount_gd_id || '') + '">');
                html.push('<img src="' + (dis.picUrl || '') + '">');
                html.push('<hgroup><h1>' + (dis.discount_title || '') + '</h1>');
                dis.price_dis && dis.price_ori && html.push('<h5><span>' + dis.price_dis + '</span><del>' + dis.price_ori + '</del></h5>');
                html.push('</hgroup></article>');
            }
            container.html(html.join(''));
        }
        showData(container);
        //点击列表项，跳转到优惠详情页
        container.click(function(e) {
            var target = $(e.target).closest('article').eq(0),
                showtitle = window.hasWebPageTitleBar ? "&showTitleBar=1" : "";
            if (target.length && target.attr('did')) {
                POI.util.locationRedirect('exCouponDetail.html?did=' + target.attr('did')+showtitle);
            }
        });
    },
    
    show_discountlist : function( discounts ) {//显示优惠券列表，供其他页面调用
        var self = this,
            showtitle = window.hasWebPageTitleBar ? "&showTitleBar=1" : "",
            params = [{poiid:(self.clientData.poiInfo || {}).poiid || '', sign : 1}];
        if( discounts ){//如果只有一条数据，无需发请求，直接使用首页的一条优惠信息
            self.util.storage('discount', JSON.stringify( discounts ));
            self.util.locationRedirect("exCouponDetail.html?did=" + discounts[0].discount_gd_id+showtitle);
            return ;
        }
        self.api.aosrequest({params: params, poiInfo:'', urlPrefix:'discountList', 'method':'GET', progress:1, showNetErr: true}, function(arg) {
            if (arg.code == -1 || arg.code == -2 || !arg.discount_info || !arg.discount_info.length) {
                return;
            }
            self.util.storage('discount', JSON.stringify(arg.discount_info));
            self.util.locationRedirect("exCouponList.html");
        });
    }
    
});

})(POI, Zepto);