/*小区楼盘*/
;
(function (POI, $) {


    $.extend(POI, {
        
        // 获取小区下的热帖
        getResidentialThreads: function(poiid, city_code, count) {
            // 小区详情页展示UGC模块功能delay，所以注释掉请求数据接口的操作
            //var params = [
            //    {poiid: "" + poiid, sign: 1},
            //    {city_code: "" + city_code},
            //    {count: count | 0 || 2}
            //];
            //POI.api.aosrequest("ugcResidentialThreads", params, POI.showResidentialThreads, false, false, "GET");
            return '<section id="residentialThreads" class="building"></section>';
        },
        showResidentialThreads: function(data) {
            if(!data || "0" != data.code) {
                return;
            }
            var tList = data.data.threads;
            if(!tList.length) {
                return;
            }
            var htmlStr = '';
            for(var i = 0; i < tList.length; i++) {
                htmlStr += '<p ' + this.handleAttr + '="js_residentialThreads" tid="' + tList[i].tid + '" class="building_model more lineDot">' +
                               '<button class="building_icon building_topic">热点</button>' +
                               tList[i].title +
                           '</p>';
            }
            if(htmlStr) {
                htmlStr = '<h2 ' + this.handleAttr + '="js_residentialIndex" class="module_title_p line-half more">社区生活' +
                              '<button class="building_ugc_more">去看看</button>' +
                          '</h2>' +
                          htmlStr;
                $("#residentialThreads").html(htmlStr);
            }
        },
        living_arr: [],
        //展示宜居指数
        showLivable: function( deep ) {
            var that = this;
            var ul_arr = [];
            var trans_str = '';
            var dining_str = '';
            var life_str = '';
            var edu_str = '';
            if (POI.util.bool(deep.index_trans) === true) {
                ul_arr.push('index_trans');
                that.living_arr.push({
                    'score': deep.index_trans.score,
                    'poiid': deep.index_trans.poiid,
                    'name': '出行'
                });
                trans_str = that.makeTransArticle(deep);//生成article
            } 
            if (POI.util.bool(deep.index_dining) === true) {
                ul_arr.push('index_dining');
                that.living_arr.push({
                    'score': deep.index_dining.score,
                    'poiid': deep.index_dining.poiid,
                    'name': '美食'
                });
                dining_str = that.makeDiningArticle(deep);//生成article
            }
            if (POI.util.bool(deep.index_life) === true) {
                ul_arr.push('index_life');
                that.living_arr.push({
                    'score': deep.index_life.score,
                    'poiid': deep.index_life.poiid,
                    'name': '生活'
                });
                life_str = that.makeLifeArticle(deep);//生成article
            }
            if (POI.util.bool(deep.index_edu) === true) {
                ul_arr.push('index_edu');
                that.living_arr.push({
                    'score': deep.index_edu.score,
                    'poiid': deep.index_edu.poiid,
                    'name': '教育'
                });
                edu_str = that.makeEduArticle(deep);//生成article
            }

            if (ul_arr.length < 1) {
                return '';
            }

            var first_section = '<section class="livable" id="building_livable"><h2 class="module_title_p divide-line">宜居指数</h2>';
            
            var last_section = '</section>';
            var ul_str = that.makeLivingUl(ul_arr);
            POI.api.userAction('show_livable');
            return first_section+ul_str+trans_str+dining_str+life_str+edu_str+last_section;
        },
        makeLivingUl: function( arr ) {
            var that = this;
            var ul_arr = [];
            var pre_ul = '<ul class="livable_list divide-line">';
            var last_ul = '</ul>';
            var ratio = window.devicePixelRatio | 2;
            var canvasWidth = 66;
            var canvasHeight = 66;
            for (var i=0; i<arr.length; i++) {
                var class_str = i==0?' class="on"':'';
                var li_str = '<li class="livable_item" rel="#'+arr[i]+'" data-poiid="'+that.living_arr[i].poiid+'">'+
                             '<p'+class_str+'><canvas width="' + canvasWidth + '" height="' + canvasHeight + '"></canvas></p>'+
                             '</li>';
                ul_arr.push(li_str);
            }

            return pre_ul+ul_arr.join('')+last_ul;
        },
        makeTransArticle: function(deep) {
            var that = this;
            var obj = deep.index_trans;
            var time_mapping = {
                '1': '7:00-9:00',
                '2': '17:00-19:00'
            };
            var day_type_mapping = {
                '0': '工作日',
                '1': '周末'
            };
            var road_jam = '严重拥堵';//需要通过road_jam字段判断类型，暂时写死
            var bus_arr = [];
            var subway_arr = [];
            var bus_num = 0;
            try { bus_num = obj.bus.length > 3 ? 3 : obj.bus.length;} catch(e) {};
            var subway_num = 0;
            try { subway_num = obj.subway.length > 3 ? 3 : obj.subway.length;} catch(e) {};

            for (var i=0; i<bus_num; i++) {
                var str = '<button>'+obj.bus[i].name+'</button>';
                bus_arr.push(str);
            }

            for (var i=0; i<subway_num; i++) {
                var str = '<button>'+obj.subway[i].name+'</button>';
                subway_arr.push(str);
            }

            var pre_p = '<article id="index_trans" class="living_cont">';
            var last_p = '</article>';

            var p1 = obj.traffic ? '<p class="traffic divide-line more" data-name="'+obj.traffic.road_name+'">'+
                     '<button class="traffic_btn most">'+road_jam+'</button>'+
                     '<button class="road_name">'+obj.traffic.road_name+'</button>'+
                     '<button class="timespan">'+day_type_mapping[obj.traffic.day_type]+time_mapping[obj.traffic.timespan]+'</button>'+
                     '</p>' : '';

            var p2 = bus_arr.length > 0 ? '<p class="bus divide-line more" data-name="公交站">'+
                     '<button class="num_bus">'+obj.num_bus+'个公交站</button>'+
                     bus_arr.join("")+
                     '</p>':'';

            var p3 = subway_arr.length > 0 ? '<p class="subway divide-line more" data-name="地铁站">'+
                     '<button class="num_subway">'+obj.num_subway+'个地铁站</button>'+
                     subway_arr.join('')+
                     '</p>':'';

            return pre_p+p1+p2+p3+last_p;
        },
        makeDiningArticle: function(deep) {
            var that = this;
            var obj = deep.index_dining.dining_detail;
            if(!obj) {
                return '';
            }
            var chinese_arr = [];
            var western_arr = [];
            var fast_arr = [];
            var chinese_num = '';
            var western_num = '';
            var fast_num = '';
            for (var i=0; i<obj.length; i++) {
                if (obj[i].dining_type === '中餐') {
                    if (chinese_arr.length === 3) {
                        return;
                    }
                    chinese_arr.push('<button>'+obj[i].name+'</button>');
                    chinese_num = obj[i].num;
                } else if (obj[i].dining_type === '西餐') {
                    if (western_arr.length === 3) {
                        return;
                    }
                    western_arr.push('<button>'+obj[i].name+'</button>');
                    western_num = obj[i].num;
                } else if (obj[i].dining_type === '快餐') {
                    if (fast_arr.length === 3) {
                        return;
                    }
                    fast_arr.push('<button>'+obj[i].name+'</button>');
                    fast_num = obj[i].num;
                }
            }

            var pre_p = '<article id="index_dining" class="living_cont hide">';
            var last_p = '</article>';

            var p1 = chinese_arr.length > 0?'<p class="bus divide-line more" data-name="中餐">'+
                     '<button class="num_bus">'+chinese_num+'家中餐厅</button>'+
                     chinese_arr.join('')+
                     '</p>':'';
            
            var p2 = western_arr.length > 0?'<p class="bus divide-line more" data-name="西餐">'+
                     '<button class="num_bus">'+western_num+'家西餐厅</button>'+
                     western_arr.join('')+
                     '</p>':'';

            var p3 = fast_arr.length > 0?'<p class="bus divide-line more" data-name="快餐">'+
                     '<button class="num_bus">'+fast_num+'家快餐厅</button>'+
                     fast_arr.join('')+
                     '</p>':'';

            return pre_p+p1+p2+p3+last_p;
        },
        makeLifeArticle: function(deep) {
            var that = this;
            var obj = deep.index_life.index_life_detail;
            if(!obj) {
                return '';
            }
            var mall_arr = [];
            var supermarket_arr = [];
            var market_arr = [];

            for (var i=0; i<obj.length; i++) {
                if (obj[i].life_type === '购物中心') {
                    if (mall_arr.length === 3) {
                        return;
                    }
                    mall_arr.push('<button>'+obj[i].name+'</button>');
                } else if (obj[i].life_type === '超市') {
                    if (supermarket_arr.length === 3) {
                        return;
                    }
                    supermarket_arr.push('<button>'+obj[i].name+'</button>');
                } else if (obj[i].life_type === '菜市场') {
                    if (market_arr.length === 3) {
                        return;
                    }
                    market_arr.push('<button>'+obj[i].name+'</button>');
                }
            }

            var pre_p = '<article id="index_life" class="living_cont hide">';
            var last_p = '</article>';

            var p1 = mall_arr.length > 0?'<p class="bus divide-line more" data-name="购物">'+
                     '<button class="num_bus">购物商场</button>'+
                     mall_arr.join('')+
                     '</p>':'';
            
            var p2 = supermarket_arr.length > 0?'<p class="bus divide-line more" data-name="超市">'+
                     '<button class="num_bus">超市便利店</button>'+
                     supermarket_arr.join('')+
                     '</p>':'';

            var p3 = market_arr.length > 0?'<p class="bus divide-line more" data-name="菜市场">'+
                     '<button class="num_bus">菜市场</button>'+
                     market_arr.join('')+
                     '</p>':'';

            return pre_p+p1+p2+p3+last_p;

        },
        makeEduArticle: function(deep) {
            var that = this;
            var obj = deep.index_edu.index_edu_detail;
            if(!obj) {
                return '';
            }
            
            var school_arr = [];
            var highschool_arr = [];
            var school_district = [];

            if (POI.util.bool(deep.sch_dis_pri) === true && deep.sch_dis_pri.length > 0) {
                var arr1 = deep.sch_dis_pri.split('|');
                for (var i=0; i<arr1.length; i++) {
                    if (school_district.length === 3) {
                        return;
                    }
                    school_district.push('<button>'+arr1[i]+'</button>');
                }
            }

            if (POI.util.bool(deep.sch_dis_mid) === true && deep.sch_dis_mid.length > 0) {
                var arr2 = deep.sch_dis_mid.split('|');
                for (var i=0; i<arr2.length; i++) {
                    if (school_district.length === 3) {
                        return;
                    }
                    school_district.push('<button>'+arr2[i]+'</button>');
                }
            }

            for (var i=0; i<obj.length; i++) {
                if (obj[i].sch_type === '小学') {
                    if (school_arr.length === 3) {
                        return;
                    }
                    school_arr.push('<button>'+obj[i].name+'</button>');
                } else if (obj[i].sch_type === '中学') {
                    if (highschool_arr.length === 3) {
                        return;
                    }
                    highschool_arr.push('<button>'+obj[i].name+'</button>');
                }
            }

            var pre_p = '<article id="index_edu" class="living_cont hide">';
            var last_p = '</article>';
            //此部分暂时写死，后改为动态，暂时不知道哪些字段代表学区
            var p1 = school_district.length > 0?'<p class="school line-half">'+
                     '<button class="school_btn">学区</button>'+
                     school_district.join('')+
                     '</p>':'';

            var p2 = school_arr.length > 0?'<p class="bus divide-line more"  data-name="小学">'+
                     '<button class="num_bus">小学</button>'+
                     school_arr.join('')+
                     '</p>':'';

            var p3 = highschool_arr.length > 0?'<p class="bus divide-line more"  data-name="中学">'+
                     '<button class="num_bus">中学</button>'+
                     highschool_arr.join('')+
                     '</p>':'';

            return pre_p+p1+p2+p3+last_p;

        },
        chartData: {},
        chartInitType: null,
        //显示折线图
        showResidentialLineChart: function(rti) {
            var that = this;
            var obj = rti.residential ? rti.residential[0] : {};
            var ul_arr = [];
            
            if (POI.util.bool(obj.price_trend) === false) {
                return '';
            }

            if (obj.price_trend['4'] && obj.price_trend['4'].length > 0) {
                if (!that.chargeChartData(obj.price_trend['4'])) {
                    ul_arr.push({
                        'name': '全部户型',
                        'id': '4'
                    });
                    that.makeChartData('4', obj);
                    that.chartInitType = '4';
                }
            }

            if (obj.price_trend['1'] && obj.price_trend['1'].length > 0) {
                if (!that.chargeChartData(obj.price_trend['1'])) {
                    ul_arr.push({
                        'name': '一居室',
                        'id': '1'
                    });
                    that.makeChartData('1', obj);
                    if (that.chartInitType === null) {
                        that.chartInitType = '1';
                    }
                }
            }

            if (obj.price_trend['2'] && obj.price_trend['2'].length > 0) {
                if (!that.chargeChartData(obj.price_trend['2'])) {
                    ul_arr.push({
                        'name': '二居室',
                        'id': '2'
                    });
                    that.makeChartData('2', obj);
                    if (that.chartInitType === null) {
                        that.chartInitType = '2';
                    }
                }
                
            }

            if (obj.price_trend['3'] && obj.price_trend['3'].length > 0) {
                if (!that.chargeChartData(obj.price_trend['3'])) {
                        ul_arr.push({
                        'name': '三居室',
                        'id': '3'
                    });
                    that.makeChartData('3', obj);
                    if (that.chartInitType === null) {
                        that.chartInitType = '3';
                    }
                }               
            }

            if (obj.price_trend['5'] && obj.price_trend['5'].length > 0) {
                if (!that.chargeChartData(obj.price_trend['3'])) {
                    ul_arr.push({
                        'name': '其它户型',
                        'id': '5'
                    });
                    that.makeChartData('5', obj);
                    if (that.chartInitType === null) {
                        that.chartInitType = '5';
                    }
                }               
            }

            if (ul_arr.length < 1) {
                return '';
            }
            POI.api.userAction('show_community');
            var price_str = !obj.price_trend.new_price ? '':'<span class="new_price">'+
                                obj.price_trend.new_price+
                                '<i>元/平</i></span>';
            var first_section = '<section class="community" id="building_price">'+
                                '<h2 class="module_title_p divide-line">小区最新成交价'+price_str+'</h2>';
            var last_section = '</section>';
            var ul_str = that.makeChartUlHtml(ul_arr);

            var chart_str = '<div class="chart">'+
                            '<div class="price_title">'+
                            '<span><i></i>本楼盘房价</span><span><i></i>区域均价</span>'+
                            '</div>'+
                            '<div class="chart_canvas">'+
                            '<canvas id="canvas" height="200" width="580"></canvas>'+
                            '</div>'+
                            '</div>';
            
            return first_section+ul_str+chart_str+last_section;
        },
        chargeChartData: function(arr) {
            var that = this;
            var price_res = false;
            var price_dis = false;

            for (var i=0; i<arr.length; i++) {
                if (arr[i].price_res == 0 || arr[i].price_res == null || arr[i].price_res == 'null') {
                    price_res = true;
                }
                if (arr[i].price_dis == 0 || arr[i].price_dis == null || arr[i].price_dis == 'null') {
                    price_dis = true;
                }
            }
            return price_res && price_dis;
        },
        makeChartUlHtml: function( arr ) {
            var that = this;
            var pre_ul = '<div class="home_style_list divide-line">';
            var last_ul = '</div>';
            var li_arr = [];

            for (var i=0; i<arr.length; i++) {
                var class_str = i==0?' class="on" ':'';
                var li_str = '<p'+class_str+' data-id="'+arr[i].id+'">'+
                             '<span>'+arr[i].name+'</span>'+
                             '</p>';
                li_arr.push(li_str);
            }

            if (li_arr.length === 1) {
                return '';
            }
            return pre_ul+li_arr.join('')+last_ul;

        },
        //生成折线图数据
        makeChartData: function(type, obj) {
            var that = this;
            var arr = obj.price_trend[type].reverse();
            var price_res = false;
            var price_dis = false;
            that.chartData[type] = {};
            that.chartData[type].labels = [];
            that.chartData[type].price_res = [];
            that.chartData[type].price_dis = [];
            
            for (var i=0; i<arr.length; i++) {
                that.chartData[type].labels.push(arr[i].month);
                that.chartData[type].price_res.push(Number((Number(arr[i].price_res)/10000).toFixed(2)));
                that.chartData[type].price_dis.push(Number((Number(arr[i].price_dis)/10000).toFixed(2)));
                if (arr[i].price_res == 0 || arr[i].price_res == null || arr[i].price_res == 'null') {
                    price_res = true;
                } else if (arr[i].price_dis == 0 || arr[i].price_dis == null || arr[i].price_dis == 'null') {
                    price_dis = true;
                }
            }

            if (price_res) {
                that.chartData[type].price_res = [];
            } else if (price_dis) {
                that.chartData[type].price_dis = [];
            }

            var total_arr = that.chartData[type].price_res.concat(that.chartData[type].price_dis);
            var max = Number((total_arr.max() + 0.1).toFixed(1));
            var min = Number((total_arr.min() - 0.1).toFixed(1)) < 0?0:Number((total_arr.min() - 0.1).toFixed(1));
            var step = Number(((max-min)/2).toFixed(1));

            that.chartData[type].start_value  = min;
            that.chartData[type].step = step;

        },
        //画canvas
        drawChart: function( type ) {
            var that = this;
            if (type === null) {
                return;
            }
            var obj = that.chartData[type];
            var data_config = [
                {
                    label: "My First dataset",
                    fillColor : "transparent",
                    strokeColor: '#47b0ff',
                    pointColor : "#fff",
                    pointStrokeColor : "#47b0ff",
                    pointHighlightFill : "#47b0ff",
                    pointHighlightStroke : "#b2dfff",
                    textContent: "成交均价：",
                    data : obj.price_res
                },
                {
                    label: "My Second dataset",
                    fillColor : "transparent",
                    strokeColor: '#25abab',
                    pointColor : "#fff",
                    pointStrokeColor : "#25abab",
                    pointHighlightFill : "#25abab",
                    pointHighlightStroke : "#a8dddd",
                    textContent: "周边均价：",
                    data : obj.price_dis
                }
            ];

            var lineChartData = {
                labels : obj.labels,
                datasets : data_config
            }

            var w = $(window).width();
            var h = Math.floor(w*200/640);
            var ctx = $("#canvas")[0].getContext("2d");
            $("#canvas").width(w).height(h);
            window.myLine = new Chart(ctx).Line(lineChartData, {
                responsive: true,
                scaleShowGridLines: false,
                scaleShowHorizontalLines: false,
                scaleShowVerticalLines: false,
                pointDotRadius : 5,
                pointDotStrokeWidth : 3,
                bezierCurve: false,
                animation: false,
                scaleFontSize: 13,
                scaleLineColor: "#fff",
                scaleLabel: "<%=Number(value).toFixed(1)%>万",
                scaleIntegersOnly: false,
                scaleOverride: true,
                scaleStartValue: obj.start_value,
                scaleStepWidth: obj.step,
                scaleSteps: 2,
                multiTooltipTemplate: "<%= Math.floor(value*10000) %>/平"
                /*tooltipTitleFontSize: 20,
                tooltipFontSize: 28,
                tooltipTitleFontSize: 28,
                tooltipFontStyle: "bold"*/
            });
            that.browser.and && that.canvas_hack();
        },
        canvas_hack : function(){
            window.addEventListener('pageshow',function(){
                if($('#canvas').length==0)return;
                var k = 'js_test'+parseInt(Math.random()*100);
                $('body').append('<div id="'+k+'" style="display:none;"></div>');
                $('#'+k).remove();
                $('#canvas')[0].toDataURL("image/png");
            },false);
            
        },
        //周边搜索
        searchCategory: function(name) {
            var obj = {
                'action': 'searchCategory',
                'category': name,
                'poiInfo': POI.clientData.poiInfo
            };

            POI.send(obj);
        },
        addEventToClick: function() {
            var that = this;

            //点击“宜居指数”出行中的标签
            /*$('#index_trans').on('click', 'span', function() {
                var poiid = $(this).data('poiid');
                var name = $(this).text();

                if (!poiid) {
                    return;
                }

                POI.api.openPoiInfo(poiid, name);

            });*/


            //点击宜居指数中的P
            $('.living_cont p').on('click', function() {
                var name = $(this).data('name');
                
                if (!name) {
                    return;
                }
                POI.api.userAction('livableTypeList', {name:name});
                that.searchCategory(name);
            });

            $('.livable_list').on('click', 'li', function() {
                var li = $(this);

                if (li.length) {
                    li.find('p').addClass('on');
                    li.siblings().find('p').removeClass('on');
                    var rel = li.attr('rel');

                    $(rel).removeClass('hide')
                            .siblings('article').addClass('hide');
                    var poiid = li.data('poiid');
                    POI.api.userAction('livableType', {type_poiid: rel.substr(1)+'_'+poiid});
                }
            });

            //点击小区成交价
            $('.home_style_list p').on('click', function() {
                var li = $(this);
                var type = $(this).data('id');

                if (li.length) {
                    POI.api.userAction('homeType', {type: type});
                    li.addClass('on').siblings().removeClass('on');

                    var w = $("#canvas").width();
                    var h = $("#canvas").height();
                    var ctx = $("#canvas")[0].getContext("2d");
                    ctx.clearRect(0,0,w,h);
                    that.drawChart(type);//重新画折线图
                }
            });

            //点击小区服务的标签
            $('.service_list').on('click', 'p', function() {
                var p = $(this);

                if (p.length) {
                    p.addClass('on');
                    p.siblings().removeClass('on');

                    var rel = p.attr('rel');
                    
                    $(rel).removeClass('hide')
                            .siblings('article').addClass('hide');
                    POI.api.userAction('commServiceType', {type: rel.substr(1)});
                }
            });

            //点击办事指南
            $('#handling_guideline').click(function() {
                var adcode = POI.aosData.base.city_adcode;

                POI.api.userAction('serviceGuide', {adcode: adcode});
                POI.util.locationRedirect('serviceGuide.html?adcode=' + adcode);
            });
        },
        //展示小区要闻
        showCommunityNews: function(deep) {
            if(!(deep && POI.util.bool(deep.is_news))) {
                return '';
            }

            var that = this;

            var params = [
                {'poiid': POI.aosData.base.poiid, 'sign': 1},
                {'x': POI.clientData.poiInfo.lon, 'sign': 1},
                {'y': POI.clientData.poiInfo.lat, 'sign': 1},
                {'adcode': POI.aosData.base.city_adcode, 'sign': 1},
                {'diu': POI.clientDiu},
                {'page_num': 1},
                {'count': 3}
            ];
            

            POI.util.executeAfterDomInsert(function() {
                POI.api.aosrequest('communityNewsList', params, function(data) {
                    POI.headerToolBar.building_news_flag = true;
                    var html;
                    data.threads = data.threads || [];
                    
                    if (data.code == 1 && data.threads.length > 0) {
                        html = that.makeCommNewsListHtml(data);
                        
                        $('#commNewsList').replaceWith(html);
                        POI.api.userAction('communityMainNews');
                        POI.headerToolBar.poiCommunityToolBar({class_name:'building_news', title: '新闻'});
                    }
                });
                

            });

            return '<div id="commNewsList"></div>';
        },
        makeCommNewsListHtml: function(data) {
            var that = this;
            var handleAttr = POI.handleAttr;
            var list = data.threads;
            var li_arr = [];

            var pre_section = '<section class="community_news" id="community_news">'+
                              '<h2 class="module_title_p divide-line more" '+handleAttr+'="js_goToCommNewsList">小区要闻</h2>'+
                              '<ul>';
            var last_section = '</ul></section>';

            for (var i=0; i<list.length; i++) {
                var date = that.formateDate(list[i].repo_time, data.res_data.timestamp).date;
                var time = that.formateDate(list[i].repo_time, data.res_data.timestamp).time;
                var date_html = date.length > 0? '<span class="date">'+date+'</span>': '';
                var li_str = '<li class="divide-line" data-name="'+list[i].title+'" data-id="'+list[i].tid+'" '+handleAttr+'="js_goToCommNewsDetail">'+
                             '<p class="title">'+list[i].title+'</p>'+
                             '<p class="explain">'+list[i].orig+'<span class="date_time">'+
                             date_html+
                             '<span>'+time+'</span></span>'+
                             '</p>'+
                             '</li>';
                li_arr.push(li_str);
            }

            return pre_section+li_arr.join('')+last_section;

        },
        formateDate: function(compaer_time, timestamp) {
            var that = this;

            var date = compaer_time.split(' ')[0];
            var time = compaer_time.split(' ')[1];
            var time_arr = time.split(':');

            var year1 = Number(date.split('-')[0]);
            var month1 = date.split('-')[1];

            if (String(month1).length === 2 && String(month1).charAt(0) === '0') {
                month1 = Number(String(month1).charAt(1)) - 1;
            } else {
                month1 = Number(month1) - 1;
            }
            var date1 = Number(date.split('-')[2]);

            var date_obj = new Date(timestamp*1000);

            var year2 = date_obj.getYear();
            var month2 = date_obj.getMonth();
            var date2 = date_obj.getDate();

            if (year1 === year2 && month1 === month2 && date1 === date2) {
                var true_date = '';
            } else {
                var true_date = (month1+1)+'月'+date1+'日';
            }

            return {
                date: true_date,
                time: time_arr[0]+':'+time_arr[1]
            }
        },
        community_ul: [],
        //展示小区服务
        showCommunityService: function(deep) {
            var guide = POI.util.bool(deep.is_community) ? ' more">小区服务<span id="handling_guideline">办事指南</span>' : '">小区服务';
            var pre_section = '<section class="community_service">'+
                              '<h2 class="module_title_p divide-line'+guide+'</h2>';
            var last_section = '</section>';
            if (POI.util.bool(deep.is_community)) {
                POI.api.userAction('showHandlingGuideline');
            }
            if (!POI.util.bool(deep.comm_info) || deep.comm_info.length < 1) {
                return POI.util.bool(deep.is_community) ? pre_section+last_section : '';
                
            }

            var that = this;
            var list = deep.comm_info;

            var article_arr = [];

            for (var i=0; i<list.length; i++) {
                var article_str;
                if (list[i].comm_type === '派出所') {
                    article_str = that.makeCommunityUlArr(list[i], 'police', '派出所');
                    
                } else if (list[i].comm_type === '街道办') {

                    article_str = that.makeCommunityUlArr(list[i], 'street', '街道办');
                } else if (list[i].comm_type === '居委会') {
                    article_str = that.makeCommunityUlArr(list[i], 'neighborhood', '居委会');

                } else if (list[i].comm_type === '物业') {
                    article_str = that.makeCommunityUlArr(list[i], 'property', '物业');
                } else if (list[i].comm_type === '小学学区') {
                    article_str = that.makeCommunityUlArr(list[i], 'primary', '小学学区');
                } else if (list[i].comm_type === '中学学区') {
                    article_str = that.makeCommunityUlArr(list[i], 'middle', '中学学区');
                }
                article_arr.push(article_str);
            }

            if (that.community_ul.length < 1) {
                return pre_section+last_section;
            }

            var ul_str = that.makeCommServiceUl();
            
            POI.api.userAction('showCommunityService');

            return pre_section+ul_str+article_arr.join('')+last_section;      
        },
        makeCommServiceUl: function() {
            var that = this;

            var ul = that.community_ul;
            var ul_arr = [];
            var pre_ul = '<div class="service_list divide-line">';
            var last_ul = '</div>';

            for (var i=0; i<ul.length; i++) {
                var class_str = i==0?' class="on"':'';
                var p_str = '<p rel="#'+ul[i].id+'"'+class_str+'><span>'+ul[i].name+'</span></p>';
                ul_arr.push(p_str);
            }
            return pre_ul+ul_arr.join('')+last_ul;
        },
        makeCommunityUlArr: function(list, id, name) {
            var that = this;
            var article = '';
            list.name = !list.name?'':list.name;
            list.tel = !list.tel?'':list.tel;
            list.address = !list.address?'':list.address;

            if (list.name.trim().length > 0 || list.tel.trim().length > 0 || list.address.trim().length > 0) {
                
                if (that.community_ul.length == 4) {
                    return;
                }
                that.community_ul.push({
                    id: id,
                    name: name
                });
                var classname = that.community_ul[0].id === id ?'':'hide';
                
                article = that.makeCommunityArticle(list, id, classname);
            }
            return article;
        },
        makeCommunityArticle: function(list, id, classname) {
            var that = this;
            var arr = [];
            var handleAttr = POI.handleAttr;
            var section_arr = [];
            classname = classname === 'hide'? ' class="hide"':'';
            
            var name_arr = list.name.split(';');
            var tel_arr = list.tel.split(';');
            var address_arr = list.address.split(';');
            
            if (list.name.trim().length < 1) {
                var len = list.tel.trim().length > 0?tel_arr:address_arr;
            } else {
                var len = name_arr;
            }
            for (var j=0; j<len.length; j++) {
                var obj = {};
                obj.name = name_arr[j];
                obj.tel = tel_arr[j] === 'null'? '' : tel_arr[j] ;
                obj.address = address_arr[j] === 'null'? '' : address_arr[j];
                arr.push(obj);
            }
            
            var pre_article = '<article id="'+id+'"'+classname+'>';
            var last_article = '</article>';
            
            for (var i=0; i<arr.length; i++) {
                var tel_str = (arr[i].tel && arr[i].tel.length < 1) || !arr[i].tel ?'':'<div class="phone" '+handleAttr+'="js_callTelephone" data-phone="'+arr[i].tel+'">电话<span>'+arr[i].tel+'</span></div>';
                var address_str = (arr[i].address && arr[i].address.length < 1) || !arr[i].address?'':'<div class="address">地址<span>'+arr[i].address+'</span></div>';
                var name_str = (arr[i].name && arr[i].name.length < 1) || !arr[i].name?'':'<div class="name">'+arr[i].name+'</div>';
                if (tel_str == '' && address_str == '' && name_str == '') return;
                var section_str = '<section>'+
                                  name_str+
                                  tel_str+
                                  address_str+
                                  '</section>';
                section_arr.push(section_str);
            }
            
            return pre_article+section_arr.join('')+last_article;
        },
        
        /*---------------------------事件函数------------------------------*/

        js_buildingShowJushiPic : function(ele, e) {
            var itemId = ele.attr("itemid");
            POI.util.getPicData({
                poiid: POI.aosData.base.poiid,
                type: "building",
                itemId: itemId,
                showType: "list"
            });
            POI.api.userAction('bstyle', {
                itemId: itemId
            });
        },
        
        js_residentialThreads: function(ele, e) {
            var tid = ele.attr("tid");
            POI.api.userAction("residentialThreads", {
                pageId_tid: POI.clientData.poiInfo.poiid + "_" + tid
            });
            var url = POI.activityUrl.ugcUrl + "#detailtz/" + tid;
            POI.util.locationRedirect(url);
        },
        
        js_residentialIndex: function(ele, e) {
            POI.api.userAction("residentialThreads", {
                pageId: POI.clientData.poiInfo.poiid
            });
            var url = POI.activityUrl.ugcUrl + "#detailxq/" + POI.clientData.poiInfo.poiid;
            POI.util.locationRedirect(url);
        },
        js_goToCommNewsList: function() {
            var poiid = POI.aosData.base.poiid;
            var name = POI.aosData.base.name;
            var lon = POI.clientData.poiInfo.lon;
            var lat = POI.clientData.poiInfo.lat;
            var adcode = POI.aosData.base.city_adcode;
            var diu = POI.clientDiu;

            POI.util.locationRedirect('community_news_list.html?poiid='+poiid+'&lon='+lon+'&lat='+lat+'&adcode='+adcode+'&diu='+diu+'&name='+name);
            POI.api.userAction('buildingPageCommNews', {poiid: poiid});
        },
        js_goToCommNewsDetail: function(ele, e) {
            var poiid = POI.aosData.base.poiid;
            var id = ele.attr('data-id');
            var name = ele.attr('data-name');

            POI.api.userAction('buildingPageCommNewsList', {poiid_tid_name:poiid+'_'+id+'_'+name});
            //暂时写本地地址，可能改为在线地址,stt为统计参数
            POI.util.locationRedirect('community_news_detail.html?id='+id+'&stt=1');
        },
        js_callTelephone: function(ele) {
            var phone = ele.data('phone');
            var param = [phone];

            POI.api.userAction('buildingPageCallPhone', {number: phone});
            POI.api.showPanellist(param);
        },
        
        
        /*---------------------------事件函数 end------------------------------*/
        
        getIntroHtml : function(deep) {
            var nameAry = ["产权", "建筑面积", "容积率", "绿化率", "停车位", "物业费", "售楼电话"];
            var pNameAry = ["land_year", "area_total", "volume_rate", "green_rate", "service_parking", "property_fee", "400tele_read"];
            var strHtml = '';
            var handleAttr = POI.handleAttr;
            var str = '';            
            for(var i = 0; i < pNameAry.length; i++) {
                if( POI.util.bool(deep[ pNameAry[i]]) ) {
                    if(nameAry[i]=='售楼电话'){
                        //deep[pNameAry[i]] = '4008009999,1234';
                        if (deep[ pNameAry[i]].indexOf('转') != -1 ) {
                            var saleCall = deep[ pNameAry[i]].split("转") ;    
                            strHtml += '<p id="salesCall" '+handleAttr+'="js_callTelephone" data-phone="'+deep[ pNameAry[i]]+'"><span>' + nameAry[i] + '</span><em>' + saleCall[0] + '</em>转'+saleCall[1]+'</p>';                                                   
                            salesCall = saleCall[0];
                        }
                        else if (deep[ pNameAry[i]].indexOf(',') != -1) {
                            var saleCall = deep[ pNameAry[i]].split(",");    
                            strHtml += '<p id="salesCall" '+handleAttr+'="js_callTelephone" data-phone="'+deep[ pNameAry[i]]+'"><span>' + nameAry[i] + '</span><em>' + saleCall[0] + '</em>转'+saleCall[1]+'</p>';                                                   
                            salesCall = saleCall[0];
                        }
                        else{
                            strHtml += '<p id="salesCall" '+handleAttr+'="js_callTelephone" data-phone="'+deep[ pNameAry[i]]+'"><span>' + nameAry[i] + '</span><em>' + deep[ pNameAry[i]] + '</em></p>';                                                   
                            salesCall = deep[ pNameAry[i]]; 
                        } 



                    }else{  
                       strHtml += '<p><span>' + nameAry[i] + '</span>' + deep[ pNameAry[i]] + '</p>';
                    }
                }
            }
            if(strHtml) {
                str = '<section id="baseIntro" class="building canTouch">' +
                          '<h2 class="module_title_p line-half more">小区信息</h2>' +
                          '<div class="residential_info line-half clearfix canTouch">' +
                              strHtml +
                          '</div>' +
                      '</section>';
            }
            return str;   

        },

        updateBuildingPhones : function(deep) {
            var phonesChanged = false;
            var phones = this.index.getBasePhones() || [];
            if (deep['400tele_read']) {
                var tele400 = deep['400tele'] || '';
                if (deep['400tele_read'].indexOf('转') != -1) {
                    tele400 = deep['400tele_read'].replace(/\s*转\s*/, ',');
                }
                phones.unshift({title: '售楼电话(' + deep['400tele_read'] + ')', content: tele400});
                phonesChanged = true;
            }
            
            if(deep['property_tel']) {
                var propertyTelAry = deep['property_tel'].split(';');
                if(propertyTelAry.length) {
                    for(var i = 0, item = null; i < propertyTelAry.length; i++) {
                        item = propertyTelAry[i];
                        phones.unshift({
                            title: '物业电话(' + item + ')',
                            content: item.replace(/\s*转\s*/, ',')
                        });
                    }
                }
                phonesChanged = true;
            }
            if(phonesChanged) {
                this.index.updateBasePhones(phones);
            }
        },
        
        buildingPageList : function(newsStr, serviceStr, liveStr, chartStr, threadsStr, introHtml) {
            var that = this;
            
            var allAry = this.index.moduleAll(['alipayDiscount', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', serviceStr, threadsStr, liveStr, introHtml, 'impression', chartStr, newsStr, 'commentInfo', 'indoorMap', 'banner', 'placeContribution']);
            that.pagebody.html(allAry.join(""));
            POI.util.executeAfterDomInsert();

            [].slice.call(document.querySelectorAll('.livable_list canvas'),0).forEach(function( item , i){
                new POI.util.DrawPie(item , that.living_arr[ i ]);
                that.browser.and && that.circleCanvas_hack(item);
            });

            that.addEventToClick();

            $('#salesCall').on('click',function(e){                
                e.stopPropagation();

                var param = [salesCall];
                POI.api.userAction('buildPageCallPhone', {number: salesCall});
                POI.api.showPanellist(param);
            });

            $('#salesCall')
            .bind('touchstart mousedown', function(e) {
                $('#baseIntro .residential_info').removeClass('canTouch');                
                
            }).bind('touchmove touchend mouseup', function() {
                $('#baseIntro .residential_info').addClass('canTouch');                
            });

            //画折线图
            that.drawChart(that.chartInitType);
        },
        circleCanvas_hack : function(item){
            window.addEventListener('pageshow',function(){
                if($(item).length==0)return;
                var k = 'js_test'+parseInt(Math.random()*100);
                $('body').append('<div id="'+k+'" style="display:none;"></div>');
                $('#'+k).remove();
                $(item)[0].toDataURL("image/png");
            },false);
            
        },
        init : function () {

            var deep = this.aosData.deep[0];
            var rti = this.aosData.rti;
            
            var tags = '';
            var arr = [];
            if (POI.aosData.base.std_v_tag_0_v) {
                arr = POI.aosData.base.std_v_tag_0_v.split(';');
                for (var i=0; i<arr.length; i++) {
                  tags += POI.index.moduleHeadItem(arr[i]);
                }
            }
            if (POI.aosData.base.std_t_tag_0_v) {
                arr = POI.aosData.base.std_t_tag_0_v.split(';');
                for (var i=0; i<arr.length; i++) {
                  tags += POI.index.moduleHeadItem(arr[i]);
                }
            }
            this.index.moduleDeepHead(tags);
            
            this.updateBuildingPhones(deep);
            
            var base = this.aosData.base;
            
            var introHtml = this.getIntroHtml(deep);
            if(!introHtml) {
                introHtml = this.index.moduleIntro(["小区图片", "小区详情", "楼盘详情"], ["opening_data", "checkin_data", "sales_addr", "renovation", "building_types", "developer", "property_company", "property_fee", "area_total", "floor_area", "land_year", "volume_rate", "service_parking", "heating", "watersupply_syst", "sales_lice", "peripheral_supp"]);
            }

//deep.is_community = 1;
//deep.is_news = 1;
//deep.comm_info = [{"tel":"010-84711791","comm_type":"物业","community":"大西洋新城社区","address":"广顺北大街33号大西洋新城"},{"comm_type":"派出所","tel":"010-64703003","name":"南湖派出所","community":"大西洋新城社区","address":"朝阳区南湖中园238楼"},{"comm_type":"街道办","tel":"010-64703102","name":"望京街道办事处","community":"大西洋新城社区","address":"北京市朝阳区望京东园615楼"},{"tel":"64720193","comm_type":"居委会","community":"大西洋新城社区","address":"朝阳区南湖南路10号院529楼四层"}];

            this.buildingPageList(
                this.showCommunityNews(deep),
                this.showCommunityService(deep),
                this.showLivable(deep),
                this.showResidentialLineChart(rti),
                this.getResidentialThreads(base.poiid, base.city_adcode, 2),
                introHtml
            );
        }

    });

    Array.prototype.max = function(){ 
        return Math.max.apply({},this)
    }

    Array.prototype.min = function(){ 
        return Math.min.apply({},this)
    }

})(POI, Zepto);