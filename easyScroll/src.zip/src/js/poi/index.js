/*
    poi详情页
*/
;(function(POI, $) {

'use strict';
var index_cache = {};
$.extend(POI, {
    logPageId : 'index',//用于埋点统计详情页的page
    clientData : null,
    aosData : null,
    clientDiu: '',//客户单diu
    pagebody : null,
    business: '',
    basePhones: null, // Array 用于详情页面电话点击的事件
    poiRanking: null,
    handleAttr : 'js_handle',//事件委托属性
    /**
     * 行业对应js文件
     */
    jsMap: {
        "hotel"         : "js/poi/hotel/hotel.js",                         // 酒店
        "park"          : "js/poi/park.js",                          // 停车场
        "dining"        : "js/poi/dinning.js",                       // 餐饮美食
        "gasstation"    : "js/poi/gasstation.js",                    // 加油站
        "car"           : "js/poi/car.js",                           // 汽车4s店
        "cinema"        : "js/poi/movie.js",                         // 电影
        "bus"           : "js/poi/bus.js",                       // 公交
        "subway"        : "js/poi/subway.js",                       // 地铁
        "golf"          : "js/poi/golf.js",                          // 高尔夫
        "business_hall" : "js/poi/businessHall.js",                  // 联通
        "residential"   : "js/poi/building.js",                      // 小区楼盘
        "traffic"       : "js/poi/train.js",                         // 火车站
        "airport"       : "js/poi/airport.js",                       // 飞机场
        "bank"          : "js/poi/bank.js",                          // 银行
        "atm"           : "js/poi/bank.js",                          // ATM自动取款机
        "theater"       : "js/poi/theater.js",                      // 场馆
        "shopping"      : 1,                                        // 购物,目前没有shopping.js
        "event"         : "js/poi/event.js",                          // 事件
        "scenic"        : "js/poi/travel/travel.js",                   // 景区
        "hospital"      : "js/poi/hospital.js",                          //医院
        "charging"      : "js/poi/charging.js",                            //充电桩
        "kindergarten"  : "js/poi/kindergarten.js",                      // 幼儿园
        "education"     : "js/poi/education.js",                       //大学
        "company"       : "js/poi/company.js",                         //公司，企业
        "internet_bar"  : "js/poi/netTag.js",                          //网吧
        "enjoy"         : 1,                                          //休闲娱乐
        "building"      : 1,                                          //办公、写字楼
        // 商圈详情页，没有指定的business，依靠spec.mining_shape.type == 2判定为商圈
        "other_trade_area"    : "js/poi/tradeArea.js"
    },
    
    quickInit : function() {
        var self = this;
        if(self.browser.and){
            self.send({"action":"getExtraUrl"}, self.getExtraUrl);
            self.send({"action":"getPoiInfo"});
        }
        self.pagebody = $('#js_pagebody');
        self.util.delegate($('#js_poi_page'), self.handleAttr);
    },
    // 我的位置回调
    setMyLocation: function(res) {
        this.onlyClientData(res, 1);
    },
    // 长按地图选点回调
    setMapPoint: function(res) {
        this.onlyClientData(res, 2);
        POI.util.easterEgg(res.poiInfo);
    },
    /**
     * 显示客户端返回的信息.
     * @param {Object} res 客户端返回的信息
     * @param {Integer} pointType 1 - 我的位置， 2 - 长按选点
     * @return {Boolean} 已处理过一次返回false
     */
    onlyClientData: function(res, pointType) {
        var self = this;
        if (self.clientData) {
            return false;
        }
        self.clientData = res;
        self.send({"action":"getFavoriteMark"}, self.setFavoriteMark);

        /* grunt unpack start */
        window.debugInfo && debugInfo('clientData', res);
        /* grunt unpack end */

        self.fromIndoorMap = res.indoor == '1';
        self.util.storage('clientData', JSON.stringify(res));

        var poiInfo = res.poiInfo;
        
        if (pointType || !poiInfo.poiid) {
            self.index.moduleHeadHtml('', '', pointType === 1);
        }
        if (pointType) {
            self.pagebody.after(self.index.moduleAddPoint());
        }
        self.index.moduleEvent();

        var logParam = {
            poiid: poiInfo.poiid,
            lat: poiInfo.lat || '',
            lon: poiInfo.lon || '',
            new_type: poiInfo.new_type
        };
        if (poiInfo.industry) {
            logParam.business = poiInfo.industry;
        }
        if (res.isHourlyRoom == '1') {
            logParam.hourlyRoom = 1;
        }
        self.api.addLogParam(logParam);
        self.api.userAction('initPage', {type: pointType | 0});

        return true;
    },
    setPoiInfo : function(arg) {//showClientData
        if (this.onlyClientData(arg) === false) {
            return;
        }

        var self = this, poiInfo = arg.poiInfo;
        self.business = poiInfo.industry;
        // 根据行业类型预加载行业js
        if ("string" == typeof(this.jsMap[self.business])) {
            self.util.loadResources(self.jsMap[self.business]);
        }
        
        if (!poiInfo.poiid) {
            self.pagebody.after(this.index.moduleAddPoint());
            return;
        }
        POI.loadingTimeout = setTimeout(function() {
            self.api.promptMessage("正在加载", 1);
        }, 400);
        self.api.getMapLocation(function(position) {
            self.myLocation = position;

            self.api.getTransparentParams(function(tdata) {
                var params = [
                    {poiid: poiInfo.poiid, sign: 1},
                    {user_loc: position.lon + ',' + position.lat},
                    {mode: 511},
                    {deepcount: 1},
                    {src: arg.source}
                ];
                if(self.clientData && self.clientData.poiInfo && self.clientData.poiInfo.new_type) {
                    params.push({typecode: self.clientData.poiInfo.new_type});
                }
                if(tdata.transparent) {
                    params.push({transparent: tdata.transparent});
                }
                // 景区热力图入口展示需要上传用户网络状态，android端每次请求都会带上client_network_class参数，所以这里只有ios端的增加参数的逻辑
                if(self.browser.ios) {
                    params.push({client_network_class: arg.client_network_class | 0});
                }
                self.api.aosrequest('baseUrl', params, function(res) {
                    clearTimeout(POI.loadingTimeout);
                    self.api.promptMessage("正在加载", -1);
                    self.showAOSData(res);
                }, false, true, 'GET');
            });
        });

    },
    // 日期控件主动回调
    freshRoomData: function(obj) {
        if (POI.bookRoom) {
            POI.bookRoom.updateDateRoom(obj);
        }
    },
    updateClientData : function(aosBase) {
        var _map = {
            "new_type" : "new_type",
            "address" : "address",
            "name" : "name",
            "cityCode" : "city_adcode",
            "lon" : "x",
            "lat" : "y",
            "x" : "pixelx",
            "y" : "pixely"
        };
        var clientPoiInfo = this.clientData.poiInfo;
        for(var p in _map) {
            if(_map.hasOwnProperty(p) && !clientPoiInfo[p]) {
                clientPoiInfo[p] = aosBase[ _map[p] ] || "";
            }
        }
        this.util.storage('clientData', JSON.stringify(this.clientData));
    },
    showAOSData : function(res) {
        var self = this;
        if (res.code != 1 || !res.poiinfo) {
            self.index.moduleHeadHtml('', '');
            return;
        }
        // 将不存在的属性改为空对象
        var poiInfo = res.poiinfo || {};
        if (!poiInfo.deep) {
            poiInfo.deep = [{}];
        } else if (!poiInfo.deep[0]) {
            poiInfo.deep[0] = {};
        }
        var attrList = ['base', 'idDictionaries', 'pic', 'rti', 'spec', 'src_info', 'tag'];
        for (var i = 0, len = attrList.length; i < len; i++) {
            if (!poiInfo[attrList[i]]) {
                poiInfo[ attrList[i] ] = {};
            }
        }
        self.updateClientData(poiInfo.base);
        
        self.aosData = poiInfo;

        var deep = poiInfo.deep[0];
        var business = deep.business && "other" != deep.business ? deep.business : (res.poiinfo.base || {}).business;
        self.business = business;
        self.api.addLogParam({business: business, new_type: poiInfo.base.new_type});
        var general_flag = self.clientData.general_flag;
        if(undefined === general_flag) {
            general_flag = -1;
        }
        self.api.userAction('initAosPage', {generalflag: general_flag});
        self.util.storage('aosData', JSON.stringify(self.aosData));//二级页会用到【eg:高尔夫二级页】
        if( "string" == typeof(this.jsMap[self.business]) ) {
            self.util.loadResources(self.jsMap[business], function() {
                self.init && self.init();              
            });
        } else {
            
            if(self.aosData && 
               self.aosData.spec && 
               self.aosData.spec.mining_shape && 
               2 == self.aosData.spec.mining_shape.type) {
                self.util.loadResources(self.jsMap["other_trade_area"], function() {
                    self.init && self.init();
                });
            } else {
                var introInfo = {
                    shopping : [['商场图片', '', '营业时间'], ['opentime2']],
                    hospital : [['医院图片', '医院介绍']],
                    other    : [['图片介绍', '详情']]
                };
                var introParam = introInfo[business] || introInfo.other;
                var info = self.index.moduleIntro.apply(self.index, introParam);
                self.index.moduleDeepHead();
                self.index.moduleAll(null, info);
                self.util.executeAfterDomInsert();
            }
        }
        
    },
    setFavoriteMark : function(arg) {
        var status = arg.status;
        if (status) {
            var tmp = $('#favorite');
            if (tmp.length && !tmp[0].end && this.favoriteStatus === undefined) {
                tmp.addClass('favorited');
            }
            tmp[0] && (tmp[0].end =1);
        }
        this.favoriteStatus=== undefined && (this.favoriteStatus = status);
    },
    
    //js_showPhonelist : function(obj) {
    //    var phones = obj.attr('phones');
    //    if(phones) {
    //        this.api.showPanellist( JSON.parse( phones ), POI.clientData.poiInfo );
    //    }
    //},
    // 头部去这里点击
    js_goHere: function() {
        this.api.searchRoute(null, this.clientData.poiInfo);
        this.api.userAction('gohere');
    },
		js_switchSaleTicket: function($ele) {
			var self = this
            if( $ele.hasClass('active') ) return;
			$ele.addClass('active').siblings().removeClass('active')
			$('#travel .scenic-group').hide();
            $('#js_scenicTicket_box').show();
            $('#testViewMore').css('display',$('#testViewMore').attr('data-display'));
			//$('#ticketBooking>*:not(.scenic-card-title)').add($('#testViewMore')).show();
            self.api.userAction( 'switchSaleTicket' );
		},
		js_switchGroup: function($ele) {
			var self = this
			$ele.addClass('active').siblings().removeClass('active');
			$('#travel .scenic-group').show();
            $('#js_scenicTicket_box').hide();
            $('#testViewMore').attr('data-display',$('#testViewMore').css('display')).hide()
			//$('#ticketBooking>*:not(.scenic-card-title)').add($('#testViewMore')).hide()
            self.api.userAction( 'switchGroup' );
		},
		js_triggerGroup: function() {
		
		},
    // 酒店周边酒店打开poi
    js_openAroundHotel: function(elem) {
        var index = elem.attr('data-index');
        var obj = this.bookRoom.aroundHotelList[index];
        var poiInfo = {
            poiid        : obj.id || '',
            name         : obj.name || '',
            address      : obj.address || '',
            cityCode     : obj.citycode || '',
            poiType      : obj.poitype || 1,
            new_type     : obj.newtype || '',
            phoneNumbers : obj.tel || '',
            lon          : obj.longitude,
            lat          : obj.latitude
        };
        this.api.openPoi(poiInfo, 1, 'hotel');
        this.api.userAction('NB_room', {index: index});
    },
    //打开top10排行榜
    js_openPoiRankList: function(ele) {
        var id = ele.attr('data-id');
        var x = this.myLocation.lon;
        var y = this.myLocation.lat;
        var rankParam = this.poiRanking == null ?{business:this.business}:{business_ranking:this.business+'_'+this.poiRanking};
        this.api.userAction('showPoiRankPage',rankParam);
        //POI.util.locationRedirect("poiRank.html?id="+id+"&x="+x+"&y="+y);
        this.util.loadResources(['css/poiRank.css','js/poi/poiRank.js'],function(){
            POI.poiRank && POI.poiRank.show(id,x,y);
        });
    },
    js_showBgcPage : function() {
        POI.api.userAction('showBgcDetailPage');
        POI.util.locationRedirect("bgcDetail.html?title=" + (POI.aosData.base.brand_title || ""));
    },
    js_showCompanyApprovePage: function() {
        POI.api.userAction('showCompanyApprovePage');
        POI.util.locationRedirect("company_approve.html?id="+POI.clientData.poiInfo.poiid+"&source="+POI.clientData.source+'&name='+POI.aosData.base.name);
    },
    js_openInfoUrl: function($ele) {
        var appurl = POI.aosData.deep[0].info_appurl;

		if (appurl) {
            // info_appurl 下面还有其它CP的数据，判断来源是以这个 http://www.baike.com/gwiki 域名开头才跳转
            if (POI.browser.ios && appurl.ios_appurl && appurl.ios_appurl.indexOf('http://www.baike.com/gwiki') == 0) {
                this.api.userAction('gotobaike');
                this.api.getAppPara('', '', appurl.ios_appurl);
            } else if (POI.browser.and && appurl.android_appurl && appurl.android_appurl.indexOf('http://www.baike.com/gwiki') == 0) {
                this.api.userAction('gotobaike');
                this.api.getAppPara('', '', appurl.android_appurl);
            }
        }
    },
    // 幼儿园打开第三方网站
    js_open3rdWepurl: function() {
        POI.api.userAction('open_wap');
        this.api.openThirdUrl( this.aosData.deep[0].info_wapurl );
    },

    getExtraUrl : function(arg) {
        this.send({'action':'xxEncode','text': '&div='+arg.div+'&dic='+arg.dic+'&dip='+arg.dip+'&diu='+arg.diu+'&cifa='+arg.cifa}, function(dt) {
            var result = "string" === typeof(dt.result) ? JSON.parse(dt.result) : dt.result;
            this.api.extraUrl = '&in=' + encodeURIComponent(result['in']) + '&ent=' + result.ent;
        });
        POI.clientDiu = arg.diu;//存储客户端diu
    },
    index : {
        moduleEvent: function() {
            var $root = $('#js_poi_page');
            // 地址栏点击回主图
            $root.on('click', '#address', function() {
                var self = POI;
                var param = {
                    poiInfo: self.clientData.poiInfo,
                    status: '3'
                };
                var indoorInfo = null;
                try {
                    indoorInfo = self.aosData.spec.sndt;
                } catch(e) {
                    indoorInfo = {};
                }
                if (indoorInfo && indoorInfo.fl_info && indoorInfo.fl_info[0] &&
                        indoorInfo.fl_info[0].fl_no) {
                    param.floor = indoorInfo.fl_info[0].fl_no;
                    if (self.clientData.showIndoorMap) {
                        param.showIndoorMap = true;
                    }
                }
                self.api.openPoi(param);
                self.api.userAction('address');
            });
            // 打电话，酒店、小区楼盘有特殊的400电话需求时，自行修改 #basePhone 的text
            // 事件需要修改POI.basePhones
            $root.on('click', '#basePhones', function() {
                var self = POI;
                self.api.showPanellist(self.basePhones, self.clientData.poiInfo);
                self.api.userAction('phone-number');
            });
            // 介绍事件
            $root.on('click', '#baseIntro', function() {
                var self = POI;
                self.api.aosrequest('deepUrl', [
                    {poiid: self.clientData.poiInfo.poiid, sign: 1},
                    {mode: 2},
                    {deepcount: 1},
                    {src: self.clientData.source}
                ], function(res) {
                    if (res.code != 1 || !res.poiinfo) {
                        return;
                    }
                    var poiInfo = res.poiinfo || {};
                    if (!poiInfo.deep) {
                        poiInfo.deep = [{}];
                    } else if (!poiInfo.deep[0]) {
                        poiInfo.deep[0] = {};
                    }

                    self.aosData.deep = poiInfo.deep;
                    self.util.storage('aosData', JSON.stringify(self.aosData));
                    POI.util.locationRedirect('indexDetail.html?business=' + self.business);
                }, 1, true, 'GET');
                self.api.userAction('intro', {business: self.business});
            });
            // 室内地图点击事件
            $root.on('click', '#indoorMap', function() {
                var self = POI;
                var data = [{cpid: self.aosData.idDictionaries.sndt_id, source: 'amap'}];
                self.send({action: 'openIndoorMap', indoorMapArray: data});
                self.api.userAction('indoorView');
            });
            // 报错与建议按钮点击
            $root.on('click', '#reportError', function() {
                var self = POI,
                    poiInfo = null;
                if(self.aosData && self.aosData.base.poiid) {
                	poiInfo = self.aosData.base;
                	poiInfo.lon = poiInfo.x;
                	poiInfo.lat = poiInfo.y;
                } else {
                	poiInfo = self.clientData.poiInfo;
                }
                poiInfo.telephone = poiInfo.telephone || poiInfo.phoneNumbers || "";
                var newType = poiInfo.new_type.split("|")[0];
                if("subway" === self.business || "bus" === self.business || "150700" === newType || "150500" === newType || "151200" === newType || "151300" === newType) {
                    poiInfo.lines = self.clientData.poiInfo.address;
                }
                if(self.traffic_lines && self.traffic_lines.length) {
                    poiInfo.lines = self.traffic_lines.join(";");
                }
                if(self.aosData && self.aosData.spec && self.aosData.spec.mining_shape) {
                    poiInfo.shape = self.aosData.spec.mining_shape.shape;
                }
                self.send({action: 'errorReport', detail: poiInfo});
                self.api.userAction('reportError');
            });
            // 新增地点按钮点击
            $root.on('click', '#addPoint', function() {
                var self = POI;
                self.send({action: 'addNewPoint', poiInfo: self.clientData.poiInfo});
                self.api.userAction('addNewPoint');
            });
            // 景区可展开opentime2样式按钮点击
            $root.on('click', '#scenicOpenTime2', function() {
                var self = POI;
                var $specialTime = $("#specialTime");
                var $timeSwidth = $("#timeSwidth");
                var act;
                if($timeSwidth.hasClass("unfold")) {
                    $specialTime.removeClass('unfold');
                    $timeSwidth.html("展开").removeClass('unfold');
                    act = 'close';
                } else {
                    $specialTime.addClass("unfold");
                    $timeSwidth.html("收起").addClass('unfold');
                    act = 'open';
                }
                self.api.userAction('scenicOpenTime2Swidth', {act: act});
            });
            $root.on('click','.poiHeadComment', function(){
                var obj = $(this);
                var pobj = $('.poiHeadComment p');
                var act;
                if( pobj.hasClass('hide') ){
                    pobj.removeClass('hide');
                    act = 'open';
                } else {
                    pobj.addClass('hide');
                    act = 'close';
                }
                POI.api.userAction('poiHeadComment', {act: act});
            });
        },
        /**
         * 获取poi详情通用模块的html代码.
         * @param {Array.<String>} moduleList 模块名称列表
         *    如果模块名称合法，则将元素替换为对应模块的html代码
         * @param {String} intro 介绍信息html
         * @return {Array.<String>} 对应moduleList顺序的模块html数组
         */
        moduleAll: function(moduleList, intro) {
            // 在方法内使用了this的，需要像indoorMap方式调用
            var self = POI;
            var module = {
                // 团购、酒店、电影、门票
                rti          : this.moduleRti,
                // 停车攻略
                stopStrategy : self.stop.stopStrategy,
                // 评论
                commentInfo  : function() {
                    return self.comment.getIndexComment();
                },
                // 购物导览和楼层导览
                shoppingGuide: self.spGuide.getHtml,
                // 导览图
                guidePicList : function() {
                    return self.guidePicList.get_html();
                },
                // 室内地图
                indoorMap    : function() {
                    return self.index.moduleIndoorMap();
                },
                banner       : function() {return '';},
                // 用户印象
                impression   : self.impression.showImpression,
                //支付宝优惠模块
                alipayDiscount: function() {
                    return self.alipayDiscount.get_html();
                },
                //菜鸟驿站模块
                birdStation: function() {
                    return self.birdStation.get_html();
                },
                //NBA热搜词模块
                nbaHotSearch: function() {
                    return self.nbaHotSearch.get_html();
                },
                //发表评论模块
                sendComment  : function(){
                    return '';//self.sendComment.get_html();
                },
                //活动、会议模块
                activityInfo : function() {
                    return self.activityInfo.activityHtml();
                },
                // 地点贡献
                placeContribution : function() {
                    return self.placeContribution.get_html();
                }
            };
            
            var list = moduleList || ['nbaHotSearch', 'alipayDiscount','birdStation',  'sendComment', 'rti', 'stopStrategy', 'shoppingGuide', 'guidePicList', 'activityInfo', intro, 'impression', 'commentInfo',  'indoorMap', 'placeContribution'];
            
            var commentPos = 0;
            for (var n = list.length; commentPos < n; commentPos++) {
                if (list[commentPos] === 'commentInfo') {
                    break;
                }
            }

            for (var i = 0, n = list.length; i < n; i++) {
                list[i] = module[ list[i] ] ? module[ list[i] ]() : list[i];
            }

            if (!moduleList) {
                self.pagebody.html(list.join(''));
                self.util.executeAfterDomInsert();
            }
            return list;
        },
        // 动态模块排序后的html代码
        moduleRti: function() {
            var self = POI,
                rti = self.aosData.rti,
                rtiHtml = {};
            //团购 优惠 券
            rtiHtml.group = self.business == 'dining' ? self.dinningGroupopen() : self.fSerializeGroupData();
            if (rti.isHaveHotel == 'true') {
                rtiHtml.hotel = self.bookRoom.initPage();
                self.util.executeAfterDomInsert(function() {
                    self.bookRoom.initEvents();
                });
            }


            var moduleOrder = {
                hotel  : ['hotel', 'group', 'travel', 'movie'],
                cinema : ['movie', 'group', 'travel', 'hotel'],
                scenic : ['travel', 'group', 'hotel', 'movie'],
                other  : ['group', 'hotel', 'movie', 'travel']
            };

            if (rti.scenic_ticket_flag && rti.scenic_ticket_flag.length || rti.scenic_guide) {
							rtiHtml.travel = self.travelItem.fSerializeTravelData();

							if (rtiHtml.group && rtiHtml.travel) {
								var $travel = $(rtiHtml.travel).addClass('scenic-ticketAndGroup')
								$travel.find('.scenicTicket_title').replaceWith("<h2 class='scenic-card-title flexbox line-half'>\
									<div class='flexbox-child scenic-travelslink active' js_handle='js_switchSaleTicket'>订门票</div>\
									<div class='flexbox-child scenic-travelslink' js_handle='js_switchGroup' id='js_switchGroup_nav'>团购</div>\
								</h2>")
								var $group = $(rtiHtml.group).find('.sale_wrapper').add($(rtiHtml.group).find('.scenic-group-more')).appendTo('<div class="scenic-group"></div>').parents('.scenic-group').hide()

								$travel.find('.scenicTicket_switch').before($group)
								rtiHtml.travel = $travel.attr('outerHTML')

								// 订票和团购一块显示
								moduleOrder.scenic.splice(1, 1)
							}

            }
            
            if (rti.movies && rti.movies.length) {
                rtiHtml.movie = self.movie.showMovie();
            }

            var moduleHtml = '';
            var moduleList = moduleOrder[self.business] || moduleOrder.other;
            for (var i = 0, len = moduleList.length; i < len; i++) {
                moduleHtml += rtiHtml[ moduleList[i] ] || '';
            }

            var spec = self.aosData.spec;
            if (spec.alio2o_api && spec.alio2o_api.tbshop_api &&
                    spec.alio2o_api.tbshop_api.shopid) {
                moduleHtml += self.taobao.moduleInit(spec.alio2o_api.tbshop_api);
            }

            return moduleHtml;
        },
        /**
         * 拼接带有深度信息的头部.
         * @param {String} other 其它特殊信息
         *    文本信息需要使用moduleHeadItem方法格式化
         *    酒店：星级、设施
         *    餐饮：classify
         *    停车场：类型、是否收费
         *    小区：区域
         *    景点：4A
         *    加油站：图标
         *    电影 classify
         * @param {String} price 价格信息
         *    餐饮、电影、高尔夫显示“人均:￥”
         *    酒店显示“￥起”
         *    小区显示“参考价:/平方米”
         *    景点显示“门票:￥”
         *    除门票价格需特殊处理外其它均为deep[0].price
         */
        moduleDeepHead: function(other, price) {
            var self = POI,
                deep = self.aosData.deep[0];
            var line2 = '';
            var line3 = '';

            // 银行和ATM不显示评分
            if (self.business !== 'atm' && self.business !== 'bank' && deep.src_star > 0) {
                line2 += self.util.stars(deep.src_star);
            }

            if (price) {
                line2 += '<span class="ticket">' + price + '</span>';
            }
            if (line2) {
                line2 = '<p class="second_info">' + line2 + '</p>';
            }
             
            // 增加其他信息和距离
            if (self.aosData.base.tag_poi_use === '公交卡充值') {
                other = (other || "") +self.index.moduleHeadItem('公交充值点');
            }
            
            if(self.aosData.base.tag_yt_tag) {
                other = (other || "") + self.index.moduleHeadItem(self.aosData.base.tag_yt_tag);
            }
            if (other) {
                line3 += other;
            }

            var distance = self.aosData.base.distance || 0;
            if(distance > 0 && distance < 100000) {
                var etype  = distance > 3000 ? 'bus' : 'foot';
                var params = [
                    {start_x     : self.myLocation.lon, sign: 1},
                    {start_y     : self.myLocation.lat, sign: 1},
                    // {start_poi   : '', sign: 1},
                    {end_x       : self.aosData.base.x, sign: 1},
                    {end_y       : self.aosData.base.y, sign: 1},
                    {end_poi     : self.aosData.base.poiid || '', sign: 1},
                    {start_adcode: self.myLocation.adcode},
                    {end_adcode  : self.aosData.base.city_adcode}
                ];
                if(self.business === 'dining'){
                    etype  = distance > 1000 ? 'bus' : 'foot';//张强说的小于1km就去步行的
                    etype=== 'bus' && params.push({taxi_price_flag:1});
                    etype!=='bus' && params.push({etype: etype});//美食行业要显示时间，要么显示驾车时间，要么显示步行时间
                } else {
                    params.push({etype: etype});
                }
                 
                 //etarequest || http://100.69.198.235:8086/ws/mapapi/navigation/auto/etarequest/
                var key = 'etarequest'+JSON.stringify( params );
                if( index_cache[key] ) {
                    setTimeout(function(){
                        eta_cb( index_cache[key] );
                    },0);
                } else {
                    self.api.aosrequest('etarequest', params, eta_cb, false, 1, 'GET');
                }
                
                if (distance) {
                    line3 += '<span id="distance" class="distance"></span>';
                }
            }

            
            if (line3) {
                line3 = '<p class="other_info">' + line3 + '</p>';
            }

            this.moduleHeadHtml(line2, line3);
            function eta_cb(res) {
                if (res.distance) {
                    distance = res.distance;
                }
                distance = self.util.formatDistance(distance);
                $('#distance').text(distance).show();
                if(self.business === 'dining' && res.code == 1){
                    if($('#js_eta_module').length){
                        self.load_eta_module( res , etype);
                    }else{
                        self.util.executeAfterDomInsert(function(){
                            self.load_eta_module( res , etype);
                        });
                    }
                }
                index_cache[ key ] = res ;
            }
        },
        /**
         * 拼接头部html.
         * @param {String} line2 评分和价格
         * @param {String} line3 其它基础信息html
         * @param {Boolean} noRoute 是否显示“去这里”按钮
         */
        moduleHeadHtml: function(line2, line3, noRoute) {
            var self = POI;
            var name = self.util.bool(self.clientData.poiInfo.name) ? self.clientData.poiInfo.name : '';
            if(!name && self.aosData && self.aosData.base.name) {
                name = self.aosData.base.name;
            }
            // 公交站增加站台名称
            if (self.clientData.CURRENT_BUS_ALIAS) {
                name = name.replace('(公交站)','(公交站' + self.clientData.CURRENT_BUS_ALIAS + '站台)');
            }
            // bgc字段，若有则在名称后面加V
            var bgcVStr = '';
            if(self.aosData && (self.aosData.base.importance_vip_flag | 0)) {
                bgcVStr = '<span class="bgc_v" ' + self.handleAttr + '="js_showBgcPage"></span>';
                setTimeout(POI.showBgcMask, 17);
            }
            //网站诚信通，若有则在名称后面加标志图片
            if(self.aosData && self.aosData.deep && self.aosData.deep[0]) {
                if((self.aosData.deep[0].scope && self.aosData.deep[0].scope.length > 0) || (self.aosData.deep[0].main_industry && self.aosData.deep[0].main_industry.length > 0)) {
                    bgcVStr = '<span class="company_v" ' + self.handleAttr + '="js_showCompanyApprovePage"></span>';
                }
            }
            //新增导航栏部分，主图默认图根据行业不同而变化
            var headerimg_class = 'header_img';
            var toolbar_html = '';

            if (self.business == 'scenic') {
                headerimg_class = 'header_img scenic';
            } else if (self.business == 'hotel') {
                headerimg_class = 'header_img hotel';
            } else if (self.business == 'dining') {
                headerimg_class = 'header_img dining';
            }
            //导航栏模块化，在toolBar.js中实现
            toolbar_html = self.headerToolBar.get_html();

            //766添加主图功能
            var pic_html = '';
            var pic_num = '';
            var mask_html = '';
            var eventStr = '';
            var upload_html = '';
            var img_width = document.body.clientWidth;
            var img_height = Math.floor(img_width*170/320)+40;
            if (self.aosData && self.aosData.pic && self.aosData.pic.cover && self.aosData.pic.cover.url.length > 0) {
                var img_url = POI.util.imageUrlTransform(self.aosData.pic.cover.url, img_width, img_height);
                pic_html = ' style="height:'+(img_height/10)+'rem;background:url('+img_url+') no-repeat center center;background-size:cover;"';
                if (self.aosData.pic.pic_count && Number(self.aosData.pic.pic_count) > 0) {
                    pic_num = '<p class="title"><span></span><i>'+self.aosData.pic.pic_count+'</i></p>';
                }
                mask_html = '<p class="mask"></p>';
                eventStr = ' ' + POI.handleAttr + '="js_openPicList"';
                POI.api.userAction("poiHeaderImageShow");
            } else {
                pic_html = ' style="height:'+(img_height/10)+'rem"';
                try {
                    if(self.clientData.poiInfo.poiid) {
                        eventStr = ' ' + POI.handleAttr + '="js_pictureUpload"';
                        upload_html = '<img class="upload" src="img/upload.png"/>';
                        POI.api.userAction("poiHeaderImageUploadBtnShow");
                    }
                } catch(e) {}
            }
            var html = '<div class="' + headerimg_class + '"' + pic_html + eventStr + '>'+
                           '<p class="mask_head"></p>'+
                           mask_html + pic_num + upload_html +
                       '</div>';
            // 去这里
            var route_html = '';
            if (!noRoute && !self.fromIndoorMap) {
                route_html = '<p js_handle="js_goHere" class="line"><i></i><span>路线</span></p>';
            }
            
            // 认证bgc 添加
            html += '<section class="poihead_cont">'+
                   '<div class="title_div divide-line all-line">'+
                   '<p class="name">'+name+bgcVStr+'</p>'+
                   route_html+line2+line3+
                   '</div>'+
                   toolbar_html+
                   '</section>';

            // var hideHead = html.replace(/class="poiHead"/, 'class="poiHead hidden"');
            // $('#js_header').append(hideHead);
            // var totalHeight = $('#js_header > .poiHead').height();
            // var titleHeight = $('#js_header .poi-name').height();
            // var otherHeight = totalHeight - titleHeight;
            // // 其它高度为1行，标题高度不超过两行时，标题第二行居中
            // if (otherHeight < 40 && titleHeight < 90) {
            //     // 只有两行标题，无其他信息时，标题垂直居中
            //     if (otherHeight < 7 && titleHeight > 62) {
            //         var nameClass = 'class="poi-name"';
            //         html = html.replace(nameClass, 'style="top:50%; margin-top:-' +
            //             (titleHeight / 2) + 'px" ' + nameClass);
            //     }
            //     html = html.replace(/class="poiHead"/, 'class="poiHead simple"');
            // }
            html += this.poiFeature();
            html += this.addressAndPhone();
            // 用户距离目标超过50km，显示天气
            if (POI.aosData && POI.aosData.base && POI.aosData.base.distance >= 50000 &&("scenic" === self.business || "hotel" === self.business)) {
                html += this.mojiWeather();
            }
            
            $('#js_header').html(html);
            self.index.scenicSpecialTime();
            self.util.setPageTitle(name);
            this.poiHeadComment();
            this.poiHeadTime();
            //如果是默认图，则去掉下面的蒙层
            if (!$('.header_img').hasClass('scenic') && !$('.header_img').hasClass('hotel') && !$('.header_img').hasClass('dining')) {
                $('.header_img .mask').hide();
            }

            if (self.clientData.poiInfo.poiid) {
                self.pagebody.after(self.index.moduleErrorReport());
            }
            
        },
        poiHeadComment : function(){
            var h = $('.poiHeadComment p').height();
            if( h > 32 ) {
                $('.poiHeadComment p').addClass('hide');
            }
        },
        poiHeadTime: function() {
            var h = $('.address_phone .time p').height();

            if (h > 30) {
                $('.address_phone .time p').addClass('hide');
                $('.baseinfo_time_open').css('display', '-webkit-box');
            }
        },
        //获取天气信息
        mojiWeather: function() {
            var params = [
                {lon: POI.aosData.base.x, sign: 1},
                {lat: POI.aosData.base.y, sign: 1},
                {image_standard: 3, sign: 1}
            ];
            var key = 'mojiweather'+JSON.stringify( params );
            if( index_cache[ key ] ) {
                setTimeout(function(){
                    moji( index_cache[ key ] )
                },0);
            } else {
                POI.api.aosrequest('mojiweather', params, moji, 0, true, "GET");
            }
            
            function moji(data) {
                if (data.code != 1 || !data.temperature || !data.image_url) {
                    $('.header_weather').replaceWith('');
                    return; 
                }
                if (data.forecast && data.forecast[0].temp_low && data.forecast[0].temp_high) {
                    var temperature = data.forecast[0].temp_low+'-'+data.forecast[0].temp_high;
                } else {
                    var temperature = data.temperature;
                }
                var air_level = data.aqi_quality_level == null?'':'<span class="air_quanlity">空气'+data.aqi_quality_level+
                           '</span>';
                var html = '<span class="date">今日天气</span><span class="temperature">'+
                           temperature+'℃'+
                           data.weather_condition+
                           '<i style="background:url('+data.image_url+') no-repeat center center;background-size:contain;"></i>'+
                           '</span>'+air_level;
                $('.header_weather').html(html);
                index_cache[ key ] = data;
                POI.api.userAction('showWeatherInfo');
            }
            return '<section class="header_weather"></section>';
        },
        /**
         * POI头部特色数据展示 
         */
        poiFeature: function() {
            var self = POI;
            var pre_section = '<section class="Encyclopedia divide-line all-line">';
            var last_section = '</section>';
            var rank_html = '';
            var html = '';

            switch(self.business) {
                case 'scenic':
                    if (self.aosData && POI.aosData.deep[0].special) {
                        POI.api.userAction('poiHeadEncyclopedia');
                        html = '<div class="cont divide-line more" js_handle="js_openInfoUrl">'+
                               '<p>'+
                               '<span>百科：</span>'+
                               POI.aosData.deep[0].special+
                               '</p>'+
                               '</div>';
                        }
                    break;
                case 'hotel':
                    if( self.aosData && self.aosData.deep && (self.aosData.deep[0] || {}).brief_intro ) {
                        POI.api.userAction('poiHeadComment');
                        html = '<div class="poiHeadComment divide-line id="js_head_introFold""><p><span>用户评论：</span>'+self.aosData.deep[0].brief_intro+'</p></div>';
                    }
                    break;
                default:
                    break;
            }

            //展示排行榜信息
            
            if (POI.aosData && POI.aosData.deep_common && POI.aosData.deep_common[0] && POI.aosData.deep_common[0].top_list && POI.aosData.deep_common[0].top_list[0].top_list_id) {
                rank_html = '<div class="ranking more" data-id="'+POI.aosData.deep_common[0].top_list[0].top_list_id+'" js_handle="js_openPoiRankList">'+
                            POI.aosData.deep_common[0].top_list[0].district+POI.aosData.deep_common[0].top_list[0].type+'中&nbsp;&nbsp;排名'+
                            '<span>第'+POI.aosData.deep_common[0].top_list[0].list_no+'</span>'+
                            '</div>';
                POI.api.userAction('showHeaderRank', {ranking:POI.aosData.deep_common[0].top_list[0].list_no});
                POI.poiRanking = POI.aosData.deep_common[0].top_list[0].list_no;

            }

            return html || rank_html?pre_section+html+rank_html+last_section:'';
        },
        
        /**
         * 景点行业opentime2展示逻辑
         */
        scenicSpecialTime: function() {
            var self = POI;
            var $specialTime = $("#specialTime");
            var $timeSwidth = $("#timeSwidth");
            if($specialTime.length && $timeSwidth.length) {
                var $specialTimeReal = $specialTime.find("span");
                if($specialTimeReal.height() > $specialTime.height()) {
                    $specialTime.css("paddingRight", "5.3rem");
                    $timeSwidth.removeClass("hid");
                    $("#scenicOpenTime2").addClass("canTouch");
                }
            }
        },
        
        /**
         * 头部行业特殊文本信息转换为html代码.
         * @param {String} info 文本信息
         * @return {String}
         */
        moduleHeadItem: function(info) {
            if (!info) {
                return '';
            }
            return '<span>' + info + '</span>';
        },
        /**
         * 获取地址和电话的html.
         * @return {String}
         */
        addressAndPhone: function() {
            var html = '',
                self = POI,
                hasAddress = false,
                address = self.clientData.poiInfo.address,
                newType = self.clientData.poiInfo.new_type,
                bcs = '';
            if (self.aosData && self.aosData.base.address) {
                address = self.aosData.base.address;
                bcs = self.aosData.base.bcs;
            }
            if (address && newType != "150700" && newType != "150500" && self.business != 'bus' && self.business != 'subway') {
                hasAddress = true;
                html += '<li ' + (self.fromIndoorMap ? '' : 'id="address"') + ' class="baseinfo' + (self.fromIndoorMap ? '' : ' canTouch') + '">' +
                            '<div class="common_info address_icon"></div>' +
                            '<div class="cont"><p>' + address + (bcs ? '(' + bcs + ')' : '') + '</p></div>' +
                        '</li>';
            }
            var phones = this.getBasePhones(),
                num = phones.length;
            self.basePhones = phones;
            var phoneTxt = '';
            if (num > 1) {
                phoneTxt = phones[0] + "<span class='many_phones'>等" + num + "个号码</span>";
            } else {
                phoneTxt = phones.join(';');
            }
            if (phoneTxt.length > 0) {
                html += '<li id="basePhones" class="baseinfo canTouch" style="' + (0 < num ? '' : 'display:none') + '">' +
                        '<div class="common_info phone_icon"></div>' +
                        '<div class="cont"><p>' + phoneTxt + '</p></div>' +
                    '</li>';
            }
            
            if("dining" === self.business && self.aosData && self.aosData) {
                var _deep = self.aosData.deep[0];
                var isOpen = _deep.is_open | 0;
                if(_deep.opentime2 && 2 == isOpen) {
                    html += '<li class="baseinfo">' +
                                '<div class="common_info time_icon"></div>' +
                                '<div class="baseinfo_meswrapper">' +
                                    '<p class="cont">' +
                                        (2 == isOpen ? '<i class="baseinfo_time_close">参考时间</i>' : '') +
                                        _deep.opentime2 +
                                    '</p>' +
                                '</div>' +
                            '</li>';
                }
            }
            //768新增，菜鸟驿站新增时间
            if(("scenic" === self.business && self.aosData && self.aosData) || (self.aosData && self.aosData.deep_common && self.aosData.deep_common[0] && self.aosData.deep_common[0].service && self.aosData.deep_common[0].service.length > 0)) {
                var _deep = self.aosData.deep[0];
                if(_deep.opentime2) {
                    POI.api.userAction("scenicOpenTime2Show");
                    html += '<li id="scenicOpenTime2" class="baseinfo">' +
                                '<div class="common_info time_icon"></div>' +
                                '<div class="cont time">' +
                                    '<p id="specialTime"><span>' + _deep.opentime2 + '</span></p>' +
                                    '<a id="timeSwidth" href="javascript:void(0);" class="baseinfo_time_open">展开</a>' +
                                '</div>' +
                            '</li>';
                }
            }
            if ('kindergarten' === self.business && self.aosData) {
                var _deep = self.aosData.deep[0];
                if (_deep.info_wapurl) {
                    html += '<li class="baseinfo canTouch" js_handle="js_open3rdWepurl">' +
                            '<div class="baseinfo_icon baseinfo_icon_wap"></div>' +
                            '<div class="baseinfo_meswrapper"><p class="baseinfo_mes">' + _deep.info_wapurl + '</p></div>' +
                        '</li>';
                }
            }
            
            return html ? '<section id="baseInfo" class="address_phone"><ul>' + html + '</ul></section>' : '';
        },
        /**
         * 获取基础的电话数组.
         * 优先从poi的aos数据中获取，aos无数据时使用getPoiInfo中返回的电话
         * @return {Array.<String>} 电话数组
         */
        getBasePhones: function() {
            var self = POI,
                base = self.aosData ? self.aosData.base : {},
                clientInfo = self.clientData.poiInfo,
                phones;
            if (base.telephone && base.telephone.trim()) {
                phones = base.telephone;
            } else if (clientInfo.phoneNumbers && clientInfo.phoneNumbers.trim()) {
                phones = clientInfo.phoneNumbers;
            }
            if (phones) {
                // 来源电话分隔符有的是分号，有的是斜线
                return phones.trim().replace(/\//g, ';').split(';');
            }
            return [];
        },
        /**
         * 更新基础的电话信息.
         * @param {Array} phones 电话数组
         * @param {String} [text] 显示的文字
         */
        updateBasePhones: function(phones) {
            if (!phones.length) {
                return;
            }
            POI.basePhones = phones;
            var num = phones.length;
            var text = phones[0].title;
            if(1 < num) {
                text = text + "<span class='many_phones'>等" + num + "个号码</span>";
            }
            var phone_html = '<li id="basePhones" class="baseinfo canTouch">' +
                        '<div class="common_info phone_icon"></div>' +
                        '<div class="cont"><p>' + text + '</p></div>' +
                        '</li>';
            if ($('#baseInfo').length > 0) {//有dom节点
                if ($('#basePhones').length > 0) {
                    $('#basePhones .cont p').html(text);
                    $('#basePhones').show();
                } else {
                    $('#baseInfo').append(phone_html);
                }
            } else {//没有dom节点
                var html = '<section id="baseInfo" class="address_phone"><ul>'+phone_html+'</ul></section>';
                if ($('.header_weather').length > 0) {
                    $('.header_weather').before(html);
                } else {
                    $('#js_header').append(html);
                }
            }
            
               
        },
        /**
         * 获取介绍的html.
         * @param {Array.<String>} titleArr 简介各模块名称
         *    顺序为 图片、简介、特有，如果不显示其中一项，将其设置为空字符串
         * @param {String|Array.<String>} item 其它信息使用的key列表，只有一个时可以直接传字符串
         * @param {String} [time] 营业时间或设施
         * @return {String}
         */
        moduleIntro: function(titleArr, item, time) {
            var text = this.introText(titleArr, item);
            if (!text) {
                return '';
            }
            var html = '<section class="introDetail">' +
                '<h2 id="baseIntro" class="module_title_p line-half more">详情</h2>' +
                '<p class="cont">' + text + '</p>';
            if (time) {
                html += '<div class="installation">' + time + '</div>';
            }
            html += '</section>';
            return html;
        },
        /**
         * 生成简介字符串.
         * @param {Array.<String>} titleArr 简介各模块名称
         *    顺序为 图片、简介、特有，如果不显示其中一项，将其设置为空字符串
         * @param {String|Array.<String>} item 其它信息使用的key列表，只有一个时可以直接传字符串
         * @return {String}
         */
        introText: function(titleArr, item) {
            var self = POI;
            var deep = self.aosData.deep[0];
            var i, n;
            if (!deep._keys) {
                deep._keys = {};
                for (i = 0, n = deep.keys && deep.keys.length; i < n; i++) {
                    deep._keys[deep.keys[i]] = true;
                }
            }
            var flag = [];
            flag[0] = false; // 图片的判断，766版本去掉了二级页所有的图片，所以改为false
            flag[1] = !!deep._keys.intro;
            if (item) {
                var flag3 = false;
                if ( Object.prototype.toString.call(item) != '[object Array]' ) {
                    item = [item];
                }
                for (i = 0, n = item.length; i < n; i++) {
                    if (deep._keys[item[i]]) {
                        flag3 = true;
                        break;
                    }
                }
                flag[2] = flag3;
            }

            var info = [];
            for (i = 0, n = titleArr.length; i < n; i++) {
                if ( flag[i] && titleArr[i] ) {
                    info.push( titleArr[i] );
                }
            }

            if (info.length) {
                POI.api.userAction("introTextShow");
                return info.join('、') + (flag[2] ? '等' : '');
            }
            return '';
        },
        introInstallation: function(str, type) {
            if (!str) {
                return '';
            }
            var html = '';
            if( type === 1 ){
                if (/刷卡/i.test(str)) {
                    html += '<i class="hotel-installation icon3"></i>';
                }
                if (/免费停车场?/i.test(str)) {
                    html += '<i class="hotel-installation icon2"></i>';
                }
                if (/(wi-?fi|无线上网)/i.test(str)) {
                    html += '<i class="hotel-installation icon1"></i>';
                }
            } else {
                if (/(wi-?fi|无线上网)/i.test(str)) {
                    html += '<span class="half-border"><i class="icon1"></i>Wi-Fi</span>';
                }
                if (/免费停车场?/i.test(str)) {
                    html += '<span class="half-border"><i class="icon2"></i>免费停车场</span>';
                }
                if (/刷卡/i.test(str)) {
                    html += '<span class="half-border"><i class="icon3"></i>可刷卡</span>';
                }
            }
            return html;
        },
        /**
         * 室内地图模块.
         * @return {String} 室内地图按钮的html代码
         */
        moduleIndoorMap: function() {
            // 750版本删除所有室内地图入口
            return '';
            //var self = POI;
            //if (self.fromIndoorMap || !self.aosData.idDictionaries.sndt_id ||
            //        (self.aosData.spec.sndt && self.aosData.spec.sndt.sndt_unify == '1')) {
            //    return ''; 
            //}
            //
            //return this.moduleSingleHtml('indoorMap', '室内地图');
        },
        moduleSingleHtml: function(id, text) {
            return '<section><p' + (id ? ' id="' + id + '"' : '') + ' class="module_title_p more">' + text + '</p></section>';
        },
        // 报错与建议模块
        moduleErrorReport: function() {
            return '<section id="reportError" class="feedback">' +
                       '<p class="feedback_p more"><i class="feedback_icon"></i>信息有误？报告该地点问题</p>' +
                   '</section>';
        },
        // 新增地点模块
        moduleAddPoint: function() {
            return '<section id="addPoint" class="feedback">' +
                       '<p class="feedback_p more"><i class="feedback_icon"></i>新增地点</p>' +
                   '</section>';
        }
    },
    js_openPicList : function() {
        var type = 'list';
        POI.api.userAction("poiHeaderImageClick", {business: POI.business});
        POI.util.getPicData( {
            showType : type,
            poiid : POI.clientData.poiInfo.poiid,
            startIndex : 0,
            type : 'poiface'
        } );
    },
    js_pictureUpload : function() {
        POI.api.userAction("poiHeaderImageUplaod", {business: POI.business});
        POI.send({
            action: "pictureUpload",
            from: "poi",
            poiInfo: POI.clientData.poiInfo
        }, function() {});
    },
    // 展示bgc加V蒙层
    showBgcMask: function() {
        POI.api.userAction("bgcVShown");
        if("1" == POI.util.storage("poi_bgc_v_mask_shown")) {
            return;
        }
        POI.util.storage("poi_bgc_v_mask_shown", "1");
        var bgcMask = document.createElement("div");
        bgcMask.id = "bgcMask";
        bgcMask.className = "bgc_mask";
        var rectObj = document.querySelector("#js_header .bgc_v").getBoundingClientRect(),
            x = rectObj.left + 18,
            y = rectObj.top + 7;
        bgcMask.style.webkitMaskImage = "-webkit-gradient(radial, " + x + " " + y + ", 0, " + x + " " + y + ", 18, from(rgba(0,0,0,0)), to(rgba(0,0,0,1)), color-stop(98%, rgba(0,0,0,0)))";
        bgcMask.innerHTML = '<div class="bgc_tip" style="left:' + (Math.max(x - 87, 2) | 0) + 'px;top:' + (y + 24) + 'px">' +
                                '<p>此商家已经过品牌认证! 点击可查看详情~</p>' +
                            '</div>';
        POI.js_bgcMaskHide = function() {
            var bgcMask1 = document.getElementById("bgcMask");
            bgcMask.removeEventListener("touchmove", POI.cancelTouch, false);
            bgcMask.removeEventListener("click", POI.js_bgcMaskHide, false);
            window.removeEventListener("resize", POI.bgcMaskResize, false);
            POI.js_bgcMaskHide = POI.cancelTouch = POI.bgcMaskResizeTimeout = POI.bgcMaskResize = null;
            document.body.removeChild(bgcMask);
        };
        POI.cancelTouch = function(e) {
            e.stopPropagation();
            e.preventDefault();
        };
        POI.bgcMaskResizeTimeout = null;
        POI.bgcMaskResize = function() {
            clearTimeout(POI.bgcMaskResizeTimeout);
            POI.bgcMaskResizeTimeout = setTimeout(function() {
                var bgcMask = document.getElementById("bgcMask");
                var rectObj = document.querySelector("#js_header .bgc_v").getBoundingClientRect(),
                    x = rectObj.left + 18,
                    y = rectObj.top + 7;
                bgcMask.style.webkitMaskImage = "-webkit-gradient(radial, " + x + " " + y + ", 0, " + x + " " + y + ", 18, from(rgba(0,0,0,0)), to(rgba(0,0,0,1)), color-stop(98%, rgba(0,0,0,0)))";
                var bgcTip = bgcMask.querySelector(".bgc_tip");
                bgcTip.style.cssText = "left:" + (Math.max(x - 87, 2) | 0) + "px;top:" + (y + 24) + "px";
                bgcTip.removeChild(bgcMask.querySelector("canvas"));
                bgcTip.insertBefore(new POI.util.DialogBox({
                    width: 174,
                    height: 52,
                    borderWidth: 0.5,
                    borderColor: "#66bdff",
                    borderRadius: 5,
                    backgroundColor: "#fff",
                    arrowDirection: 0,
                    arrowDistance: (x - 87) > 2 ? 82 : x - 2 - 5,
                    arrowWidth: 10,
                    arrowHeight: 5
                }), bgcTip.firstChild);
            }, 100);
        };
        bgcMask.addEventListener("touchmove", POI.cancelTouch, false);
        bgcMask.addEventListener("click", POI.js_bgcMaskHide, false);
        window.addEventListener("resize", POI.bgcMaskResize, false);
        document.body.appendChild(bgcMask);
        POI.api.userAction("bgcGuideMaskShown");
        var bgcTip = bgcMask.querySelector(".bgc_tip");
        bgcTip.insertBefore(new POI.util.DialogBox({
            width: 174,
            height: 52,
            borderWidth: 0.5,
            borderColor: "#66bdff",
            borderRadius: 5,
            backgroundColor: "#fff",
            arrowDirection: 0,
            arrowDistance: (x - 87) > 2 ? 82 : x - 2 - 5,
            arrowWidth: 10,
            arrowHeight: 5
        }), bgcTip.firstChild);
    }
});
})(POI, Zepto);
