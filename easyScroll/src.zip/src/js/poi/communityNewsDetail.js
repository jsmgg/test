/*小区新闻详情页*/
;(function(POI, $) {

$.extend(POI,{
    
    logPageId : "communityDetail",
    
    showBaseInfo : function(data) {
        if(data.thread) {
            $(".title").text(data.thread.title || "");
            $(".paper .name").text(data.thread.orig || "");
            $(".paper .time").text(data.thread.repo_time || "");
        }
    },
    
    showContentInfo : function(data) {
        if(data.thread && data.thread.content) {
            $(".cont").html(data.thread.content);
        }
    },
    
    getCommunityNewsDetailData : function(id) {
        var _this = this;
        
        var params = [
            {id: id, sign: 1}
        ];
        var stt = POI.util.getUrlParam("stt");
        if(stt) {
            params.push({stt: stt});
        }
        POI.api.aosrequest('communityNewsDetail', params, function(data) {
            if("1" == data.code) {
                _this.showBaseInfo(data);
                _this.showContentInfo(data);
            }
        }, 1, true, "GET");
    },
    
    quickInit : function() {
        var id = POI.util.getUrlParam("id");
        if(id) {
            this.getCommunityNewsDetailData(id);
        }
    }
});

})(POI, Zepto)
