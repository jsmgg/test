;(function(POI, window) {

POI.util = {
    loadResources : (function() {
        var resourcesLoaded = {};
        function loaded() {
            this.onload = null;
            this.onerror = null;
            var obj = resourcesLoaded[ this.getAttribute("url") ];
            obj.status = "loaded";
            for(var i = 0, len = obj.cbAry.length; i < len; i++) {
                obj.cbAry[i].call(null);
                obj.cbAry[i] = null;
            }
        }
        function loadSingle(url, cb) {
            url = url.replace(/\?\w*/, "");
            if(!cb) {
                cb = function() {};
            }
            var status = resourcesLoaded[ url ] ? resourcesLoaded[ url ].status : "";
            if("loaded" === status) {
                cb.call(null);
            } else if("loading" === status) {
                resourcesLoaded[ url ].cbAry.push(cb);
            } else {
                resourcesLoaded[ url ] = {
                    status: "loading",
                    cbAry: [ cb ]
                };
                var res = null;
                var attr;
                if(/\.js$/.test(url)) {
                    res = document.createElement("script");
                    res.type = "text/javascript";
                    res.async = true;
                    attr = "src";
                } else if(/\.css$/.test(url)) {
                    res = document.createElement("link");
                    res.type = "text/css";
                    res.rel = "stylesheet";
                    attr = "href";
                    if( POI.browser.and && !POI.browser.and5 ){
                        //android 4.3 异步加载link标签没有onload、onreadystatechange回调,所以加这段代码hack
                        var timer = setTimeout(function(){
                            loaded.call(res);
                        },100);
                        resourcesLoaded[ url ].cbAry.push(function(){
                            clearTimeout( timer );
                        });
                    }
                } else {
                    cb.call(null);
                }
                res.onload = loaded;
                res.onerror = loaded;
                res.setAttribute(attr, url);
                res.setAttribute("url", url);
                document.body.appendChild(res);
            }
        }
        
        return function _loadResources(srcAry, handler) {
            if(!srcAry) return;
            if("string" === typeof(srcAry)) {
                srcAry = [ srcAry ];
            }
            if(!handler) {
                handler = function() {};
            }
            var len = srcAry.length,
                size = len;
            for(var i = 0; i < len; i++) {
                loadSingle(srcAry[i], function() {
                    if(!(--size)) {
                        handler.call(null);
                    }
                });
            }
        }
    })(),
    // 模拟a标签跳转
    locationRedirect: function(url) {
        if(POI.browser.ios){
            var $lr = $("#locationRedirect"),
                ev = document.createEvent('HTMLEvents');
            ev.initEvent('click', false, true);
            if($lr.length) {
                $lr.attr("href", url);
            } else {
                $lr = $('<a id="locationRedirect" href="' + url + '" style="display:none;"></a>');
                $(document.body).append($lr);
            }
            $lr[0].dispatchEvent(ev);
        }else{
            window.location.href = url;
        }
    },
    //本地存储，一个参数(key)为取，两个参数(key,value)为存
    storage : function() {
        if (arguments.length==1){
            return localStorage.getItem(arguments[0]);
        }
        localStorage.setItem(arguments[0],arguments[1]);
    },
    /**
     * 获取url参数.
     * @param {String} [name] 参数名称，无此参数时返回所有参数
     * @return {String|Object} name存在时返回相应的值，否则返回所有参数
     */
    getUrlParam: function(name) {
        var url = window.location.search.substr(1);
        if (!url) {
            return null;
        }
        url = decodeURI(url);
        if (name) {
            var value = new RegExp('(?:^|&)' + name + '=([^&]*)(&|$)', 'g').exec(url);
            return value && window.decodeURIComponent(value[1]) || '';
        }
        var result = {};
        var reg = /(?:^|&)([^&=]+)=([^&]*)(?=(&|$))/g;
        var item;
        while (item = reg.exec(url)) {
            result[item[1]] = window.decodeURIComponent(item[2]);
        }
        return result;
    },
    isMobile: function(str) {
        return /^1[3|4|5|7|8][0-9]\d{8}$/.test(str);
    },
    /**
     * 返回传入参数真正要表达的布尔值.
     * @param 不限制类型，多为字符串,数组时如果length=0也会返回false，空对象也会返回false
     * @return {Boolean} true or false
     */
    bool: function(param) {
        if(!!param) {
            var result = true;
            var typeString = Object.prototype.toString.call(param);
            switch(typeString) {
                case "[object String]":
                    param = param.replace(/(^\s*)|(\s*$)/g, "");
                    if(!param || /^(0|false|null|undefined|NaN)$/i.test(param)) {
                        result = false;
                    }
                    break;
                case "[object Array]":
                    result = !!param.length;
                    break;
                case "[object Object]":
                    if(Object.keys) {
                        result = !!Object.keys(param).length;
                    } else {
                        result = false;
                        for(var p in param) {
                            if(param.hasOwnProperty(p)) {
                                result = true;
                                break;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }
            return result;
        } else {
            return false;
        }
    },
    /**
     * 计算两点之间的距离.
     * @param {Object} p1 poi点对象，包含经纬度
     * @param {Object} p2 poi点对象，包含经纬度
     * @return {Double} 两点之间的距离，无法计算时返回-1
     */
    getDistance: function(p1, p2) {
        if (!p1 || !p2 || !p1.lat || !p1.lon || !p2.lat || !p2.lon) {
            return -1;
        }
        // 地球半径
        var EARTH_RADIUS = 6378.137;

        var radLat1 = getRadius(p1.lat);
        var radLat2 = getRadius(p2.lat);
        var a = radLat1 - radLat2;
        var b = getRadius(p1.lon) - getRadius(p2.lon);
        var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) +
            Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2))); 
        s = s * EARTH_RADIUS * 1000;
        return s;

        function getRadius(x) {
            return x * Math.PI / 180;
        }
    },
    /**
     * 格式化距离.
     * @param {Number} dis 距离
     * @return {String} 12m 3km 5.1km
     */
    formatDistance: function(dis) {
        if (typeof dis != 'number') {
            dis = parseFloat(dis, 10);
        }
        if (isNaN(dis) || dis < 0) {
            return '';
        }
        if (dis < 1000) {
            return dis.toFixed(0) + '米';
        }
        dis /= 1000;
        return dis.toFixed(1) + '公里';
    },
    /**
     * 创建打开页面的 schema.
     * @param {String} url 要打开页面的 url
     *    若未离线页面，页面 url 为相对 index.html 的 url
     * @param {Boolean} [isOffline=false] 默认为在线页面，若为离线页面传 true
     * @param {string} [source=banner] 来源标识
     * @return {String} 完整的 schema
     */
    htmlSchema: function(url, isOffline, source) {
        var plat = '';
        if (POI.browser.ios) {
            plat = 'ios';
        } else {
            plat = 'android';
        }    
        return plat + 'amap://openFeature?featureName=OpenURL&sa=1' +
            '&sourceApplication=' + (source || 'banner') +
            '&url=' + encodeURIComponent(url) +
            '&urlType=' + (isOffline ? 1 : 0) + '&contentType=autonavi';
    },
    /**
     * 格式化
     * @param {Date} date
     * @param {String} format
     * @return {String}
     */
    formatDate: function(date, format) {
        if (Object.prototype.toString.call(date) != '[object Date]') {
            return '';
        }
        return format.replace(/y{4}/g, date.getFullYear())
            .replace(/MM/g, formatTimeNo(date.getMonth() + 1))
            .replace(/M/g, date.getMonth() + 1)
            .replace(/dd/g, formatTimeNo(date.getDate()))
            .replace(/d/g, date.getDate())
            .replace(/hh/g, formatTimeNo(date.getHours()))
            .replace(/h/g, date.getHours())
            .replace(/mm/g, formatTimeNo(date.getMinutes()))
            .replace(/m/g, date.getMinutes())
            .replace(/ss/g, formatTimeNo(date.getSeconds()))
            .replace(/s/g, date.getSeconds());

        function formatTimeNo(num) {
            if (num < 10) {
                num = '0' + num;
            }
            return num;
        }
    },
    /**
     * 格式化钱数.
     * 如果数字非法或小于0，则返回0，
     * 如果数字为整数，直接返回原值
     * 否则最多保留固定位数（默认2）的小数
     * @param {String|Number} num
     * @param {Integer} [decimalLen=2] 保留的小数位数，至少为0
     * @return {Number} 格式化后的数字
     */
    formatMoney: function(num, decimalLen) {
        num = Number(num);
        if ( !num || num <= 0 ) {
            return 0;
        }
        if (!decimalLen && decimalLen !== 0) {
            decimalLen = 2;
        }
        // 如果小数位数超过预定位数，则四舍五入到相应位数
        if ( (new RegExp('\\.\\d{' + (decimalLen + 1) + ',}$')).test('' + num) ) {
            num = num.toFixed(decimalLen);
        }
        return num;
    },
    /**
     * 获取币种标识符.
     * @param {String} currency 币种名称
     * @return {String}
     */
    moneyFlag: function(currency) {
        if (!currency) {
            return '';
        }
        var symbol = {
            CNY: '￥',
            RMB: '￥',
            USD: '$',
            HKD: 'HK$',
            MOP: 'MOP'
        };
        return symbol[currency] || currency;
    },
    getStorageData:function(){
        //var pageId=localStorage.getItem('pageId');
        var poiDataString=this.storage('aosData');
        poiDataString = $.parseJSON(poiDataString);
        return  poiDataString;
    },
    /**
     * 图片缩略图
     * @param {JSON} picData 图片信息
        {
            type:模块标识,可选值：golf,movie
            itemid:golf对应场地id（courseId），movie对应电影id（movieId）
            cont:缩略图父节点,
            pics:图片数组,
            count:总图数
        }
     * @author duxing
     */
    picThumb: function( picData ){
        var _type = picData.type,
            poiid = picData.poiid || '',
            _itemId = picData.itemid,
            _cont = picData.cont,
            _pics = (picData.pics || []).length ? picData.pics.slice(0,3) : [],
            _count= picData.count || 0;//图片总数
        if( _pics.length ){
            var html = [];
            $.each( _pics , function( index, item ){//图片展示（详情）入口
                if( item.url ){
                    html.push( '<a class="img-loading"><img src="' + item.url +'" alt=""></a>' );
                }else{//默认图
                    html.push( '<a class="img-def"></a>' );
                }
            });
            html.push( '<a class="count">' + _count + '张</a>' );//全部图片（图片墙）入口
            _cont.html( html.join('') );

            this.picLoadEvt( _cont , 1 );
            this.picReqEvt( _type , _cont , _itemId , poiid );
        }else{
            _cont.hide();
        }
    },
    /**
     * 图片加载状态
     * @param {jQueryElemObject} cont 图片父节点
     * @param {Number} rate 宽高比,缺省值为1
     * @author duxing
     */
    picLoadEvt:function( cont , rate ){
        var _cont = cont,
            _rate = rate || 1;
        //设置图片的父节点
        function initImgCont(){
            var w = _cont.find('a').width();
            _cont.find('a').height( w / _rate );
        }
        /**
         * imgElem{jQuery Dom}
         * 将图片设置为方形
         */
        function cropImg( imgElem ){
            var i = imgElem;
            var iw = i.get(0).naturalWidth,
                ih = i.get(0).naturalHeight;
            if( (iw / ih) > _rate ){//太宽too broad
                i.css({'height': '100%','width':'auto'} );
            }else{
                i.css({'height': 'auto','width':'100%'} );
            }
        }

        initImgCont();//图片载入前，预先设定父容器尺寸

        _cont.find('img').each( function( index, item ){
            if( item.naturalWidth > 0 ){//有缓存，不会触发onload
                cropImg( $(item) );
            }else{//初次加载
                $(item).on('error',function(){
                    $(this).parent().removeClass('img-loading').addClass('img-err');
                    $(this).remove();
                })
                .on('load',function(){
                    $(this).unbind('error load').parent().removeClass('img-loading');
                    cropImg( $(this) );
                });
            }
        });

        var timer;
        $(window).resize(function(){
            clearTimeout( timer );
            timer = setTimeout(function(){
                initImgCont();
            },100);
        });
    },
    /**
     * 图片数据请求事件绑定(为golf,movie提供)
     * @param  {String} type 请求模块标识，golf|movie
     * @param  {jQueryElemObject} contElem 事件绑定的目标,缩略图们的父容器
     * @param  {Number} itemId
     * @author duxing
     */
    picReqEvt:function( type , contElem , itemId , poiid ){
        var self = this;
        //图片详情（大图）
        contElem.on('click' , 'img' , function(){
            var index = $('img',contElem ).index( $(this) );
            jump( 'detail' , contElem , index );
        });
        //图片墙
        contElem.find('a').last().on( 'click', function (){
            jump( 'list', contElem );
        });
        //跳转
        var jump = function( showType, contElem, index ){
            var para = {
                'type':type,
                'showType':showType,
                'itemId':itemId,
                'poiid':poiid
            };
            if( typeof index !== 'undefined' ){
                para.startIndex = index;
            }
            self.getPicData( para );
            POI.api.userAction( type + '_' + showType + '_' + itemId );
        }
    },
    /**
     * 获取图片们
     * @param {JSON} reqPara 形式如下：
     *  {type:'golf',itemId:courseId,'showType':'list'/'detial'}
     *  {type:'movie',itemId:modieId,'showType':'list'/'detial'}
     *  {type:'poiface','showType':'list'/'detial'}
     *  {type:'building',itemId:jushi,'showType':'list'/'detial'}
     *  当showType为detail时，还需要带startIndex属性，如{type:'golf',itemId:courseId,'showType':'detial',startIndex:2}
     * @author duxing
     */
    getPicData:function( reqPara ){
        var poiid = reqPara.poiid,
            itemId = reqPara.itemId||'',
            type = reqPara.type, dt,
            params = {
                'poiface':[{mode : 1, sign : 1}, {poiid: poiid}],
                'golf':[{mode : 2, sign : 1}, {poiid: poiid}, {itemid: itemId}],
                'movie':[{mode : 3, sign : 1}, {itemid: itemId}],
                'building':[{mode : 4, sign : 1}, {poiid: poiid}, {itemid: itemId}]
            };
        if( params[type] ) {
            POI.api.aosrequest('qqMoviePicList', params[type], function(dt) {
                
                if( dt ){
                    if( 1 == dt.code && dt.pic_info){//success
                        //reqPara.picList = dt.pic_info;
                        //reqPara.showMod = 1;//列表页显示标志位，1为普通，2为美食
                        //POI.util.storage( 'exPicList', JSON.stringify( reqPara ) );//缓存数据
                        //POI.util.locationRedirect("public/picview/exPiclist.html" + (window.hasWebPageTitleBar ? "?showTitleBar=1" : ""));
                        
                        POI.api.imagePreview("detail" === reqPara.showType ? "single" : "list", reqPara.startIndex, dt.pic_info, POI.clientData.poiInfo, true);
                    }
                }
            }, 1, true, 'POST');
        }
    },
    // 图片服务的url转换
    // imageUrlTransform(url /*, type */)
    // imageUrlTransform(url , width , height /*, operate , position */)
    imageUrlTransform: function(url) {
        if(!url) {
            return "";
        }
        var match_list = ['.autonavi.com', '.amap.com'],
            has = -1 !== url.indexOf("?"),//有参数
            reg = new RegExp('('+match_list.join('|')+')', 'g');
        if( !reg.exec( url ) ){
        	return  url;
        }
        var isAliYun = -1 !== url.indexOf(match_list[1]);
        url = url.replace(/\?type=pic$/, "?type=10");
        var len = arguments.length,
            str = "";
        if(1 === len) {
            url = has ? url.replace(/\?type=[0-9]$/, "?type=10") : (url + "?type=10");
        } else if(2 == len) {
            url = has ? url.replace(/\?type=[0-9]$/, "?type="+arguments[1]) : ( url + "?type=" + (+arguments[1]));
        } else {
            var ratio = window.devicePixelRatio || 1,
                realWidth = Math.floor(ratio * (+arguments[1])),
                realHeight = Math.floor(ratio * (+arguments[2]));
            if(isAliYun) {
                str = "@" + realHeight + "h_" + realWidth + "w_1e_1c_2o";
                url = url + str;
            } else {
                str = "operate=" + (arguments[3] ? arguments[3] : "merge") + "&w=" + realWidth + "&h=" + realHeight + "&position=" + (arguments[4] ? arguments[4] : 5);
                url = url + ( has ? '&' : '?') + str;
            }
        }
        return url;
    },
    /**
     * 评分（心形图标） html 获取.
     * @param {String|Number} score 实际评分
     * @param {Integer} [total=5] 总分
     * @return {String} html代码
     */
    stars: function(score, total) {
        score = parseFloat(score);
        if (isNaN(score) || score < 0) {
            return '';
        }
        // 默认为5分制
        if (!total) {
            total = 5;
        }
        // 最大分数为满分
        if (score > total) {
            score = total;
        }
        score = Math.round(score / total * 100);
        return '<span class="star"><span class="highlight" style="width:' + score + '%;"></span></span>';
    },
    /**
     * 添加图片加载状态的监听
     * @param {jQueryElemObject} imgElems 监听的图片节点
     * @param {String} rate empty填充图的比例,目前可设置的有:'1x1'、'3x1'、'4x3'，为为空时默认'1x1'。添加新的比例时，需在img/目录下添加对应图片
     * @author duxing
     * 要求：在注入img到DOM时，记得带上class，如: <img class="img-loading" src="xxx.png">
     * 描述：在图片加载成功后会移除loading;在图片加载失败时，会增加class="img-err",并填充src="img/empty.png"
     * 补充：有关default的说明，如果图片接口返回url为空，请将<img class="img-def" src="img/empty.png">，传参方式可参考： Poi.util.imgloading( $('#ContainerElem img[class=img-loading]') );
     *
     */
    imgloading:function( imgElems , rate ){
        var that = this;
        $.each( imgElems , function( ) {
            var i = $(this);
            var src = i.attr('src');
            var flag = true;
            if( !!i.attr('data-presrc')  ){//设置了自定义属性 && 有值
                if( 'undefined' == i.attr('data-presrc') ){
                    flag = false;
                }
            }else if( i.attr('data-presrc') === '' ){//设置了自定义属性 && 无值
                flag = false;
            }else if( typeof i.attr('data-presrc') === 'undefined' ){//未设置自定义属性
                if(src == undefined || src == 'undefined' || $.trim(src) == '' ){
                    flag = false;
                }else if( i[0].baseURI == i[0].src ){
                    flag = false;
                }else if( /^\s*undefined\?type=\d+$/.test( src ) ){
                    falg = false;
                }else if( /^\s*\?type=\d+$/.test( src ) ){
                    flag = false;
                }
            }

            if( flag ){
                i.addClass('img-loading');

                i.on('error',function(){
                    that.setEmptyImg( i, rate );
                    i.removeClass('img-loading').removeClass('img-def').addClass('img-err');
                })
                .on('load',function(){
                    i.unbind('error load').removeClass('img-loading').removeClass('img-def');
                });
            }else{
                i.removeClass('img-err').removeClass('img-loading').addClass('img-def');
                that.setEmptyImg( i, rate );
            }
        });
    },
    /**
     * 一行5张图片代码生成.
     * @param {Array.<Object>} list 图片列表
     * @param {Integer} total 图片总数
     * @param {String} param 打开图片墙或大图的JSON参数
     */
    modulePicList: function(list, total, param) {
        if (!list || !list.length) {
            return '';
        }
        var width = (document.body.clientWidth - 50) / 3;
        var height = width * 2 / 3;
        var html = '<article js_handle="js_openPicList" data-param=\'' + param + '\' style="height:' + height + 'px;" class="pic-line">';
        for (var i = 0, len = Math.min(list.length, 3); i < len; i++) {
            html += '<span class="img-def noLoadEvent" data-url="' +
                this.imageUrlTransform(list[i].url, width, height) +
                '" data-index="' + i + '"></span>';
        }
        if (total > 3) {
            var info = '<div data-showType="list" class="total">相册<br/>(' + total + ')</div></span>';
            html = html.replace(/<\/span>$/, info);
        }
        for (i = list.length; i < 3; i++) {
            html += '<span></span>';
        }
        html += '</article>';

        // 图片加载事件
        this.executeAfterDomInsert(function() {
            var $list = $('.pic-line > span.noLoadEvent');
            var that = POI.util;
            for (var i = 0, len = $list.length; i < len; i++) {
                var $elem = $list.eq(i).removeClass('noLoadEvent');
                new that.loadImage($elem.attr('data-url'), $elem[0], successFun, errorFun);
            }

            function successFun(elem) {
                $(elem).removeClass('img-def').css('backgroundImage', 'url("' + $(elem).attr('data-url') + '")');
            }
            function errorFun(elem) {
                $(elem).removeClass('img-def').addClass('img-err');
            }
        });

        if (!POI.js_openPicList) {
            // 图片点击事件
            POI.js_openPicList = function(elem, evt) {
                var param = elem.attr('data-param');

                param = JSON.parse(param);
                param.showType = 'detail';
                var logInfo;
                if ($(evt.target).attr('data-showType')) {
                    param.showType = 'list';
                    logInfo = 'list';
                } else {
                    logInfo = $(evt.target).attr('data-index');
                    param.startIndex = logInfo;
                    if (!logInfo) {
                        return;
                    }
                }
                this.api.userAction('pictureList', {index: logInfo});
                this.util.getPicData(param);
            };
            $(window).on('resize', function() {
                var width = (document.body.clientWidth - 70) / 5;
                $('.pic-line').height(width);
            });
        }
        return html;
    },
    /**
     * @param {jQueryElemObject} imgElem
     * @param {String} rate empty填充图的比例,目前可设置的有:'1x1'、'3x1'、'4x3'，为为空时默认'1x1'。添加新的比例时，需在img/目录下添加对应图片
     * @return {jQueryElemObject} 返回参数imgElem
     * @author duxing
     */
    setEmptyImg:function( imgElem, rate ){
        var imgType = {
            '1x1':'empty.png',
            '3x1':'empty3x1.png',
            '4x3':'empty4x3.png'
        };
        return imgElem.attr('src','img/' + imgType[ rate||'1x1' ] );
    },
    /*
        事件代理
        parentNode 代理父元素zepto对象
        attr 监听属性
    */
    delegate : function(parentNode, attr) {
        var self = POI, type = 'click';
        attr = attr || 'js_handle';
        if (!parentNode || !parentNode.length) return;
        parentNode.unbind(type).bind(type , function(e){
            var target = e.target , val;
            while(target){
                val = $(target).attr(attr);
                if(val && /^js_/.test(val) && typeof self[val] === 'function'){//方法名以js_开头
                    if(self[val]($(target), e) === false){
                        break;
                    }else{
                        target = target.parentNode;
                    }
                }else if(target === this){
                    break;
                }else{
                    target = target.parentNode;
                }
            }
        });
    },
    
    intro: (function() {
        function keyDataConvert(key) {
            var deep = POI.aosData.deep[0],
                val = deep[key];
            if(val) {
                if("opentime2" === key) {
                    val = val.replace(/(\d{2}:\d{2})(\d{2}:\d{2})/, "$1，$2");
                }
                return val;
            } else {
                return "";
            }
        }
        return function _intro(dataAry) {
            if(!dataAry || 0 === dataAry.length) {
                return "";
            }
            if("string" === typeof(dataAry)) {
                dataAry = [ dataAry ];
            }
            var htmlStr = '';
            for(var i = 0, len = dataAry.length, item = null; i < len; i++) {
                item = dataAry[i];
                if(!item) {
                    continue;
                }
                if("string" === typeof(item)) {
                    htmlStr += item;
                    continue;
                }
                item.data = item.data ? item.data : keyDataConvert(item.key);
                if(item.data) {
                    htmlStr += '<article class="intro_con">';
                    if(item.more) {
                        htmlStr += '<h1 class="intro_title">' + item.name + '</h1><p id="introSpec" class="intro_desc limits">' +
                                item.data + '</p><a class="introFold"></a>';
                    } else {
                        htmlStr += '<h1 class="intro_title">' + item.name + '</h1><p class="intro_desc">' + item.data + '</p>';
                    }
                    htmlStr += '</article>';
                }
            }
            if(!htmlStr) return "";
            return '<section id="intro" class="intro">' + htmlStr + '</section>';
        }
        
    })(),
    
    /**
     * 
     */
    executeAfterDomInsert : (function() {
        var funAry = [],
            paramAry = [];
        return function _executeAfterDomInsert() {
            if(0 === arguments.length) {
                for(var i = 0, len = funAry.length; i < len; i++) {
                    funAry[i].apply(POI, paramAry[i]);
                    funAry[i] = paramAry[i] = null;
                }
                funAry.length = paramAry.length = 0;
            } else {
                var argumentsAry = Array.prototype.slice.call(arguments);
                funAry.push(argumentsAry.shift());
                paramAry.push(argumentsAry);
            }
        }
    })(),
    /**
     * @param {jQueryElemObject} elem传入的选择器
     * @param {Object} option为对象字面量，非必须,值为option{threshold:距离阈值,data_attribute:给予图片地址的属性名称,placeholder:默认的填充图片（地址）}
     * @author Hyr
     */
    lazyLoad: function (elem, option) {
        var setting = {
            threshold : 100,
            data_attribute : "ori-src",
            placeholder : "./img/img-def.png"
        };
        $.extend(setting, option);
        Pagescroll();
        var scrollTimer = null;
        window.onscroll = function () {
            //函数节流
            if (scrollTimer) {
                clearTimeout(scrollTimer)
            }
            scrollTimer = setTimeout(function () {
                Pagescroll();
            }, 400);
        };
        function Pagescroll() {
            var elements = $(elem);
            elements.each(function(){
                var $self = $(this);
                if (this.loaded){return;}
                var cssStr = {"background" : "#f5f6f8 url(" +setting.placeholder+ ") no-repeat 50% 50%",
                    "background-size" : "auto 40%"};
                if ($self.is("img")) {
                    if ((!this.preload)&&($self.attr("src") == "")){
                        $self.css(cssStr);
                        this.preload = true;
                    }
                }
                else {
                    var background=this.style.background;
                    if (background === undefined || background === false ||background == "") {
                        $self.css(cssStr);
                    }
                }
                var top = this.getBoundingClientRect().top;
                var clientHeight = document.documentElement.clientHeight;
                if ((top > setting.threshold - $(this).height()) && (top < clientHeight)) {
                    var imgSrc = $self.attr(setting.data_attribute);
                    var img=new Image();
                    img.src = imgSrc;
                    img.onload =function(){
                        if ($self.is("img")) {
                                $self.attr("src", img.src);
                        }
                        else {
                                $self.css("background", "url('" +  img.src + "') no-repeat 50% 50%");
                                $self.css("background-size", "cover");
                            };
                    };
                    this.loaded = true;
                }
            });
        };
    }
};


/* ---------------------------------为POI.util增加一些功能类---------------------------------------- */
/**
 * 上拉加载更多功能.
 * @param {Function} moreFun 页面滑动到底部后加载更多的方法
 * @param {Element} [container=document.body] 增加此功能的元素，默认为 body
 */
POI.util.PullUpGetMore = function(moreFun, container) {
    if (!moreFun) {
        return;
    }
    // 距容器底部的距离小于此值时便触发回调
    this.MAX_BOTTOM_DIS = 64;
    this.moreFun = moreFun;
    var doc = document;
    if (!container || container == doc.body || container == doc) {
        this.container = doc.body;
        this._isBody = true;
    } else {
        this.container = container;
    }

    this._createBar();
};
POI.util.PullUpGetMore.prototype = {
    /**
     * 创建加载更多状态条.
     */
    _createBar: function() {
        var bar = document.createElement('div');
        bar.className = 'pugm-bar';

        this.container.appendChild(bar);
        var scrollEleme = this._isBody ? document : this.container;
        scrollEleme.addEventListener('scroll', this, false);
    },
    /**
     * 移除加载更多的事件和元素.
     */
    destory: function() {
        this.container.removeChild( this.container.querySelector('.pugm-bar') );
        var scrollEleme = this._isBody ? document : this.container;
        scrollEleme.removeEventListener('scroll', this, false);
    },
    /**
     * 将加载条移动到容器的最底部.
     */
    refresh: function() {
        this._pause = false;
        this.container.appendChild( this.container.querySelector('.pugm-bar') );
    },
    /**
     * 将加载条隐藏.
     */
    hide: function() {
        this._pause = false;
        this.container.querySelector('.pugm-bar').style.visibility = 'hidden';
    },
    /**
     * 事件监听函数.
     * 当页面滚动到容器底部时，触发加载更多的方法
     * @param {Event} event
     */
    handleEvent: function(event) {
        if (event.type != 'scroll') {
            return;
        }
        if (this._pause) {
            return;
        }
        var outerHeight = this._isBody ? document.documentElement.clientHeight :
                this.container.clientHeight;
        var innerHeight = this.container.scrollHeight;
        var scrollTop = this.container.scrollTop;

        if (innerHeight - outerHeight - scrollTop < this.MAX_BOTTOM_DIS) {
            this.container.querySelector('.pugm-bar').style.visibility = 'visible';
            this._pause = true;
            this.moreFun();
        }
    }
};

/**
* 查看更多收起組件
* @param {DOM} ele 被点击的DOM元素 如$('#comments a') 必选
* @param {DOM} con 收缩的DOM元素 如$('#comments p') 必选
* @param {JSON} option 可选
*/
POI.util.toggleContent = function(ele,con,option){
    if(!ele || !con){return}
    // zepto选择器选择不存在的元素时会返回空数组，需要排除这种情况
    if (Object.prototype.toString.call(ele) == '[object Array]' && !ele.length) {
        return;
    }

    this.option={
        isConClick: false,
        switchClassName:'limits', //默认的classname
        switchAttributeName:'more', //默認的name屬性值
        matchDomNodes:null, //与被点击的标签对应的文本节点
        eleContent:{
            showAll:'查看全文',
            hidePort:'收起'
        }
    }  
    for(var key in option){
        this.option[key] = option[key];
    }
    this.elementTrigger = ele;
    this.domContent = con;
    this.showDom = null;//记录最后一次展开
    this.scroll_top = 0;

    this._init(ele,con);
}

POI.util.toggleContent.prototype={
    _addEvent:function(){
        if(this.elementTrigger.length){
            for(var i=0,len=this.elementTrigger.length;i<len;i++){
                this.elementTrigger[i].addEventListener('click',this,false);
                if(this.option.isConClick) {
                    this.domContent[i].addEventListener('click',this,false);
                }
            }
        }else{
            this.elementTrigger.addEventListener('click',this,false);
        }
    },
    _removeEvent:function(){
        if(this.elementTrigger.length){
            for(var i=0,len=this.elementTrigger.length;i<len;i++){
                this.elementTrigger[i].addEventListener && this.elementTrigger[i].removeEventListener('click',this,false);
            }
        }else{
            this.elementTrigger.addEventListener && this.elementTrigger.removeEventListener('click',this,false);
        }
    },
    _mesureHeight : function(){
      if(this.domContent.length){
        for(var i=0,len=this.domContent.length;i<len;i++){
            this.oneDomContent = this.domContent[i];
            this._switchClass(this.oneDomContent,i);
        }
      }else{
            this.oneDomContent = this.domContent;
            this._switchClass(this.oneDomContent);
      }
       
    },
    _switchClass:function(domContent,index){
      var switchClassName = this.option.switchClassName
        ,eleContent = this.option.eleContent
        ,hidePort = eleContent.hidePort
        ,showAll = eleContent.showAll
        ,domCon = $(domContent);

      if(domCon.hasClass(switchClassName)){
        this.option.limitHeight = domContent.clientHeight;
        domCon.removeClass(switchClassName);
        this.option.sumHeight = domContent.clientHeight;
        domCon.addClass(switchClassName);   
        this._compareHeight(showAll,1,index);
      }else{
        this.option.sumHeight = domContent.clientHeight;
        domCon.addClass(switchClassName);  
        this.option.limitHeight = domContent.clientHeight; 
        domCon.removeClass(switchClassName);
        this._compareHeight(hidePort,0,index);
      }   
    },
    _compareHeight:function(con,flag,index){
        var eleTrigger = (index!==undefined) ? this.elementTrigger[index] : this.elementTrigger;
        if(this.option.sumHeight !== this.option.limitHeight){
            eleTrigger.innerText = con;
            if(flag){
              eleTrigger.setAttribute('name',this.option.switchAttributeName) ;
            }
            eleTrigger.style.display = 'block';
        }else{
            eleTrigger.style.display = 'none';
        }
    },
    handleEvent : function(e){
        var eleContent = this.option.eleContent,
            hidePort = eleContent.hidePort,
            showAll = eleContent.showAll,
            eleTrigger = e.target;
        if(this.option.isConClick && $(eleTrigger).closest($(this.domContent).selector).length) {
            eleTrigger = eleTrigger.nextElementSibling;
        }
        var switchName = this.option.switchAttributeName,
            matchDomNodes = this.option.matchDomNodes || eleTrigger.previousElementSibling;
        if(e.type == 'resize'){
            this._mesureHeight(); 
            this.showDom = null;
        }else{
            if(eleTrigger.getAttribute('name') == switchName){
                eleTrigger.innerText = hidePort;
                eleTrigger.removeAttribute('name');
                this.showDom = eleTrigger;
                this.scroll_top = $(window).scrollTop();
            }else{
                eleTrigger.innerText = showAll;
                eleTrigger.setAttribute('name',switchName);
                if( this.showDom == eleTrigger){
                    $(window).scrollTop( this.scroll_top );
                } else {
                    this.showDom = null;
                }
            }
            $(matchDomNodes).toggleClass(this.option.switchClassName);
        }
    },
    _init : function(ele,con){
        POI.browser.and && window.addEventListener('resize',this,false);
        this._addEvent();
        this._mesureHeight();
    }
}

POI.util.loadImage = function(src, ele, successFun, errorFun) {
        this.src = src;
        this.ele = ele;
        this.$ele = $(ele);
        if(!src) {
                this.$ele.removeClass("img-loading").addClass("img-def");
                return;
        }
        this.$ele.addClass("img-loading").find("img").hide();
        this.successFun = successFun;
        this.errorFun = errorFun;
        this._img = new Image();
        this.init();
};

POI.util.loadImage.prototype = {
        _onload: function() {
                this.$ele.removeClass("img-loading");
                this.successFun && this.successFun.call(null, this.ele, this._img);
        },
        _onerror: function() {
                this.$ele.removeClass("img-loading").addClass("img-err");
                this.errorFun && this.errorFun.call(null, this.ele);
        },
        init: function() {
                var _this = this;
                this._img.onload = function() {
                        this.onload = null;
                        this.error = null;
                        _this._onload();
                };
                this._img.onerror = function() {
                        this.onload = null;
                        this.error = null;
                        _this._onerror();
                };
                this._img.src = this.src;
        }
};

POI.util.DialogBox = function(options) {
    this.options = {
        width: 200,
        height: 100,
        borderWidth: 1,
        borderColor: "rgba(0,0,0,1)",
        borderRadius: 5,
        backgroundColor: "rgba(0,0,0,0)",
        arrowDirection: 0,
        arrowDistance: 90,
        arrowWidth: 20,
        arrowHeight: 20
    };
    for(var p in options) {
        if(options.hasOwnProperty(p)) {
            this.options[p] = options[p];
        }
    }
    this.canvas = this.createCanvas();
    this.ctx = this.canvas.getContext("2d");
    this.dataTransform();
    this.draw();
    return this.canvas;
}
POI.util.DialogBox.prototype = {
    
    ratio : window.devicePixelRatio || 1,
    
    createCanvas : function() {
        var options = this.options;
        var ratio = this.ratio;
        var canvas = document.createElement("canvas");
        canvas.width = options.width * ratio;
        canvas.height = (options.height + options.arrowHeight + options.borderWidth) * ratio;
        canvas.style.cssText = "width:" + options.width + "px;height:" + (options.height + options.arrowHeight + options.borderWidth) + "px;";
        return canvas;
    },
    
    dataTransform : function() {
        var options = this.options;
        var ratio = this.ratio
        options.width *= ratio;
        options.height *= ratio;
        options.borderWidth *= ratio;
        options.borderRadius *= ratio;
        options.arrowWidth *= ratio;
        options.arrowHeight *= ratio;
        options.arrowDistance *= ratio;
    },
    
    draw : function() {
        var ctx = this.ctx;
        var options = this.options;
        var offset = options.borderWidth / 2;
        ctx.translate(0, options.arrowHeight + offset*2);
        ctx.beginPath();
        ctx.moveTo(offset, options.borderRadius + offset);

        ctx.arc(options.borderRadius + offset, options.borderRadius + offset, options.borderRadius, Math.PI, Math.PI*3/2, false);
        ctx.lineTo(options.arrowDistance, offset);
        ctx.lineTo(options.arrowDistance + options.arrowWidth / 2, -options.arrowHeight);
        ctx.lineTo(options.arrowDistance + options.arrowWidth, offset);
        ctx.lineTo(options.width - options.borderRadius - offset, offset);

        ctx.arc(options.width - options.borderRadius - offset, options.borderRadius + offset, options.borderRadius, -Math.PI/2, 0, false);
        ctx.lineTo(options.width - offset, options.height - options.borderRadius - offset);
        
        ctx.arc(options.width - options.borderRadius - offset, options.height - options.borderRadius - offset, options.borderRadius, 0, Math.PI/2, false);
        ctx.lineTo(options.borderRadius + offset, options.height - offset);
        
        ctx.arc(options.borderRadius + offset, options.height - options.borderRadius - offset, options.borderRadius, Math.PI/2, Math.PI, false);
        ctx.lineTo(offset, options.borderRadius + offset);

        ctx.closePath();
        ctx.fillStyle = options.backgroundColor;
        ctx.fill();
        ctx.lineWidth = options.borderWidth;
        ctx.strokeStyle = options.borderColor;
        ctx.stroke();
    }
};

POI.util.DrawPie = function( canvas, count ){
    this.ratio = window.devicePixelRatio | 2;
    this.canvas = canvas;
    this.canvas.style.width = this.canvas.width + "px";
    this.canvas.style.height = this.canvas.height + "px";
    this.canvas.setAttribute("width", this.canvas.width * this.ratio);
    this.canvas.setAttribute("height", this.canvas.height * this.ratio);
    
    this.ctx = this.canvas.getContext( '2d' );
    this.width = this.canvas.width;
    this.height = this.canvas.height;
    this.radius = this.canvas.height/2;//最外层圆的半径
    this.rander_radius = 3 * this.ratio;//着色环的宽度
    this.count = count;//百分比
    this.init();
    window.ctx = this.ctx;
}
POI.util.DrawPie.prototype = {
    constructor: POI.util.DrawPie,
    init : function(){
        var self = this;
        self.canvas.width = this.width;
        self.canvas.height = this.height;
        self.ctx.translate(this.width/2,this.height/2);
        self.draw();
    },
    draw : function() {
        var self = this, ctx = self.ctx,text = self.count;
        ctx.beginPath();
        ctx.fillStyle = '#ebecec';
        ctx.arc(0,0,self.radius,0,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        self.draw_pie();
        //画中间的空心白园
        ctx.beginPath();
        ctx.fillStyle = '#fff';
        ctx.arc(0,0,self.radius-self.rander_radius,0,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        //写字,指数
        ctx.font = (14 * self.ratio) + "px Arial";
        ctx.fillStyle = '#333';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text.score, 0, -7 * self.ratio);
        //写字，文字
        ctx.font = (14 * self.ratio) + "px STXihei";
        ctx.fillStyle = '#666';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text.name, 0, 9 * self.ratio);
    },
    draw_pie : function(){
        var self = this,ctx = self.ctx,
            deg = Math.PI*2 * self.count.score / 5;
        ctx.save();
        ctx.rotate(-Math.PI/2);
        ctx.beginPath();
        ctx.moveTo(0,0);
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,this.radius,0,deg);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        self.draw_radius( deg );
    },
    draw_radius : function( deg ) {//画圆角
        var self = this, rander_radius = self.rander_radius,
            ctx = self.ctx,
            radius = self.radius;
        //上半圆角
        ctx.save();
        ctx.rotate(-Math.PI/2);
        ctx.translate(radius-rander_radius/2,0);
        ctx.beginPath();
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,rander_radius/2,Math.PI,Math.PI*2);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
        
        //下半圆角
        ctx.save();
        ctx.rotate(deg-Math.PI/2);
        ctx.translate(radius-rander_radius/2,0);
        ctx.beginPath();
        ctx.fillStyle = '#57b3ff';
        ctx.arc(0,0,rander_radius/2,0,Math.PI);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
    }
};


$(function() {
    $(window)
        .bind('touchstart mousedown', function(event) {
            //手指按下变色效果
            $(event.target).closest(".canTouch,.more,.more-bottom-blue").addClass('hover');
        }).bind('touchmove touchend mouseup', function() {
            // 取消手指按下样式
            $('.hover').removeClass('hover');
        });
});

})(POI, window);

;(function() {
    var agent = navigator.userAgent.toLowerCase();        //检测是否是ios
    var iLastTouch = null;                                //缓存上一次tap的时间
    if (agent.indexOf('iphone') >= 0 || agent.indexOf('ipad') >= 0) {
        document.body.addEventListener('touchend', function(event) {
            var iNow = new Date().getTime();
            iLastTouch = iLastTouch || iNow + 1 /** 第一次时将iLastTouch设为当前时间+1 */ ;
            var delta = iNow - iLastTouch;
            if (delta < 500 && delta > 0) {
                event.preventDefault();
                return false;
            }
            iLastTouch = iNow;
        }, false);
    }
})();

/**
 * 显示title bar
 */
(function(POI, $) {

    'use strict';
    
    window.hasWebPageTitleBar = false;
    
    if (POI.util.getUrlParam('hideTitleBar')) {
        return;
    }
    
    // TODO 附近 -> 看电影 -> 选择电影院
    var noTitleBarAry = {
            "exHotelCalendar"     : 1,
            "exHotelOrderDetail"  : 1,
            "hotelOrderDetail"    : 1,
            "queueOrderList"      : 1,
            "exMovieDetail"       : 1,
            "exMovieShowings"     : 1,
            "exMovieTuan"         : 1,
            "exMovieList"         : 1,
            "exTuangou"           : 1,
            "exScenicOrderDetail" : 1,
            "shareToCar/index"    : 1,
            "exCouponDetail"      : 1,
            "indoor"              : 1
        };

    var isShowTitleBar = POI.util.getUrlParam('showTitleBar');
    for (var key in noTitleBarAry) {
        if ( -1 !== location.href.indexOf("/" + key + '.html') && !isShowTitleBar ) {
            return;
        }
    }

    window.hasWebPageTitleBar = true;
    
    var agent = navigator.userAgent,
        os = agent.match(/iphone|ipad|ipod/i) ? "ios" : "android",
        isIndex = /\/index.html/.test(location.href),
        // todo: 测试用例
        //isIndex = /\/poiHead.html/.test(location.href),
        body = document.body,
        headerDom = document.createElement("nav"),
        titleBarHeight = 0;

    headerDom.id = "poiTitleBar";
    if("android" === os) {
        if(isIndex) {
            headerDom.className = "topBar indexBar transparent";
        } else {
            headerDom.className = "topBar";
            body.style.paddingTop = "44px";
        }
        titleBarHeight = 44;
    } else {
        if(isIndex) {
            headerDom.className = "topBar ver7 indexBar transparent";
        } else {
            headerDom.className = "topBar ver7";
            body.style.paddingTop = "64px";
        }
        titleBarHeight = 64;
    }
    headerDom.innerHTML = '<a id="webviewGoBack" href="javascript:void(0);" class="topBar_back canTouch"><i class="topBar_arrow"></i></a>' +
                          '<div class="topBar_wrapper">' +
                              '<p id="topBarName" class="topBar_name linesDot' + (isIndex ? ' topBar_opacity0' : '') + '">' + document.title + '</p>' +
                          '</div>' +
                          '<div id="titleBarBtns" class="topBar_btns">' +
                              (isIndex ? 
                              '<div class="topBar_ibox">' +
                                  '<i id="favorite" class="topBar_i1"></i><i id="poiShare" class="topBar_i2"></i>' +
                              '</div>' +
                              '<i id="gohereBar" class="topBar_i3 hid">路线</i>' : '')+
                          '</div>';

    body.insertBefore(headerDom, body.firstChild);

    POI.util.setPageTitle = function(title) {
        if(title) {
            $("#topBarName").text(title);
        }
    };
    POI.util.getTitleBarHeight = function() {
        return titleBarHeight;
    };
    POI.util.registerRightBtn = function( html, fun) {
        $( '#titleBarBtns' ).html( html );
        rightBtnClick = fun;
    };
    var rightBtnClick = function(){};
    var click = function(ele, handler, once) {
        var startTime = 0,
            startPos = {
                x: 0,
                y: 0
            };
        var start = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            startTime = new Date();
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            ele.addEventListener("touchmove", move, false);
            ele.addEventListener("touchend", end, false);
            if(e.touches) {
                startPos.x = e.touches[0].pageX;
                startPos.y = e.touches[0].pageY;
                var tar = e.target;
                tar.className = tar.className + " hover";
                setTimeout(function() {
                    tar.className = tar.className.replace(" hover", "");
                }, 300);
            }
            e.stopPropagation();
        },
        move = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            if(5 < Math.abs(e.touches[0].pageX - startPos.x) || 5 < Math.abs(e.touches[0].pageY - startPos.y)) {
                ele.removeEventListener("touchmove", move, false);
                ele.removeEventListener("touchend", end, false);
                e.stopPropagation();
            } else {
                var tar = e.touches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
        },
        end = function(e) {
            var endTime = new Date();
            if(200 > (endTime - startTime)) {
                handler.call(null, e);
                if(once) {
                    ele.removeEventListener("touchstart", start, false);
                }
            }
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            if(e.changedTouches) {
                var tar = e.changedTouches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
            e.preventDefault();
            e.stopPropagation();
        };
        ele.addEventListener("touchstart", start, false);
    };
    //var $titleBar = $('#poiTitleBar');
    //$titleBar.on('click', '#webviewGoBack', function(e) {
    //    POI.api.webviewGoBack();
    //});
    click($("#webviewGoBack")[0], function() {
        try {
            var inputs = $("input, textarea");
            for(var i = 0, len = inputs.length; i < len; i++) {
                inputs[i].blur();
            }
        } catch(e) {}
        POI.api.webviewGoBack();
    });
    click( $( '#titleBarBtns' )[0], function( e ){
        rightBtnClick.call(POI, e, $( '#titleBarBtns' ));
    });
    if(isIndex) {
        //$titleBar.on('click', '#favorite', function() {
        //    var self = POI, o = $( this );
        //    self.api.toggleFavoritePoint(self.clientData.poiInfo, function(res) {
        //        if (res.result != 1) {
        //            return;
        //        }
        //        o.hasClass('favorited') && $('#MyFavInfo').remove();
        //        o.toggleClass('favorited');
        //    });
        //    self.api.userAction('favorite');
        //});
        var favorite = $("#favorite")[0];
        click(favorite, function() {
            var self = POI, o = $( favorite );
            var name = self.util.bool(self.clientData.poiInfo.name) ? self.clientData.poiInfo.name : '';
            if(!name && self.aosData && self.aosData.base.name) {
                name = self.aosData.base.name;
            }
            if (self.clientData.CURRENT_BUS_ALIAS) {
                self.clientData.poiInfo.CURRENT_BUS_ALIAS = self.clientData.CURRENT_BUS_ALIAS;
            }
            if(!self.clientData.poiInfo.new_type) {
                self.clientData.poiInfo.new_type = self.aosData ? self.aosData.base.new_type : "";
            }
            if(!self.clientData.poiInfo.address) {
                self.clientData.poiInfo.address = self.aosData ? self.aosData.base.address : "";
            }
            self.api.toggleFavoritePoint(self.clientData.poiInfo, function(res) {
                self.clientData.poiInfo.name = name;
                if (res.result != 1) {
                    return;
                }
                o.hasClass('favorited') && $('#MyFavInfo').remove();
                o.toggleClass('favorited');
            });
            self.api.userAction('favorite');
        });
        
        //$titleBar.on('click', '#poiShare', function() {
        //    var self = POI;
        //    self.api.shareToFriends(self.clientData.poiInfo);
        //    self.api.userAction('barpoishare');
        //});
        click($("#poiShare")[0], function() {
            var self = POI;
            self.api.shareToFriends(self.clientData.poiInfo);
            self.api.userAction('barpoishare');
        });
        //$titleBar.on('click', '#gohereBar', function() {
        //    var self = POI;
        //    self.api.searchRoute(null, self.clientData.poiInfo);
        //    self.api.userAction('bargohere');
        //});
        click($("#gohereBar")[0], function() {
            var self = POI;
            self.api.searchRoute(null, self.clientData.poiInfo);
            self.api.userAction('bargohere');
        });
        
        var poiTitleBar = $("#poiTitleBar");
        var $titleBarBtns = $("#titleBarBtns");
        var nameShow = false;
        var nameShowFinish = false;
        var gohereShow = false;
        var gohereShowFinish = false;
        var backgroundShowing = false;
        var backgroundShown = false;
        var $name = $("#topBarName");
        var $gohere = $("#gohereBar");
        var mainDom = null;
        var titleDom = null;
        var gohereDom = null;
        var mainPos = 0;
        var titlePos = 0;
        var goherePos = 0;
        var iosBackgroundRange = 28;
        var iosCommonRange = 50;
        var backgroundRangeFlag = false; // ios触发scroll事件时正好位于中间地带的标识
        //var timer;
        var titleIconFlag = 0;
        var changeIcon = function(flag) {
            if(1 == flag) {
                poiTitleBar.removeClass("transparent");
            } else {
                poiTitleBar.addClass("transparent");
            }

        };
        var touchStart = function() {
            if(0 === titlePos) {
                if(!mainDom) {
                    mainDom = document.querySelector(".poihead_cont");
                    titleDom = mainDom.querySelector(".name");
                    gohereDom = mainDom.querySelector(".line");
                }
                if(mainDom) {
                    var mainDomRect = mainDom.getBoundingClientRect();
                    mainPos = mainDomRect.top - titleBarHeight;
                }
                if (gohereDom) {
                    var gohereDomRect = gohereDom.getBoundingClientRect();
                    goherePos = gohereDomRect.top + gohereDomRect.height - titleBarHeight;
                }
                if(titleDom) {
                    var titleDomRect = titleDom.getBoundingClientRect();
                    titlePos = titleDomRect.top + titleDomRect.height - titleBarHeight - 10;
                    window.removeEventListener("touchstart", touchStart, false);
                }
            }
        };
        var androidScroll = function() {
            if(!titlePos) return;
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop + iosBackgroundRange) {
                if(!backgroundShown) {
                    changeIcon(1);
                    backgroundShown = true;
                    poiTitleBar.removeClass("topBar_bg_transition").addClass("topBar_bg_transition");
                    setTimeout(function() {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)");
                    }, 0);
                }
            } else {
                if(backgroundShown) {
                    changeIcon(0);
                    backgroundShown = false;
                    poiTitleBar.removeClass("topBar_bg_transition").addClass("topBar_bg_transition");
                    setTimeout(function() {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)");
                    }, 0);
                }
            }

            if(titlePos < scrollTop) {
                if(!nameShow) {
                    $name.css("opacity", "1");
                    nameShow = true;
                }
            } else {
                if(nameShow) {
                    $name.css("opacity", "0");
                    nameShow = false;
                }
            }
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    $titleBarBtns.addClass("topBar_gohere_show");
                    setTimeout(function() {
                        $gohere.css("opacity", "1");
                    }, 0);
                    gohereShow = true;
                }
            } else {
                if(gohereShow) {
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    gohereShow = false;
                }
            }
        };
        var iosMove = function() {
            if(!mainPos) {
                return;
            }
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop) {
                backgroundRangeFlag = false;
                if(!titleIconFlag) {
                    titleIconFlag = 1;
                    changeIcon(1);
                }
                if(!backgroundShown) {
                    poiTitleBar.css("background-color", "#fff").removeClass("indexBar");
                    backgroundShown = true;
                    backgroundShowing = false;
                }
            } else {
                if(mainPos < scrollTop + iosBackgroundRange) {
                    if(!titleIconFlag) {
                        titleIconFlag = 1;
                        changeIcon(1);
                    }
                    if(!backgroundRangeFlag) {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, " + ((scrollTop + iosBackgroundRange - mainPos) / iosBackgroundRange) + ")");
                        if(backgroundShown && !backgroundShowing) {
                            poiTitleBar.addClass("indexBar");
                        }
                    }
                    backgroundShown = false;
                    backgroundShowing = true;
                } else {
                    if(titleIconFlag) {
                        titleIconFlag = 0;
                        changeIcon(0);
                    }
                    backgroundRangeFlag = false;
                    if(!backgroundShown && backgroundShowing) {
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)").removeClass("indexBar").addClass("indexBar");
                        backgroundShown = false;
                        backgroundShowing = false;
                    }

                }
            }

            if(!titlePos) {
                return;
            }
            if(titlePos < scrollTop) {
                if(!nameShowFinish) {
                    if((titlePos + iosCommonRange) > scrollTop) {
                        $name.css("opacity", 1 - ((titlePos + iosCommonRange) - scrollTop) / iosCommonRange);
                        nameShow = true;
                    } else {
                        $name.css("opacity", "1");
                        nameShowFinish = true;
                        nameShow = true;
                    }
                }
            } else {
                if(nameShowFinish || nameShow) {
                    $name.css("opacity", "0");
                    nameShowFinish = false;
                    nameShow = false;
                }
            }
            
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    $titleBarBtns.addClass("topBar_gohere_show");
                    gohereShow = true;
                }
                if(!gohereShowFinish) {
                    if((goherePos + iosCommonRange) > scrollTop) {
                        $gohere.css("opacity", 1 - ((goherePos + iosCommonRange) - scrollTop) / iosCommonRange);
                    } else {
                        gohereShowFinish = true;
                        $gohere.css("opacity", "1");
                    }
                }
            } else {
                if(gohereShowFinish) {
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    gohereShow = false;
                    gohereShowFinish = false;
                }
            }

        };
        var iosScroll = function() {
            if(!mainPos) {
                return;
            }
            var scrollTop = document.body.scrollTop;

            if(mainPos < scrollTop) {
                if(!titleIconFlag) {
                    titleIconFlag = 1;
                    changeIcon(1);
                }
                backgroundRangeFlag = false;
                if(!backgroundShown) {
                    backgroundShown = true;
                    backgroundShowing = false;
                    poiTitleBar.addClass("topBar_bg_transition");
                    poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)").removeClass("indexBar");
                    setTimeout(function() {
                        poiTitleBar.removeClass("topBar_bg_transition");
                    }, 217);
                }
            } else {
                if(mainPos < scrollTop + iosBackgroundRange) {
                    if(!titleIconFlag) {
                        titleIconFlag = 1;
                        changeIcon(1);
                    }
                    backgroundRangeFlag = true;
                    if(!backgroundShown) {
                        backgroundShown = false;
                        backgroundShowing = true;
                        poiTitleBar.addClass("topBar_bg_transition");
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 1)").removeClass("indexBar");
                        setTimeout(function() {
                            poiTitleBar.removeClass("topBar_bg_transition");
                        }, 217);
                    }
                } else {
                    if(titleIconFlag) {
                        titleIconFlag = 0;
                        changeIcon(0);
                    }
                    if(backgroundShowing || backgroundShown) {
                        backgroundRangeFlag = false;
                        backgroundShowing = false;
                        backgroundShown = false;
                        poiTitleBar.addClass("topBar_bg_transition");
                        poiTitleBar.css("background-color", "rgba(255, 255, 255, 0)").addClass("indexBar");
                        setTimeout(function() {
                            poiTitleBar.removeClass("topBar_transition");
                        }, 217);
                    }
                }
            }

            if(!titlePos) {
                return;
            }
            if(titlePos < scrollTop) {
                if(!nameShowFinish) {
                    nameShowFinish = true;
                    $name.addClass("topBar_transition");
                    $name.css("opacity", "1");
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            } else {
                if(nameShowFinish) {
                    nameShowFinish = false;
                    $name.addClass("topBar_transition");
                    $name.css("opacity", "0");
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            }
            
            if(0 === goherePos) {
                return;
            }
            if(goherePos < scrollTop) {
                if(!gohereShow) {
                    gohereShow = true;
                    $titleBarBtns.addClass("topBar_gohere_show");
                }
                if(!gohereShowFinish) {
                    gohereShowFinish = true;
                    $gohere.addClass("topBar_transition");
                    setTimeout(function() {
                        $gohere.css("opacity", "1");
                    }, 0);
                    setTimeout(function() {
                        $name.removeClass("topBar_transition");
                    }, 217);
                }
            } else {
                if(gohereShow) {
                    gohereShow = false;
                    gohereShowFinish = false;
                    $titleBarBtns.removeClass("topBar_gohere_show");
                    $gohere.css("opacity", "0");
                    $gohere.removeClass("topBar_transition");
                }
            }
        };
        var init = function() {
            if(isIndex) {
                window.addEventListener("touchstart", touchStart, false);
            }
            if("android" === os) {
                $name.addClass("topBar_transition");
                $gohere.addClass("topBar_transition");
                window.addEventListener("scroll", androidScroll, false);
            } else {
                window.addEventListener("touchmove", iosMove, false);
                window.addEventListener("scroll", iosScroll, false);
                /*
                window.addEventListener("touchend", function(e){
                    clearTimeout(timer);
                    timer = setTimeout(function(){
                        document.body.scrollTop = document.body.scrollTop;
                    }, 350);
                }, false);
                iphone5s下摸一次屏幕会导致内容往上跑1px
                */
            }
        };
        document.addEventListener("DOMContentLoaded", init, false);
    }
    
    
    
})(POI, Zepto);

