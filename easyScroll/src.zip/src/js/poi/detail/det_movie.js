﻿;(function(POI, $) {

'use strict';

$.extend(POI, {
    
    //电影介绍
    pushMovieSpec: function(deep){
        // console.log(deep)
        var movieSpec = [];
        if (!deep.service_imax && !deep.child_benefit && !deep.sale && !deep._3d_free_deposit) {
            return "";
        }
        movieSpec.push('<article><h1 class="intro_title">影院特色</h1><p>');
        if (deep.service_imax) {
            movieSpec.push('<p class="intro_desc">IMAX：'+deep.service_imax+'</p>');
        }
        if (deep.child_benefit) {
            movieSpec.push('<p class="intro_desc">儿童票：'+deep.child_benefit+'</p>');
        }
        if (deep.sale) {
            movieSpec.push('<p class="intro_desc">卖品：'+deep.sale+'</p>');
        }
        if (deep._3d_free_deposit) {
            movieSpec.push('<p class="intro_desc">3D眼镜：'+deep._3d_free_deposit+'</p>');
        }
        movieSpec.push('</article>');
        return movieSpec.join('');
    },
    
    moviePageList : function(introStr) {
        //var pic = this.aosData.pic,
        //    param = {
        //        type: 'poiface',
        //        poiid: this.aosData.base.poiid
        //    }, picStr;
        //param = JSON.stringify(param);
        //picStr = this.util.modulePicList(pic.gallery, pic.pic_count, param);
        //if (picStr) {
        //    picStr = '<section class="notop">' + picStr + '</section>';
        //}
        //this.pagebody.html(picStr + introStr);
        this.pagebody.html(introStr);
        POI.util.executeAfterDomInsert();
    },
    
    indexDetail : function() {
        var deep = this.aosData.deep[0] || {};
        this.moviePageList(
            this.showIntro(this.business, deep, this.pushMovieSpec(deep))
        );
        
    }
});

})(POI, $);
