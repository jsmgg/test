﻿;(function(POI, $) {

'use strict';

$.extend(POI, {
    
    showBuildingDetail : function(deep) {
        var arr = [];
        var baseArray = [
                //小区楼盘
                [
                    ["产权", "land_year"],
                    ["建筑面积", "area_total"],
                    ["容积率", "volume_rate"],
                    ["绿化率", "green_rate"],
                    ["停车位", "service_parking"],
                    ["物业费", "property_fee"],
                    ['开盘时间', 'opening_data'],
                    ['入住时间', 'checkin_data'],
                    ['售楼处地址', 'sales_addr'],
                    ['装修情况', 'renovation'],
                    ['建筑类型', 'building_types'],
                    ['开发商', 'developer'],
                    ['物业公司', 'property_company'],
                    ['建筑面积', 'area_total'],
                    ['占地面积', 'floor_area'],
                    ['土地年限', 'land_year'],
                    ['车位', 'service_parking'],
                    ['暖气', 'heating'],
                    ['供水系统', 'watersupply_syst'],
                    ['销售许可', 'sales_lice'],
                    ['周边配置', 'peripheral_supp']
                ]
            ];

        var intro = baseArray[0];
        for (var i = 0, len = intro.length; i < len; i++) {
            var key = intro[i][1], item = deep[key];
            if (item && !/^\s+$/.test(item)) {//有的字段会出现空白字符
                arr.push('<article>'+ intro[i][0] +'：' + item + '</article>');
            }
        }

        if (arr.length) {
            return '<section class="intro intro-building" id="buildingInfo">' +
                       '<h2 class="module_title">楼盘信息</h2>' +
                       arr.join('') +
                   '</section>';
        } else {
            return '';
        }
    },
    
    buildingPageList : function(detailStr, introStr) {
        //var pic = this.aosData.pic;
        //var param = {
        //    type: 'poiface',
        //    poiid: this.aosData.base.poiid
        //};
        //param = JSON.stringify(param);
        //var picStr = this.util.modulePicList(pic.gallery, pic.pic_count, param);
        //if (picStr) {
        //    picStr = '<section class="notop">' + picStr + '</section>';
        //}
        //var htmlStr = picStr + detailStr + introStr;
        var dataForm = '<p class="dataForm">数据来源：焦点房产</p>';
        var htmlStr = detailStr + introStr + dataForm;
        this.pagebody.html(htmlStr);
        POI.util.executeAfterDomInsert();
    },
    
    indexDetail : function () {
        var poiData = this.aosData;
        if (!poiData) {
            return;
        }
        var deep = poiData.deep[0];
        
        this.buildingPageList(
            this.showBuildingDetail(deep),
            this.showIntro(this.business, deep)
        );
        
    }
    
});

})(POI, $);
