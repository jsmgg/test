(function(POI, $) {

'use strict';

$.extend(POI, {
    indexDetail: function() {
        var self = this;
        var deep = this.aosData.deep[0];
        var html = '';

        // 增加图片显示
        //var pic = self.aosData.pic;
        //var param = {
        //    type: 'poiface',
        //    poiid: self.aosData.base.poiid
        //};
        //param = JSON.stringify(param);
        //html = self.util.modulePicList(pic.gallery, pic.pic_count, param);
        //if (html) {
        //    html = '<section>' + html + '</section>';
        //}

        var season = '';
        if (deep.season && deep.season.length) {
            if (deep.season.length === 12) {
                season = '全年';
            }
            else {
                season = deep.season.join('月,') + '月';
            }
        }
        var obj = [
            {name: "开放时间", key: "opentime2"},
            {name: "最佳旅游时节", data: season},
            //{name: "景点特色", key: "special", more: true},
            {name: "景点简介", key: "intro", more: true}
        ];
        html += self.util.intro(obj);

        self.pagebody.html(html);
        var $introSpec = $('#intro #introSpec'),
            $introFold = $('#intro .introFold');
        new POI.util.toggleContent($introFold, $introSpec);

        self.util.executeAfterDomInsert();
    }
});

})(POI, $);
