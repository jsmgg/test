(function(POI, $) {

'use strict';

$.extend(POI, {
    indexDetail: function() {
        var self = this;
        var deep = this.aosData.deep[0];
        var html = '';

        //var pic = self.aosData.pic;
        //var param = {
        //    type: 'poiface',
        //    poiid: self.aosData.base.poiid
        //};
        //param = JSON.stringify(param);
        //html = self.util.modulePicList(pic.gallery, pic.pic_count, param);
        //if (html) {
        //    html = '<section>' + html + '</section>';
        //}

        html += this._formaIinstallation('酒店设施', deep.detail_facilities);
        html += this._formaIinstallation('酒店服务', deep.service);

        var obj = [
            {name: '酒店简介', more: true, key: 'intro'},
            {name: '餐饮设施', more: true, key: 'service_dinning'},
            {name: '会议设施', more: true, key: 'service_meeting'},
            {name: '客房设施', more: true, key: 'service_room'},
            {name: '周边环境', more: true, key: 'surrounding'}
        ];
        self.pagebody.html( html + self.util.intro(obj) );
        var $introSpec = $('#intro #introSpec'),
            $introFold = $('#intro .introFold');
        new POI.util.toggleContent($introFold, $introSpec);
        self.util.executeAfterDomInsert();
    },
    /**
     * 生成蓝色框包含的标签信息.
     * @param {String} name 模块标题
     * @param {String} value 内容，标签以“|”分隔
     * @return {String}
     */
    _formaIinstallation: function(name, value) {
        if (!value) {
            return '';
        }
        return '<section class="intro"><article class="intro_con">' +
            '<h1 class="intro_title">' + name + '</h1>' +
            '<div class="installation">' +
            '<i class="tag half-border">' +
            value.replace(/\|/g, '</i><i class="tag half-border">') +
            '</i>' +
        '</article></section>';
    }
});

})(POI, $);
