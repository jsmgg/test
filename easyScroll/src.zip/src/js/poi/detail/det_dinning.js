﻿(function(POI, $) {

'use strict';

$.extend(POI, {
    
    showTextPromotion : function(textPromotion) {
        if(!textPromotion) {
            return '';
        }
        // todo
        //Log.userAction("merchant_text_" + textPromotion.promotion_id);
        return '<aside id="wordActivities">' +
                   '<div>'+
                       '<h5 class="lineDot">' + textPromotion.promotion_title + '</h5>'+
                       '<hgroup>'+
                           '<p class="linesDot">' + textPromotion.promotion_content + '</p>'+
                           '<time>' + textPromotion.promotion_efftime + '</time>'+
                       '</hgroup>'+
                   '</div>' +
               '</aside>';
    },
    
    showBannerPromotion : function(bannerPromotion) {
        if(bannerPromotion) {
            POI.util.executeAfterDomInsert(function() {
                var ba = $("#imgActivities");
                new POI.util.loadImage(ba.attr("icon"), ba[0], function(ele, img) {
                    var aImg = ba.find("img");
                    aImg.attr("src", img.src).show();
                    ba.show();
                    POI.api.userAction("merchant_banner_" + img.getAttribute("pid"));
                });
                
                POI.pagebody.on("click", "#imgActivities img", function() {
                    var ele = $(this);
                    POI.api.userAction("merchant_banner_click",{pageID : ele.attr("pid")});
                    var link = ele.attr("link");
                    
                    // todo 测试代码，用后删除
                    //link = link.replace("wap.amap.com", "group.myamap.com/deming.zhu");
                    //link = link + "&activity_title=活动标题";
                    
                    if(link) {
                        var schema = (POI.browser.ios ? "ios" : "android") + 'amap://openFeature?featureName=OpenURL&sa=1' +
                                '&sourceApplication=banner' +
                                '&url=' + encodeURIComponent(link) +
                                '&urlType=0&contentType=autonavi';
                        POI.api.loadSchema(schema);
                    }
                });
                
            });
            return '<aside id="imgActivities" icon="' + bannerPromotion.icon + '"><img pid="' + bannerPromotion.promotion_id + '" link="' + bannerPromotion.promotion_link + '"></img></aside>';
        } else {
            return '';
        }
    },
    
    dinningPageList : function(textPromotion, bannerPromotion, introStr) {
        var htmlStr = textPromotion + bannerPromotion + introStr;
        this.pagebody.html(htmlStr);
        POI.util.executeAfterDomInsert();
    },
    
    indexDetail : function() {
        var deep = this.aosData.deep[0] || {},
            rti = this.aosData.rti || {},
            cprInfo = rti.cpr_info || {}
        this.dinningPageList(
            this.showTextPromotion(cprInfo.text_promotion),
            this.showBannerPromotion(cprInfo.banner_promotion),
            this.showIntro(this.business, deep)
        );
        
    }
});

})(POI, $);
