(function(POI, $) {

'use strict';

$.extend(POI, {
    indexDetail: function() {
        var self = this;
        var deep = this.aosData.deep[0];
        //var html = '';
        //
        //var pic = self.aosData.pic;
        //var param = {
        //    type: 'poiface',
        //    poiid: self.aosData.base.poiid
        //};
        //param = JSON.stringify(param);
        //html = self.util.modulePicList(pic.gallery, pic.pic_count, param);
        //if (html) {
        //    html = '<section>' + html + '</section>';
        //}
        //self.pagebody.html( html + self.get_intro( deep ) );
        self.pagebody.html( self.get_intro( deep ) );
        var $introSpec = $('#intro #introSpec'),
            $introFold = $('#intro .introFold');
        new POI.util.toggleContent($introFold, $introSpec);
        self.util.executeAfterDomInsert();
    },
    get_intro : function( deep ) {
        var html = [];
        if( deep.intro ) {
            html.push( '<section id="intro" class="intro education"><article class="intro_con">' );
            if( deep.badge_pic || deep.motto) {
                html.push( '<div class="intro_con_head"><h1 class="intro_title">概况</h1>' );
                deep.motto && html.push( '<em class="intro_tmp_title">'+ deep.motto +'</em>' );
                deep.badge_pic && html.push( '<img src="' + deep.badge_pic + '" width="40" height="40" class="intro_school_logo"/>' );
                html.push( '</div>' );
            } else {
                html.push( '<h1 class="intro_title">概况</h1>' );
            }
            html.push('<p id="introSpec" class="intro_desc limits">' + deep.intro + '</p><a class="introFold"></a>');
            html.push( '</article></section>' );
        }
        return html.join('');
    }
});

})(POI, $);
