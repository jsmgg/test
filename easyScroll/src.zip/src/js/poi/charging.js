/**
 * 充电桩相关
 */
;(function(POI, $) {
$.extend(POI,{
    chargeArticleArr: [],
    getChargeData: function(deep, data) {
        var that = this;
        
        var num = data == null ? null:(Number(data.slow_free) || 0)+(Number(data.fast_free) || 0);
        if (num == null) {
            if (!((deep.price_charging && deep.price_charging.length > 0) || (deep.charge_info && deep.charge_info.length > 0))) {
                return '';
            }
        }
        
        var pre_section = '<section class="charging">';
        var last_section = '</section>';
        var title_html = that.makeTitleHtml(deep, num);
        var article_html = that.makeArticleHtml(deep, data);

        return pre_section+title_html+article_html+last_section;
    },
    makeTitleHtml: function(deep, num) {
        var that = this;
        var res_html = '';

        var title_arr = [];
        if ((deep.price_charging && deep.price_charging.length > 0) || (deep.charge_info && deep.charge_info.length > 0)) {
            title_arr.push('充电速配');
            that.chargeArticleArr.push('charing_match');
            POI.api.userAction('showCharingMatch');
        }

        if (num != null || ((deep.num_fast && deep.num_fast != 0) || (deep.num_slow && deep.num_slow != 0)) ) {
            title_arr.push('电桩数量<button>'+num+'</button>');
            that.chargeArticleArr.push('realtime_available');
            POI.api.userAction('showRealtimeAvailable');
        }
        
        if (title_arr.length > 1) {
            var li_arr = [];
            for (var i=0; i<title_arr.length; i++) {
                var rel = i == 0?'#charing_match" class="on"':'#realtime_available"';
                var li_str = '<li rel="'+rel+'>'+title_arr[i]+'</li>';
                li_arr.push(li_str);
            }
            res_html = '<ul class="charge_type">'+li_arr.join('')+'</ul>';
        } else {
            res_html = '<div class="charge_type_one">'+title_arr[0]+'</div>';
        }
        return res_html;
    },
    makeArticleHtml: function(deep, data) {
        var that = this;
        var article1_html = '';
        var article2_html = '';
        var table_html = '';
        var chargeinfo_html = '';

        if (that.chargeArticleArr.length > 1) {
            table_html = that.makeTableHtml(deep);
            chargeinfo_html = that.makeChargeInfoHtml(deep);
            article1_html = '<article id="charing_match">'+table_html+chargeinfo_html+'</article>';
            article2_html = that.makeRealtimeHtml(deep, data);
        } else {
            if (that.chargeArticleArr[0] == 'charing_match') {
                table_html = that.makeTableHtml(deep);
                chargeinfo_html = that.makeChargeInfoHtml(deep);
                article1_html = '<article id="charing_match">'+table_html+chargeinfo_html+'</article>';
            } else {
                article2_html = that.makeRealtimeHtml(deep, data);
            }
        }
        return article1_html+article2_html;
    },
    charging_line: '-',
    makeTableHtml: function(deep) {
        var that = this;

        var arr = deep.charge_info;
        if (!deep.charge_info) {
            return '';
        }
        var type_mapping = {
            '0': '慢',
            '1': '快'
        };
        var line = that.charging_line;
        var tr_arr = [];
        var tr_title = '<tr class="title">'+
                       '<td class="w1">插孔</td>'+
                       '<td class="w2">交直流</td>'+
                       '<td class="w3">速度</td>'+
                       '<td class="w4">品牌</td>'+
                       '</tr>';

        for(var i=0; i<arr.length; i++) {
            var tr_str = '<tr>'+
                         '<td class="w1">'+(arr[i].plugstype || line)+'</td>'+
                         '<td class="w2">'+(arr[i].vol_type || line)+'</td>'+
                         '<td class="w3">'+(type_mapping[arr[i].plugs_info[0].speed_type] || line)+'</td>'+
                         '<td class="w4">'+(arr[i].plugs_info[0].brand_desc || line)+'</td>'+
                         '</tr>';
            tr_arr.push(tr_str);
        }
        return '<table class="divide-line all-line">'+tr_title+tr_arr.join('')+'</table>';
    },
    makeChargeInfoHtml: function(deep) {
        var that = this;

        var arr = deep.price_charging;
        if (!arr) {
            return '';
        }
        var li_arr = [];
        var li_title = '<ul class="title">'+
                       '<li class="charge_time">时间</li>'+
                       '<li class="flex"></li>'+
                       '<li class="charge_money">充电费</li>'+
                       '<li class="flex"></li>'+
                       '<li>服务费</li>'+
                       '</ul>';
        var resource = '';
        var li_cont = '';

        for (var i=0; i<arr.length; i++) {
            var ele_price = arr[i].ele_price ?arr[i].ele_price+'元/度':'-';
            var ser_price = arr[i].ser_price ?arr[i].ser_price+'元/度':'-';
            var time = '-';
            if (arr[i].time) {
                if (arr[i].time == '00:00-24:00' || arr[i].time == '00:00~24:00') {
                    time = '&nbsp;&nbsp;&nbsp;24小时';
                } else {
                    time = arr[i].time;
                }
            }
            var li_str = '<li class="divide-line">'+
                         '<p class="p1">'+time+'</p>'+
                         '<p class="flex"></p>'+
                         '<p class="p2">'+ele_price+'</p>'+
                         '<p class="flex"></p>'+
                         '<p class="p3">'+ser_price+'</p>'+
                         '</li>';
            li_arr.push(li_str);
        }
        if (deep.price_parking && deep.price_parking.length > 0) {
            li_arr.push('<li class="divide-line parking"><span>停车价格</span>'+deep.price_parking+'</li>');
        }
        li_cont = '<ul class="cont">'+li_arr.join('')+'</ul>';
        if (deep.charge_src_name && deep.charge_src_name.length > 0) {
            resource = '<p class="resource">信息来源：'+deep.charge_src_name+'</p>';
        }

        return '<div class="charge-info">'+li_title+li_cont+resource+'</div>';
    },
    makeRealtimeHtml: function(deep, data) {
        var that = this;

        var pre_article = that.chargeArticleArr.length > 1 ?'<article id="realtime_available" class="hide"><ul>':'<article id="realtime_available"><ul>';
        var last_article = '</ul></article>';

        var li_title = '<li>';

        if (deep.num_fast && deep.num_fast != 0) {
            li_title += '<p>快速充电桩</p>';
        }

        if (deep.num_slow && deep.num_slow != 0) {
            li_title += '<p>慢速充电桩</p>';
        }

        li_title += '</li>';
        var fast_str = '';
        var slow_str = '';

        if (deep.num_fast && deep.num_fast != 0) {
            var fast_free = data.fast_free || data.fast_free == 0?'&nbsp;&nbsp;&nbsp;<span>空闲<i>'+data.fast_free+'</i>个</span>':'';
            fast_str = '<p>共'+deep.num_fast+'个'+fast_free+'</p>';
        }

        if (deep.num_slow && deep.num_slow != 0) {
            var slow_free = data.slow_free || data.slow_free == 0?'&nbsp;&nbsp;&nbsp;<span>空闲<i>'+data.slow_free+'</i>个</span>':'';
            slow_str = '<p>共'+deep.num_slow+'个'+slow_free+'</p>';
        }

        var li_cont = '<li>'+fast_str+slow_str+'</li>';

        return pre_article+li_title+li_cont+last_article;
    },
    showChargeIntro: function(deep) {
        var that = this;

        if (!deep.opentime2 && !deep.pay_type) {
            return '';
        } else {
            if (deep.opentime2 && deep.opentime2.length < 1) {
                return '';
            } else if (deep.pay_type && deep.pay_type.length < 1) {
                return '';
            }
        }

        var mapping = {
            '1': '现金',
            '2': '银行卡',
            '3': '手机钱包',
            '4': '充值卡'
        };
        var pre_section = '<section class="charging_detail divide-line"><h2 class="module_title_p line-half">详情</h2><div>';
        var last_section = '</div></section>'

        var time_str = '';
        if (deep.opentime2 && deep.opentime2.length > 0) {
            if (deep.opentime2 == '00:00-23:59' || deep.opentime2 == '00:00-24:00') {
                time_str = '<p><span>营业时间</span>24小时</p>';
            } else {
                time_str = '<p><span>营业时间</span>'+deep.opentime2+'</p>';
            }
        }
        var pay_str = '';
       
        if (deep.pay_type && deep.pay_type.length > 0) {
             var pay_arr = deep.pay_type.split(';');
             var str_arr = [];
             for (var i=0; i<pay_arr.length; i++) {
                str_arr.push(mapping[pay_arr[i]]);
             }
             pay_str = '<p><span>支付方式</span>'+str_arr.join('、')+'</p>';
        }
        POI.api.userAction('showChargingDetail');
        return pre_section+time_str+pay_str+last_section;    
    },
    bindEvent: function() {
        $('.charge_type').on('click', 'li', function() {
            var li = $(this);

            if (li.length) {
                li.addClass('on');
                li.siblings().removeClass('on');
                var rel = li.attr('rel');

                $(rel).removeClass('hide')
                        .siblings('article').addClass('hide');
                POI.api.userAction('chargeType', {type: rel.substr(1)});
            }
        });
    },
    buildingPageList: function(infoStr, intro) {
        var that = this;

        var allAry = this.index.moduleAll(['guidePicList', 'activityInfo', infoStr, intro, 'commentInfo', 'indoorMap', 'banner']);
        that.pagebody.html(allAry.join(""));
        POI.util.executeAfterDomInsert();
        that.bindEvent();
    },
    init:function(){
        var deep = this.aosData.deep[0];
        var rti = this.aosData.rti;
        this.index.moduleDeepHead();

        if (rti.charge_status_info && rti.charge_status_info.src_type && rti.charge_status_info.src_id && rti.charge_status_info.src_type.length > 0 && rti.charge_status_info.src_id.length > 0) {
            var params = [
                {
                    'src_type': rti.charge_status_info.src_type,
                    'sign': 1
                },
                {
                    'src_id': rti.charge_status_info.src_id,
                    'sign': 1
                }
            ];
            
            POI.api.aosrequest('chargeLiveStatus', params, function(data) {
                if (data.code == 1) {

                    if (data.fast_free || data.slow_free) {                      
                        this.buildingPageList(
                            this.getChargeData(deep, data),
                            this.showChargeIntro(deep)
                        );
                    } else {
                        this.buildingPageList(
                            this.getChargeData(deep, null),
                            this.showChargeIntro(deep)
                        );
                    }
                }
            }, 0, true, "GET");
        } else {
            this.buildingPageList(
                this.getChargeData(deep, null),
                this.showChargeIntro(deep)
            );
        }
        
    }
});
})(POI, Zepto);