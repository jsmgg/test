/*火车站经验数据攻略
* @author jing.chu
*/
;(function(POI, $) {

var pageNum = 1,   //页数
    pageSize = 8,  //每一页的条目数
    pageCount = 1, //有多少页
    isMore = null; //是否有更多信息

$.extend(POI, {

    // 买点page标识
    logPageId : "strategy",

    poiId : "",
    
    quickInit : function() {
        var isListPage = /exStrategy\.html$/.test(location.pathname);
        if(isListPage) {
            this.reqListData();
        } else {
            this.showDetailInfo();
        }
    },
    
    //经验数据入口
    reqListData : function() {
        this.poiId = this.util.getUrlParam( 'poiid' );
        this.reqSend(this.poiId);
    },
    
    /*请求数据服务开始*/
    reqSend : function(poiId) {
        var _this = this,
            params = [
                {poiid: poiId, sign: 1},
                {page_num: pageNum},
                {page_size: pageSize}
            ];
        POI.api.aosrequest('strategyList', params, function(data){
            if(1 == data.code){
                _this.showListData(data);
            }else if(-1 == data.code || -2 == data.code){
				isMore.destory();
            }
        }, 0, 1, 'get');
    },
    
    /**
     * 火车站经验数据列表
     * @param data 列表数据
     */
    showListData : function(data) {
        var arr = [],
            len = data.total,
            lists = data.lists;
        pageCount = len / pageSize;// data.page_count;
        for(var i = 0, l = lists.length, qa = null, tmpNo = 0; i < l; i++) {
            qa = lists[i]; 
            if(qa.title && qa.content) {
                tmpNo = i + 1 + pageSize * (pageNum - 1);
                arr.push('<section class="canTouch" onclick="POI.util.locationRedirect(\'exStrategyDetail.html\')">',
                         '<div><h1>',
                         (tmpNo + '.' + qa.title),
                         '</h1><article>',
                         qa.content.words,
                         '</article></div></section>');
            }
        }
        $('#Strategy').append(arr.join('')).find('section').each(function(i) {
            var n = pageSize * (pageNum - 1);
            if(i >= n) {
                var wordList = lists[i-n];
                $(this).click(function() {
                    POI.util.storage('strategyTitle', wordList.title);
                    POI.util.storage('strategyWords', wordList.content.words);
                    if(wordList.content.action && wordList.content.action.length) {
                        POI.util.storage('strategyAction', JSON.stringify(wordList.content.action));
                    } else {
                        localStorage.removeItem('strategyAction');
                    }
                    POI.api.userAction(wordList.title.substring(0,5));
                });
            }
        });
        //下拉控件 如果只有一页不去请求
        if(len > pageSize) {
            if(pageNum >= pageCount) {
                isMore.destory();
            } else if(1 != pageNum) {
                isMore.refresh();
                pageNum++;
            } else {
                isMore = new POI.util.PullUpGetMore(function() {
                    POI.reqSend(POI.poiId);
                });
                pageNum++;
            }
        }
    },
    
    /**
     * 火车站经验数据详情 展示图文混排详情
     */
    showDetailInfo : function() {
        var sDetail = POI.util.storage('strategyWords'),
            sTitle = POI.util.storage('strategyTitle'),
            sAction = POI.util.storage('strategyAction');
        if(sTitle) {
            $("#sTitle").html(sTitle);
        }
        if(sDetail) {
            $("#sDetail").html(sDetail);
        }
        if(!sAction) return;
        var actions = JSON.parse(sAction);
        $('#sDetail b').each(function() {
            var src = $(this).attr('data-src');
            var poiid = $(this).attr('name');
            if(src && poiid) {
                $(this).click(function() {
                    for(var i = 0, al = actions.length, ac = null; i < al; i++) {
                        ac = actions[i];
                        if(ac.poiid == poiid) {
                            switch(ac.type) {
                                case 'openPoi':
                                    POI.api.openPoiInfo(
                                        ac.params.poiid,
                                        ac.params.name,
                                        ac.params.address,
                                        ac.params.cityCode,
                                        ac.params.new_type,
                                        ac.params.phoneNumbers,
                                        ac.params.lon,
                                        ac.params.lat
                                    );
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                });
            }
        });
    }
    
});


})(POI, Zepto);
