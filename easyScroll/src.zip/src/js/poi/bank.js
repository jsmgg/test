/*
 * 银行、atm行业
 */
;(function(POI, $){

$.extend(POI, {
    
    init : function() {
        this.index.moduleDeepHead();
        var introHtml = this.index.moduleIntro(["图片介绍", "", "详情"], ["intro", "opentime2", "b_sphere"]);
        var allAry = this.index.moduleAll(null, introHtml);
    }
    
    
    
});

})(POI, Zepto);