;(function($) {

    'use strict';
    
    if(-1 === location.href.indexOf("showTitleBar")) {
        return;
    }
    
    var agent = navigator.userAgent,
        os = agent.match(/iphone|ipad|ipod/i) ? "ios" : "android",
        version6 = /OS [1-6]/.test(agent),
        isIndex = /\/index.html/.test(location.href),
        body = document.body,
        headerDom = document.createElement("nav");

    headerDom.id = "poiTitleBar";
    if("android" === os) {
        body.style.paddingTop = "44px";
        headerDom.className = "topBar";
    } else {
        if(version6) {
            headerDom.className = "topBar";
            body.style.paddingTop = "44px";
        } else {
            headerDom.className = "topBar ver7";
            body.style.paddingTop = "64px";
        }
    }
    headerDom.innerHTML = '<a id="webviewGoBack" href="javascript:void(0);" class="topBar_back canTouch"><i class="topBar_arrow"></i></a>' +
                          '<div class="topBar_wrapper">' +
                              '<p id="topBarName" class="topBar_name linesDot' + (isIndex ? ' topBar_opacity0' : '') + '">' + document.title + '</p>' +
                          '</div>' +
                          '<div id="titleBarBtns" class="topBar_btns">' +
                              (isIndex ? 
                              '<div class="topBar_ibox">' +
                                  '<i id="favorite" class="topBar_i1"></i><i id="poiShare" class="topBar_i2"></i>' +
                              '</div>' +
                              '<i id="gohereBar" class="topBar_i3 hid">去这里</i>' : '')+
                          '</div>';

    body.insertBefore(headerDom, body.firstChild);
    
    window.setPageTitle = function(title) {
        if(title) {
            $("#topBarName").text(title);
        }
    };
    
    var click = function(ele, handler, once) {
        var startTime = 0,
            startPos = {
                x: 0,
                y: 0
            };
        var start = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            startTime = new Date();
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            ele.addEventListener("touchmove", move, false);
            ele.addEventListener("touchend", end, false);
            if(e.touches) {
                startPos.x = e.touches[0].pageX;
                startPos.y = e.touches[0].pageY;
                //var tar = e.target;
                //tar.className = tar.className + " hover";
                //setTimeout(function() {
                //    tar.className = tar.className.replace(" hover", "");
                //}, 300);
            }
            e.stopPropagation();
        },
        move = function(e) {
            if(e.touches && 1 < e.touches.length) return;
            if(5 < Math.abs(e.touches[0].pageX - startPos.x) || 5 < Math.abs(e.touches[0].pageY - startPos.y)) {
                ele.removeEventListener("touchmove", move, false);
                ele.removeEventListener("touchend", end, false);
                e.stopPropagation();
            } else {
                var tar = e.touches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
        },
        end = function(e) {
            var endTime = new Date();
            if(200 > (endTime - startTime)) {
                handler.call(null, e);
                if(once) {
                    ele.removeEventListener("touchstart", start, false);
                }
            }
            ele.removeEventListener("touchmove", move, false);
            ele.removeEventListener("touchend", end, false);
            if(e.changedTouches) {
                var tar = e.changedTouches[0].target;
                tar.className = tar.className.replace(" hover", "");
            }
            e.preventDefault();
            e.stopPropagation();
        };
        ele.addEventListener("touchstart", start, false);
    };
    
    //var $titleBar = $('#poiTitleBar');
    //$titleBar.on('click', '#webviewGoBack', function() {
    //    Bridge.send({
    //        "action": "webviewGoBack",
    //        "step": 1
    //    });
    //});
    click($("#webviewGoBack")[0], function() {
        Bridge.send({
            "action": "webviewGoBack",
            "step": 1
        });
    });
    
    
})(Zepto);