;(function(win, $, undefined) {
//var exPicList = {
//    showType : "detail",
//    needSwitch : false,
//    showMod : "1",//1:普通，2:美食，3:易车
//    startIndex : 9,
//    picList : [
//        {"url":"attach/5_1.png", "title":"外观0"    ,"desc":"外观"     ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5.png"  , "title":"标准大床1","desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"best"},
//        {"url":"",               "title":""        ,"desc":""         ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"new"},
//        {"url":"attach/5_5.png", "title":"错误图片3"                   ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5_2.png", "title":"外观4"    ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"best"},
//        {"url":"attach/5_3.png", "title":"标准大床5","desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5_4.png", "title":""        ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"new"},
//        {"url":"attach/5_5.png", "title":"错误图片7","desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"best"},
//        {"url":"attach/5_2.png", "title":"外观8"    ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5_3.png", "title":"标准大床9","desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"new"},
//        {"url":"attach/5_4.png", "title":"餐厅"    ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"best"},
//        {"url":"attach/5_5.png", "title":""        ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5_2.png", "title":"外观"    ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"new"},
//        {"url":"attach/5_3.png", "title":""        ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"best"},
//        {"url":"",               "title":"餐厅"    ,"desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"hot"},
//        {"url":"attach/5_4.png", "title":"错误图片","desc":"标准大床" ,"dtit":"哈哈哈哈哈哈哈哈", "price":"￥128/份" ,"grade":"new"}
//    ]
//}

//Array.prototype.push.apply(exPicList.picList, exPicList.picList);
//Array.prototype.push.apply(exPicList.picList, exPicList.picList);
//Array.prototype.push.apply(exPicList.picList, exPicList.picList);
//Array.prototype.push.apply(exPicList.picList, exPicList.picList);

var poiBridge = Bridge;

var picture = {
    
    isAndroid : /android/i.test(navigator.userAgent),
    
    listObj: null,
    
    positionTop : 0,
    
    listLoaded: false,
    
    detailLoaded: false
};

picture.util = {
    
    setTitleBar: function() {
        var titleBarBtns = document.getElementById("titleBarBtns");
        if(!titleBarBtns) return;
        titleBarBtns.innerHTML = '<a class="picBar_btn half-border canTouch">列表</a>';
        
        document.querySelector(".picBar_btn").addEventListener("click", function() {
            if("detail" === picture.listObj.showType && !picture.listLoaded) {
                picture.list.initList(picture.listObj.showMod, picture.listObj.picList);
            } else {
                picture.util.showPanel("list");
                $(win).scrollTop(picture.positionTop);
            }
            document.querySelector(".picBar_btn").style.visibility = "hidden";
        }, false);
    },
    
    regBackBtn: function(text) {
        text = text || "";
        var picBarBtn = document.querySelector(".picBar_btn");
        if(picBarBtn) {
            if(text) {
                picBarBtn.style.visibility = "visible";
            } else {
                picBarBtn.style.visibility = "hidden";
            }
        }
        poiBridge.send({
            "action": "registRightButton",
            "type": "jsCallBack",
            "buttonText": text,
            "function": {
                "action": "jsCallBack"
            }
        }, function(data) {
            if("detail" === picture.listObj.showType && !picture.listLoaded) {
                picture.list.initList(picture.listObj.showMod, picture.listObj.picList);
            } else {
                picture.util.showPanel("list");
                $(win).scrollTop(picture.positionTop);
            }
            picture.util.regBackBtn();
        });
    },
    
    showPanel: function(flag) {
        if("list" === flag) {
            $("body").css("background-color", "#e5e5e5");
            $("#ListPanel").show();
            $("#BigPicPanel").hide();
        } else if("detail" === flag) {
            $("body").css("background-color", "#000");
            $("#ListPanel").hide();
            $("#BigPicPanel").show();
        }
    },
    
    addImageType: function(url, num) {
        if(!url) return;
        if(-1 !== url.indexOf("?")) {
            return url.replace(/\?type=[0-9]$/, "?type=9");
        } else {
            return url + "?type=" + num;
        }
    },
    
    setTitle: function(flag) {
        if(2 == flag) {
            document.title = "全部图片";
            window.setPageTitle && window.setPageTitle("全部图片");
        } else {
            document.title = "图片列表";
            window.setPageTitle && window.setPageTitle("图片列表");
        }
    }

};

picture.list = {
    
    imgHeight : ($(win).width() / (screen.width < screen.height ? 2 : 3) - 4 - 8 - 8) * 3 / 4,
    
    count : 12,
    
    total : 0,
    
    sIndex : 0,
    
    createItem : function(item, idx) {
        var priceStr = "",
            gradeAttr = "";
        if(2 == picture.listObj.showMod) {
            item.price && (priceStr = "<cite>" + item.price + "</cite>");
            item.grade && (gradeAttr = ' grade="' + item.grade + '"');
        }
        return '<div idx="' + idx + '"' + gradeAttr + '>' +
                   '<a class="img_loading">' +
                       '<img data-src="' + (item.url ? item.url : "") + '" style="height:' + this.imgHeight + 'px;"/>' +
                       '<i>' + priceStr + '<span>' + item.title + '</span></i>' +
                   '</a>' +
               '</div>';
    },
    
    createList : function(listAry) {
        var htmlArray = [],
            len = (this.total - this.sIndex) > this.count ? this.count : this.total - this.sIndex;
        
        for(var i = this.sIndex, item = null; i < this.sIndex + len; i++) {
            item = listAry[i];
            htmlArray.push(this.createItem(item, i));
        }
        this.sIndex = i;
        
        return htmlArray.join("");
    },
    
    addList : function(listAry) {
        var nodeAry = $(this.createList(listAry)),
            imgAry = nodeAry.find("img");
        
        for(var i = 0, len = imgAry.length, item = null, datasrc=""; i < len; i++) {
            item = imgAry[i];
            datasrc = item.getAttribute("data-src");
            if(!!datasrc) {
                item.onload = this._onload;
                item.onerror = this._onerror;
                item.removeAttribute("data-src");
                item.src = picture.util.addImageType(datasrc, "9");
            } else {
                item.parentNode.className = "img_def";
            }
        }
        
        $("#Gallery").append(nodeAry);
        nodeAry = null;
        delete nodeAry;
        
        if(this.sIndex >= this.total) {
            $("#ListMore").hide();
            //$(win).off("scroll", picture.list._onscroll);
            picture.list.scrollDie = true;
        }
    },
    
    _onload : function(e) {
        if(this.hasAttribute("data-src")) return;
        this.onload = null;
        this.onerror = null;
        var divCon = $(this).closest("div");
        var gradeStr = divCon.attr("grade");
        if(gradeStr) {
            divCon.removeClass().addClass(gradeStr).removeAttr("grade");
        }
        $(this).css("visibility", "visible").next().css("visibility", "visible").parent().removeClass("img_loading");
    },
    
    _onerror : function(e) {
        if(this.hasAttribute("data-src")) return;
        this.onload = null;
        this.onerror = null;
        this.parentNode.className = "img_error";
    },
    
    scrollTimer : null,
    scrollDie : false,
    _onscroll : function() {
        clearTimeout(picture.list.scrollTimer);
        picture.list.scrollTimer = setTimeout(function() {
            var top = $(win).scrollTop();
            picture.positionTop = top;
            if(picture.list.scrollDie)return;
            if(50 > $(document).height() - top - $(win).height()) {
                picture.list.addList(picture.listObj.picList);
            }
        }, 100);
    },
    
    initList : function(mod, listAry) {
        
        mod = +mod || 1;
        picture.list.total = listAry.length;
        
        if(screen.width > screen.height) {
            $("#Gallery").addClass("horizontal");
        }
        
        if(2 === mod) {
            $("#Gallery").addClass("menu");
        }
        picture.list.addList(listAry);
        picture.util.showPanel("list");
        $("#ListPanel").off("click", "div").on("click", "div", function(e) {
            if(this.hasAttribute("idx")) {
                picture.positionTop = $(win).scrollTop();
                picture.bigPic.initBig(picture.listObj.picList, +$(this).attr("idx"));
                picture.listObj.needSwitch && picture.util.regBackBtn("列表");
                $(window).trigger('resize');
            }
        });
        
        $(win).on("scroll", this._onscroll);
        
        picture.listLoaded = true;
    }
    
};

/* ---------------------------------------------大图展示------------------------------------------------ */

picture.bigPic = {
    
    PRE_LOAD: 1,     // 预加载与当前图片距离小于等于此值的图片，为0时不预加载
    IMG_MARGIN: 5,   // 图片与窗口的距离
    picIndex: 0,     // 进入此页面点击图片的 index
    picAmount: 0,    // 图片总数
    imgMaxWidth: 0,  // 图片的最大宽度
    imgMaxHeight: 0, // 图片的最大高度
    contAspect: 1,   // 图片容器的高宽比
    descHeight: 63,  // 图片下方描述区域的高度
    slide: null,
    
    createItem : function(item) {
        var tit = "";
        if(3 == picture.listObj.showMod) {
            tit = ' tit="' + (item.title ? item.title : "") + '"';
        }
        return '<li' + tit + '>' +
                   '<figure><img data-src="' + (item.url ? item.url : "")  + '" pass="0"/></figure>' +
                   (item.desc ? '<article>' + item.desc + '</article>' : '') +
               '</li>';
    },
    
    createList : function(listAry) {
        var htmlArray = [];
        for(var i = 0, len = listAry.length, item = null; i < len; i++) {
            item = listAry[i];
            htmlArray.push(this.createItem(item));
        }
        return htmlArray.join("");
    },
    
    showList : function(listAry) {
        var contHeight = Math.max($(win).width(), $(win).height()) - $('#PageNum').height(),
            contWidth = Math.min($(win).width(), $(win).height());
        $("#Picture").height(contHeight).html(this.createList(listAry));
        this.imgsAry = $("#Picture img");
        this.picAmount = this.imgsAry.length;
        this.imgMaxHeight = contHeight - this.IMG_MARGIN * 2;
        this.imgMaxWidth = contWidth - this.IMG_MARGIN * 2;
    },
    
    callback : function(idx, item) {
        this.setPageInfo(idx);
        this.loadImages(idx);
        if(3 == picture.listObj.showMod) {
            this.setDetailTit(item.getAttribute("tit"));
        }
    },
    
    loadImages : function(idx) {
        idx && (this.picIndex = idx);
        this.loadSingleImage(this.picIndex);
        for(var i = 1, end = this.PRE_LOAD; i <= end; i++) {
            this.loadSingleImage(this.picIndex + i);
            this.loadSingleImage(this.picIndex - i);
        }
    },
    
    loadSingleImage : function(idx) {
        if(0 > idx || this.picAmount <= idx) return;
        
        var img = this.imgsAry[idx];
        if("0" !== img.getAttribute("pass")) {
            return;
        }
        
        //img.parentNode.className = 'animate';
        
        var dataSrc = img.getAttribute("data-src");
        if(!!dataSrc) {
            img.onload = this._onload;
            img.onerror = this._onerror;
            img.style.visibility = "hidden";
            img.removeAttribute("data-src");
            img.setAttribute("pass", "1");
            img.src = picture.util.addImageType(dataSrc, "10");
        } else {
            img.parentNode.className = "img_default";
        }
    },
    _onload : function() {
        this.onload = null;
        this.onerror = null;
        var $this = $(this);
        //$this.parent().parent().css('-webkit-animation-iteration-count','0').css('background', 'none');
    	//$this.parent().css('-webkit-animation-iteration-count','0').css('background','none').removeClass('animate');
        $this.parent().parent().css('background', 'none');
    	$this.parent().css('background','none');
        var	that = picture.bigPic,
            imgWidth = $this.width(),
            imgHeight = $this.height(),
            imgAspect = imgHeight / imgWidth;
        var realMaxHeight = that.imgMaxHeight - ($this.parents("li").find("article").length ? 63 : 0);
        // 图片比区域小并且比较宽
        if (that.contAspect >= imgAspect && imgWidth < that.imgMaxWidth) {
            $this.width(that.imgMaxWidth);
        // 图片比区域小并且比较高
        } else if (that.contAspect < imgAspect && imgHeight < realMaxHeight) {
            $this.height(realMaxHeight);
        } else {
            $this.css("max-height", realMaxHeight);
        }
        // 等待图片完全加载后再显示图片，防止用户看到图片拉伸过程
        // 要使用 visibility:hidden 隐藏，否则无法获取图片的实际高和宽 
        $this.css('visibility', 'visible');
    },
    
    _onerror : function() {
        this.onload = null;
        this.onerror = null;
        var pn = this.parentNode;
        pn.className = "img_error";
    },
    
    setPageInfo : function(idx) {
        $("#PageNum i").html(this.picAmount);
        $("#PageNum b").html(+idx + 1);
        var pre = $("#prevpic"),
            next = $("#nextpic");
        0 === idx ? pre.hide() : pre.show();
        this.picAmount - 1 === idx ? next.hide() : next.show();
    },
    
    setDetailTit: function(dtit) {
        $("#PageNum span").html(dtit ? dtit : "");
    },
    
    initBig : function (listAry, index) {
        if(!picture.detailLoaded) {
            
            this.picIndex = +index || 0;
            
            $("#PageNum").addClass(3 == picture.listObj.showMod ? "hastip" : "").css("visibility", "visible");
            
            picture.util.showPanel("detail");
            this.showList(listAry);
            this.slide = new PicSlide($("#PlaceHolder")[0], {
                startIndex : this.picIndex,
                isLoop : false,
                scrope : this,
                afterFun : this.callback
            });
            
            $("#prevpic")[0].onclick = function() {
                picture.bigPic.slide.prev();
            };
            $("#nextpic")[0].onclick = function() {
                picture.bigPic.slide.next();
            };
            picture.detailLoaded = true;
        } else {
            this.picIndex = index;
            this.slide.slideTo(this.picIndex);
            picture.util.showPanel("detail");
        }
        this.loadImages();
        this.setPageInfo(this.picIndex);
        if(3 == picture.listObj.showMod) {
            this.setDetailTit(picture.listObj.picList[this.picIndex].title);
        }
        
    }
};

$(function() {
    var _picListObj = win.localStorage.getItem("exPicList"),resize;
    if(_picListObj) {
        try {_picListObj = $.parseJSON(_picListObj);} catch(e) {return;}
    } else {
        return;
    }
    //_picListObj = exPicList;
    
    picture.util.setTitleBar();
    
    if(!("needSwitch" in _picListObj)) {
        _picListObj.needSwitch = true;
    }
    picture.listObj = _picListObj;
    
    picture.util.setTitle(_picListObj.showMod);
    
    if("list" === _picListObj.showType) {
        picture.list.initList(_picListObj.showMod, _picListObj.picList);
    } else {
        _picListObj.needSwitch && picture.util.regBackBtn("列表");
        picture.bigPic.initBig(_picListObj.picList, _picListObj.startIndex);
    }
    
    $(win).bind("resize", resize = function(e) {
        clearTimeout( win.orientationResizeTimeout );
        $(win).off("scroll", picture.list._onscroll);
        win.orientationResizeTimeout = setTimeout(function() {
            var height = $('#Gallery div').eq(0).height(),
                top = picture.positionTop,
                count = parseInt( top / height ) + ( top % height > height/2 ? 1 : 0);
            if(90 === Math.abs(window.orientation)) {
                //$("#Picture").css("height", Math.min($(win).width(), $(win).height()) - $('#PageNum').height());
                $("#Gallery").addClass("horizontal");
                count*=2;
            } else if(0 === Math.abs(window.orientation)) {
                $("#Picture").css("height", Math.max($(win).width(), $(win).height()) - $('#PageNum').height());
                $("#Gallery").removeClass("horizontal");
                count*=3;
            }
            $(win).bind("scroll", picture.list._onscroll);
            $(win).scrollTop( $('#Gallery div').eq(count).offset().top );
        }, 200);
    }).bind('orientationchange',resize);

});


})(window, $);
$(function() {
    $(window)
        .bind('touchstart mousedown', function(event) {
            //手指按下变色效果
            $(event.target).closest(".canTouch,.more,.more-bottom-blue").addClass('hover');
        }).bind('touchmove touchend mouseup', function() {
            // 取消手指按下样式
            $('.hover').removeClass('hover');
        });
});